# Full Upheaval backend parallel A/B

Status: passed

| Sample | Wall ms | CPU ms | Compile calls | Max backend overlap |
| --- | ---: | ---: | ---: | ---: |
| nocache-cold-1 | 52369.7 | 52265.6 | 3354 | off |
| nocache-cold-4 | 35259.7 | 60093.8 | 3354 | off |
| nocache-cold-auto | 34875.9 | 59875.0 | 3354 | off |
| defaults-cold-4 | 36954.3 | 61328.1 | 3354 | off |
| defaults-hot-4 | 2355.9 | 2203.1 | 0 | off |
| defaults-hot-repeat-4 | 2331.1 | 2265.6 | 0 | off |
| defaults-hot-diagnostic-4 | 2357.7 | 2343.8 | 0 | 0 |
| defaults-cold-1 | 55764.9 | 55343.8 | 3354 | off |
| defaults-hot-1 | 2346.6 | 2218.8 | 0 | off |
| defaults-hot-repeat-1 | 2337.3 | 2140.6 | 0 | off |
| defaults-hot-diagnostic-1 | 2328.3 | 2218.8 | 0 | 0 |
| defaults-cold-auto | 36795.0 | 61671.9 | 3354 | off |
| defaults-hot-auto | 2367.8 | 2250.0 | 0 | off |
| defaults-hot-repeat-auto | 2306.7 | 2187.5 | 0 | off |
| defaults-hot-diagnostic-auto | 2390.8 | 2234.4 | 0 | 0 |
| diagnostic-cold-1 | 52848.3 | 52812.5 | 3354 | 1 |
| diagnostic-cold-4 | 34876.3 | 59078.1 | 3354 | 4 |
| diagnostic-cold-auto | 34657.3 | 59031.2 | 3354 | 4 |
| modified-independent-control | 21103.4 | 20921.9 | 1 | off |
| defaults-modified-1 | 2555.9 | 2390.6 | 1 | off |
| defaults-modified-4 | 2528.6 | 2406.2 | 1 | off |
| defaults-modified-auto | 2566.3 | 2484.4 | 1 | off |

Off = throughput comparison. Detailed = diagnostic attribution; durations overlap and cannot be added.

