# Full Upheaval backend parallel A/B

Status: passed

| Sample | Wall ms | CPU ms | Compile calls | Max backend overlap |
| --- | ---: | ---: | ---: | ---: |
| nocache-cold-1 | 38893.6 | 38625.0 | 3354 | off |
| nocache-cold-4 | 30064.0 | 47500.0 | 3354 | off |
| nocache-cold-auto | 29929.1 | 47046.9 | 3354 | off |
| defaults-cold-4 | 31351.6 | 48531.2 | 3354 | off |
| defaults-hot-4 | 2296.6 | 2109.4 | 0 | off |
| defaults-hot-repeat-4 | 2254.6 | 2109.4 | 0 | off |
| defaults-hot-diagnostic-4 | 2259.0 | 2109.4 | 0 | 0 |
| defaults-cold-1 | 40736.7 | 40218.8 | 3354 | off |
| defaults-hot-1 | 2270.2 | 2125.0 | 0 | off |
| defaults-hot-repeat-1 | 2206.2 | 2093.8 | 0 | off |
| defaults-hot-diagnostic-1 | 2246.7 | 2093.8 | 0 | 0 |
| defaults-cold-auto | 33101.5 | 50750.0 | 3354 | off |
| defaults-hot-auto | 2272.6 | 2140.6 | 0 | off |
| defaults-hot-repeat-auto | 2201.0 | 2109.4 | 0 | off |
| defaults-hot-diagnostic-auto | 2208.7 | 2093.8 | 0 | 0 |
| diagnostic-cold-1 | 38885.2 | 38718.8 | 3354 | 1 |
| diagnostic-cold-4 | 30230.0 | 47375.0 | 3354 | 4 |
| diagnostic-cold-auto | 30270.7 | 47640.6 | 3354 | 4 |
| modified-independent-control | 19599.4 | 19234.4 | 1 | off |
| defaults-modified-1 | 2667.8 | 2515.6 | 1 | off |
| defaults-modified-4 | 2587.0 | 2406.2 | 1 | off |
| defaults-modified-auto | 2569.1 | 2468.8 | 1 | off |

Off = throughput comparison. Detailed = diagnostic attribution; durations overlap and cannot be added.

