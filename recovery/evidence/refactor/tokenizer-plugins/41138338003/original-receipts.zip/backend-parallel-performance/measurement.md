# Full Upheaval backend parallel A/B

Status: passed

| Sample | Wall ms | CPU ms | Compile calls | Max backend overlap |
| --- | ---: | ---: | ---: | ---: |
| nocache-cold-1 | 30870.0 | 30703.1 | 3354 | off |
| nocache-cold-4 | 20531.0 | 35875.0 | 3354 | off |
| nocache-cold-auto | 21071.3 | 36125.0 | 3354 | off |
| defaults-cold-4 | 21405.4 | 35828.1 | 3354 | off |
| defaults-hot-4 | 1551.1 | 1421.9 | 0 | off |
| defaults-hot-repeat-4 | 1624.7 | 1453.1 | 0 | off |
| defaults-hot-diagnostic-4 | 1421.7 | 1296.9 | 0 | 0 |
| defaults-cold-1 | 32038.7 | 31437.5 | 3354 | off |
| defaults-hot-1 | 1474.4 | 1343.8 | 0 | off |
| defaults-hot-repeat-1 | 1413.4 | 1234.4 | 0 | off |
| defaults-hot-diagnostic-1 | 1390.7 | 1265.6 | 0 | 0 |
| defaults-cold-auto | 21688.6 | 37171.9 | 3354 | off |
| defaults-hot-auto | 1364.3 | 1250.0 | 0 | off |
| defaults-hot-repeat-auto | 1431.5 | 1296.9 | 0 | off |
| defaults-hot-diagnostic-auto | 1467.1 | 1343.8 | 0 | 0 |
| diagnostic-cold-1 | 29873.8 | 29828.1 | 3354 | 1 |
| diagnostic-cold-4 | 20046.8 | 34453.1 | 3354 | 4 |
| diagnostic-cold-auto | 20409.2 | 34687.5 | 3354 | 4 |
| modified-independent-control | 12264.9 | 12000.0 | 1 | off |
| defaults-modified-1 | 1680.8 | 1453.1 | 1 | off |
| defaults-modified-4 | 1650.2 | 1546.9 | 1 | off |
| defaults-modified-auto | 1608.6 | 1437.5 | 1 | off |

Off = throughput comparison. Detailed = diagnostic attribution; durations overlap and cannot be added.

