# Full Upheaval backend parallel A/B

Status: passed

| Sample | Wall ms | CPU ms | Compile calls | Max backend overlap |
| --- | ---: | ---: | ---: | ---: |
| nocache-cold-1 | 53889.4 | 53734.4 | 3354 | off |
| nocache-cold-4 | 35886.8 | 60796.9 | 3354 | off |
| nocache-cold-auto | 35885.5 | 60468.8 | 3354 | off |
| defaults-cold-4 | 38379.4 | 63171.9 | 3354 | off |
| defaults-hot-4 | 3653.5 | 3203.1 | 0 | off |
| defaults-hot-repeat-4 | 3127.7 | 2906.2 | 0 | off |
| defaults-hot-diagnostic-4 | 2901.5 | 2859.4 | 0 | 0 |
| defaults-cold-1 | 56004.8 | 55578.1 | 3354 | off |
| defaults-hot-1 | 2963.7 | 2843.8 | 0 | off |
| defaults-hot-repeat-1 | 2907.3 | 2875.0 | 0 | off |
| defaults-hot-diagnostic-1 | 2792.3 | 2734.4 | 0 | 0 |
| defaults-cold-auto | 37690.5 | 62578.1 | 3354 | off |
| defaults-hot-auto | 2902.0 | 2796.9 | 0 | off |
| defaults-hot-repeat-auto | 2852.5 | 2765.6 | 0 | off |
| defaults-hot-diagnostic-auto | 2739.9 | 2671.9 | 0 | 0 |
| diagnostic-cold-1 | 53721.2 | 53609.4 | 3354 | 1 |
| diagnostic-cold-4 | 35962.7 | 61093.8 | 3354 | 4 |
| diagnostic-cold-auto | 36068.4 | 60312.5 | 3354 | 4 |
| modified-independent-control | 39014.6 | 38890.6 | 1292 | off |
| defaults-modified-1 | 3144.3 | 3078.1 | 1 | off |
| defaults-modified-4 | 3156.3 | 3093.8 | 1 | off |
| defaults-modified-auto | 3157.6 | 3078.1 | 1 | off |

Off = throughput comparison. Detailed = diagnostic attribution; durations overlap and cannot be added.

