# Full Upheaval backend parallel A/B

Status: passed

| Sample | Wall ms | CPU ms | Compile calls | Max backend overlap |
| --- | ---: | ---: | ---: | ---: |
| nocache-cold-1 | 49132.5 | 49515.6 | 3354 | off |
| nocache-cold-4 | 31864.6 | 56031.2 | 3354 | off |
| nocache-cold-auto | 31686.0 | 55718.8 | 3354 | off |
| defaults-cold-4 | 33312.3 | 58312.5 | 3354 | off |
| defaults-hot-4 | 1715.1 | 1703.1 | 0 | off |
| defaults-hot-repeat-4 | 1683.3 | 1687.5 | 0 | off |
| defaults-hot-diagnostic-4 | 1655.7 | 1609.4 | 0 | 0 |
| defaults-cold-1 | 50367.4 | 50296.9 | 3354 | off |
| defaults-hot-1 | 1653.4 | 1625.0 | 0 | off |
| defaults-hot-repeat-1 | 1650.3 | 1593.8 | 0 | off |
| defaults-hot-diagnostic-1 | 1669.6 | 1671.9 | 0 | 0 |
| defaults-cold-auto | 33357.2 | 57625.0 | 3354 | off |
| defaults-hot-auto | 1663.1 | 1656.2 | 0 | off |
| defaults-hot-repeat-auto | 1646.2 | 1656.2 | 0 | off |
| defaults-hot-diagnostic-auto | 1676.4 | 1640.6 | 0 | 0 |
| diagnostic-cold-1 | 49135.3 | 49359.4 | 3354 | 1 |
| diagnostic-cold-4 | 32528.9 | 57062.5 | 3354 | 4 |
| diagnostic-cold-auto | 32593.3 | 56562.5 | 3354 | 4 |
| modified-independent-control | 18753.7 | 18765.6 | 1 | off |
| defaults-modified-1 | 2049.8 | 2031.2 | 1 | off |
| defaults-modified-4 | 2109.7 | 2140.6 | 1 | off |
| defaults-modified-auto | 2087.6 | 2093.8 | 1 | off |

Off = throughput comparison. Detailed = diagnostic attribution; durations overlap and cannot be added.

