# Full Upheaval backend parallel A/B

Status: passed

| Sample | Wall ms | CPU ms | Compile calls | Max backend overlap |
| --- | ---: | ---: | ---: | ---: |
| nocache-cold-1 | 48780.9 | 48906.2 | 3354 | off |
| nocache-cold-4 | 31637.0 | 55421.9 | 3354 | off |
| nocache-cold-auto | 31917.0 | 55421.9 | 3354 | off |
| defaults-cold-4 | 32961.4 | 57421.9 | 3354 | off |
| defaults-hot-4 | 1663.6 | 1593.8 | 0 | off |
| defaults-hot-repeat-4 | 1653.6 | 1625.0 | 0 | off |
| defaults-hot-diagnostic-4 | 1635.9 | 1625.0 | 0 | 0 |
| defaults-cold-1 | 50839.9 | 50765.6 | 3354 | off |
| defaults-hot-1 | 1701.2 | 1687.5 | 0 | off |
| defaults-hot-repeat-1 | 1656.3 | 1625.0 | 0 | off |
| defaults-hot-diagnostic-1 | 1645.5 | 1578.1 | 0 | 0 |
| defaults-cold-auto | 33328.4 | 57406.2 | 3354 | off |
| defaults-hot-auto | 1702.8 | 1703.1 | 0 | off |
| defaults-hot-repeat-auto | 1678.3 | 1640.6 | 0 | off |
| defaults-hot-diagnostic-auto | 1692.0 | 1703.1 | 0 | 0 |
| diagnostic-cold-1 | 49595.8 | 49765.6 | 3354 | 1 |
| diagnostic-cold-4 | 32459.0 | 56234.4 | 3354 | 4 |
| diagnostic-cold-auto | 32217.3 | 56468.8 | 3354 | 4 |
| modified-independent-control | 18643.7 | 18703.1 | 1 | off |
| defaults-modified-1 | 2084.0 | 2015.6 | 1 | off |
| defaults-modified-4 | 2047.6 | 2046.9 | 1 | off |
| defaults-modified-auto | 2022.6 | 1984.4 | 1 | off |

Off = throughput comparison. Detailed = diagnostic attribution; durations overlap and cannot be added.

