# Full Upheaval backend parallel A/B

Status: passed

| Sample | Wall ms | CPU ms | Compile calls | Max backend overlap |
| --- | ---: | ---: | ---: | ---: |
| nocache-cold-1 | 50505.1 | 50546.9 | 3354 | off |
| nocache-cold-4 | 33177.3 | 56546.9 | 3354 | off |
| nocache-cold-auto | 33194.4 | 57093.8 | 3354 | off |
| defaults-cold-4 | 35009.6 | 59906.2 | 3354 | off |
| defaults-hot-4 | 1766.6 | 1718.8 | 0 | off |
| defaults-hot-repeat-4 | 1753.7 | 1734.4 | 0 | off |
| defaults-hot-diagnostic-4 | 1747.6 | 1734.4 | 0 | 0 |
| defaults-cold-1 | 52801.2 | 52687.5 | 3354 | off |
| defaults-hot-1 | 1766.1 | 1718.8 | 0 | off |
| defaults-hot-repeat-1 | 1748.0 | 1765.6 | 0 | off |
| defaults-hot-diagnostic-1 | 1746.5 | 1687.5 | 0 | 0 |
| defaults-cold-auto | 34401.9 | 59296.9 | 3354 | off |
| defaults-hot-auto | 1781.2 | 1765.6 | 0 | off |
| defaults-hot-repeat-auto | 1744.7 | 1687.5 | 0 | off |
| defaults-hot-diagnostic-auto | 1744.2 | 1734.4 | 0 | 0 |
| diagnostic-cold-1 | 50279.8 | 50281.2 | 3354 | 1 |
| diagnostic-cold-4 | 33603.7 | 57359.4 | 3354 | 4 |
| diagnostic-cold-auto | 33263.4 | 57187.5 | 3354 | 4 |
| modified-independent-control | 19819.6 | 19671.9 | 1 | off |
| defaults-modified-1 | 2031.2 | 2000.0 | 1 | off |
| defaults-modified-4 | 2049.5 | 2000.0 | 1 | off |
| defaults-modified-auto | 2025.9 | 2015.6 | 1 | off |

Off = throughput comparison. Detailed = diagnostic attribution; durations overlap and cannot be added.

