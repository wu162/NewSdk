Microsoft (R) COFF/PE Dumper Version 14.44.35229.0
Copyright (C) Microsoft Corporation.  All rights reserved.


Dump of file D:\a\NewSdk\NewSdk\SDK\tools\BinaryAssetBuilder.W3XCompiler.dll

File Type: DLL

  10001000: add         esi,dword ptr [eax]
  10001002: add         byte ptr [eax],al
  10001004: add         dword ptr [eax],eax
  10001006: add         byte ptr [eax],al
  10001008: add         byte ptr [eax],al
  1000100A: add         byte ptr [eax],al
  1000100C: sub         cl,ah
  1000100E: int         3
  1000100F: int         3
  10001010: add         esi,dword ptr [eax]
  10001012: add         eax,dword ptr [eax]
  10001014: sub         eax,9000000h
  10001019: add         byte ptr [eax],al
  1000101B: adc         dword ptr [edx],eax
  1000101D: inc         edi
  1000101E: sub         al,27h
  10001020: adc         al,byte ptr [eax]
  10001022: lidt        fword ptr [ecx]
  10001025: pop         eax
  10001026: inc         edi
  10001027: push        edx
  10001028: adc         al,byte ptr [eax]
  1000102A: pop         ss
  1000102B: pop         eax
  1000102C: lidt        fword ptr [eax]
  1000102F: pop         eax
  10001030: inc         edi
  10001031: push        edx
  10001032: adc         al,byte ptr [eax]
  10001034: sbb         byte ptr [eax+0Fh],bl
  10001037: add         dword ptr [edi],edx
  10001039: pop         eax
  1000103A: inc         edi
  1000103B: push        edx
  1000103C: adc         al,byte ptr [eax]
  1000103E: sbb         dword ptr [eax+0Fh],ebx
  10001041: add         dword ptr [edi+52h],eax
  10001044: push        es
  10001045: adc         byte ptr [ecx],al
  10001047: add         ebp,dword ptr [edx]
  10001049: int         3
  1000104A: int         3
  1000104B: int         3
  1000104C: add         esi,dword ptr [eax]
  1000104E: add         eax,dword ptr [eax]
  10001050: sbb         dword ptr [eax],eax
  10001052: add         byte ptr [eax],al
  10001054: pop         es
  10001055: add         byte ptr [eax],al
  10001057: adc         dword ptr [edx],eax
  10001059: inc         edi
  1000105A: sub         al,13h
  1000105C: adc         al,byte ptr [eax]
  1000105E: lgdt        fword ptr [edi]
  10001061: pop         eax
  10001062: inc         edi
  10001063: push        edx
  10001064: adc         al,byte ptr [eax]
  10001066: pop         ss
  10001067: pop         eax
  10001068: sgdt        fword ptr [edi+52h]
  1000106C: push        es
  1000106D: adc         byte ptr [ecx],al
  1000106F: add         ebp,dword ptr [edx]
  10001071: int         3
  10001072: int         3
  10001073: int         3
  10001074: add         esi,dword ptr [eax]
  10001076: add         eax,dword ptr [eax]
  10001078: add         byte ptr cs:[eax],al
  1000107B: add         byte ptr [ecx],cl
  1000107D: add         byte ptr [eax],al
  1000107F: adc         dword ptr [edx],eax
  10001081: inc         edi
  10001082: sub         al,28h
  10001084: adc         al,byte ptr [eax]
  10001086: lidt        fword ptr [ecx]
  10001089: pop         eax
  1000108A: inc         edi
  1000108B: push        edx
  1000108C: adc         al,byte ptr [eax]
  1000108E: pop         ss
  1000108F: pop         eax
  10001090: lidt        fword ptr [eax]
  10001093: pop         eax
  10001094: inc         edi
  10001095: push        edx
  10001096: adc         al,byte ptr [eax]
  10001098: sbb         byte ptr [eax+0Fh],bl
  1000109B: add         dword ptr [edi],edx
  1000109D: pop         eax
  1000109E: inc         edi
  1000109F: push        edx
  100010A0: adc         al,byte ptr [eax]
  100010A2: sbb         dword ptr [eax+0Fh],ebx
  100010A5: add         dword ptr [edi+52h],eax
  100010A8: sgdt        fword ptr [esi]
  100010AB: push        esp
  100010AC: add         ebp,dword ptr [edx]
  100010AE: int         3
  100010AF: int         3
  100010B0: add         esi,dword ptr [eax]
  100010B2: push        es
  100010B3: add         cl,cl
  100010B5: add         byte ptr [eax],al
  100010B7: add         byte ptr [eax],al
  100010B9: add         byte ptr [eax],al
  100010BB: add         byte ptr [edx],al
  100010BD: add         ebx,dword ptr [edx]
  100010BF: pop         eax
  100010C0: dec         esi
  100010C1: ins         byte ptr es:[edi],dx
  100010C2: add         al,1Eh
  100010C4: pop         eax
  100010C5: dec         esi
  100010C6: ins         byte ptr es:[edi],dx
  100010C7: pop         edx
  100010C8: add         ebx,dword ptr [esi]
  100010CA: pop         eax
  100010CB: dec         esi
  100010CC: ins         byte ptr es:[edi],dx
  100010CD: add         al,1Ah
  100010CF: pop         eax
  100010D0: dec         esi
  100010D1: ins         byte ptr es:[edi],dx
  100010D2: pop         edx
  100010D3: pop         ecx
  100010D4: add         ecx,dword ptr [esi+6Ch]
  100010D7: add         al,1Fh
  100010D9: or          al,58h
  100010DB: dec         esi
  100010DC: ins         byte ptr es:[edi],dx
  100010DD: pop         edx
  100010DE: add         al,4Eh
  100010E0: ins         byte ptr es:[edi],dx
  100010E1: add         ebx,dword ptr [edi]
  100010E3: or          al,58h
  100010E5: dec         esi
  100010E6: ins         byte ptr es:[edi],dx
  100010E7: pop         edx
  100010E8: pop         eax
  100010E9: pop         eax
  100010EA: imul        edx,dword ptr [esi+2],1Ah
  100010EE: pop         eax
  100010EF: add         al,1Ah
  100010F1: pop         eax
  100010F2: dec         esi
  100010F3: ins         byte ptr es:[edi],dx
  100010F4: add         ebx,dword ptr [edi]
  100010F6: or          al,58h
  100010F8: dec         esi
  100010F9: ins         byte ptr es:[edi],dx
  100010FA: pop         edx
  100010FB: add         ebx,dword ptr [edx]
  100010FD: pop         eax
  100010FE: dec         esi
  100010FF: ins         byte ptr es:[edi],dx
  10001100: add         al,1Fh
  10001102: or          al,58h
  10001104: dec         esi
  10001105: ins         byte ptr es:[edi],dx
  10001106: pop         edx
  10001107: pop         eax
  10001108: add         ecx,dword ptr [esi+6Ch]
  1000110B: add         al,1Eh
  1000110D: pop         eax
  1000110E: dec         esi
  1000110F: ins         byte ptr es:[edi],dx
  10001110: pop         edx
  10001111: add         ebx,dword ptr [esi]
  10001113: pop         eax
  10001114: dec         esi
  10001115: ins         byte ptr es:[edi],dx
  10001116: add         al,4Eh
  10001118: ins         byte ptr es:[edi],dx
  10001119: pop         edx
  1000111A: pop         ecx
  1000111B: pop         ecx
  1000111C: imul        edx,dword ptr [esi+2],1Eh
  10001120: pop         eax
  10001121: add         al,1Ah
  10001123: pop         eax
  10001124: dec         esi
  10001125: ins         byte ptr es:[edi],dx
  10001126: add         ecx,dword ptr [esi+6Ch]
  10001129: pop         edx
  1000112A: add         al,4Eh
  1000112C: ins         byte ptr es:[edi],dx
  1000112D: add         ebx,dword ptr [edx]
  1000112F: pop         eax
  10001130: dec         esi
  10001131: ins         byte ptr es:[edi],dx
  10001132: pop         edx
  10001133: pop         ecx
  10001134: add         ebx,dword ptr [esi]
  10001136: pop         eax
  10001137: dec         esi
  10001138: ins         byte ptr es:[edi],dx
  10001139: add         al,1Fh
  1000113B: or          al,58h
  1000113D: dec         esi
  1000113E: ins         byte ptr es:[edi],dx
  1000113F: pop         edx
  10001140: add         ebx,dword ptr [edi]
  10001142: or          al,58h
  10001144: dec         esi
  10001145: ins         byte ptr es:[edi],dx
  10001146: add         al,1Eh
  10001148: pop         eax
  10001149: dec         esi
  1000114A: ins         byte ptr es:[edi],dx
  1000114B: pop         edx
  1000114C: pop         eax
  1000114D: pop         eax
  1000114E: imul        edx,dword ptr [esi+2],1Fh
  10001152: or          al,58h
  10001154: add         ebx,dword ptr [edi]
  10001156: or          al,58h
  10001158: dec         esi
  10001159: ins         byte ptr es:[edi],dx
  1000115A: add         al,1Fh
  1000115C: or          al,58h
  1000115E: dec         esi
  1000115F: ins         byte ptr es:[edi],dx
  10001160: pop         edx
  10001161: add         ecx,dword ptr [esi+6Ch]
  10001164: add         al,4Eh
  10001166: ins         byte ptr es:[edi],dx
  10001167: pop         edx
  10001168: add         al,1Ah
  1000116A: pop         eax
  1000116B: dec         esi
  1000116C: ins         byte ptr es:[edi],dx
  1000116D: add         ebx,dword ptr [edx]
  1000116F: pop         eax
  10001170: dec         esi
  10001171: ins         byte ptr es:[edi],dx
  10001172: pop         edx
  10001173: pop         eax
  10001174: add         ebx,dword ptr [esi]
  10001176: pop         eax
  10001177: dec         esi
  10001178: ins         byte ptr es:[edi],dx
  10001179: add         al,1Eh
  1000117B: pop         eax
  1000117C: dec         esi
  1000117D: ins         byte ptr es:[edi],dx
  1000117E: pop         edx
  1000117F: pop         eax
  10001180: pop         ecx
  10001181: imul        edx,dword ptr [esi+2],2Ah
  10001185: int         3
  10001186: int         3
  10001187: int         3
  10001188: add         esi,dword ptr [eax]
  1000118A: add         eax,11600h
  1000118F: add         byte ptr [esi],cl
  10001191: add         byte ptr [eax],al
  10001193: adc         dword ptr [ebx],eax
  10001195: dec         esi
  10001196: ins         byte ptr es:[edi],dx
  10001197: add         al,4Eh
  10001199: ins         byte ptr es:[edi],dx
  1000119A: pop         edx
  1000119B: add         ebx,dword ptr [edx]
  1000119D: pop         eax
  1000119E: dec         esi
  1000119F: ins         byte ptr es:[edi],dx
  100011A0: add         al,1Ah
  100011A2: pop         eax
  100011A3: dec         esi
  100011A4: ins         byte ptr es:[edi],dx
  100011A5: pop         edx
  100011A6: pop         eax
  100011A7: add         ebx,dword ptr [esi]
  100011A9: pop         eax
  100011AA: dec         esi
  100011AB: ins         byte ptr es:[edi],dx
  100011AC: add         al,1Eh
  100011AE: pop         eax
  100011AF: dec         esi
  100011B0: ins         byte ptr es:[edi],dx
  100011B1: pop         edx
  100011B2: pop         eax
  100011B3: add         ebx,dword ptr [edi]
  100011B5: or          al,58h
  100011B7: dec         esi
  100011B8: ins         byte ptr es:[edi],dx
  100011B9: add         al,1Fh
  100011BB: or          al,58h
  100011BD: dec         esi
  100011BE: ins         byte ptr es:[edi],dx
  100011BF: pop         edx
  100011C0: pop         eax
  100011C1: imul        ecx,dword ptr [ebx],7
  100011C4: and         al,byte ptr [eax]
  100011C6: add         byte ptr [eax],al
  100011C8: add         byte ptr [edi+eax],dh
  100011CB: pop         es
  100011CC: imul        ecx,dword ptr gs:[ebx],17h
  100011D0: sub         eax,dword ptr [ecx]
  100011D2: push        ss
  100011D3: and         eax,dword ptr [eax]
  100011D5: add         byte ptr [eax],al
  100011D7: add         byte ptr [eax],al
  100011D9: add         al,dh
  100011DB: aas
  100011DC: pop         es
  100011DD: ins         byte ptr es:[edi],dx
  100011DE: pop         ecx
  100011DF: and         eax,dword ptr [eax]
  100011E1: add         byte ptr [eax],al
  100011E3: ror         byte ptr [esi+343E4579h],10h
  100011EA: and         eax,dword ptr [eax]
  100011EC: add         byte ptr [eax],al
  100011EE: add         byte ptr [eax],al
  100011F0: add         al,dh
  100011F2: aas
  100011F3: add         eax,0A6B596Ch
  100011F8: sub         edx,dword ptr [ebx+7]
  100011FB: ins         byte ptr es:[edi],dx
  100011FC: sub         byte ptr [eax],cl
  100011FE: add         byte ptr [eax],al
  10001200: or          ch,byte ptr [ebx+6Bh]
  10001203: adc         eax,dword ptr ds:[286C0511h]
  10001209: or          al,byte ptr [eax]
  1000120B: add         byte ptr [edx],cl
  1000120D: imul        ebp,dword ptr [ebx+13h],6
  10001211: and         eax,dword ptr [eax]
  10001213: add         byte ptr [eax],al
  10001215: add         byte ptr [eax],al
  10001217: add         al,dh
  10001219: aas
  1000121A: adc         dword ptr [esi],eax
  1000121C: ins         byte ptr es:[edi],dx
  1000121D: pop         ebx
  1000121E: imul        edx,dword ptr [ebx],4
  10001221: adc         dword ptr ds:[6C050D6Ch],eax
  10001227: or          dword ptr [edx+0Ch],ebx
  1000122A: or          dword ptr [eax],ecx
  1000122C: pop         ecx
  1000122D: imul        ebp,dword ptr [eax+ebp+0Ah],0
  10001232: add         byte ptr [edx],cl
  10001234: imul        ebp,dword ptr [ecx+edx+4],6Ch
  10001239: pop         edx
  1000123A: imul        ecx,dword ptr [edx],8
  1000123D: imul        ebp,dword ptr [eax+ebp+0Ah],0
  10001242: add         byte ptr [edx],cl
  10001244: imul        ebp,dword ptr [ecx+edx+4],6Ch
  10001249: pop         edx
  1000124A: imul        edx,dword ptr [eax],3
  1000124D: sub         al,5
  1000124F: add         eax,3106B65h
  10001254: add         al,byte ptr [ebx]
  10001256: dec         esi
  10001257: ins         byte ptr es:[edi],dx
  10001258: push        es
  10001259: ins         byte ptr es:[edi],dx
  1000125A: pop         edx
  1000125B: add         al,4Eh
  1000125D: ins         byte ptr es:[edi],dx
  1000125E: add         eax,6B585A6Ch
  10001263: push        esi
  10001264: add         bl,byte ptr [edx]
  10001266: pop         eax
  10001267: push        es
  10001268: ins         byte ptr es:[edi],dx
  10001269: add         ebx,dword ptr [edx]
  1000126B: pop         eax
  1000126C: dec         esi
  1000126D: ins         byte ptr es:[edi],dx
  1000126E: pop         edx
  1000126F: add         eax,581A046Ch
  10001274: dec         esi
  10001275: ins         byte ptr es:[edi],dx
  10001276: pop         edx
  10001277: pop         eax
  10001278: imul        edx,dword ptr [esi+2],1Eh
  1000127C: pop         eax
  1000127D: add         ebx,dword ptr [esi]
  1000127F: pop         eax
  10001280: dec         esi
  10001281: ins         byte ptr es:[edi],dx
  10001282: push        es
  10001283: ins         byte ptr es:[edi],dx
  10001284: pop         edx
  10001285: add         al,1Eh
  10001287: pop         eax
  10001288: dec         esi
  10001289: ins         byte ptr es:[edi],dx
  1000128A: add         eax,6B585A6Ch
  1000128F: push        esi
  10001290: add         bl,byte ptr [edi]
  10001292: or          al,58h
  10001294: add         ebx,dword ptr [edi]
  10001296: or          al,58h
  10001298: dec         esi
  10001299: ins         byte ptr es:[edi],dx
  1000129A: push        es
  1000129B: ins         byte ptr es:[edi],dx
  1000129C: pop         edx
  1000129D: add         al,1Fh
  1000129F: or          al,58h
  100012A1: dec         esi
  100012A2: ins         byte ptr es:[edi],dx
  100012A3: add         eax,6B585A6Ch
  100012A8: push        esi
  100012A9: sub         cl,ah
  100012AB: int         3
  100012AC: add         esi,dword ptr [eax]
  100012AE: add         al,0
  100012B0: pop         esp
  100012B1: add         byte ptr [eax],al
  100012B3: add         byte ptr [eax],dl
  100012B5: add         byte ptr [eax],al
  100012B7: adc         dword ptr [esi],edx
  100012B9: or          al,byte ptr [esi]
  100012BB: sbb         bl,byte ptr [edx+7Fh]
  100012BE: push        es
  100012BF: add         byte ptr [eax],al
  100012C1: add         al,1Fh
  100012C3: inc         eax
  100012C4: pop         eax
  100012C5: pop         eax
  100012C6: and         eax,dword ptr [eax]
  100012C8: add         byte ptr [eax],al
  100012CA: add         byte ptr [eax],al
  100012CC: add         al,dh
  100012CE: aas
  100012CF: push        es
  100012D0: imul        ebp,dword ptr [ebx],0
  100012D5: add         byte ptr [eax],al
  100012D7: add         byte ptr [eax],al
  100012D9: outs        dx,byte ptr [esi]
  100012DA: inc         eax
  100012DB: pop         ebx
  100012DC: imul        ebp,dword ptr [ebx],0
  100012E1: add         byte ptr [eax],al
  100012E3: add         byte ptr [eax+235A4056h],al
  100012E9: add         byte ptr [eax],al
  100012EB: add         byte ptr [eax-5],ah
  100012EE: and         dword ptr [ecx],ecx
  100012F0: inc         eax
  100012F1: pop         edx
  100012F2: and         eax,dword ptr [eax]
  100012F4: add         byte ptr [eax],al
  100012F6: add         byte ptr [eax],al
  100012F8: and         byte ptr [esi+40h],5Bh
  100012FC: sub         byte ptr [edx],cl
  100012FE: add         byte ptr [eax],al
  10001300: or          ch,byte ptr [ebx+6Ch]
  10001303: pop         ecx
  10001304: imul        edx,dword ptr [esi+6],17h
  10001308: pop         eax
  10001309: or          al,byte ptr [esi]
  1000130B: and         al,dh
  1000130D: add         byte ptr [eax],al
  1000130F: add         byte ptr [edx],dh
  10001311: test        al,17h
  10001313: sub         al,byte ptr [ebx]
  10001315: xor         byte ptr [ebx],al
  10001317: add         byte ptr ds:[15000001h],al
  1000131D: add         byte ptr [eax],al
  1000131F: adc         dword ptr [ebx],eax
  10001321: add         al,52h
  10001323: add         bl,byte ptr [edi]
  10001325: sbb         al,58h
  10001327: dec         edx
  10001328: sbb         ch,byte ptr [esi]
  1000132A: pop         es
  1000132B: and         byte ptr [eax+2B000000h],al
  10001331: add         dword ptr [esi],ebx
  10001333: adc         eax,dword ptr [eax+00220C4Eh]
  1000133A: add         byte ptr [eax],al
  1000133C: add         byte ptr [ebx],dl
  1000133E: add         eax,7F5A1A04h
  10001343: push        es
  10001344: add         byte ptr [eax],al
  10001346: add         al,58h
  10001348: dec         esi
  10001349: ins         byte ptr es:[edi],dx
  1000134A: push        cs
  1000134B: add         al,6Ch
  1000134D: pop         edx
  1000134E: imul        ecx,dword ptr ds:[80200411h],0
  10001355: add         byte ptr [eax],al
  10001357: xor         ecx,dword ptr [ecx]
  10001359: or          dword ptr [edx],esp
  1000135B: add         byte ptr [eax],al
  1000135D: cmp         byte ptr ds:[230D6B5Ah],0
  10001364: add         byte ptr [eax],al
  10001366: add         byte ptr [eax],al
  10001368: add         al,dh
  1000136A: aas
  1000136B: or          dword ptr [ebx+ebx*2+6Bh],ebp
  1000136F: adc         ecx,dword ptr [edx]
  10001371: pop         ss
  10001372: or          eax,dword ptr [edi]
  10001374: sbb         bl,byte ptr [edx+5]
  10001377: pop         eax
  10001378: dec         esi
  10001379: ins         byte ptr es:[edi],dx
  1000137A: or          byte ptr [ecx+ebx*2+6Bh],ch
  1000137E: ins         byte ptr es:[edi],dx
  1000137F: sub         byte ptr [edi],al
  10001381: add         byte ptr [eax],al
  10001383: or          ch,byte ptr [ebx+6Bh]
  10001386: adc         ecx,dword ptr [ecx]
  10001388: adc         dword ptr [ecx],ecx
  1000138A: ins         byte ptr es:[edi],dx
  1000138B: adc         dword ptr [edx],ecx
  1000138D: ins         byte ptr es:[edi],dx
  1000138E: pop         edx
  1000138F: and         eax,dword ptr [eax]
  10001391: add         byte ptr [eax],al
  10001393: add         byte ptr [eax],al
  10001395: add         al,ah
  10001397: aas
  10001398: pop         eax
  10001399: imul        ebp,dword ptr [eax+ebp+9],0
  1000139E: add         byte ptr [edx],cl
  100013A0: imul        ebp,dword ptr [ecx+ebp*2+0Ah],7
  100013A5: sbb         bl,byte ptr [edx+5]
  100013A8: pop         eax
  100013A9: dec         esi
  100013AA: ins         byte ptr es:[edi],dx
  100013AB: or          byte ptr [esp+esi+12h],ch
  100013AF: push        es
  100013B0: or          dl,byte ptr gs:[ecx]
  100013B3: add         al,65h
  100013B5: adc         ecx,dword ptr [eax]
  100013B7: push        es
  100013B8: adc         dword ptr [eax],ecx
  100013BA: das
  100013BB: movups      xmmword ptr [eax],xmm1
  100013BE: or          ch,byte ptr [ebx]
  100013C0: or          al,byte ptr [esi]
  100013C2: adc         dword ptr [edx+esi],eax
  100013C5: add         eax,59170411h
  100013CA: or          al,byte ptr [esi]
  100013CC: imul        ebp,dword ptr [ecx+ecx+6Ch],5Ah
  100013D1: or          byte ptr [eax+ebx*2+13h],ch
  100013D5: pop         es
  100013D6: adc         dword ptr [edi],eax
  100013D8: pop         es
  100013D9: sbb         bl,byte ptr [edx+5]
  100013DC: pop         eax
  100013DD: dec         esi
  100013DE: ins         byte ptr es:[edi],dx
  100013DF: pop         ecx
  100013E0: imul        ebp,dword ptr [eax+ebp+7],0
  100013E5: add         byte ptr [edx],cl
  100013E7: imul        ebp,dword ptr [ebx+13h],6
  100013EB: pop         es
  100013EC: add         ebx,dword ptr [eax+6]
  100013EF: push        edx
  100013F0: adc         dword ptr [edi],eax
  100013F2: imul        ecx,dword ptr [ecx+edx],6
  100013F6: ins         byte ptr es:[edi],dx
  100013F7: adc         dword ptr ds:[136B586Ch],eax
  100013FD: add         eax,0C2C060Eh
  10001402: adc         dword ptr [esi],eax
  10001404: ins         byte ptr es:[edi],dx
  10001405: push        cs
  10001406: pop         es
  10001407: ins         byte ptr es:[edi],dx
  10001408: add         al,0Eh
  1000140B: push        es
  1000140C: pop         ss
  1000140D: push        edx
  1000140E: pop         es
  1000140F: pop         ss
  10001410: pop         eax
  10001411: or          eax,dword ptr [edi]
  10001413: pop         ds
  10001414: adc         byte ptr [esi],bh
  10001416: pop         ecx
  10001417: FF
  10001418: FF
  10001419: dec         dword ptr [esi]
  1000141B: add         eax,50E042Ch
  10001420: or          byte ptr [esi+11h],dl
  10001423: add         eax,0CCCCCC2Ah
  10001428: add         esi,dword ptr [eax]
  1000142A: add         al,byte ptr [eax]
  1000142C: or          al,byte ptr [eax]
  1000142E: add         byte ptr [eax],al
  10001430: add         byte ptr [eax],al
  10001432: add         byte ptr [eax],al
  10001434: add         bl,byte ptr [edx]
  10001436: pop         eax
  10001437: dec         edx
  10001438: add         cl,byte ptr [edx+59h]
  1000143B: sbb         byte ptr [ebx+2Ah],ah
  1000143E: int         3
  1000143F: int         3
  10001440: add         esi,dword ptr [eax]
  10001442: add         dword ptr [eax],eax
  10001444: or          eax,9000000h
  10001449: add         byte ptr [eax],al
  1000144B: adc         dword ptr [edx],eax
  1000144D: dec         edx
  1000144E: or          al,byte ptr [esi]
  10001450: sub         al,6
  10001452: push        es
  10001453: sub         byte ptr [edi],bl
  10001455: add         dword ptr [eax],eax
  10001457: push        es
  10001458: sub         cl,ah
  1000145A: int         3
  1000145B: int         3
  1000145C: add         esi,dword ptr [eax]
  1000145E: add         al,0
  10001460: mov         edx,27000001h
  10001465: add         byte ptr [eax],al
  10001467: adc         dword ptr [edx],eax
  10001469: dec         edx
  1000146A: or          eax,dword ptr [edx]
  1000146C: sbb         bl,byte ptr [eax+4Ah]
  1000146F: pop         es
  10001470: pop         ecx
  10001471: pop         ds
  10001472: sbb         byte ptr [ebx+13h],bl
  10001475: or          dl,byte ptr [ecx]
  10001477: or          bl,byte ptr [eax]
  10001479: xor         al,2
  1000147B: adc         eax,180A112Ah
  10001480: inc         eax
  10001481: add         dword ptr [eax],0
  10001484: add         byte ptr [edi],al
  10001486: pop         ds
  10001487: sub         al,58h
  10001489: inc         edi
  1000148A: sub         al,2
  1000148C: adc         eax,22032Ah
  10001491: add         byte ptr [eax],al
  10001493: add         byte ptr [edi],dh
  10001495: jo          1000149E
  10001497: pop         ds
  10001498: sbb         byte ptr [eax+4Ah],bl
  1000149B: pop         es
  1000149C: dec         edx
  1000149D: pop         ecx
  1000149E: jbe         1000150B
  100014A0: ins         byte ptr es:[edi],dx
  100014A1: add         ebp,dword ptr [edx+ebx*2+6Bh]
  100014A5: adc         byte ptr [ecx],al
  100014A7: push        ss
  100014A8: adc         ecx,dword ptr [ecx]
  100014AA: pop         es
  100014AB: sbb         bl,byte ptr [eax+13h]
  100014AE: adc         al,11h
  100014B0: adc         al,13h
  100014B2: adc         edx,dword ptr [esi]
  100014B4: adc         dword ptr [ebx],edx
  100014B6: sbb         bl,byte ptr [eax+4Ah]
  100014B9: adc         dword ptr [ebx],edx
  100014BB: dec         edx
  100014BC: pop         ecx
  100014BD: sbb         byte ptr [ebx+34h],ah
  100014C0: inc         ebp
  100014C1: adc         dword ptr [ebx+edx],edx
  100014C4: adc         dl,byte ptr [ecx]
  100014C6: adc         bl,byte ptr [edx]
  100014C8: pop         eax
  100014C9: dec         edx
  100014CA: adc         dword ptr [edx],edx
  100014CC: dec         edx
  100014CD: pop         ecx
  100014CE: sbb         byte ptr [ebx+13h],ah
  100014D1: pop         ss
  100014D2: pop         es
  100014D3: pop         ds
  100014D4: sbb         al,58h
  100014D6: dec         edx
  100014D7: adc         ecx,dword ptr [eax]
  100014D9: adc         dword ptr [eax],ecx
  100014DB: dec         esi
  100014DC: ins         byte ptr es:[edi],dx
  100014DD: adc         edx,dword ptr [esi]
  100014DF: adc         dword ptr [esi],edx
  100014E1: and         eax,286C6B59h
  100014E6: pop         es
  100014E7: add         byte ptr [eax],al
  100014E9: or          ch,byte ptr [ebx+6Ch]
  100014EC: add         ebp,dword ptr [eax+esi+14h]
  100014F0: adc         dword ptr [ecx],ecx
  100014F2: pop         ss
  100014F3: pop         eax
  100014F4: adc         ecx,dword ptr [ecx]
  100014F6: adc         dword ptr [eax],ecx
  100014F8: sbb         bl,byte ptr [eax+13h]
  100014FB: or          byte ptr [ecx],dl
  100014FD: or          dword ptr [ecx],edx
  100014FF: pop         ss
  10001500: aaa
  10001501: xlat        byte ptr [ebx]
  10001502: sub         eax,dword ptr [edx]
  10001504: adc         eax,162A172Ah
  10001509: adc         eax,dword ptr [edi]
  1000150B: and         bh,bh
  1000150D: FF
  1000150E: jg          1000158F
  10001510: adc         edx,dword ptr [ecx]
  10001512: push        ss
  10001513: adc         eax,dword ptr [ecx+edx]
  10001516: or          bl,byte ptr [eax]
  10001518: pop         ecx
  10001519: adc         edx,dword ptr [eax]
  1000151B: push        ss
  1000151C: adc         dword ptr [eax],edx
  1000151E: inc         ecx
  1000151F: out         dx,al
  10001520: add         byte ptr [eax],al
  10001522: add         byte ptr [edi],al
  10001524: pop         ds
  10001525: inc         esp
  10001526: pop         eax
  10001527: or          al,byte ptr [edi]
  10001529: pop         ds
  1000152A: xor         al,58h
  1000152C: adc         eax,dword ptr ds:[59301F06h]
  10001532: inc         edi
  10001533: cmp         dh,byte ptr [edi+06000000h]
  10001539: inc         edi
  1000153A: cmp         dh,byte ptr [eax+06000000h]
  10001540: pop         ds
  10001541: inc         esp
  10001542: pop         ecx
  10001543: dec         edx
  10001544: adc         ecx,dword ptr [edi]
  10001546: push        es
  10001547: pop         ds
  10001548: sub         al,59h
  1000154A: dec         edx
  1000154B: adc         dword ptr [edi],ecx
  1000154D: pop         ecx
  1000154E: jbe         100015BB
  10001550: ins         byte ptr es:[edi],dx
  10001551: push        es
  10001552: pop         ds
  10001553: adc         al,59h
  10001555: dec         edx
  10001556: adc         dword ptr [edi],ecx
  10001558: pop         ecx
  10001559: jbe         100015C6
  1000155B: ins         byte ptr es:[edi],dx
  1000155C: pop         ebx
  1000155D: imul        edx,dword ptr [ebx],15h
  10001560: and         al,byte ptr [eax]
  10001562: add         byte ptr [eax],al
  10001564: add         byte ptr ds:[16061316h],cl
  1000156A: adc         dword ptr ds:[4A592C1Fh],eax
  10001570: push        es
  10001571: pop         ds
  10001572: inc         eax
  10001573: pop         ecx
  10001574: dec         edx
  10001575: pop         ecx
  10001576: sbb         byte ptr [ebx+34h],ah
  10001579: pop         edi
  1000157A: adc         dword ptr ds:[110E134Ah],eax
  10001580: push        cs
  10001581: or          al,6
  10001583: pop         ds
  10001584: inc         eax
  10001585: pop         ecx
  10001586: dec         edx
  10001587: adc         dword ptr [esi],ecx
  10001589: pop         ecx
  1000158A: adc         ecx,dword ptr ds:[116C4E08h]
  10001590: or          eax,6C4E5808h
  10001595: pop         ecx
  10001596: adc         dword ptr ds:[0D115A6Ch],edx
  1000159C: or          byte ptr [eax+4Eh],bl
  1000159F: ins         byte ptr es:[edi],dx
  100015A0: pop         eax
  100015A1: or          byte ptr [esi+6Ch],cl
  100015A4: pop         ecx
  100015A5: imul        ebp,dword ptr [eax+ebp+7],0
  100015AA: add         byte ptr [edx],cl
  100015AC: imul        ebp,dword ptr [ebx+13h],0Ch
  100015B0: adc         dword ptr [esp+ebp*2],ecx
  100015B3: or          dword ptr [esi+esi+3],ebp
  100015B7: adc         dword ptr [ecx+58170611h],ecx
  100015BE: adc         eax,dword ptr [esi]
  100015C0: or          byte ptr [edx],bl
  100015C2: pop         eax
  100015C3: or          al,6
  100015C5: pop         ds
  100015C6: inc         eax
  100015C7: pop         ecx
  100015C8: adc         ecx,dword ptr [ebx]
  100015CA: adc         dword ptr [esi],eax
  100015CC: adc         dword ptr [ebx],ecx
  100015CE: sbb         bl,byte ptr [eax+4Ah]
  100015D1: adc         dword ptr [ebx],ecx
  100015D3: dec         edx
  100015D4: pop         ecx
  100015D5: sbb         byte ptr [ebx+37h],ah
  100015D8: mov         bl,9
  100015DA: ins         byte ptr es:[edi],dx
  100015DB: add         ebp,dword ptr [edx+esi+2Dh]
  100015DF: or          dword ptr [ecx+edx+11h],ebp
  100015E3: ins         byte ptr es:[edi],dx
  100015E4: xor         al,9
  100015E6: adc         dword ptr [edi+edx],eax
  100015E9: pop         eax
  100015EA: adc         eax,dword ptr [edi]
  100015EC: or          dword ptr [ebx],edx
  100015EE: adc         dword ptr [ecx],edx
  100015F0: add         al,17h
  100015F2: pop         eax
  100015F3: adc         eax,dword ptr [ecx+edx]
  100015F6: add         eax,1358181Fh
  100015FB: add         eax,58181F06h
  10001600: or          dl,byte ptr [ecx]
  10001602: add         al,11h
  10001604: adc         byte ptr [esp-1],al
  10001608: FF
  10001609: jmp         fword ptr [ebx]
  1000160B: add         eax,58170411h
  10001610: sub         al,byte ptr [ebx]
  10001612: and         al,byte ptr [eax]
  10001614: add         byte ptr [eax],al
  10001616: add         byte ptr [edi+eax],dh
  10001619: adc         dword ptr [edi],eax
  1000161B: sub         al,3
  1000161D: adc         dword ptr [edi],eax
  1000161F: sub         dl,byte ptr ds:[03CCCC2Ah]
  10001625: xor         byte ptr [esi],al
  10001627: add         byte ptr [ebp+29000002h],dh
  1000162D: add         byte ptr [eax],al
  1000162F: adc         dword ptr [edx],eax
  10001631: dec         edx
  10001632: or          al,2
  10001634: sbb         bl,byte ptr [eax+4Ah]
  10001637: or          byte ptr [ecx+1Fh],bl
  1000163A: sbb         byte ptr [ebx+13h],bl
  1000163D: or          byte ptr [ecx],dl
  1000163F: or          byte ptr [eax],bl
  10001641: xor         al,2
  10001643: adc         eax,1808112Ah
  10001648: inc         eax
  10001649: lock add    byte ptr [eax],al
  1000164C: add         byte ptr [eax],cl
  1000164E: pop         ds
  1000164F: sub         al,58h
  10001651: inc         edi
  10001652: sub         al,2
  10001654: adc         eax,22032Ah
  10001659: add         byte ptr [eax],al
  1000165B: add         byte ptr [edx+ebx*8],al
  1000165F: add         byte ptr [eax],al
  10001661: or          byte ptr [edx],bl
  10001663: pop         eax
  10001664: dec         edx
  10001665: adc         eax,dword ptr [edi]
  10001667: adc         dword ptr [edi],eax
  10001669: dec         esi
  1000166A: adc         ebp,dword ptr [ecx+edx]
  1000166D: pop         es
  1000166E: sbb         bl,byte ptr [eax+4Eh]
  10001671: adc         ebp,dword ptr [ebx]
  10001673: adc         dword ptr [edi],eax
  10001675: push        ds
  10001676: pop         eax
  10001677: dec         esi
  10001678: adc         ebp,dword ptr [edx]
  1000167A: adc         dword ptr [edi],eax
  1000167C: pop         ds
  1000167D: or          al,58h
  1000167F: dec         esi
  10001680: adc         ebp,dword ptr [ecx]
  10001682: or          byte ptr [edi],bl
  10001684: sbb         al,58h
  10001686: dec         edx
  10001687: adc         eax,dword ptr [esi]
  10001689: adc         dword ptr [esi],eax
  1000168B: dec         esi
  1000168C: adc         ebp,dword ptr [eax]
  1000168E: adc         dword ptr [esi],eax
  10001690: sbb         bl,byte ptr [eax+4Eh]
  10001693: adc         esp,dword ptr [edi]
  10001695: adc         dword ptr [esi],eax
  10001697: push        ds
  10001698: pop         eax
  10001699: dec         esi
  1000169A: adc         esp,dword ptr [esi]
  1000169C: adc         dword ptr [esi],eax
  1000169E: pop         ds
  1000169F: or          al,58h
  100016A1: dec         esi
  100016A2: adc         esp,dword ptr ds:[28113612h]
  100016A8: push        esi
  100016A9: adc         dh,byte ptr [esi]
  100016AB: sbb         bl,byte ptr [eax+11h]
  100016AE: daa
  100016AF: push        esi
  100016B0: adc         dh,byte ptr [esi]
  100016B2: push        ds
  100016B3: pop         eax
  100016B4: adc         dword ptr [esi],esp
  100016B6: push        esi
  100016B7: adc         dh,byte ptr [esi]
  100016B9: pop         ds
  100016BA: or          al,58h
  100016BC: adc         dword ptr ds:[652C1156h],esp
  100016C2: imul        edx,dword ptr [ebx],24h
  100016C5: adc         dword ptr [ebx],ebp
  100016C7: imul        edx,dword ptr gs:[ebx],23h
  100016CB: adc         dword ptr [edx],ebp
  100016CD: imul        edx,dword ptr gs:[ebx],22h
  100016D1: adc         dh,byte ptr ds:[12562411h]
  100016D7: xor         eax,2311581Ah
  100016DC: push        esi
  100016DD: adc         dh,byte ptr ds:[2211581Eh]
  100016E3: push        esi
  100016E4: adc         dh,byte ptr ds:[11580C1Fh]
  100016EA: sub         dword ptr [esi+12h],edx
  100016ED: xor         al,12h
  100016EF: xor         eax,8283612h
  100016F4: add         byte ptr [eax],al
  100016F6: push        es
  100016F7: adc         esp,dword ptr [ecx]
  100016F9: adc         dh,byte ptr [ebx]
  100016FB: pop         ds
  100016FC: or          al,58h
  100016FE: adc         dword ptr [ecx],esp
  10001700: pop         ds
  10001701: or          al,58h
  10001703: dec         esi
  10001704: push        esi
  10001705: adc         dh,byte ptr [ebx]
  10001707: pop         ds
  10001708: or          al,58h
  1000170A: dec         esi
  1000170B: ins         byte ptr es:[edi],dx
  1000170C: sub         byte ptr [edi],al
  1000170E: add         byte ptr [eax],al
  10001710: or          ch,byte ptr [ebx+13h]
  10001713: push        cs
  10001714: adc         dword ptr [esi],ecx
  10001716: and         al,byte ptr [eax]
  10001718: add         byte ptr [eax+111E343Fh],al
  1000171E: push        cs
  1000171F: adc         esp,dword ptr [eax]
  10001721: adc         dword ptr [eax],esp
  10001723: ins         byte ptr es:[edi],dx
  10001724: sub         byte ptr [eax],cl
  10001726: add         byte ptr [eax],al
  10001728: or          ch,byte ptr [ebx+6Ch]
  1000172B: and         eax,dword ptr [eax]
  1000172D: add         byte ptr [eax],al
  1000172F: add         byte ptr [eax],al
  10001731: add         byte ptr [eax],al
  10001733: inc         eax
  10001734: pop         edx
  10001735: add         ebp,dword ptr [esi+esi+2]
  10001739: adc         eax,162A172Ah
  1000173E: adc         ecx,dword ptr [edx]
  10001740: and         bh,bh
  10001742: FF
  10001743: jg          100017C4
  10001745: adc         ecx,dword ptr ds:[11160B16h]
  1000174B: or          byte ptr [eax],bl
  1000174D: pop         ecx
  1000174E: inc         ecx
  1000174F: add         dword ptr [ecx],1A080000h
  10001755: pop         eax
  10001756: or          al,byte ptr [esi]
  10001758: pop         ds
  10001759: inc         eax
  1000175A: pop         eax
  1000175B: pop         ds
  1000175C: xor         byte ptr [ecx+47h],bl
  1000175F: cmp         dl,byte ptr [ebx+1]
  10001762: add         byte ptr [eax],al
  10001764: push        es
  10001765: pop         ds
  10001766: inc         eax
  10001767: pop         eax
  10001768: inc         edi
  10001769: cmp         cl,byte ptr [ecx+1]
  1000176C: add         byte ptr [eax],al
  1000176E: push        es
  1000176F: dec         edx
  10001770: adc         eax,dword ptr ds:[134E0511h]
  10001776: pop         ds
  10001777: adc         dword ptr ds:[134E581Ah],eax
  1000177D: push        ds
  1000177E: adc         dword ptr ds:[134E581Eh],eax
  10001784: sbb         eax,0C1F0511h
  10001789: pop         eax
  1000178A: dec         esi
  1000178B: adc         ebx,dword ptr [edx+edx]
  1000178E: xor         dl,byte ptr [ecx]
  10001790: pop         ds
  10001791: push        esi
  10001792: adc         dh,byte ptr [edx]
  10001794: sbb         bl,byte ptr [eax+11h]
  10001797: push        ds
  10001798: push        esi
  10001799: adc         dh,byte ptr [edx]
  1000179B: push        ds
  1000179C: pop         eax
  1000179D: adc         dword ptr ds:[1F321256h],ebx
  100017A3: or          al,58h
  100017A5: adc         dword ptr [esi+edx*2],ebx
  100017A8: push        es
  100017A9: pop         ds
  100017AA: sbb         byte ptr [eax+4Ah],bl
  100017AD: adc         eax,dword ptr [ecx+edx]
  100017B0: add         al,4Eh
  100017B2: adc         ebx,dword ptr [ebx]
  100017B4: adc         dword ptr [edx+ebx],eax
  100017B7: pop         eax
  100017B8: dec         esi
  100017B9: adc         ebx,dword ptr [edx]
  100017BB: adc         dword ptr [esi+ebx],eax
  100017BE: pop         eax
  100017BF: dec         esi
  100017C0: adc         ebx,dword ptr [ecx]
  100017C2: adc         dword ptr [edi+ebx],eax
  100017C5: or          al,58h
  100017C7: dec         esi
  100017C8: adc         ebx,dword ptr [eax]
  100017CA: push        es
  100017CB: pop         ds
  100017CC: xor         byte ptr [eax+4Ah],bl
  100017CF: or          eax,17134E09h
  100017D4: or          dword ptr [edx],ebx
  100017D6: pop         eax
  100017D7: dec         esi
  100017D8: adc         edx,dword ptr [esi]
  100017DA: or          dword ptr [esi],ebx
  100017DC: pop         eax
  100017DD: dec         esi
  100017DE: adc         edx,dword ptr ds:[580C1F09h]
  100017E4: dec         esi
  100017E5: adc         edx,dword ptr [edx+edx]
  100017E8: xor         dword ptr [ecx],edx
  100017EA: pop         ss
  100017EB: push        esi
  100017EC: adc         dh,byte ptr [ecx]
  100017EE: sbb         bl,byte ptr [eax+11h]
  100017F1: push        ss
  100017F2: push        esi
  100017F3: adc         dh,byte ptr [ecx]
  100017F5: push        ds
  100017F6: pop         eax
  100017F7: adc         dword ptr ds:[1F311256h],edx
  100017FD: or          al,58h
  100017FF: adc         dword ptr [esi+edx*2],edx
  10001802: push        es
  10001803: sbb         bl,byte ptr [ecx+4Ah]
  10001806: adc         ecx,dword ptr [edx+edx]
  10001809: xor         byte ptr [edx],dl
  1000180B: xor         dl,byte ptr [edx]
  1000180D: xor         dword ptr [esi],eax
  1000180F: pop         ds
  10001810: adc         al,58h
  10001812: dec         edx
  10001813: adc         dword ptr [ecx+ebx*2],ecx
  10001816: jbe         10001883
  10001818: ins         byte ptr es:[edi],dx
  10001819: push        es
  1000181A: pop         ds
  1000181B: sub         al,58h
  1000181D: dec         edx
  1000181E: adc         dword ptr [ecx+ebx*2],ecx
  10001821: jbe         1000188E
  10001823: ins         byte ptr es:[edi],dx
  10001824: pop         ebx
  10001825: imul        ebp,dword ptr [eax],9
  10001828: add         byte ptr [eax],al
  1000182A: push        es
  1000182B: adc         dword ptr [ebx],ebx
  1000182D: imul        edx,dword ptr gs:[ebx],13h
  10001831: adc         dword ptr [edx],ebx
  10001833: imul        edx,dword ptr gs:[ebx],12h
  10001837: adc         dword ptr [ecx],ebx
  10001839: imul        edx,dword ptr gs:[ebx],11h
  1000183D: adc         ch,byte ptr [edi]
  1000183F: adc         dword ptr [ebx],edx
  10001841: push        esi
  10001842: adc         ch,byte ptr [edi]
  10001844: sbb         bl,byte ptr [eax+11h]
  10001847: adc         dl,byte ptr [esi+12h]
  1000184A: das
  1000184B: push        ds
  1000184C: pop         eax
  1000184D: adc         dword ptr [ecx],edx
  1000184F: push        esi
  10001850: adc         ch,byte ptr [edi]
  10001852: pop         ds
  10001853: or          al,58h
  10001855: adc         dword ptr [eax],ebx
  10001857: push        esi
  10001858: adc         ch,byte ptr [esi]
  1000185A: adc         ch,byte ptr [edi]
  1000185C: adc         dh,byte ptr [eax]
  1000185E: sub         byte ptr [eax],cl
  10001860: add         byte ptr [eax],al
  10001862: push        es
  10001863: adc         edx,dword ptr [eax]
  10001865: adc         ch,byte ptr ds:[11580C1Fh]
  1000186B: adc         byte ptr [edi],bl
  1000186D: or          al,58h
  1000186F: dec         esi
  10001870: push        esi
  10001871: adc         ch,byte ptr ds:[4E580C1Fh]
  10001877: ins         byte ptr es:[edi],dx
  10001878: sub         byte ptr [edi],al
  1000187A: add         byte ptr [eax],al
  1000187C: or          ch,byte ptr [ebx+13h]
  1000187F: or          edx,dword ptr [ecx]
  10001881: or          esp,dword ptr [edx]
  10001883: add         byte ptr [eax],al
  10001885: cmp         byte ptr [edi],2Fh
  10001888: inc         ebx
  10001889: adc         dword ptr [ebx],ecx
  1000188B: adc         ecx,dword ptr [edi]
  1000188D: adc         dword ptr [edi],ecx
  1000188F: ins         byte ptr es:[edi],dx
  10001890: sub         byte ptr [eax],cl
  10001892: add         byte ptr [eax],al
  10001894: or          ch,byte ptr [ebx+22h]
  10001897: add         byte ptr [eax],al
  10001899: add         byte ptr [eax+5Ah],al
  1000189C: imul        edx,dword ptr [ebx],9
  1000189F: adc         dword ptr [ecx],ecx
  100018A1: ins         byte ptr es:[edi],dx
  100018A2: add         ebp,dword ptr [ecx+esi+2Ah]
  100018A6: adc         dword ptr [ecx],ecx
  100018A8: ins         byte ptr es:[edi],dx
  100018A9: adc         dword ptr ds:[0709346Ch],ecx
  100018AF: pop         ss
  100018B0: pop         eax
  100018B1: adc         ecx,dword ptr [edx]
  100018B3: adc         dword ptr [ecx],ecx
  100018B5: adc         ecx,dword ptr ds:[0B581707h]
  100018BB: push        es
  100018BC: pop         ds
  100018BD: sbb         byte ptr [eax+0Ah],bl
  100018C0: pop         es
  100018C1: adc         dword ptr [eax],ecx
  100018C3: sbb         byte ptr [ecx+44h],bl
  100018C6: 8D
  100018C7: FE
  100018C8: FF
  100018C9: jmp         fword ptr [ebx]
  100018CB: or          byte ptr [edi],al
  100018CD: pop         ss
  100018CE: pop         eax
  100018CF: sub         al,byte ptr [edi]
  100018D1: pop         ss
  100018D2: pop         eax
  100018D3: sub         al,byte ptr [ebx]
  100018D5: and         al,byte ptr [eax]
  100018D7: add         byte ptr [eax],al
  100018D9: add         byte ptr [edi+eax],dh
  100018DC: adc         dword ptr [edx],ecx
  100018DE: sub         al,3
  100018E0: adc         dword ptr [edx],ecx
  100018E2: sub         dl,byte ptr ds:[CCCCCC2Ah]
  100018E8: add         esi,dword ptr [eax]
  100018EA: add         eax,dword ptr [eax]
  100018EC: xor         eax,dword ptr [eax]
  100018EE: add         byte ptr [eax],al
  100018F0: sub         eax,dword ptr [eax]
  100018F2: add         byte ptr [ecx],dl
  100018F4: add         bl,byte ptr [esi]
  100018F6: pop         eax
  100018F7: or          al,byte ptr [esi]
  100018F9: or          eax,1A094A09h
  100018FE: pop         eax
  100018FF: dec         edx
  10001900: inc         byte ptr [ecx]
  10001902: shr         byte ptr [edx+eax],cl
  10001905: push        ss
  10001906: sub         al,byte ptr [esi]
  10001908: or          al,6
  1000190A: dec         edx
  1000190B: sbb         bl,byte ptr [eax+0Bh]
  1000190E: pop         es
  1000190F: sbb         bl,byte ptr [eax+4Ah]
  10001912: pop         es
  10001913: dec         edx
  10001914: pop         ecx
  10001915: sbb         byte ptr [ebx+1Ah],ah
  10001918: pop         edx
  10001919: sbb         byte ptr [eax+8],bl
  1000191C: sbb         bl,byte ptr [eax+4Ah]
  1000191F: or          byte ptr [edx+59h],cl
  10001922: pop         ds
  10001923: sbb         byte ptr [ebx+5Ah],bl
  10001926: sub         cl,ah
  10001928: add         esi,dword ptr [eax]
  1000192A: add         eax,3A00h
  1000192F: add         byte ptr ds:[02110000h],ch
  10001935: pop         ds
  10001936: or          al,58h
  10001938: or          al,8
  1000193A: or          ecx,dword ptr [eax]
  1000193C: or          al,byte ptr [esi]
  1000193E: sbb         bl,byte ptr [eax+4Ah]
  10001941: push        es
  10001942: dec         edx
  10001943: pop         ecx
  10001944: sbb         byte ptr [ebx+1Ah],ah
  10001947: pop         edx
  10001948: pop         es
  10001949: sbb         bl,byte ptr [eax+4Ah]
  1000194C: pop         es
  1000194D: dec         edx
  1000194E: pop         ecx
  1000194F: sbb         byte ptr [ebx+2],ah
  10001952: pop         ds
  10001953: sbb         al,58h
  10001955: dec         edx
  10001956: pop         edx
  10001957: sbb         eax,2641958h
  1000195C: pop         ds
  1000195D: and         byte ptr [eax+1Ah],bl
  10001960: pop         eax
  10001961: dec         edx
  10001962: add         bl,byte ptr [edi]
  10001964: and         byte ptr [eax+4Ah],bl
  10001967: pop         ecx
  10001968: pop         ds
  10001969: adc         dword ptr [ebx+5Ah],ebx
  1000196C: pop         eax
  1000196D: sub         cl,ah
  1000196F: int         3
  10001970: add         esi,dword ptr [eax]
  10001972: add         al,byte ptr [eax]
  10001974: adc         dword ptr [eax],eax
  10001976: add         byte ptr [eax],al
  10001978: xor         byte ptr [eax],al
  1000197A: add         byte ptr [ecx],dl
  1000197C: add         bl,byte ptr [edx]
  1000197E: pop         eax
  1000197F: or          eax,dword ptr [edi]
  10001981: dec         edx
  10001982: or          al,byte ptr [esi]
  10001984: sub         al,6
  10001986: push        es
  10001987: sub         byte ptr [edi],bl
  10001989: add         dword ptr [eax],eax
  1000198B: push        es
  1000198C: sub         al,byte ptr [eax]
  1000198E: add         byte ptr [eax],al
  10001990: add         byte ptr [eax],al
  10001992: add         byte ptr [eax],al
  10001994: or          esi,dword ptr [eax]
  10001996: add         eax,dword ptr [eax]
  10001998: inc         esi
  10001999: add         byte ptr [eax],al
  1000199B: add         byte ptr [ebx],dh
  1000199D: add         byte ptr [eax],al
  1000199F: adc         dword ptr [edx],eax
  100019A1: lsl         ebx,word ptr [edx]
  100019A4: FE
  100019A5: pop         ss
  100019A6: sidt        fword ptr [edx+0Fh]
  100019AA: add         cl,byte ptr [edx+33h]
  100019AD: add         edx,dword ptr [esi]
  100019AF: sub         eax,dword ptr [ecx]
  100019B1: pop         ss
  100019B2: shr         byte ptr [edi+ebp],cl
  100019B5: add         cl,byte ptr [edx+0Bh]
  100019B8: pop         es
  100019B9: or          al,byte ptr [esi]
  100019BB: or          al,6
  100019BD: sub         eax,612DE02h
  100019C2: sidt        fword ptr [edx+1Fh]
  100019C6: or          al,0FEh
  100019C8: pop         ss
  100019C9: fimul       word ptr [eax]
  100019CB: or          byte ptr [esi],al
  100019CD: sub         byte ptr [ecx],al
  100019CF: add         byte ptr [eax],al
  100019D1: push        es
  100019D2: fmul        qword ptr [edi]
  100019D4: add         dword ptr [edi],ecx
  100019D6: add         dword ptr [edx+1Fh],ecx
  100019D9: or          al,58h
  100019DB: push        esp
  100019DC: add         al,byte ptr [edi]
  100019DE: pop         ds
  100019DF: or          al,58h
  100019E1: push        esp
  100019E2: sub         eax,edx
  100019E4: add         ch,byte ptr [edx]
  100019E6: add         byte ptr [eax],al
  100019E8: inc         ecx
  100019E9: sbb         al,0
  100019EB: add         byte ptr [eax+eax],al
  100019EE: add         byte ptr [eax],al
  100019F0: sbb         al,0
  100019F2: add         byte ptr [eax],al
  100019F4: sldt        word ptr [eax]
  100019F7: add         byte ptr [ebx],ch
  100019F9: add         byte ptr [eax],al
  100019FB: add         byte ptr [eax],cl
  100019FD: add         byte ptr [eax],al
  100019FF: add         byte ptr [eax],ah
  10001A01: add         byte ptr [eax],al
  10001A03: add         dword ptr [ebx],ecx
  10001A05: xor         byte ptr [ebx],al
  10001A07: add         byte ptr [esi],al
  10001A0A: add         byte ptr [eax],al
  10001A0C: xor         eax,2110000h
  10001A11: lsl         ebx,word ptr [edx]
  10001A14: FE
  10001A15: pop         ss
  10001A16: sidt        fword ptr [edx+0Fh]
  10001A1A: add         cl,byte ptr [edx+33h]
  10001A1D: add         edx,dword ptr [esi]
  10001A1F: sub         eax,dword ptr [ecx]
  10001A21: pop         ss
  10001A22: shr         byte ptr [edi+ebp],cl
  10001A25: add         cl,byte ptr [edx+0Bh]
  10001A28: pop         es
  10001A29: or          al,byte ptr [esi]
  10001A2B: or          al,6
  10001A2D: sub         eax,612DE02h
  10001A32: sidt        fword ptr [edx+1Fh]
  10001A36: or          al,0FEh
  10001A38: pop         ss
  10001A39: fimul       word ptr [eax]
  10001A3B: or          byte ptr [esi],al
  10001A3D: sub         byte ptr [ecx],al
  10001A3F: add         byte ptr [eax],al
  10001A41: push        es
  10001A42: fmul        qword ptr [edi]
  10001A44: add         dword ptr [edi],ecx
  10001A46: add         dword ptr [edx+1Fh],ecx
  10001A49: or          al,58h
  10001A4B: push        esp
  10001A4C: add         al,byte ptr [edi]
  10001A4E: pop         ds
  10001A4F: or          al,58h
  10001A51: push        esp
  10001A52: sub         eax,edx
  10001A54: add         ch,byte ptr [edx]
  10001A56: add         byte ptr [eax],al
  10001A58: inc         ecx
  10001A59: sbb         al,0
  10001A5B: add         byte ptr [eax+eax],al
  10001A5E: add         byte ptr [eax],al
  10001A60: sbb         al,0
  10001A62: add         byte ptr [eax],al
  10001A64: sldt        word ptr [eax]
  10001A67: add         byte ptr [ebx],ch
  10001A69: add         byte ptr [eax],al
  10001A6B: add         byte ptr [eax],cl
  10001A6D: add         byte ptr [eax],al
  10001A6F: add         byte ptr [eax],ah
  10001A71: add         byte ptr [eax],al
  10001A73: add         dword ptr [ebx],ecx
  10001A75: xor         byte ptr [ebx],al
  10001A77: add         byte ptr [ecx],cl
  10001A7A: add         byte ptr [eax],al
  10001A7C: aaa
  10001A7D: add         byte ptr [eax],al
  10001A7F: adc         dword ptr [edx],eax
  10001A81: lsl         ebx,word ptr [edx]
  10001A84: FE
  10001A85: pop         ss
  10001A86: sidt        fword ptr [edx+0Fh]
  10001A8A: add         cl,byte ptr [edx+33h]
  10001A8D: add         edx,dword ptr [esi]
  10001A8F: sub         eax,dword ptr [ecx]
  10001A91: pop         ss
  10001A92: shr         byte ptr [edx+esi],cl
  10001A95: add         cl,byte ptr [edx+0Bh]
  10001A98: pop         es
  10001A99: or          al,byte ptr [esi]
  10001A9B: or          al,6
  10001A9D: sub         eax,615DE02h
  10001AA2: sidt        fword ptr [edx+1Fh]
  10001AA6: adc         esi,edi
  10001AA8: adc         al,byte ptr [ecx]
  10001AAA: FE
  10001AAB: pop         ss
  10001AAC: fimul       word ptr [eax]
  10001AAE: or          byte ptr [esi],al
  10001AB0: sub         byte ptr [ecx],al
  10001AB2: add         byte ptr [eax],al
  10001AB4: push        es
  10001AB5: fmul        qword ptr [edi]
  10001AB7: add         dword ptr [edi],ecx
  10001AB9: add         dword ptr [edx+1Fh],ecx
  10001ABC: adc         dword ptr [eax+54h],ebx
  10001ABF: add         al,byte ptr [edi]
  10001AC1: pop         ds
  10001AC2: adc         dword ptr [eax+54h],ebx
  10001AC5: sub         edi,dword ptr [edi+00002A02h]
  10001ACB: add         byte ptr [ecx+1Ch],al
  10001ACE: add         byte ptr [eax],al
  10001AD0: add         al,0
  10001AD2: add         byte ptr [eax],al
  10001AD4: sbb         al,0
  10001AD6: add         byte ptr [eax],al
  10001AD8: adc         al,byte ptr [eax]
  10001ADA: add         byte ptr [eax],al
  10001ADC: add         byte ptr cs:[eax],al
  10001ADF: add         byte ptr [eax],cl
  10001AE1: add         byte ptr [eax],al
  10001AE3: add         byte ptr [eax],ah
  10001AE5: add         byte ptr [eax],al
  10001AE7: add         dword ptr [ebx],ecx
  10001AE9: xor         byte ptr [ebx],al
  10001AEB: add         byte ptr [eax],bh
  10001AED: add         byte ptr [eax],al
  10001AEF: add         byte ptr [edx],bh
  10001AF1: add         byte ptr [eax],al
  10001AF3: adc         dword ptr [edx],eax
  10001AF5: pop         ds
  10001AF6: or          al,58h
  10001AF8: or          eax,dword ptr [edi]
  10001AFA: push        ss
  10001AFB: push        esp
  10001AFC: pop         es
  10001AFD: sbb         bl,byte ptr [eax+16h]
  10001B00: push        esp
  10001B01: pop         es
  10001B02: push        ds
  10001B03: pop         eax
  10001B04: push        ss
  10001B05: push        esp
  10001B06: add         bl,byte ptr [edi]
  10001B08: and         byte ptr [eax+0Ah],bl
  10001B0B: push        es
  10001B0C: push        ss
  10001B0D: push        esp
  10001B0E: push        es
  10001B0F: sbb         bl,byte ptr [eax+16h]
  10001B12: push        esp
  10001B13: push        es
  10001B14: push        ds
  10001B15: pop         eax
  10001B16: push        ss
  10001B17: push        esp
  10001B18: ficom       word ptr [eax]
  10001B1A: inc         byte ptr [esi]
  10001B1C: push        ss
  10001B1D: add         byte ptr [eax],al
  10001B1F: push        es
  10001B20: add         bl,byte ptr [edi]
  10001B22: or          al,58h
  10001B24: sub         byte ptr [ebx],al
  10001B26: add         dword ptr [eax],eax
  10001B28: push        es
  10001B29: fadd        qword ptr [edx]
  10001B2B: sub         al,byte ptr [ecx+1Ch]
  10001B2E: add         byte ptr [eax],al
  10001B30: add         al,0
  10001B32: add         byte ptr [eax],al
  10001B34: adc         al,byte ptr [eax]
  10001B36: add         byte ptr [eax],al
  10001B38: adc         al,0
  10001B3A: add         byte ptr [eax],al
  10001B3C: add         byte ptr es:[eax],al
  10001B3F: add         byte ptr [eax],dl
  10001B41: add         byte ptr [eax],al
  10001B43: add         byte ptr [eax],ah
  10001B45: add         byte ptr [eax],al
  10001B47: add         dword ptr [ebx],eax
  10001B49: xor         byte ptr [edx],al
  10001B4B: add         byte ptr [edi],bl
  10001B4D: add         byte ptr [eax],al
  10001B4F: add         byte ptr [eax],dh
  10001B51: add         byte ptr [eax],al
  10001B53: adc         dword ptr [ebx],eax
  10001B55: add         al,34h
  10001B57: sbb         al,byte ptr [ebx]
  10001B59: sbb         bl,byte ptr [eax+0Bh]
  10001B5C: pop         es
  10001B5D: dec         edx
  10001B5E: or          al,byte ptr [esi]
  10001B60: sub         al,6
  10001B62: push        es
  10001B63: sub         byte ptr [edi],bl
  10001B65: add         dword ptr [eax],eax
  10001B67: push        es
  10001B68: add         ebx,dword ptr [edi]
  10001B6A: sbb         byte ptr [eax+10h],bl
  10001B6D: add         dword ptr [ebx],eax
  10001B6F: add         al,37h
  10001B71: out         2Ah,al
  10001B73: add         byte ptr [eax],al
  10001B75: add         byte ptr [eax],al
  10001B77: add         byte ptr [ebx],al
  10001B79: xor         byte ptr ds:[00001C00h],al
  10001B7F: add         byte ptr [eax+eax],bh
  10001B82: add         byte ptr [ecx],dl
  10001B84: adc         al,byte ptr [edx]
  10001B86: add         al,54h
  10001B88: adc         al,byte ptr [ecx]
  10001B8A: add         edx,dword ptr [edx+edx]
  10001B8E: add         dl,byte ptr [edx+edx+4]
  10001B92: push        es
  10001B93: pop         es
  10001B94: or          byte ptr [ecx],cl
  10001B96: sub         byte ptr ds:[26060000h],ch
  10001B9C: adc         al,byte ptr [edx+ecx*2]
  10001B9F: sub         al,byte ptr [ebx]
  10001BA1: xor         byte ptr ds:[00001C00h],al
  10001BA7: add         byte ptr [esi],bh
  10001BA9: add         byte ptr [eax],al
  10001BAB: adc         dword ptr [edx],edx
  10001BAD: add         al,byte ptr [esp+edx*2]
  10001BB0: adc         al,byte ptr [ecx]
  10001BB2: add         edx,dword ptr [edx+edx]
  10001BB6: add         dl,byte ptr [edx+edx+4]
  10001BBA: push        es
  10001BBB: pop         es
  10001BBC: or          byte ptr [ecx],cl
  10001BBE: sub         byte ptr [esi],ch
  10001BC0: add         byte ptr [eax],al
  10001BC2: push        es
  10001BC3: adc         al,byte ptr es:[edx+ecx*2]
  10001BC7: sub         al,byte ptr [ebx]
  10001BC9: xor         byte ptr ds:[00001C00h],al
  10001BCF: add         byte ptr [eax],al
  10001BD2: add         byte ptr [ecx],dl
  10001BD4: adc         al,byte ptr [edx]
  10001BD6: add         al,54h
  10001BD8: adc         al,byte ptr [ecx]
  10001BDA: add         edx,dword ptr [edx+edx]
  10001BDE: add         dl,byte ptr [edx+edx+4]
  10001BE2: push        es
  10001BE3: pop         es
  10001BE4: or          byte ptr [ecx],cl
  10001BE6: sub         byte ptr [eax],dh
  10001BE8: add         byte ptr [eax],al
  10001BEA: push        es
  10001BEB: adc         al,byte ptr es:[edx+ecx*2]
  10001BEF: sub         cl,byte ptr [ebx]
  10001BF1: xor         byte ptr [eax+eax],al
  10001BF4: sub         byte ptr [eax],al
  10001BF6: add         byte ptr [eax],al
  10001BF8: adc         byte ptr [eax],al
  10001BFA: add         byte ptr [ecx],dl
  10001BFC: add         ah,byte ptr ds:[581A024Ah]
  10001C02: dec         edx
  10001C03: sub         byte ptr [ebx],ah
  10001C05: add         byte ptr [eax],al
  10001C07: push        es
  10001C08: fimul       word ptr ds:[002406FEh]
  10001C0E: add         byte ptr [esi],al
  10001C10: add         ch,byte ptr [eax]
  10001C12: add         eax,dword ptr [ecx]
  10001C14: add         byte ptr [esi],al
  10001C16: fadd        qword ptr [edx]
  10001C18: dec         edx
  10001C19: or          al,byte ptr [esi]
  10001C1B: sub         al,6
  10001C1D: push        es
  10001C1E: sub         byte ptr [edi],bl
  10001C20: add         dword ptr [eax],eax
  10001C22: push        es
  10001C23: sub         al,byte ptr [ecx+1Ch]
  10001C26: add         byte ptr [eax],al
  10001C28: add         al,0
  10001C2A: add         byte ptr [eax],al
  10001C2C: add         byte ptr [eax],al
  10001C2E: add         byte ptr [eax],al
  10001C30: push        cs
  10001C31: add         byte ptr [eax],al
  10001C33: add         byte ptr [esi],cl
  10001C35: add         byte ptr [eax],al
  10001C37: add         byte ptr ds:[20000000h],cl
  10001C3D: add         byte ptr [eax],al
  10001C3F: add         dword ptr [ebx],eax
  10001C41: xor         byte ptr [esi],al
  10001C43: add         cl,dh
  10001C45: add         byte ptr [eax],al
  10001C47: add         byte ptr [eax+eax],al
  10001C4B: adc         dword ptr [edx],eax
  10001C4D: sbb         bl,byte ptr [eax+4Ah]
  10001C50: or          al,byte ptr [esi]
  10001C52: add         bl,byte ptr [esi]
  10001C54: pop         eax
  10001C55: dec         edx
  10001C56: popad
  10001C58: add         al,13h
  10001C5A: or          dword ptr [ebx+eax],eax
  10001C5D: aaa
  10001C5E: or          al,byte ptr [esi+eax]
  10001C61: xor         al,6
  10001C63: add         al,1Fh
  10001C65: or          al,58h
  10001C67: adc         ecx,dword ptr [ecx]
  10001C69: push        es
  10001C6A: adc         ecx,dword ptr [eax]
  10001C6C: adc         dword ptr [eax],ecx
  10001C6E: sub         al,0Ah
  10001C70: adc         dword ptr [eax],ecx
  10001C72: push        es
  10001C73: pop         ds
  10001C74: or          al,59h
  10001C76: pop         ds
  10001C77: or          al,0FEh
  10001C79: pop         ss
  10001C7A: add         bl,byte ptr [edx]
  10001C7C: pop         eax
  10001C7D: dec         edx
  10001C7E: or          al,byte ptr [esi]
  10001C80: adc         eax,dword ptr ds:[590C1F06h]
  10001C86: or          al,8
  10001C88: add         ebp,dword ptr [esi]
  10001C8A: pop         ss
  10001C8B: or          byte ptr [edi],bl
  10001C8D: or          al,59h
  10001C8F: or          al,11h
  10001C91: add         eax,13590C1Fh
  10001C96: add         eax,1F080511h
  10001C9B: or          al,0FEh
  10001C9D: pop         ss
  10001C9E: or          byte ptr [ebx],al
  10001CA0: xor         ebp,ecx
  10001CA2: add         edx,dword ptr [ecx]
  10001CA4: or          dword ptr [edi],ebx
  10001CA6: or          al,0FEh
  10001CA8: pop         ss
  10001CA9: add         bl,byte ptr [edx]
  10001CAB: pop         eax
  10001CAC: add         bl,byte ptr [edx]
  10001CAE: pop         eax
  10001CAF: dec         edx
  10001CB0: pop         ds
  10001CB1: or          al,58h
  10001CB3: push        esp
  10001CB4: cmp         byte ptr [ebx+06000000h],al
  10001CBA: add         cl,byte ptr [edx+59h]
  10001CBD: pop         ds
  10001CBE: or          al,5Bh
  10001CC0: adc         eax,dword ptr [edi]
  10001CC2: adc         dword ptr [edi],eax
  10001CC4: push        ss
  10001CC5: or          byte ptr ss:[ecx],dl
  10001CC8: pop         es
  10001CC9: pop         ss
  10001CCA: bound       edx,qword ptr [ebx]
  10001CCC: add         al,2Bh
  10001CCE: add         eax,2B041317h
  10001CD3: add         al,11h
  10001CD5: add         al,2Ch
  10001CD7: push        ds
  10001CD8: adc         dword ptr [edi+ebx],eax
  10001CDB: or          al,5Ah
  10001CDD: jg          10001CE1
  10001CDF: add         byte ptr [eax],al
  10001CE1: add         al,16h
  10001CE3: push        ss
  10001CE4: jg          10001CE9
  10001CE6: add         byte ptr [eax],al
  10001CE8: add         al,20h
  10001CEA: rol         dword ptr [eax],1
  10001CEC: add         byte ptr [eax],al
  10001CEE: sub         byte ptr [edx+0D060000h],ah
  10001CF4: sub         eax,dword ptr [edx]
  10001CF6: push        ss
  10001CF7: or          eax,9034A02h
  10001CFC: sub         byte ptr [eax],ch
  10001CFE: add         byte ptr [eax],al
  10001D00: push        es
  10001D01: or          eax,dword ptr [edi]
  10001D03: sub         al,6
  10001D05: pop         es
  10001D06: add         al,1Fh
  10001D08: or          al,0FEh
  10001D0A: pop         ss
  10001D0B: add         eax,dword ptr [edx]
  10001D0D: sbb         bl,byte ptr [eax+4Ah]
  10001D10: pop         es
  10001D11: pop         ds
  10001D12: or          al,58h
  10001D14: sub         byte ptr [eax],ch
  10001D16: add         byte ptr [eax],al
  10001D18: push        es
  10001D19: or          eax,dword ptr [edx]
  10001D1B: dec         edx
  10001D1C: adc         eax,dword ptr [esi]
  10001D1E: adc         dword ptr [esi],eax
  10001D20: sub         al,7
  10001D22: adc         dword ptr [esi],eax
  10001D24: sub         byte ptr [edi],bl
  10001D26: add         dword ptr [eax],eax
  10001D28: push        es
  10001D29: add         cl,byte ptr [ecx]
  10001D2B: push        esp
  10001D2C: add         bl,byte ptr [edx]
  10001D2E: pop         eax
  10001D2F: pop         es
  10001D30: push        esp
  10001D31: add         bl,byte ptr [esi]
  10001D33: pop         eax
  10001D34: adc         dword ptr [edi+ebx],eax
  10001D37: or          al,5Ah
  10001D39: or          dword ptr [eax+54h],ebx
  10001D3C: sub         cl,ah
  10001D3E: int         3
  10001D3F: int         3
  10001D40: add         esi,dword ptr [eax]
  10001D42: push        es
  10001D43: add         cl,dh
  10001D45: add         byte ptr [eax],al
  10001D47: add         byte ptr [edi],al
  10001D4A: add         byte ptr [ecx],dl
  10001D4C: add         bl,byte ptr [edx]
  10001D4E: pop         eax
  10001D4F: dec         edx
  10001D50: or          al,byte ptr [esi]
  10001D52: add         bl,byte ptr [esi]
  10001D54: pop         eax
  10001D55: dec         edx
  10001D56: popad
  10001D58: add         al,13h
  10001D5A: or          dword ptr [ebx+eax],eax
  10001D5D: aaa
  10001D5E: or          al,byte ptr [esi+eax]
  10001D61: xor         al,6
  10001D63: add         al,1Fh
  10001D65: or          al,58h
  10001D67: adc         ecx,dword ptr [ecx]
  10001D69: push        es
  10001D6A: adc         ecx,dword ptr [eax]
  10001D6C: adc         dword ptr [eax],ecx
  10001D6E: sub         al,0Ah
  10001D70: adc         dword ptr [eax],ecx
  10001D72: push        es
  10001D73: pop         ds
  10001D74: or          al,59h
  10001D76: pop         ds
  10001D77: or          al,0FEh
  10001D79: pop         ss
  10001D7A: add         bl,byte ptr [edx]
  10001D7C: pop         eax
  10001D7D: dec         edx
  10001D7E: or          al,byte ptr [esi]
  10001D80: adc         eax,dword ptr ds:[590C1F06h]
  10001D86: or          al,8
  10001D88: add         ebp,dword ptr [esi]
  10001D8A: pop         ss
  10001D8B: or          byte ptr [edi],bl
  10001D8D: or          al,59h
  10001D8F: or          al,11h
  10001D91: add         eax,13590C1Fh
  10001D96: add         eax,1F080511h
  10001D9B: or          al,0FEh
  10001D9D: pop         ss
  10001D9E: or          byte ptr [ebx],al
  10001DA0: xor         ebp,ecx
  10001DA2: add         edx,dword ptr [ecx]
  10001DA4: or          dword ptr [edi],ebx
  10001DA6: or          al,0FEh
  10001DA8: pop         ss
  10001DA9: add         bl,byte ptr [edx]
  10001DAB: pop         eax
  10001DAC: add         bl,byte ptr [edx]
  10001DAE: pop         eax
  10001DAF: dec         edx
  10001DB0: pop         ds
  10001DB1: or          al,58h
  10001DB3: push        esp
  10001DB4: cmp         byte ptr [ebx+06000000h],al
  10001DBA: add         cl,byte ptr [edx+59h]
  10001DBD: pop         ds
  10001DBE: or          al,5Bh
  10001DC0: adc         eax,dword ptr [edi]
  10001DC2: adc         dword ptr [edi],eax
  10001DC4: push        ss
  10001DC5: or          byte ptr ss:[ecx],dl
  10001DC8: pop         es
  10001DC9: pop         ss
  10001DCA: bound       edx,qword ptr [ebx]
  10001DCC: add         al,2Bh
  10001DCE: add         eax,2B041317h
  10001DD3: add         al,11h
  10001DD5: add         al,2Ch
  10001DD7: push        ds
  10001DD8: adc         dword ptr [edi+ebx],eax
  10001DDB: or          al,5Ah
  10001DDD: jg          10001DE1
  10001DDF: add         byte ptr [eax],al
  10001DE1: add         al,16h
  10001DE3: push        ss
  10001DE4: jg          10001DE9
  10001DE6: add         byte ptr [eax],al
  10001DE8: add         al,20h
  10001DEA: rol         dword ptr [eax],1
  10001DEC: add         byte ptr [eax],al
  10001DEE: sub         byte ptr [edx+0D060000h],ah
  10001DF4: sub         eax,dword ptr [edx]
  10001DF6: push        ss
  10001DF7: or          eax,9034A02h
  10001DFC: sub         byte ptr [ecx],ch
  10001DFE: add         byte ptr [eax],al
  10001E00: push        es
  10001E01: or          eax,dword ptr [edi]
  10001E03: sub         al,6
  10001E05: pop         es
  10001E06: add         al,1Fh
  10001E08: or          al,0FEh
  10001E0A: pop         ss
  10001E0B: add         eax,dword ptr [edx]
  10001E0D: sbb         bl,byte ptr [eax+4Ah]
  10001E10: pop         es
  10001E11: pop         ds
  10001E12: or          al,58h
  10001E14: sub         byte ptr [ecx],ch
  10001E16: add         byte ptr [eax],al
  10001E18: push        es
  10001E19: or          eax,dword ptr [edx]
  10001E1B: dec         edx
  10001E1C: adc         eax,dword ptr [esi]
  10001E1E: adc         dword ptr [esi],eax
  10001E20: sub         al,7
  10001E22: adc         dword ptr [esi],eax
  10001E24: sub         byte ptr [edi],bl
  10001E26: add         dword ptr [eax],eax
  10001E28: push        es
  10001E29: add         cl,byte ptr [ecx]
  10001E2B: push        esp
  10001E2C: add         bl,byte ptr [edx]
  10001E2E: pop         eax
  10001E2F: pop         es
  10001E30: push        esp
  10001E31: add         bl,byte ptr [esi]
  10001E33: pop         eax
  10001E34: adc         dword ptr [edi+ebx],eax
  10001E37: or          al,5Ah
  10001E39: or          dword ptr [eax+54h],ebx
  10001E3C: sub         cl,ah
  10001E3E: int         3
  10001E3F: int         3
  10001E40: add         esi,dword ptr [eax]
  10001E42: push        es
  10001E43: add         ch,bh
  10001E45: add         byte ptr [eax],al
  10001E47: add         byte ptr [edx],cl
  10001E4A: add         byte ptr [ecx],dl
  10001E4C: add         bl,byte ptr [edx]
  10001E4E: pop         eax
  10001E4F: dec         edx
  10001E50: or          al,byte ptr [esi]
  10001E52: add         bl,byte ptr [esi]
  10001E54: pop         eax
  10001E55: dec         edx
  10001E56: push        4
  10001E59: adc         ecx,dword ptr [ecx]
  10001E5B: add         al,3
  10001E5D: aaa
  10001E5E: or          al,byte ptr [esi+eax]
  10001E61: xor         al,6
  10001E63: add         al,1Fh
  10001E65: adc         dword ptr [eax+13h],ebx
  10001E68: or          dword ptr [esi],eax
  10001E6A: adc         ecx,dword ptr [eax]
  10001E6C: adc         dword ptr [eax],ecx
  10001E6E: sub         al,0Dh
  10001E70: adc         dword ptr [eax],ecx
  10001E72: push        es
  10001E73: pop         ds
  10001E74: adc         dword ptr [ecx+1Fh],ebx
  10001E77: adc         esi,edi
  10001E79: adc         al,byte ptr [ecx]
  10001E7B: FE
  10001E7C: pop         ss
  10001E7D: add         bl,byte ptr [edx]
  10001E7F: pop         eax
  10001E80: dec         edx
  10001E81: or          al,byte ptr [esi]
  10001E83: adc         eax,dword ptr ds:[59111F06h]
  10001E89: or          al,8
  10001E8B: add         ebp,dword ptr [esi]
  10001E8D: sbb         cl,byte ptr [eax]
  10001E8F: pop         ds
  10001E90: adc         dword ptr [ecx+0Ch],ebx
  10001E93: adc         dword ptr ds:[1359111Fh],eax
  10001E99: add         eax,1F080511h
  10001E9E: adc         esi,edi
  10001EA0: adc         al,byte ptr [ecx]
  10001EA2: FE
  10001EA3: pop         ss
  10001EA4: or          byte ptr [ebx],al
  10001EA6: xor         esp,esi
  10001EA8: add         edx,dword ptr [ecx]
  10001EAA: or          dword ptr [edi],ebx
  10001EAC: adc         esi,edi
  10001EAE: adc         al,byte ptr [ecx]
  10001EB0: FE
  10001EB1: pop         ss
  10001EB2: add         bl,byte ptr [edx]
  10001EB4: pop         eax
  10001EB5: add         bl,byte ptr [edx]
  10001EB7: pop         eax
  10001EB8: dec         edx
  10001EB9: pop         ds
  10001EBA: adc         dword ptr [eax+54h],ebx
  10001EBD: cmp         byte ptr [esi+06000000h],al
  10001EC3: add         cl,byte ptr [edx+59h]
  10001EC6: pop         ds
  10001EC7: adc         dword ptr [ebx+13h],ebx
  10001ECA: pop         es
  10001ECB: adc         dword ptr [edi],eax
  10001ECD: push        ss
  10001ECE: or          byte ptr ss:[ecx],dl
  10001ED1: pop         es
  10001ED2: pop         ss
  10001ED3: bound       edx,qword ptr [ebx]
  10001ED5: add         al,2Bh
  10001ED7: add         eax,2B041317h
  10001EDC: add         al,11h
  10001EDE: add         al,2Ch
  10001EE0: push        ds
  10001EE1: adc         dword ptr [edi+ebx],eax
  10001EE4: adc         dword ptr [edx+7Fh],ebx
  10001EE7: add         al,byte ptr [eax]
  10001EE9: add         byte ptr [esi+edx],al
  10001EEC: push        ss
  10001EED: jg          10001EF2
  10001EEF: add         byte ptr [eax],al
  10001EF1: add         al,20h
  10001EF3: rol         dword ptr [eax],1
  10001EF5: add         byte ptr [eax],al
  10001EF7: sub         byte ptr [edx+0D060000h],ah
  10001EFD: sub         eax,dword ptr [edx]
  10001EFF: push        ss
  10001F00: or          eax,9034A02h
  10001F05: sub         byte ptr [eax+eax],ch
  10001F08: add         byte ptr [esi],al
  10001F0A: or          eax,dword ptr [edi]
  10001F0C: sub         al,9
  10001F0E: pop         es
  10001F0F: add         al,1Fh
  10001F11: adc         esi,edi
  10001F13: adc         al,byte ptr [ecx]
  10001F15: FE
  10001F16: pop         ss
  10001F17: add         eax,dword ptr [edx]
  10001F19: sbb         bl,byte ptr [eax+4Ah]
  10001F1C: pop         es
  10001F1D: pop         ds
  10001F1E: adc         dword ptr [eax+28h],ebx
  10001F21: sub         al,0
  10001F23: add         byte ptr [esi],al
  10001F25: or          eax,dword ptr [edx]
  10001F27: dec         edx
  10001F28: adc         eax,dword ptr [esi]
  10001F2A: adc         dword ptr [esi],eax
  10001F2C: sub         al,7
  10001F2E: adc         dword ptr [esi],eax
  10001F30: sub         byte ptr [edi],bl
  10001F32: add         dword ptr [eax],eax
  10001F34: push        es
  10001F35: add         cl,byte ptr [ecx]
  10001F37: push        esp
  10001F38: add         bl,byte ptr [edx]
  10001F3A: pop         eax
  10001F3B: pop         es
  10001F3C: push        esp
  10001F3D: add         bl,byte ptr [esi]
  10001F3F: pop         eax
  10001F40: adc         dword ptr [edi+ebx],eax
  10001F43: adc         dword ptr [edx+9],ebx
  10001F46: pop         eax
  10001F47: push        esp
  10001F48: sub         cl,ah
  10001F4A: int         3
  10001F4B: int         3
  10001F4C: add         esi,dword ptr [eax]
  10001F4E: add         eax,dword ptr [eax]
  10001F50: sub         eax,4C000000h
  10001F55: add         byte ptr [eax],al
  10001F57: adc         dword ptr [edx],eax
  10001F59: sbb         bl,byte ptr [eax+4Ah]
  10001F5C: or          al,byte ptr [esi]
  10001F5E: add         bl,byte ptr [esi]
  10001F60: pop         eax
  10001F61: dec         edx
  10001F62: xor         al,18h
  10001F64: push        es
  10001F65: or          eax,dword ptr [edx]
  10001F67: sbb         bl,byte ptr [eax+6]
  10001F6A: pop         ds
  10001F6B: adc         dword ptr [eax+54h],ebx
  10001F6E: pop         es
  10001F6F: sub         al,13h
  10001F71: pop         es
  10001F72: add         ebx,dword ptr [edi]
  10001F74: adc         esi,edi
  10001F76: adc         al,byte ptr [ecx]
  10001F78: FE
  10001F79: pop         ss
  10001F7A: sub         ecx,dword ptr [eax]
  10001F7C: add         al,byte ptr [esi]
  10001F7E: add         ebp,dword ptr [eax]
  10001F80: daa
  10001F81: add         byte ptr [eax],al
  10001F83: push        es
  10001F84: sub         cl,ah
  10001F86: int         3
  10001F87: int         3
  10001F88: add         esi,dword ptr [eax]
  10001F8A: add         al,0
  10001F8C: inc         esp
  10001F8D: add         byte ptr [eax],al
  10001F8F: add         byte ptr [ebp],cl
  10001F92: add         byte ptr [ecx],dl
  10001F94: add         bl,byte ptr [edx]
  10001F96: pop         eax
  10001F97: dec         edx
  10001F98: adc         eax,dword ptr ds:[020C0511h]
  10001F9E: dec         edx
  10001F9F: adc         eax,dword ptr [ecx+edx]
  10001FA2: add         eax,0B04110Dh
  10001FA7: or          byte ptr [edx],cl
  10001FA9: or          byte ptr [ecx],cl
  10001FAB: pop         ss
  10001FAD: pop         es
  10001FAE: push        es
  10001FAF: pop         ds
  10001FB0: adc         esi,edi
  10001FB2: adc         al,byte ptr [ecx]
  10001FB4: FE
  10001FB5: pop         ss
  10001FB6: pop         es
  10001FB7: pop         ds
  10001FB8: adc         dword ptr [eax+0Bh],ebx
  10001FBB: push        es
  10001FBC: pop         ds
  10001FBD: adc         dword ptr [eax+0Ah],ebx
  10001FC0: push        es
  10001FC1: or          dword ptr [ebx],esi
  10001FC3: jmp         125839CA
  10001FC8: sbb         bl,byte ptr [eax+4Ah]
  10001FCB: or          byte ptr [ecx],dl
  10001FCD: add         al,59h
  10001FCF: pop         ds
  10001FD0: out         dx,eax
  10001FD1: pop         ebx
  10001FD2: pop         ds
  10001FD3: adc         dword ptr [edx+58h],ebx
  10001FD6: push        esp
  10001FD7: sub         cl,byte ptr [ebx]
  10001FD9: xor         byte ptr [esi],al
  10001FDB: add         byte ptr [ecx],dh
  10001FDE: add         byte ptr [eax],al
  10001FE0: dec         esi
  10001FE1: add         byte ptr [eax],al
  10001FE3: adc         dword ptr [ebx],eax
  10001FE5: sbb         bl,byte ptr [eax+4Ah]
  10001FE8: add         ecx,dword ptr [edx+59h]
  10001FEB: sbb         byte ptr [ebx+0Bh],ah
  10001FEE: pop         es
  10001FEF: sub         al,1Ch
  10001FF1: pop         es
  10001FF2: sbb         byte ptr [edx+7Fh],ah
  10001FF5: add         al,byte ptr [eax]
  10001FF7: add         byte ptr [esi+edx],al
  10001FFA: push        ss
  10001FFB: jg          10002000
  10001FFD: add         byte ptr [eax],al
  10001FFF: add         al,20h
  10002001: rol         dword ptr [eax],1
  10002003: add         byte ptr [eax],al
  10002005: sub         byte ptr [edx+0A060000h],ah
  1000200B: sub         eax,dword ptr [edx]
  1000200D: push        ss
  1000200E: or          al,byte ptr [edx]
  10002010: push        es
  10002011: push        esp
  10002012: add         bl,byte ptr [edx]
  10002014: pop         eax
  10002015: adc         eax,dword ptr [ecx+edx]
  10002018: add         al,6
  1000201A: push        esp
  1000201B: add         bl,byte ptr [esi]
  1000201D: pop         eax
  1000201E: pop         es
  1000201F: sbb         bl,byte ptr [edx+6]
  10002022: pop         eax
  10002023: push        esp
  10002024: add         cl,byte ptr [edx+13h]
  10002027: add         eax,4A581A03h
  1000202C: add         ecx,dword ptr [edx+0Dh]
  1000202F: or          dword ptr [ecx+0Ch],ebx
  10002032: adc         dword ptr [eax+ecx],eax
  10002035: sbb         byte ptr [ebx+1Ah],ah
  10002038: pop         edx
  10002039: adc         dword ptr ds:[21280809h],eax
  1000203F: add         dword ptr [eax],eax
  10002041: push        es
  10002042: pop         eax
  10002043: push        esp
  10002044: fimul       word ptr ds:[002206FEh]
  1000204A: add         byte ptr [esi],al
  1000204C: add         ch,byte ptr [eax]
  1000204E: add         eax,dword ptr [ecx]
  10002050: add         byte ptr [esi],al
  10002052: fadd        qword ptr [edx]
  10002054: sub         al,byte ptr [eax]
  10002056: add         byte ptr [eax],al
  10002058: inc         ecx
  10002059: sbb         al,0
  1000205B: add         byte ptr [eax+eax],al
  1000205E: add         byte ptr [eax],al
  10002060: inc         eax
  10002061: add         byte ptr [eax],al
  10002063: add         byte ptr [edx],ah
  10002065: add         byte ptr [eax],al
  10002067: add         byte ptr [edx],ah
  1000206A: add         byte ptr [eax],al
  1000206C: or          eax,20000000h
  10002071: add         byte ptr [eax],al
  10002073: add         dword ptr [ebx],eax
  10002075: xor         byte ptr [esi],al
  10002077: add         byte ptr [esi],ch
  10002079: add         byte ptr [eax],al
  1000207B: add         byte ptr [eax],bh
  1000207D: add         byte ptr [eax],al
  1000207F: adc         dword ptr [ebx],eax
  10002081: sub         al,1Ch
  10002083: add         ebx,dword ptr [eax]
  10002085: bound       edi,qword ptr [edi+2]
  10002088: add         byte ptr [eax],al
  1000208A: add         al,16h
  1000208C: push        ss
  1000208D: jg          10002092
  1000208F: add         byte ptr [eax],al
  10002091: add         al,20h
  10002093: rol         dword ptr [eax],1
  10002095: add         byte ptr [eax],al
  10002097: sub         byte ptr [edx+0A060000h],ah
  1000209D: sub         eax,dword ptr [edx]
  1000209F: push        ss
  100020A0: or          al,byte ptr [esi]
  100020A2: add         al,5
  100020A4: add         al,59h
  100020A6: sub         byte ptr [ecx],ah
  100020A8: add         dword ptr [eax],eax
  100020AA: push        es
  100020AB: push        es
  100020AD: sub         cl,ah
  100020AF: int         3
  100020B0: add         esi,dword ptr [eax]
  100020B2: add         al,0
  100020B4: jo          100020B6
  100020B6: add         byte ptr [eax],al
  100020B8: push        eax
  100020B9: add         byte ptr [eax],al
  100020BB: adc         dword ptr [ebx],eax
  100020BD: add         al,5Ah
  100020BF: sbb         dword ptr [eax+1Fh],ebx
  100020C2: cld
  100020C3: pop         edi
  100020C4: adc         eax,dword ptr ds:[11170612h]
  100020CA: add         eax,12028h
  100020CF: push        es
  100020D0: push        esp
  100020D1: adc         al,byte ptr [esi]
  100020D3: sbb         bl,byte ptr [eax+11h]
  100020D6: add         eax,1E061254h
  100020DB: pop         eax
  100020DC: add         al,54h
  100020DE: add         bl,byte ptr [edi]
  100020E0: adc         al,58h
  100020E2: adc         eax,dword ptr [ecx+edx]
  100020E5: add         al,0Bh
  100020E7: pop         es
  100020E8: sbb         bl,byte ptr [eax+4Ah]
  100020EB: or          al,byte ptr [esi]
  100020ED: pop         es
  100020EE: push        ds
  100020EF: pop         eax
  100020F0: dec         edx
  100020F1: xor         al,16h
  100020F3: push        es
  100020F4: or          eax,6581A07h
  100020F9: pop         ds
  100020FA: or          al,58h
  100020FC: push        esp
  100020FD: or          dword ptr [edx+edx],ebp
  10002100: or          dword ptr [edx],edx
  10002102: push        es
  10002103: pop         ds
  10002104: or          al,0FEh
  10002106: pop         ss
  10002107: sub         ecx,dword ptr [ecx]
  10002109: pop         es
  1000210A: push        es
  1000210B: adc         al,byte ptr [esi]
  1000210D: sub         byte ptr [edi],bl
  1000210F: add         byte ptr [eax],al
  10002111: push        es
  10002112: add         ah,byte ptr ds:[1A06124Ah]
  10002118: pop         eax
  10002119: dec         edx
  1000211A: pop         eax
  1000211B: push        esp
  1000211C: adc         dword ptr [esp+ecx],eax
  1000211F: or          byte ptr [edx],bl
  10002121: pop         eax
  10002122: dec         edx
  10002123: or          byte ptr [edx+59h],cl
  10002126: pop         ds
  10002127: or          al,5Bh
  10002129: pop         ss
  1000212A: pop         ecx
  1000212B: sub         al,byte ptr [ebx]
  1000212D: xor         byte ptr [esi],al
  1000212F: add         byte ptr [edx],al
  10002131: add         dword ptr [eax],eax
  10002133: add         byte ptr [edx],dl
  10002136: add         byte ptr [ecx],dl
  10002138: add         bl,byte ptr [edx]
  1000213A: pop         eax
  1000213B: dec         edx
  1000213C: or          al,byte ptr [esi]
  1000213E: add         bl,byte ptr [esi]
  10002140: pop         eax
  10002141: dec         edx
  10002142: dec         edi
  10002144: add         al,13h
  10002146: or          al,byte ptr [ebx+eax]
  10002149: aaa
  1000214A: or          dword ptr [esi+eax],eax
  1000214D: xor         al,5
  1000214F: add         al,1Ah
  10002151: pop         eax
  10002152: adc         ecx,dword ptr [edx]
  10002154: push        es
  10002155: adc         ecx,dword ptr [ecx]
  10002157: adc         dword ptr [ecx],ecx
  10002159: sub         al,7
  1000215B: adc         dword ptr [ecx],ecx
  1000215D: push        es
  1000215E: sbb         bl,byte ptr [ecx+4Eh]
  10002161: push        esi
  10002162: add         bl,byte ptr [edx]
  10002164: pop         eax
  10002165: dec         edx
  10002166: or          al,byte ptr [esi]
  10002168: sbb         bl,byte ptr [ecx+3]
  1000216B: pop         ecx
  1000216C: adc         ecx,dword ptr [eax]
  1000216E: push        es
  1000216F: adc         dword ptr [eax],ecx
  10002171: sbb         byte ptr [ebx+18h],ah
  10002174: bound       ebx,qword ptr [ecx+3]
  10002177: adc         dword ptr [eax],ecx
  10002179: sub         byte ptr [ecx],ah
  1000217B: add         dword ptr [eax],eax
  1000217D: push        es
  1000217E: add         edx,dword ptr es:[ecx]
  10002181: or          cl,byte ptr [esi+56h]
  10002184: add         bl,byte ptr [edx]
  10002186: pop         eax
  10002187: add         bl,byte ptr [edx]
  10002189: pop         eax
  1000218A: dec         edx
  1000218B: sbb         bl,byte ptr [eax+54h]
  1000218E: cmp         byte ptr [esi+06000000h],ah
  10002194: add         cl,byte ptr [edx+59h]
  10002197: sbb         byte ptr [ebx+13h],ah
  1000219A: pop         es
  1000219B: adc         dword ptr [edi],eax
  1000219D: push        ss
  1000219E: pop         es
  100021A0: adc         dword ptr [edi],eax
  100021A2: pop         ss
  100021A3: bound       ecx,qword ptr ds:[0D17042Bh]
  100021A9: sub         eax,dword ptr [ebx]
  100021AB: or          dword ptr [esp+ebx],ebp
  100021AE: or          dword ptr [eax],ebx
  100021B0: bound       edi,qword ptr [edi+2]
  100021B3: add         byte ptr [eax],al
  100021B5: add         al,16h
  100021B7: push        ss
  100021B8: jg          100021BD
  100021BA: add         byte ptr [eax],al
  100021BC: add         al,20h
  100021BE: rol         dword ptr [eax],1
  100021C0: add         byte ptr [eax],al
  100021C2: sub         byte ptr [edx+0C060000h],ah
  100021C8: sub         eax,dword ptr [edx]
  100021CA: push        ss
  100021CB: or          al,12h
  100021CD: or          eax,3544A02h
  100021D2: adc         cl,byte ptr ds:[0613594Ah]
  100021D8: adc         dword ptr [esi],eax
  100021DA: sbb         byte ptr [ebx+1Ah],ah
  100021DD: pop         edx
  100021DE: or          byte ptr [edx],dl
  100021E0: or          eax,2806114Ah
  100021E5: and         dword ptr [ecx],eax
  100021E7: add         byte ptr [esi],al
  100021E9: pop         eax
  100021EA: or          eax,dword ptr [edi]
  100021EC: sub         al,4
  100021EE: pop         es
  100021EF: add         al,4Eh
  100021F1: push        esi
  100021F2: adc         cl,byte ptr [edi+eax]
  100021F5: sbb         bl,byte ptr [eax+54h]
  100021F8: adc         cl,byte ptr [ebx]
  100021FA: add         bl,byte ptr [edx]
  100021FC: pop         eax
  100021FD: dec         edx
  100021FE: push        esp
  100021FF: adc         cl,byte ptr [ebx]
  10002201: dec         edx
  10002202: add         ebx,dword ptr [ecx+13h]
  10002205: add         eax,63180511h
  1000220A: sbb         bl,byte ptr [edx+12h]
  1000220D: or          al,4Ah
  1000220F: add         edx,dword ptr [ecx]
  10002211: add         eax,12128h
  10002216: push        es
  10002217: pop         eax
  10002218: or          eax,dword ptr [edx]
  1000221A: dec         edx
  1000221B: adc         eax,dword ptr [ecx+edx]
  1000221E: add         al,2Ch
  10002220: pop         es
  10002221: adc         dword ptr [eax+ebp],eax
  10002224: pop         ds
  10002225: add         dword ptr [eax],eax
  10002227: push        es
  10002228: add         cl,byte ptr [eax]
  1000222A: push        esp
  1000222B: add         bl,byte ptr [edx]
  1000222D: pop         eax
  1000222E: pop         es
  1000222F: push        esp
  10002230: add         bl,byte ptr [esi]
  10002232: pop         eax
  10002233: or          dword ptr [edx],ebx
  10002235: pop         edx
  10002236: or          byte ptr [eax+54h],bl
  10002239: sub         cl,ah
  1000223B: int         3
  1000223C: add         esi,dword ptr [eax]
  1000223E: push        es
  1000223F: add         byte ptr [edx],al
  10002241: add         dword ptr [eax],eax
  10002243: add         byte ptr [eax+eax],dl
  10002247: adc         dword ptr [edx],eax
  10002249: sbb         bl,byte ptr [eax+4Ah]
  1000224C: or          al,byte ptr [esi]
  1000224E: add         bl,byte ptr [esi]
  10002250: pop         eax
  10002251: dec         edx
  10002252: dec         edi
  10002254: add         al,13h
  10002256: or          al,byte ptr [ebx+eax]
  10002259: aaa
  1000225A: or          dword ptr [esi+eax],eax
  1000225D: xor         al,5
  1000225F: add         al,1Ah
  10002261: pop         eax
  10002262: adc         ecx,dword ptr [edx]
  10002264: push        es
  10002265: adc         ecx,dword ptr [ecx]
  10002267: adc         dword ptr [ecx],ecx
  10002269: sub         al,7
  1000226B: adc         dword ptr [ecx],ecx
  1000226D: push        es
  1000226E: sbb         bl,byte ptr [ecx+4Ah]
  10002271: push        esp
  10002272: add         bl,byte ptr [edx]
  10002274: pop         eax
  10002275: dec         edx
  10002276: or          al,byte ptr [esi]
  10002278: sbb         bl,byte ptr [ecx+3]
  1000227B: pop         ecx
  1000227C: adc         ecx,dword ptr [eax]
  1000227E: push        es
  1000227F: adc         dword ptr [eax],ecx
  10002281: sbb         byte ptr [ebx+18h],ah
  10002284: bound       ebx,qword ptr [ecx+3]
  10002287: adc         dword ptr [eax],ecx
  10002289: sub         byte ptr [ecx],ah
  1000228B: add         dword ptr [eax],eax
  1000228D: push        es
  1000228E: add         edx,dword ptr es:[ecx]
  10002291: or          cl,byte ptr [edx+54h]
  10002294: add         bl,byte ptr [edx]
  10002296: pop         eax
  10002297: add         bl,byte ptr [edx]
  10002299: pop         eax
  1000229A: dec         edx
  1000229B: sbb         bl,byte ptr [eax+54h]
  1000229E: cmp         byte ptr [esi+06000000h],ah
  100022A4: add         cl,byte ptr [edx+59h]
  100022A7: sbb         byte ptr [ebx+13h],ah
  100022AA: pop         es
  100022AB: adc         dword ptr [edi],eax
  100022AD: push        ss
  100022AE: pop         es
  100022B0: adc         dword ptr [edi],eax
  100022B2: pop         ss
  100022B3: bound       ecx,qword ptr ds:[0D17042Bh]
  100022B9: sub         eax,dword ptr [ebx]
  100022BB: or          dword ptr [esp+ebx],ebp
  100022BE: or          dword ptr [eax],ebx
  100022C0: bound       edi,qword ptr [edi+2]
  100022C3: add         byte ptr [eax],al
  100022C5: add         al,16h
  100022C7: push        ss
  100022C8: jg          100022CD
  100022CA: add         byte ptr [eax],al
  100022CC: add         al,20h
  100022CE: rol         dword ptr [eax],1
  100022D0: add         byte ptr [eax],al
  100022D2: sub         byte ptr [edx+0C060000h],ah
  100022D8: sub         eax,dword ptr [edx]
  100022DA: push        ss
  100022DB: or          al,12h
  100022DD: or          eax,3544A02h
  100022E2: adc         cl,byte ptr ds:[0613594Ah]
  100022E8: adc         dword ptr [esi],eax
  100022EA: sbb         byte ptr [ebx+1Ah],ah
  100022ED: pop         edx
  100022EE: or          byte ptr [edx],dl
  100022F0: or          eax,2806114Ah
  100022F5: and         dword ptr [ecx],eax
  100022F7: add         byte ptr [esi],al
  100022F9: pop         eax
  100022FA: or          eax,dword ptr [edi]
  100022FC: sub         al,4
  100022FE: pop         es
  100022FF: add         al,4Ah
  10002301: push        esp
  10002302: adc         cl,byte ptr [edi+eax]
  10002305: sbb         bl,byte ptr [eax+54h]
  10002308: adc         cl,byte ptr [ebx]
  1000230A: add         bl,byte ptr [edx]
  1000230C: pop         eax
  1000230D: dec         edx
  1000230E: push        esp
  1000230F: adc         cl,byte ptr [ebx]
  10002311: dec         edx
  10002312: add         ebx,dword ptr [ecx+13h]
  10002315: add         eax,63180511h
  1000231A: sbb         bl,byte ptr [edx+12h]
  1000231D: or          al,4Ah
  1000231F: add         edx,dword ptr [ecx]
  10002321: add         eax,12128h
  10002326: push        es
  10002327: pop         eax
  10002328: or          eax,dword ptr [edx]
  1000232A: dec         edx
  1000232B: adc         eax,dword ptr [ecx+edx]
  1000232E: add         al,2Ch
  10002330: pop         es
  10002331: adc         dword ptr [eax+ebp],eax
  10002334: pop         ds
  10002335: add         dword ptr [eax],eax
  10002337: push        es
  10002338: add         cl,byte ptr [eax]
  1000233A: push        esp
  1000233B: add         bl,byte ptr [edx]
  1000233D: pop         eax
  1000233E: pop         es
  1000233F: push        esp
  10002340: add         bl,byte ptr [esi]
  10002342: pop         eax
  10002343: or          dword ptr [edx],ebx
  10002345: pop         edx
  10002346: or          byte ptr [eax+54h],bl
  10002349: sub         cl,ah
  1000234B: int         3
  1000234C: add         esi,dword ptr [eax]
  1000234E: add         al,0
  10002350: int         0
  10002352: add         byte ptr [eax],al
  10002354: push        edi
  10002355: add         byte ptr [eax],al
  10002357: adc         dword ptr [ebx],eax
  10002359: add         bh,byte ptr [ebx]
  1000235B: les         eax,fword ptr [eax]
  1000235D: add         byte ptr [eax],al
  1000235F: add         ebx,dword ptr [edx]
  10002361: pop         eax
  10002362: dec         edx
  10002363: adc         eax,dword ptr [ebx+eax]
  10002366: dec         edx
  10002367: or          edx,dword ptr [ecx]
  10002369: add         al,7
  1000236B: pop         ecx
  1000236C: sbb         byte ptr [ebx+0Ah],ah
  1000236F: add         cl,byte ptr [edx+0Dh]
  10002372: push        es
  10002373: add         bl,byte ptr [esi]
  10002375: pop         eax
  10002376: dec         edx
  10002377: or          dword ptr [ecx+18h],ebx
  1000237A: arpl        word ptr [esi],si
  1000237C: das
  1000237D: add         al,byte ptr [esi]
  1000237F: pop         es
  10002380: adc         dword ptr [eax+ebp],eax
  10002383: xor         eax,dword ptr [eax]
  10002385: add         byte ptr [esi],al
  10002387: adc         ecx,dword ptr [edx]
  10002389: add         bl,byte ptr [edx]
  1000238B: pop         eax
  1000238C: or          al,2
  1000238E: dec         edx
  1000238F: adc         ecx,dword ptr [ecx]
  10002391: adc         dword ptr [ecx],ecx
  10002393: sub         al,7
  10002395: adc         dword ptr [ecx],ecx
  10002397: sub         byte ptr [edi],bl
  10002399: add         dword ptr [eax],eax
  1000239B: push        es
  1000239C: add         dl,byte ptr [ecx]
  1000239E: or          dl,byte ptr [edx+eax+1Eh]
  100023A2: pop         eax
  100023A3: push        es
  100023A4: sbb         bl,byte ptr [edx+11h]
  100023A7: or          bl,byte ptr [eax+54h]
  100023AA: sub         ebp,dword ptr [edi+2]
  100023AD: sbb         bl,byte ptr [eax+0Ch]
  100023B0: or          byte ptr [edx+9],cl
  100023B3: pop         ecx
  100023B4: sbb         byte ptr [ebx+13h],ah
  100023B7: or          byte ptr [esi],al
  100023B9: adc         dword ptr [eax],ecx
  100023BB: dec         ecx
  100023BD: pop         es
  100023BE: adc         eax,dword ptr [edi]
  100023C0: or          dword ptr [ecx],edx
  100023C2: pop         es
  100023C3: adc         dword ptr [eax],ecx
  100023C5: sbb         byte ptr [edx+11h],ah
  100023C8: pop         es
  100023C9: pop         ecx
  100023CA: pop         es
  100023CB: pop         eax
  100023CC: sub         byte ptr [ecx],ah
  100023CE: add         dword ptr [eax],eax
  100023D0: push        es
  100023D1: or          byte ptr es:[edx+13h],cl
  100023D5: push        es
  100023D6: adc         cl,byte ptr [esi]
  100023D8: adc         dword ptr [esi],eax
  100023DA: push        esp
  100023DB: adc         cl,byte ptr ds:[4A581A03h]
  100023E1: push        esp
  100023E2: adc         cl,byte ptr [ecx+edx]
  100023E5: push        es
  100023E6: add         cl,byte ptr [edx+59h]
  100023E9: sbb         byte ptr [ebx+1Ah],ah
  100023EC: pop         edx
  100023ED: add         ecx,dword ptr [edx+58h]
  100023F0: push        esp
  100023F1: adc         cl,byte ptr [esi]
  100023F3: dec         edx
  100023F4: adc         cl,byte ptr [edx+ecx*2]
  100023F7: adc         cl,byte ptr ds:[4A0C124Ah]
  100023FD: pop         ecx
  100023FE: sub         byte ptr [ecx],ah
  10002400: add         dword ptr [eax],eax
  10002402: push        es
  10002403: sub         edx,dword ptr es:[13041109h]
  1000240A: or          eax,dword ptr [edi]
  1000240C: adc         eax,dword ptr ds:[0B110511h]
  10002412: adc         dword ptr ds:[01212859h],eax
  10002418: add         byte ptr [esi],al
  1000241A: or          byte ptr es:[esi],al
  1000241D: sbb         bl,byte ptr [edx+2]
  10002420: dec         edx
  10002421: pop         eax
  10002422: push        esp
  10002423: add         ch,byte ptr [edx]
  10002425: int         3
  10002426: int         3
  10002427: int         3
  10002428: add         esi,dword ptr [eax]
  1000242A: add         eax,dword ptr [eax]
  1000242C: daa
  1000242D: add         byte ptr [eax],al
  1000242F: add         byte ptr [eax+eax],cl
  10002433: adc         dword ptr [edx],eax
  10002435: sbb         bl,byte ptr [eax+4Ah]
  10002438: or          al,byte ptr [esi]
  1000243A: add         bl,byte ptr [esi]
  1000243C: pop         eax
  1000243D: dec         edx
  1000243E: xor         al,12h
  10002440: push        es
  10002441: or          eax,dword ptr [edx]
  10002443: sbb         bl,byte ptr [eax+6]
  10002446: sbb         bl,byte ptr [eax+54h]
  10002449: pop         es
  1000244A: sub         al,0Eh
  1000244C: pop         es
  1000244D: add         ecx,dword ptr [esi+56h]
  10002450: sub         ecx,dword ptr [eax]
  10002452: add         al,byte ptr [esi]
  10002454: add         ebp,dword ptr [eax]
  10002456: and         dword ptr [eax],eax
  10002458: add         byte ptr [esi],al
  1000245A: sub         cl,ah
  1000245C: or          esi,dword ptr [eax]
  1000245E: add         eax,dword ptr [eax]
  10002460: outs        dx,byte ptr [esi]
  10002461: add         byte ptr [eax],al
  10002463: add         byte ptr [ecx],bl
  10002466: add         byte ptr [ecx],dl
  10002468: add         cl,byte ptr [edi]
  1000246A: add         ebx,dword ptr [edx]
  1000246C: FE
  1000246D: pop         ss
  1000246E: sidt        fword ptr [edx+0Fh]
  10002472: add         cl,byte ptr [edx+33h]
  10002475: add         edx,dword ptr [esi]
  10002477: sub         eax,dword ptr [ecx]
  10002479: pop         ss
  1000247A: shr         byte ptr [edi+edx*2],cl
  1000247D: add         cl,byte ptr [edx+0Ah]
  10002480: push        es
  10002481: or          eax,dword ptr [esi]
  10002483: sub         eax,63BDE02h
  10002488: sidt        fword ptr [edx+4Ah]
  1000248C: push        esp
  1000248D: push        es
  1000248E: sbb         bl,byte ptr [eax+0Fh]
  10002491: add         dword ptr [edx+1Ah],ecx
  10002494: pop         eax
  10002495: sub         byte ptr [ecx],dh
  10002497: add         byte ptr [eax],al
  10002499: push        es
  1000249A: push        es
  1000249C: pop         ds
  1000249D: adc         al,58h
  1000249F: sidt        fword ptr [edx+1Fh]
  100024A3: adc         al,58h
  100024A5: inc         edi
  100024A6: push        edx
  100024A7: fimul       word ptr [edi]
  100024A9: inc         byte ptr [esi]
  100024AB: push        ss
  100024AC: add         byte ptr [eax],al
  100024AE: push        es
  100024AF: pop         es
  100024B0: sbb         bl,byte ptr [eax+28h]
  100024B3: add         eax,dword ptr [ecx]
  100024B5: add         byte ptr [esi],al
  100024B7: fcomp3      st(6)
  100024B9: or          byte ptr [edi],al
  100024BB: push        es
  100024BC: sub         byte ptr [ecx],al
  100024BE: add         byte ptr [eax],al
  100024C0: push        es
  100024C1: fmul        qword ptr [edi]
  100024C3: add         dword ptr [edi],ecx
  100024C5: add         dword ptr [edx+1Fh],ecx
  100024C8: sbb         byte ptr [eax+54h],bl
  100024CB: add         ah,byte ptr ds:[58181F4Ah]
  100024D1: push        esp
  100024D2: sub         ebx,dword ptr [edx+00002A02h]
  100024D8: inc         ecx
  100024D9: xor         al,0
  100024DB: add         byte ptr [eax+eax],al
  100024DE: add         byte ptr [eax],al
  100024E0: xor         eax,dword ptr [eax]
  100024E2: add         byte ptr [eax],al
  100024E4: push        cs
  100024E5: add         byte ptr [eax],al
  100024E7: add         byte ptr [ecx],al
  100024EA: add         byte ptr [eax],al
  100024EC: sldt        word ptr [eax]
  100024EF: add         byte ptr [eax],ah
  100024F1: add         byte ptr [eax],al
  100024F3: add         dword ptr [eax+eax],eax
  100024F6: add         byte ptr [eax],al
  100024F8: sbb         al,byte ptr [eax]
  100024FA: add         byte ptr [eax],al
  100024FC: cmp         byte ptr [eax],al
  100024FE: add         byte ptr [eax],al
  10002500: push        edx
  10002501: add         byte ptr [eax],al
  10002503: add         byte ptr [eax],cl
  10002505: add         byte ptr [eax],al
  10002507: add         byte ptr [eax],ah
  10002509: add         byte ptr [eax],al
  1000250B: add         dword ptr [ebx],ecx
  1000250D: xor         byte ptr [eax],cl
  1000250F: add         dh,ch
  10002511: add         al,byte ptr [eax]
  10002513: add         byte ptr [eax],ah
  10002516: add         byte ptr [ecx],dl
  10002518: add         ebx,dword ptr [edx]
  1000251A: pop         eax
  1000251B: dec         edx
  1000251C: add         ecx,dword ptr [edx+59h]
  1000251F: pop         ds
  10002520: sbb         byte ptr [ebx+18h],bl
  10002523: xor         al,2
  10002525: push        ss
  10002526: sub         bl,byte ptr [edi]
  10002528: xor         al,28h
  1000252A: sbb         eax,13060001h
  1000252F: adc         dword ptr [ecx],edx
  10002531: adc         dword ptr [edx+ecx],ebp
  10002534: adc         dword ptr [ecx],edx
  10002536: sub         byte ptr [ebx],dl
  10002538: add         byte ptr [eax],al
  1000253A: push        es
  1000253B: or          bl,dh
  1000253D: or          al,16h
  1000253F: or          bl,dh
  10002541: or          byte ptr [ecx],dl
  10002543: adc         dword ptr [eax],ebp
  10002545: push        ds
  10002546: add         dword ptr [eax],eax
  10002548: push        es
  10002549: fadd        qword ptr [esi]
  1000254B: add         bl,byte ptr [edx]
  1000254D: pop         eax
  1000254E: dec         edx
  1000254F: push        esp
  10002550: push        es
  10002551: sbb         bl,byte ptr [eax+2]
  10002554: pop         ds
  10002555: or          al,58h
  10002557: dec         ecx
  10002558: push        ebx
  10002559: and         al,byte ptr [eax]
  1000255B: add         byte ptr [eax],al
  1000255D: add         byte ptr [ebx],dl
  1000255F: adc         byte ptr [ebx],al
  10002561: dec         edx
  10002562: pop         ds
  10002563: sbb         byte ptr [eax+0Bh],bl
  10002566: add         ebx,dword ptr [edx]
  10002568: pop         eax
  10002569: dec         edx
  1000256A: adc         ebx,dword ptr [ecx+edx]
  1000256D: sbb         al,13h
  1000256F: sysret
  10002571: adc         dword ptr [edi],ecx
  10002573: cmp         edi,dword ptr [esi]
  10002576: add         byte ptr [eax],al
  10002578: adc         dword ptr [ebx+edx],ebx
  1000257B: movhps      xmm2,qword ptr [ebx]
  1000257E: push        cs
  1000257F: push        ss
  10002580: pop         es
  10002581: pop         ds
  10002582: adc         al,59h
  10002584: pop         ds
  10002585: sbb         al,58h
  10002587: dec         edx
  10002588: pop         es
  10002589: sbb         bl,byte ptr [eax+4Ah]
  1000258C: pop         ecx
  1000258D: sbb         byte ptr [ebx+34h],ah
  10002590: pop         ebx
  10002591: pop         es
  10002592: pop         ds
  10002593: adc         al,59h
  10002595: dec         edx
  10002596: adc         ebx,dword ptr [ebx]
  10002598: adc         dword ptr [ebx],ebx
  1000259A: adc         ecx,dword ptr [edx]
  1000259C: pop         es
  1000259D: sbb         bl,byte ptr [eax+4Ah]
  100025A0: adc         dword ptr [ebx],ebx
  100025A2: pop         ecx
  100025A3: adc         ebp,dword ptr [eax]
  100025A5: adc         dword ptr [eax],ebp
  100025A7: adc         dword ptr [edx],ecx
  100025A9: pop         eax
  100025AA: dec         esi
  100025AB: ins         byte ptr es:[edi],dx
  100025AC: adc         dword ptr [edx],ecx
  100025AE: dec         esi
  100025AF: ins         byte ptr es:[edi],dx
  100025B0: pop         ecx
  100025B1: imul        edx,dword ptr [ebx],27h
  100025B4: adc         dword ptr [edi],esp
  100025B6: ins         byte ptr es:[edi],dx
  100025B7: sub         byte ptr [edi],al
  100025B9: add         byte ptr [eax],al
  100025BB: or          ch,byte ptr [ebx+6Bh]
  100025BE: adc         ebx,dword ptr [edx]
  100025C0: adc         dword ptr [edx],ebx
  100025C2: ins         byte ptr es:[edi],dx
  100025C3: adc         dword ptr [eax],edx
  100025C5: ins         byte ptr es:[edi],dx
  100025C6: add         al,11h
  100025C9: sbb         dl,byte ptr [ebx]
  100025CB: adc         byte ptr [ecx],dl
  100025CD: push        cs
  100025CE: pop         ss
  100025CF: pop         eax
  100025D0: adc         ecx,dword ptr [esi]
  100025D2: adc         dword ptr [edx],ecx
  100025D4: sbb         bl,byte ptr [eax+13h]
  100025D7: or          al,byte ptr [edi]
  100025D9: sbb         bl,byte ptr [eax+13h]
  100025DC: sbb         dword ptr [ecx],edx
  100025DE: push        cs
  100025DF: adc         dword ptr [ecx],ebx
  100025E1: sbb         bl,byte ptr [eax+4Ah]
  100025E4: adc         dword ptr [ecx],ebx
  100025E6: dec         edx
  100025E7: pop         ecx
  100025E8: sbb         byte ptr [ebx+37h],ah
  100025EB: mov         ecx,58181F07h
  100025F0: or          eax,dword ptr [edi]
  100025F2: adc         dword ptr [edi],ecx
  100025F4: xor         eax,dword ptr [esi+11581E06h]
  100025FA: adc         byte ptr [ebx],ch
  100025FE: add         byte ptr [eax],al
  10002600: add         byte ptr [eax],al
  10002602: add         byte ptr [eax+eax*2],bl
  10002605: pop         ebx
  10002606: imul        edx,dword ptr [esi+3],4Ah
  1000260A: sbb         bl,byte ptr [eax+13h]
  1000260D: sbb         byte ptr [ecx],dl
  1000260F: sbb         byte ptr [edx],bl
  10002611: pop         eax
  10002612: dec         edx
  10002613: adc         dword ptr [eax],ebx
  10002615: dec         edx
  10002616: pop         ecx
  10002617: sbb         byte ptr [ebx+0Dh],ah
  1000261A: push        es
  1000261B: pop         ds
  1000261C: xor         byte ptr [eax+9],bl
  1000261F: push        esp
  10002620: push        ss
  10002621: adc         ecx,dword ptr [ecx]
  10002623: push        ss
  10002624: or          dword ptr [edx],esi
  10002627: push        es
  10002628: pop         ds
  10002629: or          al,58h
  1000262B: adc         esp,dword ptr [esi]
  1000262D: adc         dword ptr [esi],esp
  1000262F: adc         dword ptr [ecx],ecx
  10002631: sbb         bl,byte ptr [edx+3]
  10002634: dec         edx
  10002635: sbb         bl,byte ptr [eax+4Ah]
  10002638: pop         eax
  10002639: sub         byte ptr [eax],bl
  1000263B: add         byte ptr [eax],al
  1000263D: push        es
  1000263E: adc         dword ptr [ecx],ecx
  10002640: pop         ss
  10002641: pop         eax
  10002642: adc         ecx,dword ptr [ecx]
  10002644: adc         dword ptr [ecx],ecx
  10002646: or          dword ptr [edi],esi
  10002648: in          al,6
  1000264A: pop         ds
  1000264B: sbb         al,58h
  1000264D: adc         esp,dword ptr ds:[1108131Ah]
  10002653: and         eax,6540811h
  10002658: pop         ds
  10002659: and         byte ptr [eax+28h],bl
  1000265C: sbb         eax,16060000h
  10002661: or          dword ptr [eax+edx],esi
  10002664: push        es
  10002665: pop         ds
  10002666: or          al,58h
  10002668: dec         edx
  10002669: adc         esp,dword ptr [edx+edx]
  1000266C: sub         al,11h
  1000266E: and         al,9
  10002670: sbb         byte ptr [edx-2],ah
  10002673: pop         ss
  10002674: push        ss
  10002675: adc         esp,dword ptr [ebx]
  10002677: pop         ss
  10002678: adc         ecx,dword ptr ds:[4A581A03h]
  1000267E: add         ecx,dword ptr [edx+59h]
  10002681: pop         ds
  10002682: sbb         byte ptr [ebx+1Fh],bl
  10002685: addps       xmm3,xmmword ptr [edx]
  10002688: adc         eax,dword ptr fs:[edi]
  1000268B: adc         dword ptr [edi],eax
  1000268D: cmp         dword ptr [edx+1],esi
  10002690: add         byte ptr [eax],al
  10002692: pop         ds
  10002693: sbb         byte ptr [ebx],dl
  10002695: or          al,11h
  10002697: pop         es
  10002698: pop         ss
  10002699: pop         ecx
  1000269A: adc         eax,dword ptr [edi]
  1000269C: push        ss
  1000269D: adc         eax,dword ptr [esi]
  1000269F: push        ss
  100026A0: or          dword ptr [ecx-19h],eax
  100026A3: add         byte ptr [eax],al
  100026A5: add         byte ptr [edi+ebx],al
  100026A8: or          al,58h
  100026AA: adc         esp,dword ptr [edx]
  100026AC: adc         ch,byte ptr [ebx+edx]
  100026AF: add         eax,5112B12h
  100026B4: dec         esi
  100026B5: push        esi
  100026B6: push        ss
  100026B7: or          al,3
  100026B9: dec         edx
  100026BA: adc         edx,dword ptr [edi]
  100026BC: add         ebx,dword ptr [edx]
  100026BE: pop         eax
  100026BF: dec         edx
  100026C0: adc         dword ptr [edi],edx
  100026C2: pop         ecx
  100026C3: pop         ds
  100026C4: sbb         byte ptr [ebx+13h],bl
  100026C7: and         dword ptr [ecx],edx
  100026C9: push        es
  100026CA: sbb         bl,byte ptr [edx+13h]
  100026CD: and         byte ptr [ecx],dl
  100026CF: pop         ss
  100026D0: adc         dword ptr [eax+ebx*2],ecx
  100026D3: sbb         bl,byte ptr [eax+13h]
  100026D6: or          ecx,dword ptr [eax]
  100026D8: adc         dword ptr ds:[34211158h],ecx
  100026DE: adc         cl,byte ptr [eax]
  100026E0: sbb         bl,byte ptr [edx+12h]
  100026E3: sub         ebx,dword ptr [edx]
  100026E5: pop         eax
  100026E6: pop         eax
  100026E7: adc         dword ptr [eax],esp
  100026E9: adc         dword ptr [ebx],ecx
  100026EB: dec         edx
  100026EC: pop         eax
  100026ED: dec         esi
  100026EE: push        esi
  100026EF: sub         edx,dword ptr [eax]
  100026F1: or          byte ptr [edx],bl
  100026F3: pop         edx
  100026F4: adc         ch,byte ptr [ebx]
  100026F6: sbb         bl,byte ptr [eax+58h]
  100026F9: or          byte ptr [edx],bl
  100026FB: pop         edx
  100026FC: adc         ch,byte ptr [ebx]
  100026FE: pop         eax
  100026FF: dec         esi
  10002700: push        esi
  10002701: or          byte ptr [edi],dl
  10002703: pop         eax
  10002704: or          al,11h
  10002706: or          ebx,dword ptr [edi]
  10002708: sbb         byte ptr [eax+13h],bl
  1000270B: or          ecx,dword ptr [eax]
  1000270D: pop         ds
  1000270E: adc         byte ptr [edi],dh
  10002710: C6
  10002711: adc         eax,0FF221613h
  10002716: FF
  10002717: jg          10002798
  10002719: adc         edx,dword ptr ds:[06041316h]
  1000271F: adc         ch,byte ptr [edx]
  10002721: adc         dword ptr [edx+edx],eax
  10002724: sub         eax,dword ptr [esi]
  10002726: push        ds
  10002727: pop         eax
  10002728: dec         esi
  10002729: push        ss
  1000272A: push        ss
  1000272B: and         al,byte ptr [eax]
  1000272D: add         byte ptr [eax],al
  1000272F: add         byte ptr [eax],ch
  10002731: adc         dword ptr [eax],eax
  10002733: add         byte ptr [esi],al
  10002735: adc         edx,dword ptr [ecx+edx]
  10002738: adc         al,6Ch
  1000273A: adc         dword ptr ds:[1108346Ch],edx
  10002740: add         al,13h
  10002742: push        ss
  10002743: adc         dword ptr [ebx+edx],edx
  10002746: adc         eax,58170411h
  1000274B: adc         eax,dword ptr [ecx+edx]
  1000274E: add         al,20h
  10002750: add         byte ptr [ecx],al
  10002752: add         byte ptr [eax],al
  10002754: xor         cl,al
  10002756: push        es
  10002757: adc         ch,byte ptr [ecx]
  10002759: adc         dword ptr [esi],edx
  1000275B: adc         ch,byte ptr [ebx]
  1000275D: push        es
  1000275E: push        ds
  1000275F: pop         eax
  10002760: dec         esi
  10002761: adc         dword ptr ds:[22112312h],eax
  10002767: dec         esi
  10002768: sub         byte ptr [ecx],dl
  1000276A: add         byte ptr [eax],al
  1000276C: push        es
  1000276D: push        es
  1000276F: pop         ds
  10002770: and         byte ptr [eax+12h],bl
  10002773: sub         dword ptr [eax],ebp
  10002775: sbb         al,0
  10002777: add         byte ptr [esi],al
  10002779: adc         dword ptr [esi],eax
  1000277B: pop         ss
  1000277C: pop         eax
  1000277D: adc         eax,dword ptr [esi]
  1000277F: adc         dword ptr ds:[0513581Ah],eax
  10002785: adc         dword ptr [esi],eax
  10002787: or          dword ptr [ebx-1],eax
  1000278B: FF
  1000278C: call        dword ptr [ecx]
  1000278E: or          eax,1358101Fh
  10002793: or          eax,80200C11h
  10002798: add         dword ptr [eax],eax
  1000279A: add         byte ptr [eax+13h],bl
  1000279D: or          al,11h
  1000279F: pop         es
  100027A0: cmp         dh,cl
  100027A2: FE
  100027A3: FF
  100027A4: call        dword ptr [ecx]
  100027A6: and         ebp,dword ptr [ebx+ebx*2]
  100027A9: adc         dword ptr [eax],ecx
  100027AB: sbb         bl,byte ptr [eax+13h]
  100027AE: or          byte ptr [ecx],dl
  100027B0: or          byte ptr [edi],bl
  100027B2: or          al,3Fh
  100027B4: call        1F13:06FFFFFE
  100027BB: push        es
  100027BC: pop         ds
  100027BD: and         byte ptr [eax+13h],bl
  100027C0: push        ds
  100027C1: adc         dword ptr [esi],ebx
  100027C3: dec         edx
  100027C4: adc         edx,dword ptr [ebx]
  100027C6: adc         dword ptr [ebx],edx
  100027C8: sub         eax,111ADE02h
  100027CD: adc         ebp,dword ptr [eax]
  100027CF: pop         ds
  100027D0: add         dword ptr [eax],eax
  100027D2: push        es
  100027D3: ficom       word ptr [ecx]
  100027D5: inc         byte ptr [esi]
  100027D7: push        ss
  100027D8: add         byte ptr [eax],al
  100027DA: push        es
  100027DB: adc         dword ptr [edi],ebx
  100027DD: pop         ds
  100027DE: or          al,58h
  100027E0: sub         byte ptr [ebx],al
  100027E2: add         dword ptr [eax],eax
  100027E4: push        es
  100027E5: fadd        qword ptr [esi]
  100027E7: pop         ds
  100027E8: or          al,58h
  100027EA: adc         ebx,dword ptr ds:[134A1D11h]
  100027F0: adc         dl,byte ptr [ecx]
  100027F2: adc         ch,byte ptr [edi+eax]
  100027F5: adc         dword ptr [edx],edx
  100027F7: sub         byte ptr [edi],bl
  100027F9: add         dword ptr [eax],eax
  100027FB: push        es
  100027FC: push        es
  100027FD: sub         byte ptr [esi],bl
  100027FF: add         dword ptr [eax],eax
  10002801: push        es
  10002802: push        ss
  10002803: sub         al,byte ptr [esi]
  10002805: sub         al,byte ptr [eax]
  10002807: add         byte ptr [ecx+34h],al
  1000280A: add         byte ptr [eax],al
  1000280C: add         al,0
  1000280E: add         byte ptr [eax],al
  10002810: sbb         byte ptr [eax],al
  10002812: add         byte ptr [eax],al
  10002814: adc         al,byte ptr [eax]
  10002816: add         byte ptr [eax],al
  10002818: sub         al,byte ptr [eax]
  1000281A: add         byte ptr [eax],al
  1000281C: or          byte ptr [eax],al
  1000281E: add         byte ptr [eax],al
  10002820: and         byte ptr [eax],al
  10002822: add         byte ptr [ecx],al
  10002824: add         al,0
  10002826: add         byte ptr [eax],al
  10002828: mov         dword ptr ds:[1A000002h],eax
  1000282D: add         byte ptr [eax],al
  1000282F: add         byte ptr [ebp+11000002h],bh
  10002835: add         byte ptr [eax],al
  10002837: add         byte ptr [eax],ah
  10002839: add         byte ptr [eax],al
  1000283B: add         dword ptr [ebx],eax
  1000283D: xor         byte ptr ds:[00001C00h],al
  10002843: add         byte ptr [edx],ah
  10002846: add         byte ptr [ecx],dl
  10002848: adc         al,byte ptr [edx]
  1000284A: add         al,54h
  1000284C: adc         al,byte ptr [ecx]
  1000284E: add         edx,dword ptr [edx+edx]
  10002852: add         dl,byte ptr [edx+edx+4]
  10002856: push        es
  10002857: pop         es
  10002858: or          byte ptr [ecx],cl
  1000285A: sub         byte ptr [ebx],ch
  1000285C: add         byte ptr [eax],al
  1000285E: push        es
  1000285F: adc         al,byte ptr es:[edx+ecx*2]
  10002863: sub         al,byte ptr [ebx]
  10002865: xor         byte ptr [eax+eax],al
  10002868: adc         al,1
  1000286A: add         byte ptr [eax],al
  1000286C: add         byte ptr gs:[eax],al
  1000286F: adc         dword ptr [edx],eax
  10002871: sbb         bl,byte ptr [eax+13h]
  10002874: push        cs
  10002875: adc         dword ptr [esi],ecx
  10002877: sbb         bl,byte ptr [eax+4Ah]
  1000287A: adc         dword ptr [esi],ecx
  1000287C: dec         edx
  1000287D: pop         ecx
  1000287E: pop         ds
  1000287F: cld
  10002880: pop         edi
  10002881: sub         eax,4050257h
  10002886: sub         byte ptr [edi],al
  10002888: add         byte ptr [eax],al
  1000288A: push        es
  1000288B: adc         ecx,dword ptr ds:[13581A02h]
  10002891: add         eax,581A0511h
  10002896: dec         edx
  10002897: adc         eax,dword ptr [ecx+edx]
  1000289A: add         al,11h
  1000289C: add         eax,344A581Eh
  100028A1: sbb         byte ptr [ecx],dl
  100028A3: add         al,13h
  100028A5: or          al,11h
  100028A7: add         eax,411581Ah
  100028AC: sbb         bl,byte ptr [eax+54h]
  100028AF: adc         dword ptr [esp+ebp],ecx
  100028B2: adc         dl,byte ptr [ecx]
  100028B4: or          al,11h
  100028B6: or          eax,110B2B54h
  100028BB: add         eax,0D120411h
  100028C0: sub         byte ptr [edx],ch
  100028C2: add         byte ptr [eax],al
  100028C4: push        es
  100028C5: adc         dword ptr ds:[025A0C1Fh],ecx
  100028CB: pop         ds
  100028CC: adc         al,58h
  100028CE: dec         edx
  100028CF: pop         eax
  100028D0: dec         edx
  100028D1: adc         ecx,dword ptr [ebx]
  100028D3: add         edx,dword ptr [ecx]
  100028D5: or          edx,dword ptr [ecx+edx+0Bh]
  100028D9: sub         al,byte ptr [edx]
  100028DB: push        ds
  100028DC: pop         eax
  100028DD: dec         edx
  100028DE: sbb         bl,byte ptr [ecx+4Ah]
  100028E1: adc         ecx,dword ptr [edx]
  100028E3: add         al,byte ptr ds:[00072804h]
  100028E9: add         byte ptr [esi],al
  100028EB: adc         eax,dword ptr [esi]
  100028ED: add         bl,byte ptr [edx]
  100028EF: pop         eax
  100028F0: or          eax,4A581A09h
  100028F5: or          al,8
  100028F7: or          dword ptr [esi],ebx
  100028F9: pop         eax
  100028FA: dec         edx
  100028FB: xor         al,15h
  100028FD: or          byte ptr [ebx],dl
  100028FF: or          dword ptr [ecx],ecx
  10002901: sbb         bl,byte ptr [eax+8]
  10002904: sbb         bl,byte ptr [eax+54h]
  10002907: adc         dword ptr [ecx],ecx
  10002909: sub         al,10h
  1000290B: adc         dword ptr [ecx],ecx
  1000290D: adc         dword ptr [esi],eax
  1000290F: push        esp
  10002910: sub         ecx,dword ptr [ecx]
  10002912: or          dword ptr [eax],ecx
  10002914: adc         al,byte ptr [esi]
  10002916: sub         byte ptr [edx],ch
  10002918: add         byte ptr [eax],al
  1000291A: push        es
  1000291B: add         ebp,dword ptr [esp]
  1000291E: adc         cl,byte ptr [edi]
  10002920: adc         dword ptr [edx],ecx
  10002922: push        esp
  10002923: add         bl,byte ptr [edi]
  10002925: adc         al,58h
  10002927: dec         edx
  10002928: adc         ecx,dword ptr [eax]
  1000292A: adc         cl,byte ptr [edi]
  1000292C: sbb         bl,byte ptr [eax+3]
  1000292F: adc         dword ptr [edx],ecx
  10002931: pop         ds
  10002932: or          al,5Ah
  10002934: adc         dword ptr [eax],ecx
  10002936: pop         eax
  10002937: dec         edx
  10002938: pop         ecx
  10002939: push        esp
  1000293A: adc         cl,byte ptr [edi]
  1000293C: push        ds
  1000293D: pop         eax
  1000293E: adc         dword ptr [esi],eax
  10002940: push        esp
  10002941: add         edx,dword ptr [ecx]
  10002943: push        es
  10002944: pop         ds
  10002945: or          al,5Ah
  10002947: adc         dword ptr [eax],ecx
  10002949: pop         eax
  1000294A: dec         edx
  1000294B: push        esp
  1000294C: add         bl,byte ptr [edi]
  1000294E: and         al,58h
  10002950: or          eax,dword ptr [edi]
  10002952: sbb         bl,byte ptr [eax+4Ah]
  10002955: or          al,byte ptr [esi]
  10002957: pop         es
  10002958: push        ds
  10002959: pop         eax
  1000295A: dec         edx
  1000295B: xor         al,19h
  1000295D: push        es
  1000295E: adc         eax,dword ptr [edi]
  10002960: pop         es
  10002961: sbb         bl,byte ptr [eax+6]
  10002964: pop         ds
  10002965: or          al,58h
  10002967: push        esp
  10002968: adc         dword ptr [edi],eax
  1000296A: sub         al,13h
  1000296C: adc         dword ptr [edi],eax
  1000296E: adc         cl,byte ptr [edi]
  10002970: pop         ds
  10002971: or          al,0FEh
  10002973: pop         ss
  10002974: sub         ecx,dword ptr [ecx]
  10002976: pop         es
  10002977: push        es
  10002978: adc         cl,byte ptr [edi]
  1000297A: sub         byte ptr [eax],ah
  1000297C: add         byte ptr [eax],al
  1000297E: push        es
  1000297F: add         ecx,dword ptr [edx+2Ah]
  10002982: push        ss
  10002983: sub         al,byte ptr [ebx]
  10002985: xor         byte ptr [esi],al
  10002987: add         byte ptr ds:[66000000h],bh
  1000298D: add         byte ptr [eax],al
  1000298F: adc         dword ptr [ebx],eax
  10002991: sub         al,1Dh
  10002993: add         ebx,dword ptr [edi]
  10002995: sbb         byte ptr [edx+7Fh],bl
  10002998: add         al,byte ptr [eax]
  1000299A: add         byte ptr [esi+edx],al
  1000299D: push        ss
  1000299E: jg          100029A3
  100029A0: add         byte ptr [eax],al
  100029A2: add         al,20h
  100029A4: rol         dword ptr [eax],1
  100029A6: add         byte ptr [eax],al
  100029A8: sub         byte ptr [edx+0A060000h],ah
  100029AE: sub         eax,dword ptr [edx]
  100029B0: push        ss
  100029B1: or          dl,byte ptr [edx]
  100029B3: add         eax,dword ptr [esi]
  100029B5: push        esp
  100029B6: adc         al,byte ptr [edx]
  100029B8: add         eax,4011254h
  100029BD: push        esp
  100029BE: adc         al,byte ptr ds:[11090807h]
  100029C4: add         al,28h
  100029C6: sub         eax,dword ptr [eax]
  100029C8: add         byte ptr [esi],al
  100029CA: push        es
  100029CC: sub         cl,ah
  100029CE: int         3
  100029CF: int         3
  100029D0: add         esi,dword ptr [eax]
  100029D2: add         eax,dword ptr [eax]
  100029D4: cmp         byte ptr [eax],al
  100029D6: add         byte ptr [eax],al
  100029D8: add         byte ptr [bx+si],al
  100029DB: adc         dword ptr [edx+ecx],eax
  100029DE: add         cl,byte ptr [ebx]
  100029E0: add         al,byte ptr [ebx]
  100029E2: add         al,byte ptr cs:[ecx+ebx*2]
  100029E7: or          al,6
  100029E9: pop         es
  100029EA: dec         edx
  100029EB: push        esp
  100029EC: push        es
  100029ED: sbb         bl,byte ptr [eax+6]
  100029F0: or          byte ptr [eax+1Ah],bl
  100029F3: pop         eax
  100029F4: sub         byte ptr [edx],dh
  100029F6: add         byte ptr [eax],al
  100029F8: push        es
  100029F9: push        es
  100029FB: pop         ds
  100029FC: adc         al,58h
  100029FE: pop         es
  100029FF: pop         ds
  10002A00: adc         al,58h
  10002A02: inc         edi
  10002A03: push        edx
  10002A04: push        es
  10002A05: pop         ds
  10002A06: sbb         byte ptr [eax+0Ah],bl
  10002A09: pop         es
  10002A0A: pop         ds
  10002A0B: sbb         byte ptr [eax+0Bh],bl
  10002A0E: pop         es
  10002A0F: add         esi,dword ptr [ebx]
  10002A11: D6
  10002A12: push        es
  10002A13: sub         al,byte ptr [ebx]
  10002A15: xor         byte ptr [esi],al
  10002A17: add         byte ptr [ebx+eax],dh
  10002A1A: add         byte ptr [eax],al
  10002A1C: ins         byte ptr es:[edi],dx
  10002A1D: add         byte ptr [eax],al
  10002A1F: adc         dword ptr [ebx],eax
  10002A21: add         eax,2817241Fh
  10002A26: push        es
  10002A27: add         byte ptr [eax],al
  10002A29: push        es
  10002A2A: and         byte ptr es:[ecx-31h],ch
  10002A2E: fsub        dword ptr [eax+13h]
  10002A31: sbb         al,4
  10002A33: inc         edi
  10002A34: sub         al,24h
  10002A36: adc         ah,byte ptr [edi+ebx]
  10002A39: pushad
  10002A3A: push        edx
  10002A3B: adc         ah,byte ptr [edi+edx]
  10002A3E: pop         eax
  10002A3F: and         al,bl
  10002A41: add         byte ptr [eax],al
  10002A43: add         byte ptr [edx+12h],dl
  10002A46: and         al,18h
  10002A48: pop         eax
  10002A49: and         bh,cl
  10002A4B: add         byte ptr [eax],al
  10002A4D: add         byte ptr [edx+12h],dl
  10002A50: and         al,19h
  10002A52: pop         eax
  10002A53: pop         ds
  10002A54: imul        edx,dword ptr [edx+11h],51C1324h
  10002A5B: dec         edx
  10002A5C: adc         dword ptr [esp+edx*2],ebx
  10002A5F: add         cl,byte ptr [edx+13h]
  10002A62: sbb         eax,dword ptr [edi+eax*2]
  10002A65: sub         al,28h
  10002A67: adc         ah,byte ptr [ebx]
  10002A69: adc         bl,byte ptr [ebx]
  10002A6B: sbb         dword ptr [eax+47h],ebx
  10002A6E: push        edx
  10002A6F: adc         ah,byte ptr [ebx]
  10002A71: pop         ss
  10002A72: pop         eax
  10002A73: adc         bl,byte ptr [ebx]
  10002A75: sbb         byte ptr [eax+47h],bl
  10002A78: push        edx
  10002A79: adc         ah,byte ptr [ebx]
  10002A7B: sbb         byte ptr [eax+12h],bl
  10002A7E: sbb         edx,dword ptr [edi]
  10002A80: pop         eax
  10002A81: inc         edi
  10002A82: push        edx
  10002A83: adc         ah,byte ptr [ebx]
  10002A85: sbb         dword ptr [eax+12h],ebx
  10002A88: sbb         eax,dword ptr [edi+52h]
  10002A8B: adc         dword ptr [ebx],esp
  10002A8D: adc         ebx,dword ptr [ebx]
  10002A8F: add         eax,11581A4Ah
  10002A94: sbb         edx,dword ptr [edx+eax+1Eh]
  10002A98: pop         eax
  10002A99: adc         ebx,dword ptr [edx]
  10002A9B: adc         dword ptr [edx],ebx
  10002A9D: sbb         bl,byte ptr [eax+4Ah]
  10002AA0: adc         dword ptr [edx],ebx
  10002AA2: dec         edx
  10002AA3: pop         ecx
  10002AA4: pop         ds
  10002AA5: sbb         byte ptr [ebx+13h],bl
  10002AA8: sbb         dword ptr [edi+eax*2],eax
  10002AAB: sub         al,28h
  10002AAD: adc         ah,byte ptr [edx]
  10002AAF: adc         bl,byte ptr [ecx]
  10002AB1: sbb         dword ptr [eax+47h],ebx
  10002AB4: push        edx
  10002AB5: adc         ah,byte ptr [edx]
  10002AB7: pop         ss
  10002AB8: pop         eax
  10002AB9: adc         bl,byte ptr [ecx]
  10002ABB: sbb         byte ptr [eax+47h],bl
  10002ABE: push        edx
  10002ABF: adc         ah,byte ptr [edx]
  10002AC1: sbb         byte ptr [eax+12h],bl
  10002AC4: sbb         dword ptr [edi],edx
  10002AC6: pop         eax
  10002AC7: inc         edi
  10002AC8: push        edx
  10002AC9: adc         ah,byte ptr [edx]
  10002ACB: sbb         dword ptr [eax+12h],ebx
  10002ACE: sbb         dword ptr [edi+52h],eax
  10002AD1: adc         dword ptr [edx],esp
  10002AD3: adc         ebx,dword ptr [ecx]
  10002AD5: add         eax,11581E4Ah
  10002ADA: sbb         dword ptr [edx+eax+1Eh],edx
  10002ADE: pop         eax
  10002ADF: adc         ebx,dword ptr [eax]
  10002AE1: adc         dword ptr [eax],ebx
  10002AE3: dec         edx
  10002AE4: adc         dword ptr [eax],ebx
  10002AE6: sbb         bl,byte ptr [eax+4Ah]
  10002AE9: inc         byte ptr [ecx]
  10002AEB: shr         byte ptr [eax+2B171317h],cl
  10002AF2: adc         eax,4A581E02h
  10002AF7: sbb         bl,byte ptr [eax+13h]
  10002AFA: push        ss
  10002AFB: adc         dword ptr [esi],edx
  10002AFD: sbb         bl,byte ptr [eax+4Ah]
  10002B00: adc         dword ptr [esi],edx
  10002B02: dec         edx
  10002B03: pop         ecx
  10002B04: sbb         byte ptr [ebx+13h],ah
  10002B07: pop         ss
  10002B08: adc         dword ptr [edi],edx
  10002B0A: adc         edx,dword ptr ds:[282C4704h]
  10002B10: adc         ah,byte ptr [ecx]
  10002B12: adc         dl,byte ptr [edi]
  10002B14: sbb         dword ptr [eax+47h],ebx
  10002B17: push        edx
  10002B18: adc         ah,byte ptr [ecx]
  10002B1A: pop         ss
  10002B1B: pop         eax
  10002B1C: adc         dl,byte ptr [edi]
  10002B1E: sbb         byte ptr [eax+47h],bl
  10002B21: push        edx
  10002B22: adc         ah,byte ptr [ecx]
  10002B24: sbb         byte ptr [eax+12h],bl
  10002B27: pop         ss
  10002B28: pop         ss
  10002B29: pop         eax
  10002B2A: inc         edi
  10002B2B: push        edx
  10002B2C: adc         ah,byte ptr [ecx]
  10002B2E: sbb         dword ptr [eax+12h],ebx
  10002B31: pop         ss
  10002B32: inc         edi
  10002B33: push        edx
  10002B34: adc         dword ptr [ecx],esp
  10002B36: adc         edx,dword ptr ds:[0C1F4A05h]
  10002B3C: pop         eax
  10002B3D: adc         dword ptr ds:[581A0254h],edx
  10002B43: dec         ecx
  10002B44: adc         edx,dword ptr [esp+eax]
  10002B47: inc         edi
  10002B48: sub         al,14h
  10002B4A: adc         ah,byte ptr [eax]
  10002B4C: adc         dl,byte ptr [edi+edx]
  10002B4F: pop         eax
  10002B50: inc         edi
  10002B51: push        edx
  10002B52: adc         ah,byte ptr [eax]
  10002B54: pop         ss
  10002B55: pop         eax
  10002B56: adc         dl,byte ptr [edi+eax*2]
  10002B59: push        edx
  10002B5A: adc         dword ptr [eax],esp
  10002B5C: adc         edx,dword ptr [eax+58101F4Ah]
  10002B63: adc         dword ptr [ebx+edx*2],edx
  10002B66: add         bl,byte ptr [esi]
  10002B68: pop         eax
  10002B69: adc         edx,dword ptr [ebx]
  10002B6B: add         bl,byte ptr [esi]
  10002B6D: pop         eax
  10002B6E: dec         edx
  10002B6F: sbb         bl,byte ptr [eax+13h]
  10002B72: adc         dl,byte ptr [ecx]
  10002B74: adc         bl,byte ptr [edx]
  10002B76: pop         eax
  10002B77: dec         edx
  10002B78: adc         dword ptr [edx],edx
  10002B7A: dec         edx
  10002B7B: pop         ecx
  10002B7C: sbb         byte ptr [ebx+11h],ah
  10002B7F: adc         ebx,dword ptr [edx]
  10002B81: pop         eax
  10002B82: dec         edx
  10002B83: adc         dword ptr [ebx],edx
  10002B85: dec         edx
  10002B86: pop         ecx
  10002B87: pop         ds
  10002B88: sbb         byte ptr [ebx+5Ah],bl
  10002B8B: adc         edx,dword ptr [ecx]
  10002B8D: add         al,47h
  10002B8F: sub         al,28h
  10002B91: adc         bl,byte ptr [edi]
  10002B93: adc         dl,byte ptr [ecx]
  10002B95: sbb         dword ptr [eax+47h],ebx
  10002B98: push        edx
  10002B99: adc         bl,byte ptr [edi]
  10002B9B: pop         ss
  10002B9C: pop         eax
  10002B9D: adc         dl,byte ptr [ecx]
  10002B9F: sbb         byte ptr [eax+47h],bl
  10002BA2: push        edx
  10002BA3: adc         bl,byte ptr [edi]
  10002BA5: sbb         byte ptr [eax+12h],bl
  10002BA8: adc         dword ptr [edi],edx
  10002BAA: pop         eax
  10002BAB: inc         edi
  10002BAC: push        edx
  10002BAD: adc         bl,byte ptr [edi]
  10002BAF: sbb         dword ptr [eax+12h],ebx
  10002BB2: adc         dword ptr [edi+52h],eax
  10002BB5: adc         dword ptr [edi],ebx
  10002BB7: adc         edx,dword ptr [ecx]
  10002BB9: add         eax,581C1F4Ah
  10002BBE: adc         dword ptr [ecx],edx
  10002BC0: push        esp
  10002BC1: add         bl,byte ptr [esi]
  10002BC3: pop         eax
  10002BC4: adc         edx,dword ptr [eax]
  10002BC6: adc         dword ptr [eax],edx
  10002BC8: sbb         bl,byte ptr [eax+4Ah]
  10002BCB: adc         dword ptr [eax],edx
  10002BCD: dec         edx
  10002BCE: pop         ecx
  10002BCF: pop         ds
  10002BD0: sbb         byte ptr [ebx+13h],bl
  10002BD3: 0F
  10002BD4: add         al,47h
  10002BD6: sub         al,28h
  10002BD8: adc         bl,byte ptr [esi]
  10002BDA: adc         cl,byte ptr [edi]
  10002BDC: sbb         dword ptr [eax+47h],ebx
  10002BDF: push        edx
  10002BE0: adc         bl,byte ptr [esi]
  10002BE2: pop         ss
  10002BE3: pop         eax
  10002BE4: adc         cl,byte ptr [edi]
  10002BE6: sbb         byte ptr [eax+47h],bl
  10002BE9: push        edx
  10002BEA: adc         bl,byte ptr [esi]
  10002BEC: sbb         byte ptr [eax+12h],bl
  10002BEF: movhps      qword ptr [eax+47h],xmm3
  10002BF3: push        edx
  10002BF4: adc         bl,byte ptr [esi]
  10002BF6: sbb         dword ptr [eax+12h],ebx
  10002BF9: cmova       edx,dword ptr [edx+11h]
  10002BFD: push        ds
  10002BFE: adc         ecx,dword ptr [edi]
  10002C00: add         eax,58141F4Ah
  10002C05: adc         dword ptr [edi],ecx
  10002C07: push        esp
  10002C08: add         bl,byte ptr [esi]
  10002C0A: pop         eax
  10002C0B: adc         ecx,dword ptr [esi]
  10002C0D: adc         dword ptr [esi],ecx
  10002C0F: dec         edx
  10002C10: adc         dword ptr [esi],ecx
  10002C12: sbb         bl,byte ptr [eax+4Ah]
  10002C15: inc         byte ptr [ecx]
  10002C17: sar         byte ptr [edx],cl
  10002C19: daa
  10002C1A: add         dword ptr [eax],eax
  10002C1C: add         byte ptr [edx],al
  10002C1E: push        ds
  10002C1F: pop         eax
  10002C20: adc         ecx,dword ptr ds:[4A581E02h]
  10002C26: sbb         bl,byte ptr [eax+13h]
  10002C29: or          al,3
  10002C2B: add         eax,58201F4Ah
  10002C30: sbb         dl,byte ptr [ecx]
  10002C32: or          al,1Ah
  10002C34: pop         eax
  10002C35: dec         edx
  10002C36: adc         dword ptr [edx+ecx*2],ecx
  10002C39: pop         ecx
  10002C3A: sbb         byte ptr [ebx+11h],ah
  10002C3D: or          eax,114A581Ah
  10002C42: or          eax,181F594Ah
  10002C47: pop         ebx
  10002C48: pop         edx
  10002C49: sub         byte ptr [esi],al
  10002C4B: add         byte ptr [eax],al
  10002C4D: push        es
  10002C4E: add         ebx,dword ptr es:[edx]
  10002C51: pop         eax
  10002C52: adc         ecx,dword ptr [ebx]
  10002C54: adc         dword ptr [ebx],ecx
  10002C56: sbb         bl,byte ptr [eax+11h]
  10002C59: or          ebx,dword ptr [edx]
  10002C5B: pop         eax
  10002C5C: dec         edx
  10002C5D: pop         ds
  10002C5E: cld
  10002C5F: pop         eax
  10002C60: push        esp
  10002C61: add         eax,110A134Ah
  10002C66: or          bl,byte ptr [edi]
  10002C68: and         byte ptr [eax+4Ah],bl
  10002C6B: adc         eax,dword ptr [edi]
  10002C6D: add         bl,byte ptr [esi]
  10002C6F: pop         eax
  10002C70: adc         ecx,dword ptr [ecx]
  10002C72: add         edx,dword ptr [ecx]
  10002C74: or          bl,byte ptr [edi]
  10002C76: sbb         byte ptr [eax+18h],bl
  10002C79: adc         dword ptr [ecx],ecx
  10002C7B: sbb         bl,byte ptr [eax+4Ah]
  10002C7E: adc         dword ptr [ecx],ecx
  10002C80: dec         edx
  10002C81: pop         ecx
  10002C82: pop         ds
  10002C83: sbb         byte ptr [ebx+28h],bl
  10002C86: push        es
  10002C87: add         byte ptr [eax],al
  10002C89: push        es
  10002C8A: add         ebx,dword ptr es:[edx]
  10002C8D: pop         eax
  10002C8E: adc         ecx,dword ptr [eax]
  10002C90: adc         dword ptr [eax],ecx
  10002C92: sbb         bl,byte ptr [eax+11h]
  10002C95: or          byte ptr [edx],bl
  10002C97: pop         eax
  10002C98: dec         edx
  10002C99: pop         ds
  10002C9A: cld
  10002C9B: pop         eax
  10002C9C: push        esp
  10002C9D: add         eax,58181F4Ah
  10002CA2: dec         edx
  10002CA3: adc         eax,dword ptr [esi]
  10002CA5: push        ss
  10002CA6: adc         eax,dword ptr ds:[0B581E02h]
  10002CAC: push        ss
  10002CAD: pop         es
  10002CAE: sbb         bl,byte ptr [eax+4Ah]
  10002CB1: pop         es
  10002CB2: dec         edx
  10002CB3: pop         ecx
  10002CB4: pop         ds
  10002CB5: sbb         byte ptr [ebx+41h],bl
  10002CB8: mov         byte ptr [eax],al
  10002CBA: add         byte ptr [eax],al
  10002CBC: push        ss
  10002CBD: adc         eax,dword ptr [edx+eax]
  10002CC0: push        ds
  10002CC1: pop         eax
  10002CC2: dec         edx
  10002CC3: adc         dword ptr [eax+ebx*2],eax
  10002CC6: or          al,byte ptr [esi]
  10002CC8: dec         edx
  10002CC9: ror         dword ptr ds:[58141F06h],1
  10002CCF: inc         edi
  10002CD0: sub         al,8
  10002CD2: or          dword ptr [eax],esp
  10002CD4: add         byte ptr [eax+0D600000h],al
  10002CDA: adc         dword ptr [esi],eax
  10002CDC: add         al,9
  10002CDE: sub         byte ptr [eax+eax],al
  10002CE1: add         byte ptr [esi],al
  10002CE3: push        ebx
  10002CE4: adc         dword ptr [esi],eax
  10002CE6: sbb         byte ptr [eax+13h],bl
  10002CE9: push        es
  10002CEA: push        ss
  10002CEB: or          al,16h
  10002CED: push        es
  10002CEE: sbb         bl,byte ptr [eax+28h]
  10002CF1: pop         ss
  10002CF2: add         byte ptr [eax],al
  10002CF4: push        es
  10002CF5: xor         al,2Bh
  10002CF7: or          byte ptr [edx],bl
  10002CF9: pop         edx
  10002CFA: push        es
  10002CFB: sbb         bl,byte ptr [eax+4Ah]
  10002CFE: pop         eax
  10002CFF: adc         ebx,dword ptr ds:[11040711h]
  10002D05: sbb         eax,5284Eh
  10002D0A: add         byte ptr [esi],al
  10002D0C: push        esi
  10002D0D: adc         dword ptr [edi],eax
  10002D0F: sbb         bl,byte ptr [eax+13h]
  10002D12: pop         es
  10002D13: or          byte ptr [edi],dl
  10002D15: pop         eax
  10002D16: or          al,8
  10002D18: push        es
  10002D19: sbb         bl,byte ptr [eax+28h]
  10002D1C: pop         ss
  10002D1D: add         byte ptr [eax],al
  10002D1F: push        es
  10002D20: aaa
  10002D21: aadb        11h
  10002D23: add         eax,5135817h
  10002D28: adc         dword ptr [edi+ebx],eax
  10002D2B: sbb         byte ptr [eax+13h],bl
  10002D2E: add         al,2
  10002D30: push        ds
  10002D31: pop         eax
  10002D32: or          edx,dword ptr [ecx]
  10002D34: add         eax,4A581A07h
  10002D39: pop         es
  10002D3A: dec         edx
  10002D3B: pop         ecx
  10002D3C: pop         ds
  10002D3D: sbb         byte ptr [ebx+44h],bl
  10002D40: jnp         10002D41
  10002D42: FF
  10002D43: inc         dword ptr [ebx]
  10002D45: sbb         bl,byte ptr [eax+1Ah]
  10002D48: pop         eax
  10002D49: add         ebx,dword ptr [edx]
  10002D4B: pop         eax
  10002D4C: sbb         bl,byte ptr [eax+4Ah]
  10002D4F: pop         ds
  10002D50: cld
  10002D51: pop         eax
  10002D52: push        esp
  10002D53: sub         al,byte ptr [ebx]
  10002D55: xor         byte ptr ds:[0003AC00h],al
  10002D5B: add         byte ptr [edi],ch
  10002D5E: add         byte ptr [ecx],dl
  10002D60: add         eax,dword ptr ds:[28172C1Fh]
  10002D66: push        es
  10002D67: add         byte ptr [eax],al
  10002D69: push        es
  10002D6A: and         byte ptr es:[1377F973h],al
  10002D71: sbb         byte ptr [edi+eax*2],al
  10002D74: sub         al,20h
  10002D76: adc         ah,byte ptr ds:[1252771Fh]
  10002D7C: and         eax,0F9205817h
  10002D81: add         byte ptr [eax],al
  10002D83: add         byte ptr [edx+12h],dl
  10002D86: and         eax,731F5818h
  10002D8B: push        edx
  10002D8C: adc         ah,byte ptr ds:[521B5819h]
  10002D92: adc         dword ptr ds:[4A051813h],esp
  10002D98: adc         dword ptr [eax],ebx
  10002D9A: push        esp
  10002D9B: add         cl,byte ptr [edx+13h]
  10002D9E: pop         ss
  10002D9F: add         al,47h
  10002DA1: sub         al,28h
  10002DA3: adc         ah,byte ptr [edx+edx]
  10002DA6: pop         ss
  10002DA7: sbb         dword ptr [eax+47h],ebx
  10002DAA: push        edx
  10002DAB: adc         ah,byte ptr [edi+edx]
  10002DAE: pop         eax
  10002DAF: adc         dl,byte ptr [edi]
  10002DB1: sbb         byte ptr [eax+47h],bl
  10002DB4: push        edx
  10002DB5: adc         ah,byte ptr [eax+ebx]
  10002DB8: pop         eax
  10002DB9: adc         dl,byte ptr [edi]
  10002DBB: pop         ss
  10002DBC: pop         eax
  10002DBD: inc         edi
  10002DBE: push        edx
  10002DBF: adc         ah,byte ptr [ecx+ebx]
  10002DC2: pop         eax
  10002DC3: adc         dl,byte ptr [edi]
  10002DC5: inc         edi
  10002DC6: push        edx
  10002DC7: adc         dword ptr [ebx+edx],esp
  10002DCA: pop         ss
  10002DCB: add         eax,11581A4Ah
  10002DD0: pop         ss
  10002DD1: push        esp
  10002DD2: add         bl,byte ptr [edi]
  10002DD4: and         byte ptr [eax+13h],bl
  10002DD7: push        ss
  10002DD8: adc         dword ptr [esi],edx
  10002DDA: sbb         bl,byte ptr [eax+4Ah]
  10002DDD: adc         dword ptr [esi],edx
  10002DDF: dec         edx
  10002DE0: pop         ecx
  10002DE1: pop         ds
  10002DE2: adc         dword ptr [ebx+2],ebx
  10002DE5: pop         ds
  10002DE6: xor         byte ptr [eax+4Ah],bl
  10002DE9: pop         esp
  10002DEA: pop         ds
  10002DEB: adc         byte ptr [edx+13h],bl
  10002DEE: adc         eax,282C4704h
  10002DF3: adc         ah,byte ptr [ebx]
  10002DF5: adc         dl,byte ptr ds:[52475819h]
  10002DFB: adc         ah,byte ptr [ebx]
  10002DFD: pop         ss
  10002DFE: pop         eax
  10002DFF: adc         dl,byte ptr ds:[52475818h]
  10002E05: adc         ah,byte ptr [ebx]
  10002E07: sbb         byte ptr [eax+12h],bl
  10002E0A: adc         eax,52475817h
  10002E0F: adc         ah,byte ptr [ebx]
  10002E11: sbb         dword ptr [eax+12h],ebx
  10002E14: adc         eax,23115247h
  10002E19: adc         edx,dword ptr ds:[581E4A05h]
  10002E1F: adc         dword ptr ds:[301F0254h],edx
  10002E25: pop         eax
  10002E26: dec         edx
  10002E27: adc         edx,dword ptr [esp+eax]
  10002E2A: inc         edi
  10002E2B: sub         al,28h
  10002E2D: adc         ah,byte ptr [edx]
  10002E2F: adc         dl,byte ptr [ecx+ebx]
  10002E32: pop         eax
  10002E33: inc         edi
  10002E34: push        edx
  10002E35: adc         ah,byte ptr [edx]
  10002E37: pop         ss
  10002E38: pop         eax
  10002E39: adc         dl,byte ptr [eax+ebx]
  10002E3C: pop         eax
  10002E3D: inc         edi
  10002E3E: push        edx
  10002E3F: adc         ah,byte ptr [edx]
  10002E41: sbb         byte ptr [eax+12h],bl
  10002E44: adc         al,17h
  10002E46: pop         eax
  10002E47: inc         edi
  10002E48: push        edx
  10002E49: adc         ah,byte ptr [edx]
  10002E4B: sbb         dword ptr [eax+12h],ebx
  10002E4E: adc         al,47h
  10002E50: push        edx
  10002E51: adc         dword ptr [edx],esp
  10002E53: adc         edx,dword ptr [eax+580C1F4Ah]
  10002E5A: adc         dword ptr [esp+edx*2],edx
  10002E5D: add         bl,byte ptr [edx]
  10002E5F: pop         eax
  10002E60: dec         ecx
  10002E61: adc         edx,dword ptr [ebx]
  10002E63: add         al,47h
  10002E65: sub         al,14h
  10002E67: adc         ah,byte ptr [ecx]
  10002E69: adc         dl,byte ptr [ebx]
  10002E6B: pop         ss
  10002E6C: pop         eax
  10002E6D: inc         edi
  10002E6E: push        edx
  10002E6F: adc         ah,byte ptr [ecx]
  10002E71: pop         ss
  10002E72: pop         eax
  10002E73: adc         dl,byte ptr [ebx]
  10002E75: inc         edi
  10002E76: push        edx
  10002E77: adc         dword ptr [ecx],esp
  10002E79: adc         edx,dword ptr [ebx]
  10002E7B: add         eax,58101F4Ah
  10002E80: adc         dword ptr [ebx],edx
  10002E82: push        ebx
  10002E83: add         bl,byte ptr [esi]
  10002E85: pop         eax
  10002E86: dec         esi
  10002E87: adc         esp,dword ptr [eax]
  10002E89: add         al,47h
  10002E8B: sub         al,29h
  10002E8D: adc         bl,byte ptr [edi]
  10002E8F: adc         ah,byte ptr [eax]
  10002E91: sbb         dword ptr [eax+47h],ebx
  10002E94: push        edx
  10002E95: adc         bl,byte ptr [edi]
  10002E97: pop         ss
  10002E98: pop         eax
  10002E99: adc         ah,byte ptr [eax]
  10002E9B: sbb         byte ptr [eax+47h],bl
  10002E9E: push        edx
  10002E9F: adc         bl,byte ptr [edi]
  10002EA1: sbb         byte ptr [eax+12h],bl
  10002EA4: and         byte ptr [edi],dl
  10002EA6: pop         eax
  10002EA7: inc         edi
  10002EA8: push        edx
  10002EA9: adc         bl,byte ptr [edi]
  10002EAB: sbb         dword ptr [eax+12h],ebx
  10002EAE: and         byte ptr [edi+52h],al
  10002EB1: adc         ah,byte ptr [eax]
  10002EB3: adc         dword ptr [edi],ebx
  10002EB5: push        esp
  10002EB6: add         eax,58141F4Ah
  10002EBB: adc         dword ptr [eax],esp
  10002EBD: push        esi
  10002EBE: add         bl,byte ptr [edi]
  10002EC0: sbb         al,58h
  10002EC2: dec         edx
  10002EC3: adc         edx,dword ptr [edx]
  10002EC5: add         al,47h
  10002EC7: sub         al,28h
  10002EC9: adc         bl,byte ptr [esi]
  10002ECB: adc         dl,byte ptr [edx]
  10002ECD: sbb         dword ptr [eax+47h],ebx
  10002ED0: push        edx
  10002ED1: adc         bl,byte ptr [esi]
  10002ED3: pop         ss
  10002ED4: pop         eax
  10002ED5: adc         dl,byte ptr [edx]
  10002ED7: sbb         byte ptr [eax+47h],bl
  10002EDA: push        edx
  10002EDB: adc         bl,byte ptr [esi]
  10002EDD: sbb         byte ptr [eax+12h],bl
  10002EE0: adc         dl,byte ptr [edi]
  10002EE2: pop         eax
  10002EE3: inc         edi
  10002EE4: push        edx
  10002EE5: adc         bl,byte ptr [esi]
  10002EE7: sbb         dword ptr [eax+12h],ebx
  10002EEA: adc         al,byte ptr [edi+52h]
  10002EED: adc         dword ptr [esi],ebx
  10002EEF: adc         edx,dword ptr [edx]
  10002EF1: add         eax,58201F4Ah
  10002EF6: adc         dword ptr [edx],edx
  10002EF8: push        esp
  10002EF9: add         bl,byte ptr [edi]
  10002EFB: or          al,58h
  10002EFD: adc         edx,dword ptr [ecx]
  10002EFF: adc         dword ptr [ecx],edx
  10002F01: sbb         bl,byte ptr [eax+4Ah]
  10002F04: adc         dword ptr [ecx],edx
  10002F06: dec         edx
  10002F07: pop         ecx
  10002F08: sbb         byte ptr [ebx+13h],ah
  10002F0B: adc         byte ptr [edi+eax*2],al
  10002F0E: sub         al,28h
  10002F10: adc         bl,byte ptr ds:[58191012h]
  10002F16: inc         edi
  10002F17: push        edx
  10002F18: adc         bl,byte ptr ds:[10125817h]
  10002F1E: sbb         byte ptr [eax+47h],bl
  10002F21: push        edx
  10002F22: adc         bl,byte ptr ds:[10125818h]
  10002F28: pop         ss
  10002F29: pop         eax
  10002F2A: inc         edi
  10002F2B: push        edx
  10002F2C: adc         bl,byte ptr ds:[10125819h]
  10002F32: inc         edi
  10002F33: push        edx
  10002F34: adc         dword ptr ds:[4A051013h],ebx
  10002F3A: pop         ds
  10002F3B: sbb         byte ptr [eax+11h],bl
  10002F3E: adc         byte ptr [edx+eax+1Fh],dl
  10002F42: or          al,58h
  10002F44: adc         ecx,dword ptr [edi]
  10002F46: add         eax,dword ptr ds:[581C1F4Ah]
  10002F4C: sbb         dl,byte ptr [ecx]
  10002F4E: bndldx      bnd3,dword ptr [eax+4Ah]
  10002F52: adc         dword ptr [edi],ecx
  10002F54: dec         edx
  10002F55: pop         ecx
  10002F56: sbb         byte ptr [ebx+28h],ah
  10002F59: push        es
  10002F5A: add         byte ptr [eax],al
  10002F5C: push        es
  10002F5D: add         ebx,dword ptr es:[edx]
  10002F60: pop         eax
  10002F61: adc         ecx,dword ptr [esi]
  10002F63: adc         dword ptr [esi],ecx
  10002F65: sbb         bl,byte ptr [eax+11h]
  10002F68: push        cs
  10002F69: sbb         bl,byte ptr [eax+4Ah]
  10002F6C: pop         ds
  10002F6D: cld
  10002F6E: pop         eax
  10002F6F: push        esp
  10002F70: push        ss
  10002F71: or          eax,580C1F02h
  10002F76: or          al,16h
  10002F78: or          byte ptr [edx],bl
  10002F7A: pop         eax
  10002F7B: dec         edx
  10002F7C: or          byte ptr [edx+59h],cl
  10002F7F: sbb         byte ptr [ebx+34h],ah
  10002F82: pop         ebx
  10002F83: or          dword ptr [edx],ebx
  10002F85: pop         edx
  10002F86: add         bl,byte ptr [edi]
  10002F88: or          al,58h
  10002F8A: dec         edx
  10002F8B: pop         eax
  10002F8C: dec         esi
  10002F8D: adc         ebx,dword ptr [esp+eax]
  10002F90: inc         edi
  10002F91: sub         al,29h
  10002F93: adc         bl,byte ptr [ebx]
  10002F95: adc         bl,byte ptr [ecx+ebx]
  10002F98: pop         eax
  10002F99: inc         edi
  10002F9A: push        edx
  10002F9B: adc         bl,byte ptr [ebx]
  10002F9D: pop         ss
  10002F9E: pop         eax
  10002F9F: adc         bl,byte ptr [eax+ebx]
  10002FA2: pop         eax
  10002FA3: inc         edi
  10002FA4: push        edx
  10002FA5: adc         bl,byte ptr [ebx]
  10002FA7: sbb         byte ptr [eax+12h],bl
  10002FAA: sbb         al,17h
  10002FAC: pop         eax
  10002FAD: inc         edi
  10002FAE: push        edx
  10002FAF: adc         bl,byte ptr [ebx]
  10002FB1: sbb         dword ptr [eax+12h],ebx
  10002FB4: sbb         al,47h
  10002FB6: push        edx
  10002FB7: adc         bl,byte ptr [ecx+edx]
  10002FBA: sbb         edx,dword ptr [ebp+eax+4Ah]
  10002FBE: pop         ds
  10002FBF: sbb         al,58h
  10002FC1: dec         edx
  10002FC2: or          dword ptr [edx],ebx
  10002FC4: pop         edx
  10002FC5: pop         eax
  10002FC6: adc         dword ptr [esi+edx*2],ebx
  10002FC9: or          dword ptr [edi],edx
  10002FCB: pop         eax
  10002FCC: or          eax,580C1F02h
  10002FD1: or          al,9
  10002FD3: or          byte ptr [edx],bl
  10002FD5: pop         eax
  10002FD6: dec         edx
  10002FD7: or          byte ptr [edx+59h],cl
  10002FDA: sbb         byte ptr [ebx+37h],ah
  10002FDD: movs        dword ptr es:[edi],dword ptr [esi]
  10002FDE: add         bl,byte ptr [edi]
  10002FE0: sbb         al,58h
  10002FE2: dec         edx
  10002FE3: sbb         ch,byte ptr [esi]
  10002FE5: add         al,1Fh
  10002FE7: adc         dword ptr [ebx],ebp
  10002FE9: add         bl,byte ptr [edi]
  10002FEB: or          dword ptr [ebx],edx
  10002FED: sbb         al,byte ptr [edx]
  10002FEF: pop         ds
  10002FF0: and         byte ptr [eax+13h],bl
  10002FF3: or          eax,581A0D11h
  10002FF8: dec         edx
  10002FF9: adc         dword ptr ds:[111F594Ah],ecx
  10002FFF: pop         ebx
  10003000: adc         dword ptr [edx],ebx
  10003002: pop         edx
  10003003: adc         ecx,dword ptr [ecx+edx]
  10003006: or          al,13h
  10003008: or          eax,dword ptr [edi+eax*2]
  1000300B: sub         al,28h
  1000300D: adc         bl,byte ptr [ecx]
  1000300F: adc         cl,byte ptr [ecx+ebx]
  10003012: pop         eax
  10003013: inc         edi
  10003014: push        edx
  10003015: adc         bl,byte ptr [ecx]
  10003017: pop         ss
  10003018: pop         eax
  10003019: adc         cl,byte ptr [eax+ebx]
  1000301C: pop         eax
  1000301D: inc         edi
  1000301E: push        edx
  1000301F: adc         bl,byte ptr [ecx]
  10003021: sbb         byte ptr [eax+12h],bl
  10003024: or          al,17h
  10003026: pop         eax
  10003027: inc         edi
  10003028: push        edx
  10003029: adc         bl,byte ptr [ecx]
  1000302B: sbb         dword ptr [eax+12h],ebx
  1000302E: or          al,47h
  10003030: push        edx
  10003031: adc         dword ptr [ecx],ebx
  10003033: adc         ecx,dword ptr [ebx]
  10003035: add         eax,58241F4Ah
  1000303A: adc         dword ptr [ebx],ecx
  1000303C: push        esp
  1000303D: add         eax,dword ptr ds:[58281F4Ah]
  10003043: pop         ss
  10003044: adc         dword ptr [eax+ebp],ecx
  10003047: push        es
  10003048: add         byte ptr [eax],al
  1000304A: push        es
  1000304B: add         ebx,dword ptr es:[edx]
  1000304E: pop         eax
  1000304F: adc         ecx,dword ptr [edx]
  10003051: adc         dword ptr [edx],ecx
  10003053: sbb         bl,byte ptr [eax+11h]
  10003056: or          bl,byte ptr [edx]
  10003058: pop         eax
  10003059: dec         edx
  1000305A: pop         ds
  1000305B: cld
  1000305C: pop         eax
  1000305D: push        esp
  1000305E: add         eax,58281F4Ah
  10003063: dec         edx
  10003064: or          dl,byte ptr [esi]
  10003066: adc         ecx,dword ptr [eax]
  10003068: add         bl,byte ptr [edi]
  1000306A: and         byte ptr [eax+0Bh],bl
  1000306D: push        ss
  1000306E: pop         es
  1000306F: sbb         bl,byte ptr [eax+4Ah]
  10003072: pop         es
  10003073: dec         edx
  10003074: pop         ecx
  10003075: pop         ds
  10003076: adc         dword ptr [ebx+41h],ebx
  10003079: jl          1000307B
  1000307B: add         byte ptr [eax],al
  1000307D: push        ss
  1000307E: adc         eax,dword ptr [edi]
  10003080: add         bl,byte ptr [edi]
  10003082: and         byte ptr [eax+4Ah],bl
  10003085: adc         dword ptr [edi],eax
  10003087: pop         eax
  10003088: adc         eax,dword ptr [esi]
  1000308A: push        es
  1000308B: adc         dword ptr [esi],eax
  1000308D: inc         edi
  1000308E: push        edx
  1000308F: push        es
  10003090: pop         ss
  10003091: pop         eax
  10003092: or          al,byte ptr [edx]
  10003094: pop         ds
  10003095: sbb         al,58h
  10003097: dec         edx
  10003098: sbb         dh,byte ptr [ebx]
  1000309A: xor         byte ptr [ecx],dl
  1000309C: push        es
  1000309D: sbb         byte ptr [eax+13h],bl
  100030A0: add         al,1Eh
  100030A2: adc         eax,dword ptr ds:[17041106h]
  100030A8: pop         ecx
  100030A9: inc         esi
  100030AA: pop         ds
  100030AB: maxps       xmm2,xmmword ptr [ecx]
  100030AE: add         al,46h
  100030B0: sbb         ah,byte ptr [edx+60h]
  100030B3: push        edx
  100030B4: push        es
  100030B5: pop         ss
  100030B6: pop         eax
  100030B7: or          dl,byte ptr [ecx]
  100030B9: add         al,18h
  100030BB: pop         eax
  100030BC: adc         eax,dword ptr [ecx+edx]
  100030BF: add         eax,5135917h
  100030C4: adc         dword ptr ds:[2BDB3516h],eax
  100030CA: push        cs
  100030CB: push        es
  100030CC: adc         dword ptr [esi],eax
  100030CE: pop         ss
  100030CF: pop         eax
  100030D0: pop         ds
  100030D1: adc         dh,bh
  100030D3: pop         ss
  100030D4: push        es
  100030D5: pop         ds
  100030D6: adc         byte ptr [eax+0Ah],bl
  100030D9: adc         dword ptr [eax],ecx
  100030DB: pop         ss
  100030DC: pop         eax
  100030DD: adc         ecx,dword ptr [eax]
  100030DF: adc         dword ptr [edi],eax
  100030E1: pop         ds
  100030E2: adc         dword ptr [eax+13h],ebx
  100030E5: pop         es
  100030E6: add         bl,byte ptr [edi]
  100030E8: and         byte ptr [eax+0Bh],bl
  100030EB: adc         dword ptr [eax],ecx
  100030ED: pop         es
  100030EE: sbb         bl,byte ptr [eax+4Ah]
  100030F1: pop         es
  100030F2: dec         edx
  100030F3: pop         ecx
  100030F4: pop         ds
  100030F5: adc         dword ptr [ebx+37h],ebx
  100030F8: xchg        eax,dword ptr [ebx]
  100030FA: sbb         bl,byte ptr [eax+13h]
  100030FD: or          dword ptr [ecx],edx
  100030FF: or          dword ptr [edx],ebx
  10003101: pop         eax
  10003102: adc         dword ptr [ecx],ecx
  10003104: sbb         bl,byte ptr [eax+4Ah]
  10003107: pop         ds
  10003108: cld
  10003109: pop         eax
  1000310A: push        esp
  1000310B: sub         al,byte ptr [ebx]
  1000310D: xor         byte ptr [eax+eax],al
  10003110: retf        0
  10003113: add         byte ptr [eax],dh
  10003116: add         byte ptr [ecx],dl
  10003118: add         eax,dword ptr [edx]
  1000311A: cmp         eax,ecx
  1000311C: add         byte ptr [eax],al
  1000311E: add         byte ptr [ebx],al
  10003120: sbb         bl,byte ptr [eax+4Ah]
  10003123: adc         eax,dword ptr [ebx+eax]
  10003126: dec         edx
  10003127: or          al,11h
  10003129: add         al,8
  1000312B: pop         ecx
  1000312C: pop         ds
  1000312D: sbb         byte ptr [ebx+0Bh],bl
  10003130: add         cl,byte ptr [edx+0Dh]
  10003133: pop         es
  10003134: add         bl,byte ptr [esi]
  10003136: pop         eax
  10003137: dec         edx
  10003138: or          dword ptr [ecx+1Fh],ebx
  1000313B: sbb         byte ptr [ebx+36h],bl
  1000313E: cmp         al,byte ptr [edx]
  10003140: pop         es
  10003141: or          byte ptr [ecx],dl
  10003143: add         al,28h
  10003145: and         eax,13060000h
  1000314A: or          byte ptr [edx],al
  1000314C: sbb         bl,byte ptr [eax+0Ah]
  1000314F: add         ah,byte ptr ds:[284A064Ah]
  10003155: and         eax,dword ptr [eax]
  10003157: add         byte ptr [esi],al
  10003159: add         cl,byte ptr [edx+13h]
  1000315C: pop         es
  1000315D: adc         dword ptr [edi],eax
  1000315F: sub         al,7
  10003161: adc         dword ptr [edi],eax
  10003163: sub         byte ptr [edi],bl
  10003165: add         dword ptr [eax],eax
  10003167: push        es
  10003168: add         dl,byte ptr [ecx]
  1000316A: or          byte ptr [edx+eax+1Eh],dl
  1000316E: pop         eax
  1000316F: pop         es
  10003170: pop         ds
  10003171: sbb         byte ptr [edx+11h],bl
  10003174: or          byte ptr [eax+54h],bl
  10003177: sub         ebx,dword ptr [esi+2]
  1000317A: sbb         bl,byte ptr [eax+0Ah]
  1000317D: push        es
  1000317E: dec         edx
  1000317F: or          dword ptr [ecx+1Fh],ebx
  10003182: sbb         byte ptr [ebx+13h],bl
  10003185: push        es
  10003186: pop         es
  10003187: adc         dword ptr [esi],eax
  10003189: das
  1000318B: or          byte ptr [ecx],dl
  1000318D: push        es
  1000318E: pop         ds
  1000318F: sbb         byte ptr [edx+8],bl
  10003192: pop         eax
  10003193: or          dword ptr [eax],ebp
  10003195: das
  10003196: add         byte ptr [eax],al
  10003198: push        es
  10003199: push        es
  1000319B: dec         edx
  1000319C: adc         eax,dword ptr ds:[4A020511h]
  100031A2: pop         ecx
  100031A3: pop         ds
  100031A4: sbb         byte ptr [ebx+1Fh],bl
  100031A7: sbb         byte ptr [edx+3],bl
  100031AA: dec         edx
  100031AB: pop         eax
  100031AC: add         ebx,dword ptr [edx]
  100031AE: pop         eax
  100031AF: dec         edx
  100031B0: adc         dword ptr ds:[00002628h],eax
  100031B6: push        es
  100031B7: sub         ebx,dword ptr es:[110B1309h]
  100031BE: add         al,13h
  100031C0: or          cl,byte ptr [eax]
  100031C2: adc         dword ptr [edx],ecx
  100031C4: adc         dword ptr [ebx],ecx
  100031C6: sub         byte ptr [edi],ch
  100031C8: add         byte ptr [eax],al
  100031CA: push        es
  100031CB: adc         ecx,dword ptr [ecx]
  100031CD: add         dl,byte ptr [ecx]
  100031CF: or          dword ptr [esi],eax
  100031D1: dec         edx
  100031D2: sub         byte ptr [ebx],ah
  100031D4: add         byte ptr [eax],al
  100031D6: push        es
  100031D7: push        es
  100031D8: pop         es
  100031D9: pop         ds
  100031DA: sbb         byte ptr [edx+2],bl
  100031DD: dec         edx
  100031DE: pop         eax
  100031DF: push        esp
  100031E0: add         ch,byte ptr [edx]
  100031E2: int         3
  100031E3: int         3
  100031E4: add         esi,dword ptr [eax]
  100031E6: add         eax,dword ptr [eax]
  100031E8: aas
  100031E9: add         byte ptr [eax],al
  100031EB: add         byte ptr [ecx],dh
  100031EE: add         byte ptr [ecx],dl
  100031F0: add         ebx,dword ptr [edi]
  100031F2: sbb         byte ptr [eax+0Ch],bl
  100031F5: add         bl,byte ptr [edx]
  100031F7: pop         eax
  100031F8: dec         edx
  100031F9: or          ecx,dword ptr [eax]
  100031FB: pop         es
  100031FC: xor         al,0Dh
  100031FE: pop         es
  100031FF: adc         eax,dword ptr ds:[03051108h]
  10003205: sub         byte ptr [edi],ch
  10003207: add         byte ptr [eax],al
  10003209: push        es
  1000320A: add         bl,byte ptr es:[edx]
  1000320D: pop         eax
  1000320E: add         bl,byte ptr [edx]
  10003210: pop         eax
  10003211: dec         edx
  10003212: pop         ds
  10003213: call        2A028670
  10003218: pop         eax
  10003219: dec         edx
  1000321A: adc         eax,dword ptr [ecx+edx]
  1000321D: add         al,1Ah
  1000321F: pop         eax
  10003220: or          eax,60A4A09h
  10003225: sub         al,6
  10003227: push        es
  10003228: sub         byte ptr [edi],bl
  1000322A: add         dword ptr [eax],eax
  1000322C: push        es
  1000322D: add         ebp,dword ptr [edx]
  1000322F: add         byte ptr [eax],al
  10003231: add         byte ptr [eax],al
  10003233: add         byte ptr [ebx],cl
  10003235: xor         byte ptr [eax+eax],al
  10003238: xor         eax,72000001h
  1000323D: add         byte ptr [eax],al
  1000323F: adc         dword ptr [edi],ebx
  10003241: sbb         byte ptr [eax],ch
  10003243: sbb         eax,13060001h
  10003248: add         al,11h
  1000324A: add         al,2Ch
  1000324C: sbb         edx,dword ptr [ecx]
  1000324E: add         al,1Eh
  10003250: pop         eax
  10003251: adc         eax,dword ptr ds:[54160511h]
  10003257: adc         dword ptr ds:[5416581Ah],eax
  1000325D: adc         dword ptr ds:[5416581Eh],eax
  10003263: adc         dword ptr [edx+ecx],eax
  10003266: fimul       word ptr [esi+edx]
  10003269: or          bl,dh
  1000326B: or          byte ptr [ecx],dl
  1000326D: add         al,28h
  1000326F: push        ds
  10003270: add         dword ptr [eax],eax
  10003272: push        es
  10003273: fadd        qword ptr [esi]
  10003275: add         bl,byte ptr [edx]
  10003277: pop         eax
  10003278: dec         edx
  10003279: push        esp
  1000327A: push        es
  1000327B: sbb         bl,byte ptr [eax+2]
  1000327E: pop         ds
  1000327F: or          al,58h
  10003281: dec         ecx
  10003282: push        ebx
  10003283: push        es
  10003284: push        ds
  10003285: pop         eax
  10003286: add         ebp,dword ptr [eax]
  10003288: sbb         al,byte ptr [eax]
  1000328A: add         byte ptr [esi],al
  1000328C: add         ebx,dword ptr es:[edx]
  1000328F: pop         eax
  10003290: dec         edx
  10003291: add         ecx,dword ptr [edx+59h]
  10003294: pop         ds
  10003295: sbb         byte ptr [ebx+76h],bl
  10003298: imul        ebp,dword ptr [esp+eax+1Fh],10h
  1000329D: pop         eax
  1000329E: dec         esi
  1000329F: ins         byte ptr es:[edi],dx
  100032A0: pop         edx
  100032A1: ins         dword ptr es:[edi],dx
  100032A2: or          eax,2341709h
  100032A7: pop         ss
  100032A8: or          eax,0B134A06h
  100032AD: adc         dword ptr [ebx],ecx
  100032AF: sbb         dword ptr [ebx],esi
  100032B1: pop         esp
  100032B2: add         al,1Ah
  100032B4: pop         eax
  100032B5: dec         esi
  100032B6: or          al,6
  100032B8: push        ds
  100032B9: pop         eax
  100032BA: adc         ecx,dword ptr [edx]
  100032BC: adc         dword ptr [edx],ecx
  100032BE: sbb         bl,byte ptr [eax+4Ah]
  100032C1: adc         dword ptr [edx],ecx
  100032C3: dec         edx
  100032C4: pop         ecx
  100032C5: pop         ds
  100032C6: sbb         byte ptr [ebx+9],bl
  100032C9: xor         eax,22080Bh
  100032CE: add         byte ptr [eax],al
  100032D0: add         byte ptr [ebp+ebx*4],al
  100032D4: add         byte ptr [eax],al
  100032D6: push        es
  100032D7: push        ds
  100032D8: pop         eax
  100032D9: or          byte ptr [eax],ch
  100032DB: or          eax,13060000h
  100032E0: or          dword ptr [ecx],edx
  100032E2: or          dword ptr [esi],edx
  100032E4: das
  100032E5: adc         ecx,dword ptr [eax]
  100032E7: and         al,byte ptr [eax]
  100032E9: add         byte ptr [eax],al
  100032EB: add         byte ptr [edi],bh
  100032ED: add         byte ptr [eax],0
  100032F0: add         byte ptr [edx],ah
  100032F2: add         byte ptr [eax],al
  100032F4: cmp         byte ptr [edi+06BE2B0Ch],1Eh
  100032FB: pop         eax
  100032FC: adc         dword ptr [ecx],ecx
  100032FE: pop         ds
  100032FF: sbb         byte ptr [edx+6],bl
  10003302: push        ds
  10003303: pop         eax
  10003304: dec         edx
  10003305: pop         eax
  10003306: sub         byte ptr [ebx],bl
  10003308: add         byte ptr [eax],al
  1000330A: push        es
  1000330B: sub         ebp,dword ptr es:[ecx+331A0B11h]
  10003312: or          byte ptr [esi+ebx],al
  10003315: pop         eax
  10003316: dec         esi
  10003317: adc         ecx,dword ptr [eax]
  10003319: sub         eax,dword ptr [esp+eax]
  1000331C: dec         esi
  1000331D: adc         ecx,dword ptr [eax]
  1000331F: adc         dword ptr [eax],ecx
  10003321: or          eax,dword ptr [esi]
  10003323: push        ds
  10003324: pop         eax
  10003325: adc         eax,dword ptr [edi]
  10003327: adc         dword ptr [edi],eax
  10003329: sbb         bl,byte ptr [eax+4Ah]
  1000332C: adc         dword ptr [edi],eax
  1000332E: dec         edx
  1000332F: pop         ecx
  10003330: pop         ds
  10003331: sbb         byte ptr [ebx+9],bl
  10003334: xor         eax,220708h
  10003339: add         byte ptr [eax],al
  1000333B: add         byte ptr [edi],dh
  1000333D: xor         eax,7581E06h
  10003342: sub         byte ptr [eax+eax],cl
  10003345: add         byte ptr [esi],al
  10003347: adc         eax,dword ptr [esi]
  10003349: adc         dword ptr [esi],eax
  1000334B: push        ss
  1000334C: das
  1000334D: adc         byte ptr [edi],al
  1000334F: and         al,byte ptr [eax]
  10003351: add         byte ptr [eax],al
  10003353: add         byte ptr [edx],dh
  10003355: sbb         eax,80000022h
  1000335A: mov         edi,6C42B0Bh
  1000335F: push        ds
  10003360: pop         eax
  10003361: adc         dword ptr [esi],eax
  10003363: pop         ds
  10003364: sbb         byte ptr [edx+6],bl
  10003367: push        ds
  10003368: pop         eax
  10003369: dec         edx
  1000336A: pop         eax
  1000336B: sub         byte ptr [ebx],bl
  1000336D: add         byte ptr [eax],al
  1000336F: push        es
  10003370: sub         ebp,dword ptr es:[edi+00002A06h]
  10003377: add         byte ptr [ecx+1Ch],al
  1000337A: add         byte ptr [eax],al
  1000337C: add         al,0
  1000337E: add         byte ptr [eax],al
  10003380: or          dword ptr [eax],eax
  10003382: add         byte ptr [eax],al
  10003384: and         eax,dword ptr [eax]
  10003386: add         byte ptr [eax],al
  10003388: sub         al,0
  1000338A: add         byte ptr [eax],al
  1000338C: or          byte ptr [eax],al
  1000338E: add         byte ptr [eax],al
  10003390: and         byte ptr [eax],al
  10003392: add         byte ptr [ecx],al
  10003394: add         esi,dword ptr [eax]
  10003396: add         al,byte ptr [eax]
  10003398: adc         byte ptr [eax],al
  1000339A: add         byte ptr [eax],al
  1000339C: or          dword ptr [eax],eax
  1000339E: add         byte ptr [ecx],dl
  100033A0: add         cl,byte ptr [edx+0Ah]
  100033A3: push        es
  100033A4: sub         al,9
  100033A6: push        es
  100033A7: and         eax,78294A4Ah
  100033AC: add         byte ptr [eax],al
  100033AE: adc         dword ptr [edx],ebp
  100033B0: add         esi,dword ptr [eax]
  100033B2: add         eax,dword ptr [eax]
  100033B4: inc         ecx
  100033B5: add         byte ptr [eax],al
  100033B7: add         byte ptr [ecx],cl
  100033B9: add         byte ptr [eax],al
  100033BB: adc         dword ptr [edx],eax
  100033BD: pop         ds
  100033BE: or          al,58h
  100033C0: add         al,54h
  100033C2: add         bl,byte ptr [edx]
  100033C4: pop         eax
  100033C5: add         edx,dword ptr [edx+eax+1Fh]
  100033C9: adc         al,58h
  100033CB: add         eax,36160454h
  100033D0: or          al,byte ptr [edx]
  100033D2: push        ds
  100033D3: pop         eax
  100033D4: add         al,28h
  100033D6: daa
  100033D7: add         dword ptr [eax],eax
  100033D9: push        es
  100033DA: push        esp
  100033DB: add         bl,byte ptr [edi]
  100033DD: adc         al,58h
  100033DF: dec         edx
  100033E0: or          al,byte ptr [esi]
  100033E2: push        ss
  100033E3: or          eax,dword ptr ss:[edx]
  100033E6: pop         ds
  100033E7: adc         byte ptr [eax+6],bl
  100033EA: sub         byte ptr [edi],ah
  100033EC: add         dword ptr [eax],eax
  100033EE: push        es
  100033EF: push        esp
  100033F0: add         ah,byte ptr ds:[284A581Ah]
  100033F6: daa
  100033F7: add         dword ptr [eax],eax
  100033F9: push        es
  100033FA: push        esp
  100033FB: pop         ss
  100033FC: sub         cl,ah
  100033FE: int         3
  100033FF: int         3
  10003400: add         esi,dword ptr [eax]
  10003402: add         eax,dword ptr [eax]
  10003404: mov         al,byte ptr [eax]
  10003406: add         byte ptr [eax],al
  10003408: add         dword ptr [eax],47031100h
  1000340E: sub         al,23h
  10003410: adc         al,byte ptr [edx]
  10003412: add         bl,byte ptr [ecx]
  10003414: pop         eax
  10003415: inc         edi
  10003416: push        edx
  10003417: adc         al,byte ptr [edx]
  10003419: pop         ss
  1000341A: pop         eax
  1000341B: add         bl,byte ptr [eax]
  1000341D: pop         eax
  1000341E: inc         edi
  1000341F: push        edx
  10003420: adc         al,byte ptr [edx]
  10003422: sbb         byte ptr [eax+2],bl
  10003425: pop         ss
  10003426: pop         eax
  10003427: inc         edi
  10003428: push        edx
  10003429: adc         al,byte ptr [edx]
  1000342B: sbb         dword ptr [eax+2],ebx
  1000342E: inc         edi
  1000342F: push        edx
  10003430: add         cl,byte ptr [eax]
  10003432: push        esp
  10003433: add         eax,dword ptr [edi+2Ch]
  10003436: sub         eax,1A020112h
  1000343B: pop         eax
  1000343C: sbb         dword ptr [eax+47h],ebx
  1000343F: push        edx
  10003440: adc         al,byte ptr [ecx]
  10003442: pop         ss
  10003443: pop         eax
  10003444: add         bl,byte ptr [edx]
  10003446: pop         eax
  10003447: sbb         byte ptr [eax+47h],bl
  1000344A: push        edx
  1000344B: adc         al,byte ptr [ecx]
  1000344D: sbb         byte ptr [eax+2],bl
  10003450: sbb         bl,byte ptr [eax+17h]
  10003453: pop         eax
  10003454: inc         edi
  10003455: push        edx
  10003456: adc         al,byte ptr [ecx]
  10003458: sbb         dword ptr [eax+2],ebx
  1000345B: sbb         bl,byte ptr [eax+47h]
  1000345E: push        edx
  1000345F: add         bl,byte ptr [edx]
  10003461: pop         eax
  10003462: pop         es
  10003463: push        esp
  10003464: add         eax,dword ptr [edi+2Ch]
  10003467: sub         eax,1E020012h
  1000346C: pop         eax
  1000346D: sbb         dword ptr [eax+47h],ebx
  10003470: push        edx
  10003471: adc         al,byte ptr [eax]
  10003473: pop         ss
  10003474: pop         eax
  10003475: add         bl,byte ptr [esi]
  10003477: pop         eax
  10003478: sbb         byte ptr [eax+47h],bl
  1000347B: push        edx
  1000347C: adc         al,byte ptr [eax]
  1000347E: sbb         byte ptr [eax+2],bl
  10003481: push        ds
  10003482: pop         eax
  10003483: pop         ss
  10003484: pop         eax
  10003485: inc         edi
  10003486: push        edx
  10003487: adc         al,byte ptr [eax]
  10003489: sbb         dword ptr [eax+2],ebx
  1000348C: push        ds
  1000348D: pop         eax
  1000348E: inc         edi
  1000348F: push        edx
  10003490: add         bl,byte ptr [esi]
  10003492: pop         eax
  10003493: push        es
  10003494: push        esp
  10003495: sub         cl,ah
  10003497: int         3
  10003498: add         esi,dword ptr [eax]
  1000349A: add         al,byte ptr [eax]
  1000349C: adc         eax,0
  100034A1: add         byte ptr [eax],al
  100034A3: add         byte ptr [edx],al
  100034A5: push        ss
  100034A6: jge         10003508
  100034A8: add         dword ptr [eax],eax
  100034AA: add         al,2
  100034AC: push        ss
  100034AD: jge         10003510
  100034AF: add         dword ptr [eax],eax
  100034B1: add         al,2
  100034B3: sub         byte ptr ds:[2A0A0000h],ch
  100034B9: int         3
  100034BA: int         3
  100034BB: int         3
  100034BC: add         esi,dword ptr [eax]
  100034BE: add         byte ptr [eax],al
  100034C0: add         dword ptr [eax],eax
  100034C2: add         byte ptr [eax],al
  100034C4: add         byte ptr [eax],al
  100034C6: add         byte ptr [eax],al
  100034C8: sub         cl,ah
  100034CA: int         3
  100034CB: int         3
  100034CC: add         esi,dword ptr [eax]
  100034CE: add         al,byte ptr [eax]
  100034D0: sbb         dword ptr [eax],eax
  100034D2: add         byte ptr [eax],al
  100034D4: add         byte ptr [eax],al
  100034D6: add         byte ptr [eax],al
  100034D8: add         ah,byte ptr ds:[00002E28h]
  100034DE: or          ch,byte ptr [eax]
  100034E0: sbb         al,byte ptr [eax]
  100034E2: add         byte ptr [edx],cl
  100034E4: jge         10003546
  100034E6: add         dword ptr [eax],eax
  100034E8: add         al,2
  100034EA: add         al,7Dh
  100034EC: popad
  100034ED: add         dword ptr [eax],eax
  100034EF: add         al,2Ah
  100034F1: int         3
  100034F2: int         3
  100034F3: int         3
  100034F4: add         esi,dword ptr [eax]
  100034F6: add         eax,dword ptr [eax]
  100034F8: or          dword ptr [eax],eax
  100034FA: add         byte ptr [eax],al
  100034FC: add         byte ptr [eax],al
  100034FE: add         byte ptr [eax],al
  10003500: add         al,byte ptr [ebx]
  10003502: add         al,6Fh
  10003504: inc         edx
  10003505: add         dword ptr [eax],eax
  10003507: push        es
  10003508: sub         cl,ah
  1000350A: int         3
  1000350B: int         3
  1000350C: add         esi,dword ptr [eax]
  1000350E: add         dword ptr [eax],eax
  10003510: push        es
  10003511: add         byte ptr [eax],al
  10003513: add         byte ptr [eax],al
  10003515: add         byte ptr [eax],al
  10003517: add         byte ptr [eax],ah
  10003519: out         0EEh,eax
  1000351C: push        esp
  1000351D: sub         cl,ah
  1000351F: int         3
  10003520: add         esi,dword ptr [eax]
  10003522: add         al,byte ptr [eax]
  10003524: sub         byte ptr [eax],al
  10003526: add         byte ptr [eax],al
  10003528: wait
  10003529: add         byte ptr [eax],al
  1000352B: adc         dword ptr [esi],edx
  1000352D: or          al,byte ptr [edx]
  1000352F: jnp         10003592
  10003531: add         dword ptr [eax],eax
  10003533: add         al,0Bh
  10003535: adc         al,byte ptr [ecx]
  10003537: dec         edx
  10003538: pop         ss
  10003539: xor         eax,dword ptr ds:[2B0A091Fh]
  1000353F: adc         dl,byte ptr [edx]
  10003541: add         dword ptr [edx+2Dh],ecx
  10003544: add         al,1Eh
  10003546: or          ch,byte ptr [ebx]
  10003548: or          dword ptr [edx],edx
  1000354A: add         dword ptr [edx+18h],ecx
  1000354D: xor         eax,dword ptr [ebx]
  1000354F: pop         ds
  10003550: or          ecx,dword ptr [edx]
  10003552: push        es
  10003553: sub         al,byte ptr [ebx]
  10003555: xor         byte ptr [ebx],al
  10003557: add         byte ptr [edx+9D000000h],al
  1000355D: add         byte ptr [eax],al
  1000355F: adc         dword ptr [ebx+17h],esi
  10003562: add         byte ptr [eax],al
  10003564: or          cl,byte ptr [edx]
  10003566: push        es
  10003567: push        ss
  10003568: jge         10003582
  1000356A: add         byte ptr [eax],al
  1000356C: or          al,byte ptr [esi]
  1000356E: add         edi,dword ptr [ebp+26h]
  10003571: add         byte ptr [eax],al
  10003573: or          al,byte ptr [ebx]
  10003575: and         byte ptr [eax],dh
  10003577: scas        byte ptr es:[edi]
  10003578: dec         eax
  10003579: and         al,2Eh
  1000357B: aaa
  1000357C: add         esp,dword ptr [eax]
  1000357E: bound       esp,qword ptr [edx+5C33C2B1h]
  10003584: push        es
  10003585: add         ch,byte ptr [edi+49h]
  10003588: add         dword ptr [eax],eax
  1000358A: push        es
  1000358B: and         byte ptr [eax+ecx+7D61CD8Ah],bl
  10003592: sbb         dword ptr [eax],eax
  10003594: add         byte ptr [edx],cl
  10003596: push        es
  10003597: and         byte ptr [eax+ecx+237DCD8Ah],bl
  1000359E: add         byte ptr [eax],al
  100035A0: or          al,byte ptr [esi]
  100035A2: jle         10003578
  100035A4: add         byte ptr [eax],al
  100035A6: add         al,73h
  100035A8: xor         eax,7D0A0000h
  100035AD: and         al,0
  100035AF: add         byte ptr [edx],cl
  100035B1: sub         ebp,dword ptr ds:[496F0206h]
  100035B7: add         dword ptr [eax],eax
  100035B9: push        es
  100035BA: and         cl,ah
  100035BC: pop         esp
  100035BD: push        eax
  100035BE: D6
  100035BF: popad
  100035C0: jge         100035DB
  100035C2: add         byte ptr [eax],al
  100035C4: or          al,byte ptr [esi]
  100035C6: and         al,ch
  100035C8: pop         edi
  100035C9: inc         ebp
  100035CA: push        ebp
  100035CB: jge         100035F0
  100035CD: add         byte ptr [eax],al
  100035CF: or          al,byte ptr [esi]
  100035D1: jle         10003589
  100035D3: add         byte ptr [eax],al
  100035D5: add         al,73h
  100035D7: xor         eax,7D0A0000h
  100035DC: and         al,0
  100035DE: add         byte ptr [edx],cl
  100035E0: push        es
  100035E1: sub         cl,ah
  100035E3: int         3
  100035E4: add         esi,dword ptr [eax]
  100035E6: add         dword ptr [eax],eax
  100035E8: adc         eax,0
  100035ED: add         byte ptr [eax],al
  100035EF: add         byte ptr [edi],bl
  100035F1: or          eax,dword ptr [eax+04000164h]
  100035F7: pop         ds
  100035F8: or          dword ptr [eax+04000163h],eax
  100035FE: push        ds
  100035FF: and         byte ptr [edx+1],0
  10003603: add         al,2Ah
  10003605: int         3
  10003606: int         3
  10003607: int         3
  10003608: add         esi,dword ptr [eax]
  1000360A: add         al,byte ptr [eax]
  1000360C: sbb         eax,dword ptr [eax]
  1000360E: add         byte ptr [eax],al
  10003610: mov         byte ptr ds:[12110000h],al
  10003615: add         byte ptr [edx],al
  10003617: dec         edx
  10003618: sub         byte ptr [edx],ch
  1000361A: add         byte ptr [eax],al
  1000361C: or          al,byte ptr [esi]
  1000361E: sub         byte ptr [edx],dh
  10003620: add         byte ptr [eax],al
  10003622: or          cl,byte ptr [ebx]
  10003624: adc         al,byte ptr [ecx]
  10003626: sub         byte ptr [ecx],dh
  10003628: add         byte ptr [eax],al
  1000362A: or          al,byte ptr [edx]
  1000362C: push        ss
  1000362D: push        esp
  1000362E: sub         cl,ah
  10003630: add         esi,dword ptr [eax]
  10003632: add         al,byte ptr [eax]
  10003634: sub         eax,0A0000000h
  10003639: add         byte ptr [eax],al
  1000363B: adc         dword ptr [edx],edx
  1000363D: add         byte ptr [ebx],al
  1000363F: dec         edx
  10003640: sub         byte ptr [edx],ch
  10003642: add         byte ptr [eax],al
  10003644: or          al,byte ptr [esi]
  10003646: sub         byte ptr [edx],dh
  10003648: add         byte ptr [eax],al
  1000364A: or          cl,byte ptr [edx+edx]
  1000364D: add         ch,byte ptr [eax]
  1000364F: xor         al,0
  10003651: add         byte ptr [edx],cl
  10003653: sub         byte ptr [eax],dh
  10003655: add         byte ptr [eax],al
  10003657: or          ch,byte ptr [eax]
  10003659: xor         eax,dword ptr [eax]
  1000365B: add         byte ptr [edx],cl
  1000365D: or          eax,dword ptr [edx]
  1000365F: adc         al,byte ptr [ecx]
  10003661: sub         byte ptr [ebx],ch
  10003663: add         byte ptr [eax],al
  10003665: or          dl,byte ptr [edx+eax+2Ah]
  10003669: int         3
  1000366A: int         3
  1000366B: int         3
  1000366C: add         esi,dword ptr [eax]
  1000366E: add         al,byte ptr [eax]
  10003670: jnp         10003672
  10003672: add         byte ptr [eax],al
  10003674: cmps        dword ptr [esi],dword ptr es:[edi]
  10003675: add         byte ptr [eax],al
  10003677: adc         dword ptr [esi],edx
  10003679: adc         eax,dword ptr [esi]
  1000367B: add         al,13h
  1000367D: add         eax,6F340416h
  10003682: add         al,byte ptr [esi+13h]
  10003685: or          dl,byte ptr [ecx]
  10003687: add         eax,17580611h
  1000368C: or          eax,35A1E09h
  10003692: pop         eax
  10003693: dec         edx
  10003694: adc         ecx,dword ptr [eax]
  10003696: adc         dword ptr [eax],ecx
  10003698: or          edx,dword ptr [esi]
  1000369A: adc         eax,dword ptr [ecx+edx]
  1000369D: or          cl,byte ptr [edx]
  1000369F: pop         es
  100036A0: inc         esi
  100036A1: or          al,6
  100036A3: or          byte ptr [edx],dh
  100036A5: push        ds
  100036A6: add         dl,byte ptr [ecx]
  100036A8: or          byte ptr [ecx+13h],bl
  100036AB: or          dword ptr [esi],eax
  100036AD: or          byte ptr [eax],dh
  100036AF: sbb         dword ptr [esi],eax
  100036B1: sub         al,19h
  100036B3: pop         es
  100036B4: pop         ss
  100036B5: pop         eax
  100036B6: or          edx,dword ptr [ecx]
  100036B8: or          dword ptr [edi],eax
  100036BA: pop         eax
  100036BB: inc         esi
  100036BC: or          al,byte ptr [edi]
  100036BE: inc         esi
  100036BF: or          al,6
  100036C1: or          byte ptr [edi],ch
  100036C3: call        3B0449DD
  100036C8: add         edx,dword ptr [edi]
  100036CA: adc         eax,dword ptr [ecx+edx]
  100036CD: add         al,13h
  100036CF: pop         es
  100036D0: adc         dword ptr [edi],eax
  100036D2: sub         al,17h
  100036D4: adc         dword ptr [edi],eax
  100036D6: push        ss
  100036D7: xor         dword ptr [edi],eax
  100036D9: or          dword ptr [edi],edx
  100036DB: pop         eax
  100036DC: adc         eax,dword ptr [esi]
  100036DE: sub         eax,dword ptr [ebx]
  100036E0: or          dword ptr [ebx],edx
  100036E2: add         eax,5110611h
  100036E7: aaa
  100036E8: popfd
  100036E9: sub         eax,dword ptr [esi]
  100036EB: or          dword ptr [esi],ebx
  100036ED: pop         edx
  100036EE: add         ebx,dword ptr [eax+2Ah]
  100036F1: push        ss
  100036F2: sub         cl,ah
  100036F4: add         esi,dword ptr [eax]
  100036F6: add         al,0
  100036F8: xor         eax,dword ptr [eax]
  100036FA: add         byte ptr [eax],al
  100036FC: stos        dword ptr es:[edi]
  100036FD: add         byte ptr [eax],al
  100036FF: adc         dword ptr [edx],eax
  10003701: sub         al,2Fh
  10003703: add         ah,byte ptr ds:[58101F4Ah]
  10003709: dec         edx
  1000370A: sub         dword ptr [edx],edi
  1000370D: add         byte ptr [ecx],dl
  1000370F: or          al,byte ptr [esi]
  10003711: sub         al,1Fh
  10003713: push        es
  10003714: and         eax,75294A4Ah
  10003719: add         byte ptr [eax],al
  1000371B: adc         dword ptr [ebx],ecx
  1000371D: add         eax,dword ptr [edi]
  1000371F: push        ss
  10003720: push        ss
  10003721: sub         byte ptr [ecx+eax],ah
  10003724: add         byte ptr [esi],al
  10003726: push        esp
  10003727: push        es
  10003728: and         eax,4A581A4Ah
  1000372D: sub         dword ptr [eax],edi
  10003730: add         byte ptr [ecx],dl
  10003732: sub         cl,ah
  10003734: add         esi,dword ptr [eax]
  10003736: add         eax,dword ptr [eax]
  10003738: xor         al,byte ptr [eax]
  1000373A: add         byte ptr [eax],al
  1000373C: test        byte ptr [eax],al
  1000373E: add         byte ptr [ecx],dl
  10003740: add         ch,byte ptr [esi+ebp]
  10003743: add         ah,byte ptr ds:[75294A4Ah]
  10003749: add         byte ptr [eax],al
  1000374B: adc         dword ptr [esi+0Ah],eax
  1000374E: push        es
  1000374F: pop         ds
  10003750: xor         dword ptr [esi],ebp
  10003752: push        cs
  10003753: push        es
  10003754: pop         ds
  10003755: je          10003785
  10003757: or          dword ptr [esi],eax
  10003759: pop         ds
  1000375A: push        esp
  1000375B: add         al,16h
  1000375E: or          ebp,dword ptr [ebx]
  10003760: add         dl,byte ptr [edi]
  10003762: or          eax,dword ptr [ebx]
  10003764: pop         es
  10003765: push        edx
  10003766: add         ah,byte ptr ds:[4A581A4Ah]
  1000376C: sub         dword ptr [eax],edi
  1000376F: add         byte ptr [ecx],dl
  10003771: sub         cl,ah
  10003773: int         3
  10003774: add         esi,dword ptr [eax]
  10003776: add         al,0
  10003778: xor         eax,dword ptr [eax]
  1000377A: add         byte ptr [eax],al
  1000377C: stos        dword ptr es:[edi]
  1000377D: add         byte ptr [eax],al
  1000377F: adc         dword ptr [edx],eax
  10003781: sub         al,2Fh
  10003783: add         ah,byte ptr ds:[58101F4Ah]
  10003789: dec         edx
  1000378A: sub         dword ptr [edx],edi
  1000378D: add         byte ptr [ecx],dl
  1000378F: or          al,byte ptr [esi]
  10003791: sub         al,1Fh
  10003793: push        es
  10003794: and         eax,75294A4Ah
  10003799: add         byte ptr [eax],al
  1000379B: adc         dword ptr [ebx],ecx
  1000379D: add         eax,dword ptr [edi]
  1000379F: push        ss
  100037A0: push        ss
  100037A1: sub         byte ptr [ebx],ah
  100037A3: add         dword ptr [eax],eax
  100037A5: push        es
  100037A6: push        esp
  100037A7: push        es
  100037A8: and         eax,4A581A4Ah
  100037AD: sub         dword ptr [eax],edi
  100037B0: add         byte ptr [ecx],dl
  100037B2: sub         cl,ah
  100037B4: add         esi,dword ptr [eax]
  100037B6: add         eax,dword ptr [eax]
  100037B8: dec         ebx
  100037B9: add         byte ptr [eax],al
  100037BB: add         byte ptr [ecx+02110000h],dh
  100037C1: add         ebp,dword ptr [esi]
  100037C3: inc         esi
  100037C4: add         bl,byte ptr [edi]
  100037C6: or          al,58h
  100037C8: or          al,byte ptr [esi]
  100037CA: add         ebp,dword ptr [esi]
  100037CC: cmp         eax,1F060212h
  100037D1: or          al,0FEh
  100037D3: pop         ss
  100037D4: push        es
  100037D5: or          eax,dword ptr [esi]
  100037D7: add         ch,byte ptr [esi]
  100037D9: and         byte ptr [edx],dl
  100037DB: add         al,byte ptr [edi]
  100037DD: pop         ds
  100037DE: or          al,59h
  100037E0: add         al,29h
  100037E2: jl          100037E4
  100037E4: add         byte ptr [ecx],dl
  100037E6: sub         al,12h
  100037E8: pop         es
  100037E9: and         eax,1F590C1Fh
  100037EE: or          al,0FEh
  100037F0: pop         ss
  100037F1: pop         es
  100037F2: pop         ds
  100037F3: or          al,59h
  100037F5: or          eax,dword ptr [edi]
  100037F7: add         dh,byte ptr [ebx]
  100037F9: loopne      10003802
  100037FB: adc         al,byte ptr [edx]
  100037FD: pop         ds
  100037FE: or          al,0FEh
  10003800: pop         ss
  10003801: push        es
  10003802: pop         ds
  10003803: or          al,58h
  10003805: or          al,byte ptr [esi]
  10003807: add         esi,dword ptr [ebx]
  10003809: ret
  1000380A: sub         cl,ah
  1000380C: add         esi,dword ptr [eax]
  1000380E: add         eax,dword ptr [eax]
  10003810: dec         ebp
  10003811: add         byte ptr [eax],al
  10003813: add         byte ptr [edx+02110000h],dh
  10003819: or          al,byte ptr [edx]
  1000381B: add         ebp,dword ptr [esi]
  1000381D: inc         esi
  1000381E: push        es
  1000381F: or          al,12h
  10003821: add         al,6
  10003823: pop         ds
  10003824: or          al,0FEh
  10003826: pop         ss
  10003827: push        es
  10003828: pop         ds
  10003829: or          al,59h
  1000382B: or          eax,4120B09h
  10003830: or          dword ptr [ecx+ebp],eax
  10003833: jl          10003835
  10003835: add         byte ptr [ecx],dl
  10003837: sub         al,1Bh
  10003839: or          byte ptr [edi],al
  1000383B: pop         ds
  1000383C: or          al,0FEh
  1000383E: pop         ss
  1000383F: or          byte ptr [edi],bl
  10003841: or          al,59h
  10003843: or          al,7
  10003845: pop         ds
  10003846: or          al,59h
  10003848: or          edx,dword ptr [edx]
  1000384A: add         al,7
  1000384C: add         al,29h
  1000384E: jl          10003850
  10003850: add         byte ptr [ecx],dl
  10003852: sub         eax,41208E5h
  10003857: pop         ds
  10003858: or          al,0FEh
  1000385A: pop         ss
  1000385B: push        es
  1000385C: pop         ds
  1000385D: or          al,58h
  1000385F: or          al,byte ptr [esi]
  10003861: add         esi,dword ptr [ebx]
  10003863: mov         edx,0CCCCCC2Ah
  10003868: add         esi,dword ptr [eax]
  1000386A: add         eax,dword ptr [eax]
  1000386C: add         byte ptr ds:[eax],al
  1000386F: add         byte ptr [eax],al
  10003871: add         byte ptr [eax],al
  10003873: add         byte ptr [edx],al
  10003875: add         eax,dword ptr ds:[00007C29h]
  1000387B: adc         dword ptr [edx+ebx],ebp
  1000387E: add         eax,dword ptr [eax+00007C29h]
  10003885: adc         dword ptr [edx+eax],ebp
  10003888: add         ebp,dword ptr [edx]
  1000388A: add         al,byte ptr [eax+00007C29h]
  10003891: adc         dword ptr [edx+eax],ebp
  10003894: add         al,2Ah
  10003896: add         ch,byte ptr [edx]
  10003898: add         al,byte ptr [eax+00007C29h]
  1000389F: adc         dword ptr [edx+eax],ebp
  100038A2: add         ch,byte ptr [edx]
  100038A4: add         eax,dword ptr [eax+00007C29h]
  100038AB: adc         dword ptr [edx+eax],ebp
  100038AE: add         al,2Ah
  100038B0: add         ebp,dword ptr [edx]
  100038B2: int         3
  100038B3: int         3
  100038B4: add         esi,dword ptr [eax]
  100038B6: add         eax,dword ptr [eax]
  100038B8: inc         edx
  100038B9: add         byte ptr [eax],al
  100038BB: add         byte ptr [ebx+04110000h],dh
  100038C1: pop         ss
  100038C2: pop         ecx
  100038C3: pop         ss
  100038C4: arpl        word ptr [edx],cx
  100038C6: add         al,3
  100038C8: xor         dword ptr [ebx],ebp
  100038CA: add         al,byte ptr [esi]
  100038CC: pop         ds
  100038CD: or          al,5Ah
  100038CF: pop         eax
  100038D0: or          eax,dword ptr [edi]
  100038D2: lsl         ecx,word ptr [esi]
  100038D5: add         al,29h
  100038D7: jl          100038D9
  100038D9: add         byte ptr [ecx],dl
  100038DB: sub         al,18h
  100038DD: add         al,1Fh
  100038DF: or          al,5Ah
  100038E1: add         bl,byte ptr [eax+7]
  100038E4: pop         ds
  100038E5: or          al,0FEh
  100038E7: pop         ss
  100038E8: push        es
  100038E9: adc         byte ptr [edx],al
  100038EB: push        es
  100038EC: pop         ss
  100038ED: pop         ecx
  100038EE: pop         ss
  100038EF: arpl        word ptr [edx],cx
  100038F1: add         al,3
  100038F3: xor         ch,dl
  100038F5: add         al,1Fh
  100038F7: or          al,5Ah
  100038F9: add         bl,byte ptr [eax+0Fh]
  100038FC: add         ebx,dword ptr [edi]
  100038FE: or          al,0FEh
  10003900: pop         ss
  10003901: sub         cl,ah
  10003903: int         3
  10003904: add         esi,dword ptr [eax]
  10003906: add         al,byte ptr [eax]
  10003908: cmp         byte ptr [eax],al
  1000390A: add         byte ptr [eax],al
  1000390C: add         dword ptr [eax],1E021100h
  10003912: pop         eax
  10003913: dec         edx
  10003914: or          al,8
  10003916: sub         al,0Bh
  10003918: or          byte ptr [eax],ch
  1000391A: sub         byte ptr [ecx],al
  1000391C: add         byte ptr [esi],al
  1000391E: add         bl,byte ptr [esi]
  10003920: pop         eax
  10003921: push        ss
  10003922: push        esp
  10003923: add         bl,byte ptr [edi]
  10003925: adc         byte ptr [eax+4Ah],bl
  10003928: or          eax,dword ptr [edi]
  1000392A: sub         al,0Ch
  1000392C: pop         es
  1000392D: sub         byte ptr [eax],ch
  1000392F: add         dword ptr [eax],eax
  10003931: push        es
  10003932: add         bl,byte ptr [edi]
  10003934: adc         byte ptr [eax+16h],bl
  10003937: push        esp
  10003938: add         cl,byte ptr [edx+0Ah]
  1000393B: push        es
  1000393C: sub         al,9
  1000393E: push        es
  1000393F: sub         byte ptr [eax],ch
  10003941: add         dword ptr [eax],eax
  10003943: push        es
  10003944: add         dl,byte ptr [esi]
  10003946: push        esp
  10003947: sub         al,byte ptr [ebx]
  10003949: xor         byte ptr ds:[0000E600h],al
  1000394F: add         byte ptr [esi+02110000h],dh
  10003955: cmp         edi,ebx
  10003957: add         byte ptr [eax],al
  10003959: add         byte ptr [edx],al
  1000395B: jg          10003994
  1000395D: add         byte ptr [eax],al
  1000395F: add         al,16h
  10003961: add         cl,byte ptr [edx+1Fh]
  10003964: or          al,58h
  10003966: dec         edx
  10003967: sub         dword ptr [esi],esi
  1000396A: add         byte ptr [ecx],dl
  1000396C: or          eax,9202C09h
  10003971: and         eax,75294A4Ah
  10003976: add         byte ptr [eax],al
  10003978: adc         dword ptr [ebx],edx
  1000397A: pop         es
  1000397B: add         edx,dword ptr [ecx]
  1000397D: pop         es
  1000397E: sub         byte ptr [edx],ah
  10003980: add         dword ptr [eax],eax
  10003982: push        es
  10003983: imul        edx,dword ptr [esi+9],25h
  10003987: dec         edx
  10003988: sbb         bl,byte ptr [eax+4Ah]
  1000398B: sub         dword ptr [eax],edi
  1000398E: add         byte ptr [ecx],dl
  10003990: add         bh,byte ptr [edi+38h]
  10003993: add         byte ptr [eax],al
  10003995: add         al,16h
  10003997: add         cl,byte ptr [edx+1Fh]
  1000399A: or          al,58h
  1000399C: dec         edx
  1000399D: sub         dword ptr [esi],esi
  100039A0: add         byte ptr [ecx],dl
  100039A2: or          al,8
  100039A4: sub         al,22h
  100039A6: or          byte ptr ds:[75294A4Ah],ah
  100039AC: add         byte ptr [eax],al
  100039AE: adc         dword ptr [ebx],edx
  100039B0: push        es
  100039B1: add         ebx,dword ptr [edx]
  100039B3: pop         eax
  100039B4: adc         dword ptr [esi],eax
  100039B6: sub         byte ptr [edx],ah
  100039B8: add         dword ptr [eax],eax
  100039BA: push        es
  100039BB: imul        edx,dword ptr [esi+8],25h
  100039BF: dec         edx
  100039C0: sbb         bl,byte ptr [eax+4Ah]
  100039C3: sub         dword ptr [eax],edi
  100039C6: add         byte ptr [ecx],dl
  100039C8: add         bh,byte ptr [edi+39h]
  100039CB: add         byte ptr [eax],al
  100039CD: add         al,16h
  100039CF: add         cl,byte ptr [edx+1Fh]
  100039D2: or          al,58h
  100039D4: dec         edx
  100039D5: sub         dword ptr [esi],esi
  100039D8: add         byte ptr [ecx],dl
  100039DA: or          eax,dword ptr [edi]
  100039DC: sub         al,22h
  100039DE: pop         es
  100039DF: and         eax,75294A4Ah
  100039E4: add         byte ptr [eax],al
  100039E6: adc         dword ptr [ebx],edx
  100039E8: add         eax,11581E03h
  100039ED: add         eax,12228h
  100039F2: push        es
  100039F3: imul        edx,dword ptr [esi+7],25h
  100039F7: dec         edx
  100039F8: sbb         bl,byte ptr [eax+4Ah]
  100039FB: sub         dword ptr [eax],edi
  100039FE: add         byte ptr [ecx],dl
  10003A00: add         bh,byte ptr [edi+3Ah]
  10003A03: add         byte ptr [eax],al
  10003A05: add         al,16h
  10003A07: add         cl,byte ptr [edx+1Fh]
  10003A0A: or          al,58h
  10003A0C: dec         edx
  10003A0D: sub         dword ptr [esi],esi
  10003A10: add         byte ptr [ecx],dl
  10003A12: or          al,byte ptr [esi]
  10003A14: sub         al,23h
  10003A16: push        es
  10003A17: and         eax,75294A4Ah
  10003A1C: add         byte ptr [eax],al
  10003A1E: adc         dword ptr [ebx],edx
  10003A20: add         al,3
  10003A22: pop         ds
  10003A23: or          al,58h
  10003A25: adc         dword ptr [eax+ebp],eax
  10003A28: and         al,byte ptr [ecx]
  10003A2A: add         byte ptr [esi],al
  10003A2C: imul        edx,dword ptr [esi+6],25h
  10003A30: dec         edx
  10003A31: sbb         bl,byte ptr [eax+4Ah]
  10003A34: sub         dword ptr [eax],edi
  10003A37: add         byte ptr [ecx],dl
  10003A39: sub         cl,ah
  10003A3B: int         3
  10003A3C: add         esi,dword ptr [eax]
  10003A3E: add         eax,6F00h
  10003A43: add         byte ptr [eax+eax+2C021100h],dh
  10003A4A: imul        eax,dword ptr [edx],7Fh
  10003A4D: cmp         eax,16040000h
  10003A52: add         cl,byte ptr [edx+1Fh]
  10003A55: or          al,58h
  10003A57: dec         edx
  10003A58: sub         dword ptr [esi],esi
  10003A5B: add         byte ptr [ecx],dl
  10003A5D: or          eax,dword ptr [edi]
  10003A5F: sub         al,1Eh
  10003A61: pop         es
  10003A62: and         eax,75294A4Ah
  10003A67: add         byte ptr [eax],al
  10003A69: adc         dword ptr ds:[22280903h],ecx
  10003A6F: add         dword ptr [eax],eax
  10003A71: push        es
  10003A72: imul        edx,dword ptr [esi+7],25h
  10003A76: dec         edx
  10003A77: sbb         bl,byte ptr [eax+4Ah]
  10003A7A: sub         dword ptr [eax],edi
  10003A7D: add         byte ptr [ecx],dl
  10003A7F: add         bh,byte ptr [edi+3Eh]
  10003A82: add         byte ptr [eax],al
  10003A84: add         al,16h
  10003A86: add         cl,byte ptr [edx+1Fh]
  10003A89: or          al,58h
  10003A8B: dec         edx
  10003A8C: sub         dword ptr [esi],esi
  10003A8F: add         byte ptr [ecx],dl
  10003A91: or          al,byte ptr [esi]
  10003A93: sub         al,21h
  10003A95: push        es
  10003A96: and         eax,75294A4Ah
  10003A9B: add         byte ptr [eax],al
  10003A9D: adc         dword ptr [ebx+eax],ecx
  10003AA0: sbb         bl,byte ptr [eax+8]
  10003AA3: push        ss
  10003AA4: push        ss
  10003AA5: sub         byte ptr [ebx],ah
  10003AA7: add         dword ptr [eax],eax
  10003AA9: push        es
  10003AAA: push        ebx
  10003AAB: push        es
  10003AAC: and         eax,4A581A4Ah
  10003AB1: sub         dword ptr [eax],edi
  10003AB4: add         byte ptr [ecx],dl
  10003AB6: sub         cl,ah
  10003AB8: add         esi,dword ptr [eax]
  10003ABA: add         eax,0AB00h
  10003ABF: add         byte ptr [ebp+02110000h],dh
  10003AC5: cmp         dword ptr [eax+eax+7F020000h],esp
  10003ACC: inc         eax
  10003ACD: add         byte ptr [eax],al
  10003ACF: add         al,16h
  10003AD1: add         cl,byte ptr [edx+1Fh]
  10003AD4: or          al,58h
  10003AD6: dec         edx
  10003AD7: sub         dword ptr [esi],esi
  10003ADA: add         byte ptr [ecx],dl
  10003ADC: or          al,8
  10003ADE: sub         al,20h
  10003AE0: or          byte ptr ds:[75294A4Ah],ah
  10003AE6: add         byte ptr [eax],al
  10003AE8: adc         dword ptr [ebx],edx
  10003AEA: add         eax,28051103h
  10003AEF: and         al,byte ptr [ecx]
  10003AF1: add         byte ptr [esi],al
  10003AF3: imul        edx,dword ptr [esi+8],25h
  10003AF7: dec         edx
  10003AF8: sbb         bl,byte ptr [eax+4Ah]
  10003AFB: sub         dword ptr [eax],edi
  10003AFE: add         byte ptr [ecx],dl
  10003B00: add         bh,byte ptr [edi+41h]
  10003B03: add         byte ptr [eax],al
  10003B05: add         al,16h
  10003B07: add         cl,byte ptr [edx+1Fh]
  10003B0A: or          al,58h
  10003B0C: dec         edx
  10003B0D: sub         dword ptr [esi],esi
  10003B10: add         byte ptr [ecx],dl
  10003B12: or          eax,dword ptr [edi]
  10003B14: sub         al,22h
  10003B16: pop         es
  10003B17: and         eax,75294A4Ah
  10003B1C: add         byte ptr [eax],al
  10003B1E: adc         dword ptr [ebx],edx
  10003B20: add         al,3
  10003B22: sbb         bl,byte ptr [eax+11h]
  10003B25: add         al,28h
  10003B27: and         al,byte ptr [ecx]
  10003B29: add         byte ptr [esi],al
  10003B2B: imul        edx,dword ptr [esi+7],25h
  10003B2F: dec         edx
  10003B30: sbb         bl,byte ptr [eax+4Ah]
  10003B33: sub         dword ptr [eax],edi
  10003B36: add         byte ptr [ecx],dl
  10003B38: add         bh,byte ptr [edi+42h]
  10003B3B: add         byte ptr [eax],al
  10003B3D: add         al,16h
  10003B3F: add         cl,byte ptr [edx+1Fh]
  10003B42: or          al,58h
  10003B44: dec         edx
  10003B45: sub         dword ptr [esi],esi
  10003B48: add         byte ptr [ecx],dl
  10003B4A: or          al,byte ptr [esi]
  10003B4C: sub         al,20h
  10003B4E: push        es
  10003B4F: and         eax,75294A4Ah
  10003B54: add         byte ptr [eax],al
  10003B56: adc         dword ptr ds:[09581E03h],ecx
  10003B5C: sub         byte ptr [edx],ah
  10003B5E: add         dword ptr [eax],eax
  10003B60: push        es
  10003B61: imul        edx,dword ptr [esi+6],25h
  10003B65: dec         edx
  10003B66: sbb         bl,byte ptr [eax+4Ah]
  10003B69: sub         dword ptr [eax],edi
  10003B6C: add         byte ptr [ecx],dl
  10003B6E: sub         cl,ah
  10003B70: add         esi,dword ptr [eax]
  10003B72: add         eax,6E00h
  10003B77: add         byte ptr [eax+eax+2C021100h],dh
  10003B7E: push        2
  10003B80: jg          10003BC2
  10003B82: add         byte ptr [eax],al
  10003B84: add         al,16h
  10003B86: add         cl,byte ptr [edx+1Fh]
  10003B89: or          al,58h
  10003B8B: dec         edx
  10003B8C: sub         dword ptr [esi],esi
  10003B8F: add         byte ptr [ecx],dl
  10003B91: or          eax,dword ptr [edi]
  10003B93: sub         al,1Eh
  10003B95: pop         es
  10003B96: and         eax,75294A4Ah
  10003B9B: add         byte ptr [eax],al
  10003B9D: adc         dword ptr ds:[22280903h],ecx
  10003BA3: add         dword ptr [eax],eax
  10003BA5: push        es
  10003BA6: imul        edx,dword ptr [esi+7],25h
  10003BAA: dec         edx
  10003BAB: sbb         bl,byte ptr [eax+4Ah]
  10003BAE: sub         dword ptr [eax],edi
  10003BB1: add         byte ptr [ecx],dl
  10003BB3: add         bh,byte ptr [edi+41h]
  10003BB6: add         byte ptr [eax],al
  10003BB8: add         al,16h
  10003BBA: add         cl,byte ptr [edx+1Fh]
  10003BBD: or          al,58h
  10003BBF: dec         edx
  10003BC0: sub         dword ptr [esi],esi
  10003BC3: add         byte ptr [ecx],dl
  10003BC5: or          al,byte ptr [esi]
  10003BC7: sub         al,20h
  10003BC9: push        es
  10003BCA: and         eax,75294A4Ah
  10003BCF: add         byte ptr [eax],al
  10003BD1: adc         dword ptr [ebx+eax],ecx
  10003BD4: sbb         bl,byte ptr [eax+8]
  10003BD7: sub         byte ptr [edx],ah
  10003BD9: add         dword ptr [eax],eax
  10003BDB: push        es
  10003BDC: imul        edx,dword ptr [esi+6],25h
  10003BE0: dec         edx
  10003BE1: sbb         bl,byte ptr [eax+4Ah]
  10003BE4: sub         dword ptr [eax],edi
  10003BE7: add         byte ptr [ecx],dl
  10003BE9: sub         cl,ah
  10003BEB: int         3
  10003BEC: add         esi,dword ptr [eax]
  10003BEE: add         eax,0E600h
  10003BF3: add         byte ptr [esi+02110000h],dh
  10003BF9: cmp         edi,ebx
  10003BFB: add         byte ptr [eax],al
  10003BFD: add         byte ptr [edx],al
  10003BFF: jg          10003C41
  10003C01: add         byte ptr [eax],al
  10003C03: add         al,16h
  10003C05: add         cl,byte ptr [edx+1Fh]
  10003C08: or          al,58h
  10003C0A: dec         edx
  10003C0B: sub         dword ptr [esi],esi
  10003C0E: add         byte ptr [ecx],dl
  10003C10: or          eax,9202C09h
  10003C15: and         eax,75294A4Ah
  10003C1A: add         byte ptr [eax],al
  10003C1C: adc         dword ptr [ebx],edx
  10003C1E: pop         es
  10003C1F: add         edx,dword ptr [ecx]
  10003C21: pop         es
  10003C22: sub         byte ptr [edx],ah
  10003C24: add         dword ptr [eax],eax
  10003C26: push        es
  10003C27: imul        edx,dword ptr [esi+9],25h
  10003C2B: dec         edx
  10003C2C: sbb         bl,byte ptr [eax+4Ah]
  10003C2F: sub         dword ptr [eax],edi
  10003C32: add         byte ptr [ecx],dl
  10003C34: add         bh,byte ptr [edi+41h]
  10003C37: add         byte ptr [eax],al
  10003C39: add         al,16h
  10003C3B: add         cl,byte ptr [edx+1Fh]
  10003C3E: or          al,58h
  10003C40: dec         edx
  10003C41: sub         dword ptr [esi],esi
  10003C44: add         byte ptr [ecx],dl
  10003C46: or          al,8
  10003C48: sub         al,22h
  10003C4A: or          byte ptr ds:[75294A4Ah],ah
  10003C50: add         byte ptr [eax],al
  10003C52: adc         dword ptr [ebx],edx
  10003C54: push        es
  10003C55: add         ebx,dword ptr [edx]
  10003C57: pop         eax
  10003C58: adc         dword ptr [esi],eax
  10003C5A: sub         byte ptr [edx],ah
  10003C5C: add         dword ptr [eax],eax
  10003C5E: push        es
  10003C5F: imul        edx,dword ptr [esi+8],25h
  10003C63: dec         edx
  10003C64: sbb         bl,byte ptr [eax+4Ah]
  10003C67: sub         dword ptr [eax],edi
  10003C6A: add         byte ptr [ecx],dl
  10003C6C: add         bh,byte ptr [edi+42h]
  10003C6F: add         byte ptr [eax],al
  10003C71: add         al,16h
  10003C73: add         cl,byte ptr [edx+1Fh]
  10003C76: or          al,58h
  10003C78: dec         edx
  10003C79: sub         dword ptr [esi],esi
  10003C7C: add         byte ptr [ecx],dl
  10003C7E: or          eax,dword ptr [edi]
  10003C80: sub         al,22h
  10003C82: pop         es
  10003C83: and         eax,75294A4Ah
  10003C88: add         byte ptr [eax],al
  10003C8A: adc         dword ptr [ebx],edx
  10003C8C: add         eax,11581E03h
  10003C91: add         eax,12228h
  10003C96: push        es
  10003C97: imul        edx,dword ptr [esi+7],25h
  10003C9B: dec         edx
  10003C9C: sbb         bl,byte ptr [eax+4Ah]
  10003C9F: sub         dword ptr [eax],edi
  10003CA2: add         byte ptr [ecx],dl
  10003CA4: add         bh,byte ptr [edi+43h]
  10003CA7: add         byte ptr [eax],al
  10003CA9: add         al,16h
  10003CAB: add         cl,byte ptr [edx+1Fh]
  10003CAE: or          al,58h
  10003CB0: dec         edx
  10003CB1: sub         dword ptr [esi],esi
  10003CB4: add         byte ptr [ecx],dl
  10003CB6: or          al,byte ptr [esi]
  10003CB8: sub         al,23h
  10003CBA: push        es
  10003CBB: and         eax,75294A4Ah
  10003CC0: add         byte ptr [eax],al
  10003CC2: adc         dword ptr [ebx],edx
  10003CC4: add         al,3
  10003CC6: pop         ds
  10003CC7: or          al,58h
  10003CC9: adc         dword ptr [eax+ebp],eax
  10003CCC: and         al,byte ptr [ecx]
  10003CCE: add         byte ptr [esi],al
  10003CD0: imul        edx,dword ptr [esi+6],25h
  10003CD4: dec         edx
  10003CD5: sbb         bl,byte ptr [eax+4Ah]
  10003CD8: sub         dword ptr [eax],edi
  10003CDB: add         byte ptr [ecx],dl
  10003CDD: sub         cl,ah
  10003CDF: int         3
  10003CE0: add         esi,dword ptr [eax]
  10003CE2: add         eax,7000h
  10003CE7: add         byte ptr [eax+eax+2C021100h],dh
  10003CEE: ins         byte ptr es:[edi],dx
  10003CEF: add         bh,byte ptr [edi+46h]
  10003CF2: add         byte ptr [eax],al
  10003CF4: add         al,16h
  10003CF6: add         cl,byte ptr [edx+1Fh]
  10003CF9: or          al,58h
  10003CFB: dec         edx
  10003CFC: sub         dword ptr [esi],esi
  10003CFF: add         byte ptr [ecx],dl
  10003D01: or          eax,dword ptr [edi]
  10003D03: sub         al,1Fh
  10003D05: pop         es
  10003D06: and         eax,75294A4Ah
  10003D0B: add         byte ptr [eax],al
  10003D0D: adc         dword ptr ds:[16160903h],ecx
  10003D13: sub         byte ptr [ebx],ah
  10003D15: add         dword ptr [eax],eax
  10003D17: push        es
  10003D18: push        esp
  10003D19: pop         es
  10003D1A: and         eax,4A581A4Ah
  10003D1F: sub         dword ptr [eax],edi
  10003D22: add         byte ptr [ecx],dl
  10003D24: add         bh,byte ptr [edi+47h]
  10003D27: add         byte ptr [eax],al
  10003D29: add         al,16h
  10003D2B: add         cl,byte ptr [edx+1Fh]
  10003D2E: or          al,58h
  10003D30: dec         edx
  10003D31: sub         dword ptr [esi],esi
  10003D34: add         byte ptr [ecx],dl
  10003D36: or          al,byte ptr [esi]
  10003D38: sub         al,21h
  10003D3A: push        es
  10003D3B: and         eax,75294A4Ah
  10003D40: add         byte ptr [eax],al
  10003D42: adc         dword ptr [ebx+eax],ecx
  10003D45: sbb         bl,byte ptr [eax+8]
  10003D48: push        ss
  10003D49: push        ss
  10003D4A: sub         byte ptr [ebx],ah
  10003D4C: add         dword ptr [eax],eax
  10003D4E: push        es
  10003D4F: push        esp
  10003D50: push        es
  10003D51: and         eax,4A581A4Ah
  10003D56: sub         dword ptr [eax],edi
  10003D59: add         byte ptr [ecx],dl
  10003D5B: sub         al,byte ptr [ebx]
  10003D5D: xor         byte ptr ds:[00007000h],al
  10003D63: add         byte ptr [eax+eax+2C021100h],dh
  10003D6A: ins         byte ptr es:[edi],dx
  10003D6B: add         bh,byte ptr [edi+48h]
  10003D6E: add         byte ptr [eax],al
  10003D70: add         al,16h
  10003D72: add         cl,byte ptr [edx+1Fh]
  10003D75: or          al,58h
  10003D77: dec         edx
  10003D78: sub         dword ptr [esi],esi
  10003D7B: add         byte ptr [ecx],dl
  10003D7D: or          eax,dword ptr [edi]
  10003D7F: sub         al,1Fh
  10003D81: pop         es
  10003D82: and         eax,75294A4Ah
  10003D87: add         byte ptr [eax],al
  10003D89: adc         dword ptr ds:[16160903h],ecx
  10003D8F: sub         byte ptr [ebx],ah
  10003D91: add         dword ptr [eax],eax
  10003D93: push        es
  10003D94: push        esp
  10003D95: pop         es
  10003D96: and         eax,4A581A4Ah
  10003D9B: sub         dword ptr [eax],edi
  10003D9E: add         byte ptr [ecx],dl
  10003DA0: add         bh,byte ptr [edi+49h]
  10003DA3: add         byte ptr [eax],al
  10003DA5: add         al,16h
  10003DA7: add         cl,byte ptr [edx+1Fh]
  10003DAA: or          al,58h
  10003DAC: dec         edx
  10003DAD: sub         dword ptr [esi],esi
  10003DB0: add         byte ptr [ecx],dl
  10003DB2: or          al,byte ptr [esi]
  10003DB4: sub         al,21h
  10003DB6: push        es
  10003DB7: and         eax,75294A4Ah
  10003DBC: add         byte ptr [eax],al
  10003DBE: adc         dword ptr [ebx+eax],ecx
  10003DC1: sbb         bl,byte ptr [eax+8]
  10003DC4: push        ss
  10003DC5: push        ss
  10003DC6: sub         byte ptr [ebx],ah
  10003DC8: add         dword ptr [eax],eax
  10003DCA: push        es
  10003DCB: push        esp
  10003DCC: push        es
  10003DCD: and         eax,4A581A4Ah
  10003DD2: sub         dword ptr [eax],edi
  10003DD5: add         byte ptr [ecx],dl
  10003DD7: sub         cl,byte ptr [ebx]
  10003DD9: xor         byte ptr [esi],al
  10003DDB: add         byte ptr [eax+eax],bh
  10003DDF: add         byte ptr [ebx+02110000h],bh
  10003DE5: cmp         dword ptr [ebp],esi
  10003DE8: add         byte ptr [eax],al
  10003DEA: add         bh,byte ptr [edi+58h]
  10003DED: add         byte ptr [eax],al
  10003DEF: add         al,16h
  10003DF1: add         cl,byte ptr [edx+1Fh]
  10003DF4: or          al,58h
  10003DF6: dec         edx
  10003DF7: sub         dword ptr [esi],esi
  10003DFA: add         byte ptr [ecx],dl
  10003DFC: or          al,byte ptr [esi]
  10003DFE: sub         al,1Eh
  10003E00: push        es
  10003E01: and         eax,75294A4Ah
  10003E06: add         byte ptr [eax],al
  10003E08: adc         dword ptr [ebx+eax],ecx
  10003E0B: or          byte ptr [eax],ch
  10003E0D: and         al,byte ptr [ecx]
  10003E0F: add         byte ptr [esi],al
  10003E11: imul        edx,dword ptr [esi+6],25h
  10003E15: dec         edx
  10003E16: sbb         bl,byte ptr [eax+4Ah]
  10003E19: sub         dword ptr [eax],edi
  10003E1C: add         byte ptr [ecx],dl
  10003E1E: add         dl,byte ptr [edx]
  10003E20: add         edi,dword ptr [edi+59h]
  10003E23: add         byte ptr [eax],al
  10003E25: add         al,16h
  10003E27: add         cl,byte ptr [edx+1Eh]
  10003E2A: pop         eax
  10003E2B: dec         edx
  10003E2C: sub         dword ptr [ebx],esi
  10003E2F: add         byte ptr [ecx],dl
  10003E31: or          eax,dword ptr [edi]
  10003E33: dec         edx
  10003E34: add         ebx,dword ptr [edx]
  10003E36: pop         eax
  10003E37: add         al,28h
  10003E39: aas
  10003E3A: add         byte ptr [eax],al
  10003E3C: push        es
  10003E3D: fimul       word ptr [esi]
  10003E3F: inc         byte ptr [esi]
  10003E41: xor         al,0
  10003E43: add         byte ptr [esi],al
  10003E45: adc         al,byte ptr [ebx]
  10003E47: sub         byte ptr [ebx],al
  10003E49: add         dword ptr [eax],eax
  10003E4B: push        es
  10003E4C: fcom        qword ptr [edx]
  10003E4E: add         ecx,dword ptr [edx+2Ch]
  10003E51: or          eax,124A0312h
  10003E56: add         ecx,dword ptr [edx+4Ah]
  10003E59: dec         edx
  10003E5A: sub         dword ptr [eax],edi
  10003E5D: add         byte ptr [ecx],dl
  10003E5F: sub         al,byte ptr [ecx+1Ch]
  10003E62: add         byte ptr [eax],al
  10003E64: add         al,0
  10003E66: add         byte ptr [eax],al
  10003E68: dec         esi
  10003E69: add         byte ptr [eax],al
  10003E6B: add         byte ptr ds:[5B000000h],cl
  10003E71: add         byte ptr [eax],al
  10003E73: add         byte ptr [esi],cl
  10003E75: add         byte ptr [eax],al
  10003E77: add         byte ptr [edx],bh
  10003E79: add         byte ptr [eax],al
  10003E7B: add         dword ptr [ebx],ecx
  10003E7D: xor         byte ptr [esi],al
  10003E7F: add         byte ptr [eax+BC000000h],cl
  10003E85: add         byte ptr [eax],al
  10003E87: adc         dword ptr [edx],eax
  10003E89: cmp         dword ptr [ecx+02000000h],eax
  10003E8F: adc         al,byte ptr [ebx]
  10003E91: jg          10003EDD
  10003E93: add         byte ptr [eax],al
  10003E95: add         al,16h
  10003E97: add         cl,byte ptr [edx+1Eh]
  10003E9A: pop         eax
  10003E9B: dec         edx
  10003E9C: sub         dword ptr [ebx],esi
  10003E9F: add         byte ptr [ecx],dl
  10003EA1: or          eax,dword ptr [edi]
  10003EA3: dec         edx
  10003EA4: add         eax,dword ptr [eax+ebp]
  10003EA7: aas
  10003EA8: add         byte ptr [eax],al
  10003EAA: push        es
  10003EAB: fimul       word ptr [esi]
  10003EAD: inc         byte ptr [esi]
  10003EAF: xor         al,0
  10003EB1: add         byte ptr [esi],al
  10003EB3: adc         al,byte ptr [ebx]
  10003EB5: sub         byte ptr [ebx],al
  10003EB7: add         dword ptr [eax],eax
  10003EB9: push        es
  10003EBA: fcom        qword ptr [edx]
  10003EBC: add         ecx,dword ptr [edx+2Ch]
  10003EBF: or          eax,124A0312h
  10003EC4: add         ecx,dword ptr [edx+4Ah]
  10003EC7: dec         edx
  10003EC8: sub         dword ptr [eax],edi
  10003ECB: add         byte ptr [ecx],dl
  10003ECD: add         dl,byte ptr [edx]
  10003ECF: add         bh,byte ptr [edi+4Bh]
  10003ED2: add         byte ptr [eax],al
  10003ED4: add         al,16h
  10003ED6: add         cl,byte ptr [edx+1Eh]
  10003ED9: pop         eax
  10003EDA: dec         edx
  10003EDB: sub         dword ptr [ebx],esi
  10003EDE: add         byte ptr [ecx],dl
  10003EE0: or          al,byte ptr [esi]
  10003EE2: dec         edx
  10003EE3: add         ebx,dword ptr [edi]
  10003EE5: or          al,58h
  10003EE7: add         al,28h
  10003EE9: aas
  10003EEA: add         byte ptr [eax],al
  10003EEC: push        es
  10003EED: fimul       word ptr [esi]
  10003EEF: inc         byte ptr [esi]
  10003EF1: xor         al,0
  10003EF3: add         byte ptr [esi],al
  10003EF5: adc         al,byte ptr [edx]
  10003EF7: sub         byte ptr [ebx],al
  10003EF9: add         dword ptr [eax],eax
  10003EFB: push        es
  10003EFC: fcom        qword ptr [edx]
  10003EFE: add         cl,byte ptr [edx+2Ch]
  10003F01: or          eax,124A0212h
  10003F06: add         cl,byte ptr [edx+4Ah]
  10003F09: dec         edx
  10003F0A: sub         dword ptr [eax],edi
  10003F0D: add         byte ptr [ecx],dl
  10003F0F: sub         al,byte ptr [ecx+34h]
  10003F12: add         byte ptr [eax],al
  10003F14: add         al,0
  10003F16: add         byte ptr [eax],al
  10003F18: sbb         al,byte ptr [eax]
  10003F1A: add         byte ptr [eax],al
  10003F1C: or          eax,dword ptr [eax]
  10003F1E: add         byte ptr [eax],al
  10003F20: and         eax,0E000000h
  10003F25: add         byte ptr [eax],al
  10003F27: add         byte ptr [edx],bh
  10003F29: add         byte ptr [eax],al
  10003F2B: add         dword ptr [eax+eax],eax
  10003F2E: add         byte ptr [eax],al
  10003F30: pop         ecx
  10003F31: add         byte ptr [eax],al
  10003F33: add         byte ptr [esi],cl
  10003F35: add         byte ptr [eax],al
  10003F37: add         byte ptr [edi],ah
  10003F3A: add         byte ptr [eax],al
  10003F3C: push        cs
  10003F3D: add         byte ptr [eax],al
  10003F3F: add         byte ptr [edx],bh
  10003F41: add         byte ptr [eax],al
  10003F43: add         dword ptr [ebx],eax
  10003F45: xor         byte ptr [ebx],al
  10003F47: add         byte ptr [edi+81000000h],cl
  10003F4D: add         byte ptr [eax],al
  10003F4F: adc         dword ptr [ebx],eax
  10003F51: inc         edi
  10003F52: sub         al,59h
  10003F54: adc         al,byte ptr [edx]
  10003F56: add         bl,byte ptr [edi]
  10003F58: or          al,58h
  10003F5A: sbb         dword ptr [eax+47h],ebx
  10003F5D: push        edx
  10003F5E: adc         al,byte ptr [edx]
  10003F60: pop         ss
  10003F61: pop         eax
  10003F62: add         bl,byte ptr [edi]
  10003F64: or          al,58h
  10003F66: sbb         byte ptr [eax+47h],bl
  10003F69: push        edx
  10003F6A: adc         al,byte ptr [edx]
  10003F6C: sbb         byte ptr [eax+2],bl
  10003F6F: pop         ds
  10003F70: or          al,58h
  10003F72: pop         ss
  10003F73: pop         eax
  10003F74: inc         edi
  10003F75: push        edx
  10003F76: adc         al,byte ptr [edx]
  10003F78: sbb         dword ptr [eax+2],ebx
  10003F7B: pop         ds
  10003F7C: or          al,58h
  10003F7E: inc         edi
  10003F7F: push        edx
  10003F80: add         bl,byte ptr [edi]
  10003F82: or          al,58h
  10003F84: or          byte ptr [ebx+eax+47h],dl
  10003F88: sub         al,23h
  10003F8A: adc         al,byte ptr [ecx]
  10003F8C: add         bl,byte ptr [ecx]
  10003F8E: pop         eax
  10003F8F: inc         edi
  10003F90: push        edx
  10003F91: adc         al,byte ptr [ecx]
  10003F93: pop         ss
  10003F94: pop         eax
  10003F95: add         bl,byte ptr [eax]
  10003F97: pop         eax
  10003F98: inc         edi
  10003F99: push        edx
  10003F9A: adc         al,byte ptr [ecx]
  10003F9C: sbb         byte ptr [eax+2],bl
  10003F9F: pop         ss
  10003FA0: pop         eax
  10003FA1: inc         edi
  10003FA2: push        edx
  10003FA3: adc         al,byte ptr [ecx]
  10003FA5: sbb         dword ptr [eax+2],ebx
  10003FA8: inc         edi
  10003FA9: push        edx
  10003FAA: add         al,byte ptr [edi]
  10003FAC: push        esp
  10003FAD: add         eax,dword ptr [edi+2Ch]
  10003FB0: sub         eax,1A020012h
  10003FB5: pop         eax
  10003FB6: sbb         dword ptr [eax+47h],ebx
  10003FB9: push        edx
  10003FBA: adc         al,byte ptr [eax]
  10003FBC: pop         ss
  10003FBD: pop         eax
  10003FBE: add         bl,byte ptr [edx]
  10003FC0: pop         eax
  10003FC1: sbb         byte ptr [eax+47h],bl
  10003FC4: push        edx
  10003FC5: adc         al,byte ptr [eax]
  10003FC7: sbb         byte ptr [eax+2],bl
  10003FCA: sbb         bl,byte ptr [eax+17h]
  10003FCD: pop         eax
  10003FCE: inc         edi
  10003FCF: push        edx
  10003FD0: adc         al,byte ptr [eax]
  10003FD2: sbb         dword ptr [eax+2],ebx
  10003FD5: sbb         bl,byte ptr [eax+47h]
  10003FD8: push        edx
  10003FD9: add         bl,byte ptr [edx]
  10003FDB: pop         eax
  10003FDC: push        es
  10003FDD: push        esp
  10003FDE: sub         cl,ah
  10003FE0: add         esi,dword ptr [eax]
  10003FE2: add         eax,5100h
  10003FE7: add         byte ptr [ebx+02110000h],ch
  10003FED: sub         al,4Dh
  10003FEF: add         ah,byte ptr ds:[58101F4Ah]
  10003FF5: dec         edx
  10003FF6: sub         dword ptr [edx],edi
  10003FF9: add         byte ptr [ecx],dl
  10003FFB: or          al,byte ptr [esi]
  10003FFD: sub         al,1Eh
  10003FFF: push        es
  10004000: and         eax,75294A4Ah
  10004005: add         byte ptr [eax],al
  10004007: adc         dword ptr [ebx],ecx
  10004009: add         eax,dword ptr [edi]
  1000400B: sub         byte ptr [edx],ah
  1000400D: add         dword ptr [eax],eax
  1000400F: push        es
  10004010: imul        edx,dword ptr [esi+6],25h
  10004014: dec         edx
  10004015: sbb         bl,byte ptr [eax+4Ah]
  10004018: sub         dword ptr [eax],edi
  1000401B: add         byte ptr [ecx],dl
  1000401D: add         bh,byte ptr [edi+5Eh]
  10004020: add         byte ptr [eax],al
  10004022: add         al,7Fh
  10004024: pop         ebp
  10004025: add         byte ptr [eax],al
  10004027: add         al,2
  10004029: dec         edx
  1000402A: pop         ds
  1000402B: or          al,58h
  1000402D: dec         edx
  1000402E: sub         dword ptr [esi],esi
  10004031: add         byte ptr [ecx],dl
  10004033: add         ebx,dword ptr [edx]
  10004035: pop         eax
  10004036: add         al,28h
  10004038: jne         1000403A
  1000403A: add         byte ptr [esi],al
  1000403C: sub         cl,ah
  1000403E: int         3
  1000403F: int         3
  10004040: add         esi,dword ptr [eax]
  10004042: add         eax,17700h
  10004047: add         byte ptr [edi+02110000h],bh
  1000404D: cmp         dword ptr [eax+1],esi
  10004050: add         byte ptr [eax],al
  10004052: add         bh,byte ptr [edi+70h]
  10004055: add         byte ptr [eax],al
  10004057: add         al,7Fh
  10004059: outs        dx,dword ptr [esi]
  1000405A: add         byte ptr [eax],al
  1000405C: add         al,2
  1000405E: dec         edx
  1000405F: pop         ds
  10004060: or          al,58h
  10004062: dec         edx
  10004063: sub         dword ptr [esi],esi
  10004066: add         byte ptr [ecx],dl
  10004068: add         ebx,dword ptr [edi]
  1000406A: adc         al,58h
  1000406C: add         al,28h
  1000406E: jne         10004070
  10004070: add         byte ptr [esi],al
  10004072: add         bh,byte ptr [edi+71h]
  10004075: add         byte ptr [eax],al
  10004077: add         al,7Fh
  10004079: outs        dx,dword ptr [esi]
  1000407A: add         byte ptr [eax],al
  1000407C: add         al,2
  1000407E: dec         edx
  1000407F: pop         ds
  10004080: or          al,58h
  10004082: dec         edx
  10004083: sub         dword ptr [esi],esi
  10004086: add         byte ptr [ecx],dl
  10004088: add         ebx,dword ptr [edi]
  1000408A: adc         eax,75280458h
  1000408F: add         byte ptr [eax],al
  10004091: push        es
  10004092: add         bh,byte ptr [edi+73h]
  10004095: add         byte ptr [eax],al
  10004097: add         al,7Fh
  10004099: jb          1000409B
  1000409B: add         byte ptr [edx+eax],al
  1000409E: dec         edx
  1000409F: pop         ds
  100040A0: or          al,58h
  100040A2: dec         edx
  100040A3: sub         dword ptr [esi],esi
  100040A6: add         byte ptr [ecx],dl
  100040A8: adc         eax,dword ptr [ecx+edx]
  100040AB: add         al,2Ch
  100040AD: and         dl,byte ptr [ecx]
  100040AF: add         al,25h
  100040B1: dec         edx
  100040B2: dec         edx
  100040B3: sub         dword ptr [ebp],esi
  100040B6: add         byte ptr [ecx],dl
  100040B8: adc         ecx,dword ptr [ecx]
  100040BA: add         edx,dword ptr [ecx]
  100040BC: or          dword ptr [eax],ebp
  100040BE: and         al,byte ptr [ecx]
  100040C0: add         byte ptr [esi],al
  100040C2: imul        edx,dword ptr [esi+11h],4
  100040C6: and         eax,4A581A4Ah
  100040CB: sub         dword ptr [eax],edi
  100040CE: add         byte ptr [ecx],dl
  100040D0: add         bh,byte ptr [edi+75h]
  100040D3: add         byte ptr [eax],al
  100040D5: add         al,7Fh
  100040D7: je          100040D9
  100040D9: add         byte ptr [edx+eax],al
  100040DC: dec         edx
  100040DD: pop         ds
  100040DE: or          al,58h
  100040E0: dec         edx
  100040E1: sub         dword ptr [esi],esi
  100040E4: add         byte ptr [ecx],dl
  100040E6: or          eax,9222C09h
  100040EB: and         eax,75294A4Ah
  100040F0: add         byte ptr [eax],al
  100040F2: adc         dword ptr [ebx],edx
  100040F4: or          byte ptr [ebx],al
  100040F6: sbb         bl,byte ptr [eax+11h]
  100040F9: or          byte ptr [eax],ch
  100040FB: and         al,byte ptr [ecx]
  100040FD: add         byte ptr [esi],al
  100040FF: imul        edx,dword ptr [esi+9],25h
  10004103: dec         edx
  10004104: sbb         bl,byte ptr [eax+4Ah]
  10004107: sub         dword ptr [eax],edi
  1000410A: add         byte ptr [ecx],dl
  1000410C: add         bh,byte ptr [edi+76h]
  1000410F: add         byte ptr [eax],al
  10004111: add         al,7Fh
  10004113: je          10004115
  10004115: add         byte ptr [edx+eax],al
  10004118: dec         edx
  10004119: pop         ds
  1000411A: or          al,58h
  1000411C: dec         edx
  1000411D: sub         dword ptr [esi],esi
  10004120: add         byte ptr [ecx],dl
  10004122: or          al,8
  10004124: sub         al,22h
  10004126: or          byte ptr ds:[75294A4Ah],ah
  1000412C: add         byte ptr [eax],al
  1000412E: adc         dword ptr [ebx],edx
  10004130: pop         es
  10004131: add         ebx,dword ptr [esi]
  10004133: pop         eax
  10004134: adc         dword ptr [edi],eax
  10004136: sub         byte ptr [edx],ah
  10004138: add         dword ptr [eax],eax
  1000413A: push        es
  1000413B: imul        edx,dword ptr [esi+8],25h
  1000413F: dec         edx
  10004140: sbb         bl,byte ptr [eax+4Ah]
  10004143: sub         dword ptr [eax],edi
  10004146: add         byte ptr [ecx],dl
  10004148: add         bh,byte ptr [edi+78h]
  1000414B: add         byte ptr [eax],al
  1000414D: add         al,7Fh
  1000414F: ja          10004151
  10004151: add         byte ptr [edx+eax],al
  10004154: dec         edx
  10004155: pop         ds
  10004156: or          al,58h
  10004158: dec         edx
  10004159: sub         dword ptr [esi],esi
  1000415C: add         byte ptr [ecx],dl
  1000415E: or          eax,dword ptr [edi]
  10004160: sub         al,23h
  10004162: pop         es
  10004163: and         eax,75294A4Ah
  10004168: add         byte ptr [eax],al
  1000416A: adc         dword ptr [ebx],edx
  1000416C: push        es
  1000416D: add         ebx,dword ptr [edi]
  1000416F: or          al,58h
  10004171: adc         dword ptr [esi],eax
  10004173: sub         byte ptr [edx],ah
  10004175: add         dword ptr [eax],eax
  10004177: push        es
  10004178: imul        edx,dword ptr [esi+7],25h
  1000417C: dec         edx
  1000417D: sbb         bl,byte ptr [eax+4Ah]
  10004180: sub         dword ptr [eax],edi
  10004183: add         byte ptr [ecx],dl
  10004185: add         bh,byte ptr [edi+7Ah]
  10004188: add         byte ptr [eax],al
  1000418A: add         al,7Fh
  1000418C: jns         1000418E
  1000418E: add         byte ptr [edx+eax],al
  10004191: dec         edx
  10004192: pop         ds
  10004193: or          al,58h
  10004195: dec         edx
  10004196: sub         dword ptr [esi],esi
  10004199: add         byte ptr [ecx],dl
  1000419B: or          al,byte ptr [esi]
  1000419D: sub         al,23h
  1000419F: push        es
  100041A0: and         eax,75294A4Ah
  100041A5: add         byte ptr [eax],al
  100041A7: adc         dword ptr [ebx],edx
  100041A9: add         eax,58101F03h
  100041AE: adc         dword ptr ds:[00012228h],eax
  100041B4: push        es
  100041B5: imul        edx,dword ptr [esi+6],25h
  100041B9: dec         edx
  100041BA: sbb         bl,byte ptr [eax+4Ah]
  100041BD: sub         dword ptr [eax],edi
  100041C0: add         byte ptr [ecx],dl
  100041C2: sub         cl,ah
  100041C4: or          esi,dword ptr [eax]
  100041C6: add         dword ptr [eax],eax
  100041C8: or          eax,0
  100041CD: add         byte ptr [eax],al
  100041CF: add         byte ptr [ebx],al
  100041D1: sub         eax,207DE09h
  100041D6: sub         byte ptr [edi],ch
  100041D8: add         byte ptr [eax],al
  100041DA: or          bl,ah
  100041DC: sub         al,byte ptr [eax]
  100041DE: add         byte ptr [eax],al
  100041E0: inc         ecx
  100041E1: sbb         al,0
  100041E3: add         byte ptr [edx],al
  100041E5: add         byte ptr [eax],al
  100041E7: add         byte ptr [ebx],al
  100041E9: add         byte ptr [eax],al
  100041EB: add         byte ptr [edx],al
  100041ED: add         byte ptr [eax],al
  100041EF: add         byte ptr ds:[07000000h],al
  100041F5: add         byte ptr [eax],al
  100041F7: add         byte ptr [edx],bh
  100041F9: add         byte ptr [eax],al
  100041FB: add         dword ptr [ebx],eax
  100041FD: xor         byte ptr [edx],al
  100041FF: add         byte ptr [eax],cl
  10004201: add         byte ptr [eax],al
  10004203: add         byte ptr [eax],al
  10004205: add         byte ptr [eax],al
  10004207: add         byte ptr [edx],al
  10004209: push        ss
  1000420A: outs        dx,dword ptr [esi]
  1000420B: dec         ebx
  1000420C: add         dword ptr [eax],eax
  1000420E: push        es
  1000420F: sub         al,byte ptr [ebx]
  10004211: xor         byte ptr [edx],al
  10004213: add         byte ptr [ebx],bl
  10004215: add         byte ptr [eax],al
  10004217: add         byte ptr [edx+12110000h],ah
  1000421D: add         byte ptr [edx],al
  1000421F: dec         edx
  10004220: sub         byte ptr [edx],ch
  10004222: add         byte ptr [eax],al
  10004224: or          al,byte ptr [esi]
  10004226: sub         byte ptr [edx],dh
  10004228: add         byte ptr [eax],al
  1000422A: or          cl,byte ptr [ebx]
  1000422C: adc         al,byte ptr [ecx]
  1000422E: sub         byte ptr [ecx],dh
  10004230: add         byte ptr [eax],al
  10004232: or          al,byte ptr [edx]
  10004234: push        ss
  10004235: push        esp
  10004236: sub         cl,ah
  10004238: add         esi,dword ptr [eax]
  1000423A: add         dword ptr [eax],eax
  1000423C: or          eax,10000000h
  10004241: add         byte ptr [eax],al
  10004243: adc         dword ptr [edx],eax
  10004245: dec         edx
  10004246: or          al,byte ptr [esi]
  10004248: sub         al,6
  1000424A: push        es
  1000424B: sub         byte ptr [edi],bl
  1000424D: add         dword ptr [eax],eax
  1000424F: push        es
  10004250: sub         al,byte ptr [eax]
  10004252: add         byte ptr [eax],al
  10004254: add         byte ptr [eax],al
  10004256: add         byte ptr [eax],al
  10004258: add         esi,dword ptr [eax]
  1000425A: add         eax,dword ptr [eax]
  1000425C: and         al,0
  1000425E: add         byte ptr [eax],al
  10004260: ret         0
  10004263: adc         dword ptr [edx],eax
  10004265: dec         edx
  10004266: or          al,3
  10004268: dec         edx
  10004269: or          ecx,dword ptr [eax]
  1000426B: pop         es
  1000426C: xor         al,4
  1000426E: pop         ss
  1000426F: or          ch,byte ptr [ebx]
  10004271: adc         al,8
  10004273: pop         es
  10004274: add         al,16h
  10004277: or          ch,byte ptr [ebx]
  10004279: or          al,2
  1000427B: push        ds
  1000427C: pop         eax
  1000427D: dec         edx
  1000427E: add         ebx,dword ptr [esi]
  10004280: pop         eax
  10004281: dec         edx
  10004282: inc         byte ptr ds:[2A060AD2h]
  10004288: int         3
  10004289: int         3
  1000428A: int         3
  1000428B: int         3
  1000428C: int         3
  1000428D: int         3
  1000428E: int         3
  1000428F: int         3
  10004290: jmp         dword ptr ds:[100244ACh]
  10004296: int         3
  10004297: int         3
  10004298: add         esi,dword ptr [eax]
  1000429A: add         eax,dword ptr [eax]
  1000429C: push        0
  1000429E: add         byte ptr [eax],al
  100042A0: les         eax,fword ptr [eax]
  100042A2: add         byte ptr [ecx],dl
  100042A4: add         bl,byte ptr [edx]
  100042A6: pop         eax
  100042A7: dec         edx
  100042A8: or          al,8
  100042AA: or          al,byte ptr [edx]
  100042AC: dec         edx
  100042AD: sbb         bl,byte ptr [edx+8]
  100042B0: pop         eax
  100042B1: or          eax,dword ptr [esi]
  100042B3: pop         es
  100042B4: xor         byte ptr cs:[ebx],al
  100042B7: inc         edi
  100042B8: sub         al,24h
  100042BA: adc         al,byte ptr [esi+eax]
  100042BD: sbb         dword ptr [eax+47h],ebx
  100042C0: push        edx
  100042C1: adc         al,byte ptr [edi+edx]
  100042C4: pop         eax
  100042C5: push        es
  100042C6: sbb         byte ptr [eax+47h],bl
  100042C9: push        edx
  100042CA: adc         al,byte ptr [eax+ebx]
  100042CD: pop         eax
  100042CE: push        es
  100042CF: pop         ss
  100042D0: pop         eax
  100042D1: inc         edi
  100042D2: push        edx
  100042D3: adc         al,byte ptr [ecx+ebx]
  100042D6: pop         eax
  100042D7: push        es
  100042D8: inc         edi
  100042D9: push        edx
  100042DA: push        es
  100042DB: adc         dword ptr [esp+edx*2],eax
  100042DE: push        es
  100042DF: sbb         bl,byte ptr [eax+0Ah]
  100042E2: push        es
  100042E3: pop         es
  100042E4: xor         edx,eax
  100042E6: add         eax,dword ptr [edi+2Ch]
  100042E9: and         edx,dword ptr [edx]
  100042EB: add         eax,dword ptr [edx]
  100042ED: sbb         dword ptr [eax+47h],ebx
  100042F0: push        edx
  100042F1: adc         al,byte ptr [ebx]
  100042F3: pop         ss
  100042F4: pop         eax
  100042F5: add         bl,byte ptr [eax]
  100042F7: pop         eax
  100042F8: inc         edi
  100042F9: push        edx
  100042FA: adc         al,byte ptr [ebx]
  100042FC: sbb         byte ptr [eax+2],bl
  100042FF: pop         ss
  10004300: pop         eax
  10004301: inc         edi
  10004302: push        edx
  10004303: adc         al,byte ptr [ebx]
  10004305: sbb         dword ptr [eax+2],ebx
  10004308: inc         edi
  10004309: push        edx
  1000430A: add         cl,byte ptr [ecx]
  1000430C: push        esp
  1000430D: sub         cl,ah
  1000430F: int         3
  10004310: add         esi,dword ptr [eax]
  10004312: add         eax,dword ptr [eax]
  10004314: das
  10004315: add         dword ptr [eax],eax
  10004317: add         bh,al
  10004319: add         byte ptr [eax],al
  1000431B: adc         dword ptr [edx],eax
  1000431D: sbb         bl,byte ptr [eax+4Ah]
  10004320: adc         eax,dword ptr [esi]
  10004322: adc         dword ptr [esi],eax
  10004324: or          al,2
  10004326: dec         edx
  10004327: pop         ds
  10004328: and         byte ptr [edx+11h],bl
  1000432B: push        es
  1000432C: pop         eax
  1000432D: adc         eax,dword ptr ds:[3B051108h]
  10004333: jmp         10004335
  10004335: add         byte ptr [eax],al
  10004337: or          byte ptr [ebx],al
  10004339: sub         byte ptr [eax],al
  1000433C: add         byte ptr [esi],al
  1000433E: or          byte ptr [edi],bl
  10004340: or          al,58h
  10004342: add         ebp,dword ptr [eax]
  10004344: inc         eax
  10004345: add         byte ptr [eax],al
  10004347: push        es
  10004348: or          byte ptr [edi],bl
  1000434A: sbb         byte ptr [eax+4Ah],bl
  1000434D: adc         eax,dword ptr [ecx+edx]
  10004350: add         al,2Ch
  10004352: pop         ebp
  10004353: adc         dword ptr [ebx+ecx],eax
  10004356: add         eax,dword ptr [edi+2Ch]
  10004359: and         al,12h
  1000435B: or          eax,dword ptr [edi]
  1000435D: sbb         dword ptr [eax+47h],ebx
  10004360: push        edx
  10004361: adc         cl,byte ptr [ebx]
  10004363: pop         ss
  10004364: pop         eax
  10004365: pop         es
  10004366: sbb         byte ptr [eax+47h],bl
  10004369: push        edx
  1000436A: adc         cl,byte ptr [ebx]
  1000436C: sbb         byte ptr [eax+7],bl
  1000436F: pop         ss
  10004370: pop         eax
  10004371: inc         edi
  10004372: push        edx
  10004373: adc         cl,byte ptr [ebx]
  10004375: sbb         dword ptr [eax+7],ebx
  10004378: inc         edi
  10004379: push        edx
  1000437A: pop         es
  1000437B: adc         dword ptr [ebx],ecx
  1000437D: push        esp
  1000437E: add         eax,dword ptr [edi+2Ch]
  10004381: adc         cl,byte ptr cs:[edx]
  10004384: pop         es
  10004385: sbb         bl,byte ptr [eax+19h]
  10004388: pop         eax
  10004389: inc         edi
  1000438A: push        edx
  1000438B: adc         cl,byte ptr [edx]
  1000438D: pop         ss
  1000438E: pop         eax
  1000438F: pop         es
  10004390: sbb         bl,byte ptr [eax+18h]
  10004393: pop         eax
  10004394: inc         edi
  10004395: push        edx
  10004396: adc         cl,byte ptr [edx]
  10004398: sbb         byte ptr [eax+7],bl
  1000439B: sbb         bl,byte ptr [eax+17h]
  1000439E: pop         eax
  1000439F: inc         edi
  100043A0: push        edx
  100043A1: adc         cl,byte ptr [edx]
  100043A3: sbb         dword ptr [eax+7],ebx
  100043A6: sbb         bl,byte ptr [eax+47h]
  100043A9: push        edx
  100043AA: pop         es
  100043AB: sbb         bl,byte ptr [eax+11h]
  100043AE: or          dl,byte ptr [eax+ecx+1Fh]
  100043B2: sbb         al,58h
  100043B4: dec         edx
  100043B5: or          eax,95C2C09h
  100043BA: or          al,byte ptr [ebx]
  100043BC: inc         edi
  100043BD: sub         al,24h
  100043BF: adc         cl,byte ptr [ecx]
  100043C1: push        es
  100043C2: sbb         dword ptr [eax+47h],ebx
  100043C5: push        edx
  100043C6: adc         cl,byte ptr [ecx]
  100043C8: pop         ss
  100043C9: pop         eax
  100043CA: push        es
  100043CB: sbb         byte ptr [eax+47h],bl
  100043CE: push        edx
  100043CF: adc         cl,byte ptr [ecx]
  100043D1: sbb         byte ptr [eax+6],bl
  100043D4: pop         ss
  100043D5: pop         eax
  100043D6: inc         edi
  100043D7: push        edx
  100043D8: adc         cl,byte ptr [ecx]
  100043DA: sbb         dword ptr [eax+6],ebx
  100043DD: inc         edi
  100043DE: push        edx
  100043DF: push        es
  100043E0: adc         dword ptr [ecx],ecx
  100043E2: push        esp
  100043E3: add         eax,dword ptr [edi+2Ch]
  100043E6: adc         cl,byte ptr cs:[eax]
  100043E9: push        es
  100043EA: sbb         bl,byte ptr [eax+19h]
  100043ED: pop         eax
  100043EE: inc         edi
  100043EF: push        edx
  100043F0: adc         cl,byte ptr [eax]
  100043F2: pop         ss
  100043F3: pop         eax
  100043F4: push        es
  100043F5: sbb         bl,byte ptr [eax+18h]
  100043F8: pop         eax
  100043F9: inc         edi
  100043FA: push        edx
  100043FB: adc         cl,byte ptr [eax]
  100043FD: sbb         byte ptr [eax+6],bl
  10004400: sbb         bl,byte ptr [eax+17h]
  10004403: pop         eax
  10004404: inc         edi
  10004405: push        edx
  10004406: adc         cl,byte ptr [eax]
  10004408: sbb         dword ptr [eax+6],ebx
  1000440B: sbb         bl,byte ptr [eax+47h]
  1000440E: push        edx
  1000440F: push        es
  10004410: sbb         bl,byte ptr [eax+11h]
  10004413: or          byte ptr [eax+ecx+1Fh],dl
  10004417: and         byte ptr [eax+0Ch],bl
  1000441A: or          byte ptr [ecx],dl
  1000441C: add         eax,0FFFF1540h
  10004421: inc         dword ptr [ebx]
  10004423: inc         edi
  10004424: sub         al,24h
  10004426: adc         al,byte ptr [edi]
  10004428: add         bl,byte ptr [ecx]
  1000442A: pop         eax
  1000442B: inc         edi
  1000442C: push        edx
  1000442D: adc         al,byte ptr [edi]
  1000442F: pop         ss
  10004430: pop         eax
  10004431: add         bl,byte ptr [eax]
  10004433: pop         eax
  10004434: inc         edi
  10004435: push        edx
  10004436: adc         al,byte ptr [edi]
  10004438: sbb         byte ptr [eax+2],bl
  1000443B: pop         ss
  1000443C: pop         eax
  1000443D: inc         edi
  1000443E: push        edx
  1000443F: adc         al,byte ptr [edi]
  10004441: sbb         dword ptr [eax+2],ebx
  10004444: inc         edi
  10004445: push        edx
  10004446: add         dl,byte ptr [ecx]
  10004448: pop         es
  10004449: push        esp
  1000444A: sub         cl,ah
  1000444C: add         esi,dword ptr [eax]
  1000444E: add         eax,dword ptr [eax]
  10004450: pop         esp
  10004451: add         byte ptr [eax],al
  10004453: add         dl,cl
  10004455: add         byte ptr [eax],al
  10004457: adc         dword ptr [edx],eax
  10004459: dec         edx
  1000445A: or          al,byte ptr [ebx]
  1000445C: inc         edi
  1000445D: sub         al,23h
  1000445F: adc         al,byte ptr [edx]
  10004461: push        es
  10004462: sbb         dword ptr [eax+47h],ebx
  10004465: push        edx
  10004466: adc         al,byte ptr [edx]
  10004468: pop         ss
  10004469: pop         eax
  1000446A: push        es
  1000446B: sbb         byte ptr [eax+47h],bl
  1000446E: push        edx
  1000446F: adc         al,byte ptr [edx]
  10004471: sbb         byte ptr [eax+6],bl
  10004474: pop         ss
  10004475: pop         eax
  10004476: inc         edi
  10004477: push        edx
  10004478: adc         al,byte ptr [edx]
  1000447A: sbb         dword ptr [eax+6],ebx
  1000447D: inc         edi
  1000447E: push        edx
  1000447F: push        es
  10004480: or          byte ptr [ebx+eax+47h],dl
  10004484: sub         al,2Dh
  10004486: adc         al,byte ptr [ecx]
  10004488: push        es
  10004489: sbb         bl,byte ptr [eax+19h]
  1000448C: pop         eax
  1000448D: inc         edi
  1000448E: push        edx
  1000448F: adc         al,byte ptr [ecx]
  10004491: pop         ss
  10004492: pop         eax
  10004493: push        es
  10004494: sbb         bl,byte ptr [eax+18h]
  10004497: pop         eax
  10004498: inc         edi
  10004499: push        edx
  1000449A: adc         al,byte ptr [ecx]
  1000449C: sbb         byte ptr [eax+6],bl
  1000449F: sbb         bl,byte ptr [eax+17h]
  100044A2: pop         eax
  100044A3: inc         edi
  100044A4: push        edx
  100044A5: adc         al,byte ptr [ecx]
  100044A7: sbb         dword ptr [eax+6],ebx
  100044AA: sbb         bl,byte ptr [eax+47h]
  100044AD: push        edx
  100044AE: push        es
  100044AF: sbb         bl,byte ptr [eax+7]
  100044B2: push        esp
  100044B3: sub         al,byte ptr [ebx]
  100044B5: xor         byte ptr [ebx],al
  100044B7: add         byte ptr [eax+eax],bl
  100044BB: add         ah,cl
  100044BD: add         byte ptr [eax],al
  100044BF: adc         dword ptr [edx],eax
  100044C1: dec         edx
  100044C2: or          al,byte ptr [ebx]
  100044C4: inc         edi
  100044C5: sub         al,23h
  100044C7: adc         al,byte ptr [edx]
  100044C9: push        es
  100044CA: sbb         dword ptr [eax+47h],ebx
  100044CD: push        edx
  100044CE: adc         al,byte ptr [edx]
  100044D0: pop         ss
  100044D1: pop         eax
  100044D2: push        es
  100044D3: sbb         byte ptr [eax+47h],bl
  100044D6: push        edx
  100044D7: adc         al,byte ptr [edx]
  100044D9: sbb         byte ptr [eax+6],bl
  100044DC: pop         ss
  100044DD: pop         eax
  100044DE: inc         edi
  100044DF: push        edx
  100044E0: adc         al,byte ptr [edx]
  100044E2: sbb         dword ptr [eax+6],ebx
  100044E5: inc         edi
  100044E6: push        edx
  100044E7: push        es
  100044E8: or          byte ptr [ebx+eax+47h],dl
  100044EC: sub         al,2Dh
  100044EE: adc         al,byte ptr [ecx]
  100044F0: push        es
  100044F1: sbb         bl,byte ptr [eax+19h]
  100044F4: pop         eax
  100044F5: inc         edi
  100044F6: push        edx
  100044F7: adc         al,byte ptr [ecx]
  100044F9: pop         ss
  100044FA: pop         eax
  100044FB: push        es
  100044FC: sbb         bl,byte ptr [eax+18h]
  100044FF: pop         eax
  10004500: inc         edi
  10004501: push        edx
  10004502: adc         al,byte ptr [ecx]
  10004504: sbb         byte ptr [eax+6],bl
  10004507: sbb         bl,byte ptr [eax+17h]
  1000450A: pop         eax
  1000450B: inc         edi
  1000450C: push        edx
  1000450D: adc         al,byte ptr [ecx]
  1000450F: sbb         dword ptr [eax+6],ebx
  10004512: sbb         bl,byte ptr [eax+47h]
  10004515: push        edx
  10004516: push        es
  10004517: sbb         bl,byte ptr [eax+7]
  1000451A: push        esp
  1000451B: sub         al,byte ptr [ebx]
  1000451D: xor         byte ptr [ebx],al
  1000451F: add         byte ptr [eax+eax],bl
  10004523: add         ch,cl
  10004525: add         byte ptr [eax],al
  10004527: adc         dword ptr [edx],eax
  10004529: dec         edx
  1000452A: or          al,byte ptr [ebx]
  1000452C: inc         edi
  1000452D: sub         al,23h
  1000452F: adc         al,byte ptr [edx]
  10004531: push        es
  10004532: sbb         dword ptr [eax+47h],ebx
  10004535: push        edx
  10004536: adc         al,byte ptr [edx]
  10004538: pop         ss
  10004539: pop         eax
  1000453A: push        es
  1000453B: sbb         byte ptr [eax+47h],bl
  1000453E: push        edx
  1000453F: adc         al,byte ptr [edx]
  10004541: sbb         byte ptr [eax+6],bl
  10004544: pop         ss
  10004545: pop         eax
  10004546: inc         edi
  10004547: push        edx
  10004548: adc         al,byte ptr [edx]
  1000454A: sbb         dword ptr [eax+6],ebx
  1000454D: inc         edi
  1000454E: push        edx
  1000454F: push        es
  10004550: or          byte ptr [ebx+eax+47h],dl
  10004554: sub         al,2Dh
  10004556: adc         al,byte ptr [ecx]
  10004558: push        es
  10004559: sbb         bl,byte ptr [eax+19h]
  1000455C: pop         eax
  1000455D: inc         edi
  1000455E: push        edx
  1000455F: adc         al,byte ptr [ecx]
  10004561: pop         ss
  10004562: pop         eax
  10004563: push        es
  10004564: sbb         bl,byte ptr [eax+18h]
  10004567: pop         eax
  10004568: inc         edi
  10004569: push        edx
  1000456A: adc         al,byte ptr [ecx]
  1000456C: sbb         byte ptr [eax+6],bl
  1000456F: sbb         bl,byte ptr [eax+17h]
  10004572: pop         eax
  10004573: inc         edi
  10004574: push        edx
  10004575: adc         al,byte ptr [ecx]
  10004577: sbb         dword ptr [eax+6],ebx
  1000457A: sbb         bl,byte ptr [eax+47h]
  1000457D: push        edx
  1000457E: push        es
  1000457F: sbb         bl,byte ptr [eax+7]
  10004582: push        esp
  10004583: sub         al,byte ptr [ebx]
  10004585: xor         byte ptr [ebx],al
  10004587: add         byte ptr [ebx],dh
  10004589: add         byte ptr [eax],al
  1000458B: add         byte ptr [edi+02110000h],dh
  10004591: sub         al,2Fh
  10004593: add         ah,byte ptr ds:[75294A4Ah]
  10004599: add         byte ptr [eax],al
  1000459B: adc         dword ptr [edi-7Ch],edi
  1000459E: add         byte ptr [eax],al
  100045A0: add         al,1Bh
  100045A2: sub         byte ptr [eax+eax],ah
  100045A6: push        es
  100045A7: or          eax,dword ptr [edi]
  100045A9: sub         al,7
  100045AB: pop         es
  100045AC: sbb         bl,byte ptr [eax+4Ah]
  100045AF: or          ch,byte ptr [ebx]
  100045B1: add         bl,byte ptr [ecx]
  100045B3: or          al,byte ptr [ebx]
  100045B5: push        es
  100045B6: push        esp
  100045B7: add         ah,byte ptr ds:[4A581A4Ah]
  100045BD: sub         dword ptr [eax],edi
  100045C0: add         byte ptr [ecx],dl
  100045C2: sub         cl,ah
  100045C4: add         esi,dword ptr [eax]
  100045C6: add         eax,dword ptr [eax]
  100045C8: push        0
  100045CA: add         byte ptr [eax],al
  100045CC: rol         dword ptr [eax],cl
  100045CE: add         byte ptr [ecx],dl
  100045D0: add         bl,byte ptr [edx]
  100045D2: pop         eax
  100045D3: dec         edx
  100045D4: or          al,8
  100045D6: or          al,byte ptr [edx]
  100045D8: dec         edx
  100045D9: sbb         bl,byte ptr [edx+8]
  100045DC: pop         eax
  100045DD: or          eax,dword ptr [esi]
  100045DF: pop         es
  100045E0: xor         byte ptr cs:[ebx],al
  100045E3: inc         edi
  100045E4: sub         al,24h
  100045E6: adc         al,byte ptr [esi+eax]
  100045E9: sbb         dword ptr [eax+47h],ebx
  100045EC: push        edx
  100045ED: adc         al,byte ptr [edi+edx]
  100045F0: pop         eax
  100045F1: push        es
  100045F2: sbb         byte ptr [eax+47h],bl
  100045F5: push        edx
  100045F6: adc         al,byte ptr [eax+ebx]
  100045F9: pop         eax
  100045FA: push        es
  100045FB: pop         ss
  100045FC: pop         eax
  100045FD: inc         edi
  100045FE: push        edx
  100045FF: adc         al,byte ptr [ecx+ebx]
  10004602: pop         eax
  10004603: push        es
  10004604: inc         edi
  10004605: push        edx
  10004606: push        es
  10004607: adc         dword ptr [esp+edx*2],eax
  1000460A: push        es
  1000460B: sbb         bl,byte ptr [eax+0Ah]
  1000460E: push        es
  1000460F: pop         es
  10004610: xor         edx,eax
  10004612: add         eax,dword ptr [edi+2Ch]
  10004615: and         edx,dword ptr [edx]
  10004617: add         eax,dword ptr [edx]
  10004619: sbb         dword ptr [eax+47h],ebx
  1000461C: push        edx
  1000461D: adc         al,byte ptr [ebx]
  1000461F: pop         ss
  10004620: pop         eax
  10004621: add         bl,byte ptr [eax]
  10004623: pop         eax
  10004624: inc         edi
  10004625: push        edx
  10004626: adc         al,byte ptr [ebx]
  10004628: sbb         byte ptr [eax+2],bl
  1000462B: pop         ss
  1000462C: pop         eax
  1000462D: inc         edi
  1000462E: push        edx
  1000462F: adc         al,byte ptr [ebx]
  10004631: sbb         dword ptr [eax+2],ebx
  10004634: inc         edi
  10004635: push        edx
  10004636: add         cl,byte ptr [ecx]
  10004638: push        esp
  10004639: sub         cl,ah
  1000463B: int         3
  1000463C: add         esi,dword ptr [eax]
  1000463E: add         eax,dword ptr [eax]
  10004640: xor         eax,dword ptr [eax]
  10004642: add         byte ptr [eax],al
  10004644: mov         bh,0
  10004646: add         byte ptr [ecx],dl
  10004648: add         ch,byte ptr [edi+ebp]
  1000464B: add         ah,byte ptr ds:[75294A4Ah]
  10004651: add         byte ptr [eax],al
  10004653: adc         dword ptr [edi-29h],edi
  10004656: add         byte ptr [eax],al
  10004658: add         al,1Ah
  1000465A: sub         byte ptr [eax+eax],ah
  1000465E: push        es
  1000465F: or          eax,dword ptr [edi]
  10004661: sub         al,7
  10004663: pop         es
  10004664: sbb         bl,byte ptr [eax+4Ah]
  10004667: or          ch,byte ptr [ebx]
  10004669: add         bl,byte ptr [eax]
  1000466B: or          al,byte ptr [ebx]
  1000466D: push        es
  1000466E: push        esp
  1000466F: add         ah,byte ptr ds:[4A581A4Ah]
  10004675: sub         dword ptr [eax],edi
  10004678: add         byte ptr [ecx],dl
  1000467A: sub         cl,ah
  1000467C: add         esi,dword ptr [eax]
  1000467E: add         eax,6700h
  10004683: add         byte ptr [eax],dl
  10004685: add         byte ptr [eax],al
  10004687: adc         dword ptr ds:[58185A18h],eax
  1000468D: or          al,byte ptr [esi]
  1000468F: add         al,2Fh
  10004691: xor         al,2
  10004693: push        es
  10004694: pop         ds
  10004695: or          al,5Ah
  10004697: pop         eax
  10004698: and         eax,0E590C1Fh
  1000469D: add         eax,7C29h
  100046A2: adc         dword ptr [esp+eax],ebp
  100046A5: push        es
  100046A6: pop         ss
  100046A7: pop         ecx
  100046A8: or          al,byte ptr ds:[025A0C1Fh]
  100046AE: pop         eax
  100046AF: push        es
  100046B0: pop         ds
  100046B1: or          al,5Ah
  100046B3: add         bl,byte ptr [eax+1Fh]
  100046B6: or          al,0FEh
  100046B8: pop         ss
  100046B9: push        es
  100046BA: adc         byte ptr [ebx],al
  100046BC: push        es
  100046BD: sbb         byte ptr [edx+18h],bl
  100046C0: pop         eax
  100046C1: or          al,byte ptr [esi]
  100046C3: add         al,32h
  100046C5: int         3
  100046C6: push        es
  100046C7: add         al,33h
  100046C9: sbb         byte ptr ds:[025A0C1Fh],al
  100046CF: pop         eax
  100046D0: add         al,byte ptr [esi]
  100046D2: pop         ds
  100046D3: or          al,5Ah
  100046D5: pop         eax
  100046D6: pop         ds
  100046D7: or          al,59h
  100046D9: pop         ds
  100046DA: or          al,0FEh
  100046DC: pop         ss
  100046DD: push        es
  100046DE: pop         ss
  100046DF: pop         ecx
  100046E0: adc         byte ptr [ebx],al
  100046E2: add         al,byte ptr [ebx]
  100046E4: add         eax,50E040Eh
  100046E9: sub         byte ptr [eax+2A060000h],ah
  100046EF: int         3
  100046F0: add         esi,dword ptr [eax]
  100046F2: add         eax,9100h
  100046F7: add         byte ptr [eax+eax+39021100h],dh
  100046FE: mov         al,byte ptr [eax]
  10004700: add         byte ptr [eax],al
  10004702: add         bh,byte ptr [edi+55h]
  10004705: add         byte ptr [eax],al
  10004707: add         al,16h
  10004709: add         cl,byte ptr [edx+1Fh]
  1000470C: or          al,58h
  1000470E: dec         edx
  1000470F: sub         dword ptr [esi],esi
  10004712: add         byte ptr [ecx],dl
  10004714: or          eax,dword ptr [edi]
  10004716: sub         al,22h
  10004718: pop         es
  10004719: and         eax,75294A4Ah
  1000471E: add         byte ptr [eax],al
  10004720: adc         dword ptr ds:[580C1F03h],ecx
  10004726: or          dword ptr [esi],edx
  10004728: push        ss
  10004729: sub         byte ptr [ebx],ah
  1000472B: add         dword ptr [eax],eax
  1000472D: push        es
  1000472E: push        ebx
  1000472F: pop         es
  10004730: and         eax,4A581A4Ah
  10004735: sub         dword ptr [eax],edi
  10004738: add         byte ptr [ecx],dl
  1000473A: add         bh,byte ptr [edi+3Bh]
  1000473D: add         byte ptr [eax],al
  1000473F: add         al,16h
  10004741: add         cl,byte ptr [edx+1Fh]
  10004744: or          al,58h
  10004746: dec         edx
  10004747: sub         dword ptr [esi],esi
  1000474A: add         byte ptr [ecx],dl
  1000474C: add         ebx,dword ptr [edx]
  1000474E: pop         eax
  1000474F: add         al,28h
  10004751: jae         10004753
  10004753: add         byte ptr [esi],al
  10004755: add         bh,byte ptr [edi+57h]
  10004758: add         byte ptr [eax],al
  1000475A: add         al,16h
  1000475C: add         cl,byte ptr [edx+1Fh]
  1000475F: or          al,58h
  10004761: dec         edx
  10004762: sub         dword ptr [esi],esi
  10004765: add         byte ptr [ecx],dl
  10004767: or          al,byte ptr [esi]
  10004769: sub         al,21h
  1000476B: push        es
  1000476C: and         eax,75294A4Ah
  10004771: add         byte ptr [eax],al
  10004773: adc         dword ptr [ebx+eax],ecx
  10004776: push        ds
  10004777: pop         eax
  10004778: or          byte ptr [esi],dl
  1000477A: push        ss
  1000477B: sub         byte ptr [ebx],ah
  1000477D: add         dword ptr [eax],eax
  1000477F: push        es
  10004780: push        esp
  10004781: push        es
  10004782: and         eax,4A581A4Ah
  10004787: sub         dword ptr [eax],edi
  1000478A: add         byte ptr [ecx],dl
  1000478C: sub         cl,ah
  1000478E: int         3
  1000478F: int         3
  10004790: add         esi,dword ptr [eax]
  10004792: add         al,byte ptr [eax]
  10004794: push        cs
  10004795: add         byte ptr [eax],al
  10004797: add         byte ptr [eax],al
  10004799: add         byte ptr [eax],al
  1000479B: add         byte ptr [edx],al
  1000479D: pop         ss
  1000479E: outs        dx,dword ptr [esi]
  1000479F: dec         ebx
  100047A0: add         dword ptr [eax],eax
  100047A2: push        es
  100047A3: add         ch,byte ptr [eax]
  100047A5: sub         al,0
  100047A7: add         byte ptr [edx],cl
  100047A9: sub         cl,ah
  100047AB: int         3
  100047AC: add         esi,dword ptr [eax]
  100047AE: add         eax,dword ptr [eax]
  100047B0: mov         al,byte ptr [eax]
  100047B2: add         byte ptr [eax],al
  100047B4: jecxz       100047B6
  100047B6: add         byte ptr [ecx],dl
  100047B8: add         bl,byte ptr [edx]
  100047BA: pop         eax
  100047BB: dec         edx
  100047BC: or          eax,4A020B09h
  100047C1: pop         ds
  100047C2: sbb         byte ptr [edx+9],bl
  100047C5: pop         eax
  100047C6: or          al,7
  100047C8: or          byte ptr [esi],ch
  100047CA: dec         esi
  100047CB: pop         es
  100047CC: pop         ds
  100047CD: push        ss
  100047CE: pop         eax
  100047CF: or          al,byte ptr [edi]
  100047D1: add         ebp,dword ptr [eax]
  100047D3: push        6060000h
  100047D8: pop         ds
  100047D9: push        cs
  100047DA: pop         ecx
  100047DB: add         ebp,dword ptr [eax]
  100047DD: inc         eax
  100047DE: add         byte ptr [eax],al
  100047E0: push        es
  100047E1: add         eax,dword ptr [edi+2Ch]
  100047E4: adc         al,byte ptr es:[47581706h]
  100047EB: push        edx
  100047EC: adc         al,byte ptr ds:[47065817h]
  100047F2: push        edx
  100047F3: adc         al,byte ptr ds:[17065818h]
  100047F9: pop         ecx
  100047FA: inc         edi
  100047FB: push        edx
  100047FC: adc         al,byte ptr ds:[18065819h]
  10004802: pop         ecx
  10004803: inc         edi
  10004804: push        edx
  10004805: push        es
  10004806: sbb         byte ptr [ecx+11h],bl
  10004809: add         eax,181F0754h
  1000480E: pop         eax
  1000480F: or          eax,dword ptr [esi]
  10004811: pop         ds
  10004812: sbb         byte ptr [eax+0Ah],bl
  10004815: pop         es
  10004816: or          byte ptr [ebx],dh
  10004818: mov         bh,3
  1000481A: inc         edi
  1000481B: sub         al,24h
  1000481D: adc         al,byte ptr [edx+eax]
  10004820: sbb         dword ptr [eax+47h],ebx
  10004823: push        edx
  10004824: adc         al,byte ptr [edi+edx]
  10004827: pop         eax
  10004828: add         bl,byte ptr [eax]
  1000482A: pop         eax
  1000482B: inc         edi
  1000482C: push        edx
  1000482D: adc         al,byte ptr [eax+ebx]
  10004830: pop         eax
  10004831: add         dl,byte ptr [edi]
  10004833: pop         eax
  10004834: inc         edi
  10004835: push        edx
  10004836: adc         al,byte ptr [ecx+ebx]
  10004839: pop         eax
  1000483A: add         al,byte ptr [edi+52h]
  1000483D: add         dl,byte ptr [ecx]
  1000483F: add         al,54h
  10004841: sub         cl,ah
  10004843: int         3
  10004844: add         esi,dword ptr [eax]
  10004846: push        es
  10004847: add         byte ptr [ecx],bh
  10004849: add         byte ptr [eax],al
  1000484B: add         bh,ah
  1000484D: add         byte ptr [eax],al
  1000484F: adc         dword ptr [ebx],eax
  10004851: add         bl,byte ptr [ecx+1Fh]
  10004854: or          al,5Bh
  10004856: or          al,8
  10004858: sbb         byte ptr [edx],dh
  1000485A: sub         eax,17591808h
  1000485F: arpl        word ptr [edi],dx
  10004861: pop         eax
  10004862: or          al,byte ptr [esi]
  10004864: pop         ds
  10004865: or          al,5Ah
  10004867: add         bl,byte ptr [eax+0Bh]
  1000486A: push        es
  1000486B: pop         ss
  1000486C: pop         ecx
  1000486D: or          al,byte ptr [edi]
  1000486F: pop         ds
  10004870: or          al,59h
  10004872: or          edx,dword ptr [edx]
  10004874: add         eax,dword ptr [edi]
  10004876: pop         ds
  10004877: or          al,0FEh
  10004879: pop         ss
  1000487A: add         al,byte ptr [esi]
  1000487C: or          byte ptr [esi],al
  1000487E: or          dword ptr [eax+ebp],eax
  10004881: popfd
  10004882: add         byte ptr [eax],al
  10004884: push        es
  10004885: push        es
  10004886: sub         eax,0CCCC2AE2h
  1000488B: int         3
  1000488C: add         esi,dword ptr [eax]
  1000488E: push        es
  1000488F: add         byte ptr [eax+eax],al
  10004893: add         al,ch
  10004895: add         byte ptr [eax],al
  10004897: adc         dword ptr [ebx],eax
  10004899: add         bl,byte ptr [ecx+1Fh]
  1000489C: or          al,5Bh
  1000489E: or          eax,dword ptr [edi]
  100048A0: pop         ss
  100048A1: xor         dword ptr [eax],edi
  100048A3: add         ebx,dword ptr [edi]
  100048A5: or          al,59h
  100048A7: or          bl,byte ptr [edi]
  100048A9: or          al,2
  100048AB: pop         ecx
  100048AC: adc         eax,dword ptr [edx+edx]
  100048AF: add         eax,dword ptr [esi]
  100048B1: pop         ds
  100048B2: or          al,0FEh
  100048B4: pop         ss
  100048B5: push        es
  100048B6: add         bl,byte ptr [edi]
  100048B8: or          al,0FEh
  100048BA: pop         ss
  100048BB: add         dl,byte ptr [esi]
  100048BD: pop         es
  100048BE: pop         ss
  100048BF: pop         ecx
  100048C0: push        ss
  100048C1: or          dword ptr [eax+ebp],eax
  100048C4: popfd
  100048C5: add         byte ptr [eax],al
  100048C7: push        es
  100048C8: push        es
  100048C9: pop         ds
  100048CA: or          al,59h
  100048CC: or          dl,byte ptr [ecx]
  100048CE: add         al,6
  100048D0: pop         eax
  100048D1: pop         ds
  100048D2: or          al,5Bh
  100048D4: or          al,8
  100048D6: or          ecx,dword ptr [eax]
  100048D8: pop         ss
  100048D9: xor         bl,dl
  100048DB: sub         cl,byte ptr [ebx]
  100048DD: xor         byte ptr [ebx],al
  100048DF: add         byte ptr [ecx+eax],cl
  100048E2: add         byte ptr [eax],al
  100048E4: jmp         121148E9
  100048E9: pop         ds
  100048EA: adc         al,58h
  100048EC: or          al,byte ptr [esi]
  100048EE: adc         ecx,dword ptr [eax]
  100048F0: adc         dword ptr [eax],ecx
  100048F2: dec         edx
  100048F3: adc         dword ptr [eax],ecx
  100048F5: sbb         bl,byte ptr [eax+4Ah]
  100048F8: inc         byte ptr [ecx]
  100048FA: shr         byte ptr ds:[181F0220h],cl
  10004900: pop         eax
  10004901: dec         edx
  10004902: pop         ds
  10004903: or          al,59h
  10004905: dec         edx
  10004906: sub         byte ptr [eax],ch
  10004908: add         dword ptr [eax],eax
  1000490A: push        es
  1000490B: push        es
  1000490C: adc         eax,dword ptr [edi]
  1000490E: adc         dword ptr [edi],eax
  10004910: sbb         bl,byte ptr [eax+11h]
  10004913: pop         es
  10004914: sbb         bl,byte ptr [eax+4Ah]
  10004917: pop         ds
  10004918: hlt
  10004919: pop         eax
  1000491A: push        esp
  1000491B: sub         edx,eax
  1000491D: add         bl,byte ptr [edi]
  1000491F: push        esp
  10004920: pop         eax
  10004921: dec         edx
  10004922: adc         eax,dword ptr [esi]
  10004924: adc         dword ptr [esi],eax
  10004926: sub         eax,1119DE02h
  1000492B: push        es
  1000492C: sub         byte ptr [edi],bl
  1000492E: add         dword ptr [eax],eax
  10004930: push        es
  10004931: ficom       word ptr [eax]
  10004933: inc         byte ptr [esi]
  10004935: popad
  10004936: add         byte ptr [eax],al
  10004938: push        es
  10004939: add         bl,byte ptr [edi]
  1000493B: inc         esp
  1000493C: pop         eax
  1000493D: sub         byte ptr [ebx],al
  1000493F: add         dword ptr [eax],eax
  10004941: push        es
  10004942: fadd        qword ptr [edx]
  10004944: pop         ds
  10004945: inc         esp
  10004946: pop         eax
  10004947: adc         ecx,dword ptr ds:[134A0D11h]
  1000494D: add         eax,22D0511h
  10004952: ficomp      word ptr [ecx]
  10004954: adc         dword ptr ds:[00011F28h],eax
  1000495A: push        es
  1000495B: ficom       word ptr [eax]
  1000495D: inc         byte ptr [esi]
  1000495F: pushad
  10004960: add         byte ptr [eax],al
  10004962: push        es
  10004963: add         bl,byte ptr [edi]
  10004965: xor         al,58h
  10004967: sub         byte ptr [ebx],al
  10004969: add         dword ptr [eax],eax
  1000496B: push        es
  1000496C: fadd        qword ptr [edx]
  1000496E: pop         ds
  1000496F: xor         al,58h
  10004971: adc         ecx,dword ptr [ecx+edx]
  10004974: or          al,4Ah
  10004976: adc         eax,dword ptr [ecx+edx]
  10004979: add         al,2Dh
  1000497B: add         bl,dh
  1000497D: sbb         dword ptr [ecx],edx
  1000497F: add         al,28h
  10004981: pop         ds
  10004982: add         dword ptr [eax],eax
  10004984: push        es
  10004985: ficom       word ptr [eax]
  10004987: inc         byte ptr [esi]
  10004989: pushad
  1000498A: add         byte ptr [eax],al
  1000498C: push        es
  1000498D: add         bl,byte ptr [edi]
  1000498F: and         al,58h
  10004991: sub         byte ptr [ebx],al
  10004993: add         dword ptr [eax],eax
  10004995: push        es
  10004996: fadd        qword ptr [edx]
  10004998: pop         ds
  10004999: and         al,58h
  1000499B: adc         ecx,dword ptr [ebx]
  1000499D: adc         dword ptr [ebx],ecx
  1000499F: dec         edx
  100049A0: or          eax,0DE022D09h
  100049A5: sbb         byte ptr [ecx],cl
  100049A7: sub         byte ptr [edi],bl
  100049A9: add         dword ptr [eax],eax
  100049AB: push        es
  100049AC: ficom       word ptr [eax]
  100049AE: inc         byte ptr [esi]
  100049B0: pop         edi
  100049B1: add         byte ptr [eax],al
  100049B3: push        es
  100049B4: add         bl,byte ptr [edi]
  100049B6: adc         al,58h
  100049B8: sub         byte ptr [ebx],al
  100049BA: add         dword ptr [eax],eax
  100049BC: push        es
  100049BD: fadd        qword ptr [esi]
  100049BF: adc         ecx,dword ptr [edx]
  100049C1: adc         dword ptr [edx],ecx
  100049C3: dec         edx
  100049C4: or          al,8
  100049C6: sub         eax,817DE02h
  100049CB: sub         byte ptr [edi],bl
  100049CD: add         dword ptr [eax],eax
  100049CF: push        es
  100049D0: fimul       word ptr [edi]
  100049D2: inc         byte ptr [esi]
  100049D4: cmp         al,byte ptr [eax]
  100049D6: add         byte ptr [esi],al
  100049D8: add         bl,byte ptr [edx]
  100049DA: pop         eax
  100049DB: sub         byte ptr [ebx],al
  100049DD: add         dword ptr [eax],eax
  100049DF: push        es
  100049E0: fadd        qword ptr [edx]
  100049E2: sbb         bl,byte ptr [eax+13h]
  100049E5: or          dword ptr [ecx],edx
  100049E7: or          dword ptr [edx+0Bh],ecx
  100049EA: pop         es
  100049EB: sub         al,6
  100049ED: pop         es
  100049EE: sub         byte ptr [edi],bl
  100049F0: add         dword ptr [eax],eax
  100049F2: push        es
  100049F3: sub         al,byte ptr [ecx+7Ch]
  100049F6: add         byte ptr [eax],al
  100049F8: add         al,0
  100049FA: add         byte ptr [eax],al
  100049FC: add         byte ptr [eax],al
  100049FE: add         byte ptr [eax],al
  10004A00: dec         ebx
  10004A01: add         byte ptr [eax],al
  10004A03: add         byte ptr [ebx],cl
  10004A06: add         byte ptr [eax],al
  10004A08: adc         byte ptr [eax],al
  10004A0A: add         byte ptr [eax],al
  10004A0C: cmp         al,byte ptr [eax]
  10004A0E: add         byte ptr [ecx],al
  10004A10: add         al,0
  10004A12: add         byte ptr [eax],al
  10004A14: add         byte ptr [eax],al
  10004A16: add         byte ptr [eax],al
  10004A18: jne         10004A1A
  10004A1A: add         byte ptr [eax],al
  10004A1C: jne         10004A1E
  10004A1E: add         byte ptr [eax],al
  10004A20: adc         byte ptr [eax],al
  10004A22: add         byte ptr [eax],al
  10004A24: cmp         al,byte ptr [eax]
  10004A26: add         byte ptr [ecx],al
  10004A28: add         al,0
  10004A2A: add         byte ptr [eax],al
  10004A2C: add         byte ptr [eax],al
  10004A2E: add         byte ptr [eax],al
  10004A30: lahf
  10004A31: add         byte ptr [eax],al
  10004A33: add         byte ptr [edi+10000000h],bl
  10004A39: add         byte ptr [eax],al
  10004A3B: add         byte ptr [edx],bh
  10004A3D: add         byte ptr [eax],al
  10004A3F: add         dword ptr [eax+eax],eax
  10004A42: add         byte ptr [eax],al
  10004A44: add         byte ptr [eax],al
  10004A46: add         byte ptr [eax],al
  10004A48: mov         byte ptr [eax],0
  10004A4B: add         dh,al
  10004A4D: add         byte ptr [eax],al
  10004A4F: add         byte ptr [eax],dl
  10004A51: add         byte ptr [eax],al
  10004A53: add         byte ptr [edx],bh
  10004A55: add         byte ptr [eax],al
  10004A57: add         dword ptr [eax+eax],eax
  10004A5A: add         byte ptr [eax],al
  10004A5C: add         byte ptr [eax],al
  10004A5E: add         byte ptr [eax],al
  10004A60: jmp         0000:EA000000
  10004A67: add         byte ptr [edi],cl
  10004A69: add         byte ptr [eax],al
  10004A6B: add         byte ptr [edx],bh
  10004A6D: add         byte ptr [eax],al
  10004A6F: add         dword ptr [ebx],eax
  10004A71: xor         byte ptr [ebx],al
  10004A73: add         byte ptr [ebx],ah
  10004A76: add         byte ptr [eax],al
  10004A78: mov         byte ptr [eax],al
  10004A7A: add         byte ptr [ecx],dl
  10004A7C: add         bl,byte ptr [edi]
  10004A7E: or          al,58h
  10004A80: add         ebp,dword ptr [eax]
  10004A82: js          10004A84
  10004A84: add         byte ptr [esi],al
  10004A86: add         eax,dword ptr [edi+2Ch]
  10004A89: and         edx,dword ptr [edx]
  10004A8B: add         dword ptr [edx],eax
  10004A8D: sbb         dword ptr [eax+47h],ebx
  10004A90: push        edx
  10004A91: adc         al,byte ptr [ecx]
  10004A93: pop         ss
  10004A94: pop         eax
  10004A95: add         bl,byte ptr [eax]
  10004A97: pop         eax
  10004A98: inc         edi
  10004A99: push        edx
  10004A9A: adc         al,byte ptr [ecx]
  10004A9C: sbb         byte ptr [eax+2],bl
  10004A9F: pop         ss
  10004AA0: pop         eax
  10004AA1: inc         edi
  10004AA2: push        edx
  10004AA3: adc         al,byte ptr [ecx]
  10004AA5: sbb         dword ptr [eax+2],ebx
  10004AA8: inc         edi
  10004AA9: push        edx
  10004AAA: add         al,byte ptr [edi]
  10004AAC: push        esp
  10004AAD: add         eax,dword ptr [edi+2Ch]
  10004AB0: sub         eax,1A020012h
  10004AB5: pop         eax
  10004AB6: sbb         dword ptr [eax+47h],ebx
  10004AB9: push        edx
  10004ABA: adc         al,byte ptr [eax]
  10004ABC: pop         ss
  10004ABD: pop         eax
  10004ABE: add         bl,byte ptr [edx]
  10004AC0: pop         eax
  10004AC1: sbb         byte ptr [eax+47h],bl
  10004AC4: push        edx
  10004AC5: adc         al,byte ptr [eax]
  10004AC7: sbb         byte ptr [eax+2],bl
  10004ACA: sbb         bl,byte ptr [eax+17h]
  10004ACD: pop         eax
  10004ACE: inc         edi
  10004ACF: push        edx
  10004AD0: adc         al,byte ptr [eax]
  10004AD2: sbb         dword ptr [eax+2],ebx
  10004AD5: sbb         bl,byte ptr [eax+47h]
  10004AD8: push        edx
  10004AD9: add         bl,byte ptr [edx]
  10004ADB: pop         eax
  10004ADC: push        es
  10004ADD: push        esp
  10004ADE: sub         cl,ah
  10004AE0: add         esi,dword ptr [eax]
  10004AE2: add         eax,dword ptr [eax]
  10004AE4: pop         esi
  10004AE5: add         byte ptr [eax],al
  10004AE7: add         ah,ch
  10004AE9: add         byte ptr [eax],al
  10004AEB: adc         dword ptr [edx],edx
  10004AED: add         dword ptr [edi+ebx],eax
  10004AF0: or          al,0FEh
  10004AF2: pop         ss
  10004AF3: add         dl,byte ptr [edx]
  10004AF5: add         dword ptr ds:[00007C29h],eax
  10004AFB: adc         dword ptr [eax+ecx],ebp
  10004AFE: add         bl,byte ptr [edi]
  10004B00: or          al,58h
  10004B02: adc         byte ptr [eax],al
  10004B04: sub         ebp,ebp
  10004B06: add         ebx,dword ptr [edi]
  10004B08: or          al,59h
  10004B0A: adc         byte ptr [ecx],al
  10004B0C: adc         al,byte ptr [ecx]
  10004B0E: add         eax,dword ptr ds:[00007C29h]
  10004B14: adc         dword ptr [ecx+edx],ebp
  10004B17: add         ebx,dword ptr [edi]
  10004B19: or          al,59h
  10004B1B: adc         byte ptr [ecx],al
  10004B1D: adc         al,byte ptr [ecx]
  10004B1F: add         eax,dword ptr ds:[00007C29h]
  10004B25: adc         dword ptr ds:[340302EFh],ebp
  10004B2B: sbb         al,12h
  10004B2D: add         byte ptr [edx],al
  10004B2F: pop         ds
  10004B30: or          al,0FEh
  10004B32: pop         ss
  10004B33: add         al,byte ptr [ebx]
  10004B35: pop         ds
  10004B36: or          al,0FEh
  10004B38: pop         ss
  10004B39: add         edx,dword ptr [edx]
  10004B3B: add         byte ptr [edi],bl
  10004B3D: or          al,0FEh
  10004B3F: pop         ss
  10004B40: add         bl,byte ptr [edi]
  10004B42: or          al,58h
  10004B44: adc         byte ptr [eax],al
  10004B46: sub         ebp,dword ptr [ebx+CCCC2A02h]
  10004B4C: add         esi,dword ptr [eax]
  10004B4E: push        es
  10004B4F: add         byte ptr [edi],al
  10004B52: add         byte ptr [eax],al
  10004B54: in          eax,dx
  10004B55: add         byte ptr [eax],al
  10004B57: adc         dword ptr [edx],eax
  10004B59: add         eax,dword ptr ds:[00009C28h]
  10004B5F: push        es
  10004B60: add         ecx,dword ptr [edx]
  10004B62: add         eax,dword ptr [esp+esi]
  10004B65: xor         byte ptr [esi],al
  10004B67: add         al,byte ptr ds:[00007C29h]
  10004B6D: adc         dword ptr [ebx+1F060112h],ebp
  10004B74: or          al,0FEh
  10004B76: pop         ss
  10004B77: push        es
  10004B78: add         bl,byte ptr [edi]
  10004B7A: or          al,0FEh
  10004B7C: pop         ss
  10004B7D: add         dl,byte ptr [esi]
  10004B7F: add         eax,dword ptr [edx]
  10004B81: pop         ecx
  10004B82: pop         ds
  10004B83: or          al,5Bh
  10004B85: push        ss
  10004B86: pop         es
  10004B87: add         eax,9D28h
  10004B8C: push        es
  10004B8D: push        es
  10004B8E: pop         ds
  10004B8F: or          al,58h
  10004B91: or          al,byte ptr [esi]
  10004B93: add         al,37h
  10004B95: rol         byte ptr [edx],1
  10004B97: add         eax,dword ptr ds:[00009E28h]
  10004B9D: push        es
  10004B9E: sub         cl,ah
  10004BA0: add         esi,dword ptr [eax]
  10004BA2: add         al,byte ptr [eax]
  10004BA4: pop         ebp
  10004BA5: add         byte ptr [eax],al
  10004BA7: add         byte ptr [ecx+02110000h],cl
  10004BAD: dec         edx
  10004BAE: or          eax,dword ptr [edi]
  10004BB0: sub         al,56h
  10004BB2: pop         es
  10004BB3: dec         edx
  10004BB4: or          al,byte ptr [esi]
  10004BB6: and         byte ptr [esi+30A59096h],ah
  10004BBC: xor         eax,dword ptr [esi]
  10004BBE: and         byte ptr [esi+2EA59096h],ah
  10004BC4: and         al,byte ptr [esi]
  10004BC6: and         byte ptr [edx+2E891819h],al
  10004BCC: adc         dword ptr [esi],eax
  10004BCE: and         byte ptr ds:[33A3F84Ch],bh
  10004BD4: and         eax,dword ptr [edx]
  10004BD6: add         ebp,dword ptr [eax]
  10004BD8: outs        dx,dword ptr [esi]
  10004BD9: add         byte ptr [eax],al
  10004BDB: push        es
  10004BDC: sub         ebp,dword ptr [edx]
  10004BDE: pop         es
  10004BDF: add         ebp,dword ptr [eax]
  10004BE1: push        edx
  10004BE2: add         byte ptr [eax],al
  10004BE4: push        es
  10004BE5: sub         esp,dword ptr [ecx]
  10004BE7: add         al,byte ptr [ebx]
  10004BE9: sub         byte ptr [eax],dh
  10004BEC: add         byte ptr [esi],al
  10004BEE: sub         ebx,dword ptr [eax]
  10004BF0: push        es
  10004BF1: and         byte ptr ds:[2EDF08DFh],ah
  10004BF7: or          dword ptr [edx],eax
  10004BF9: add         ebp,dword ptr [eax]
  10004BFB: jno         10004BFD
  10004BFD: add         byte ptr [esi],al
  10004BFF: sub         eax,dword ptr [edi]
  10004C01: pop         es
  10004C02: add         ebp,dword ptr [eax]
  10004C04: push        eax
  10004C05: add         byte ptr [eax],al
  10004C07: push        es
  10004C08: sub         cl,ah
  10004C0A: int         3
  10004C0B: int         3
  10004C0C: add         esi,dword ptr [eax]
  10004C0E: add         eax,dword ptr [eax]
  10004C10: dec         ecx
  10004C11: add         byte ptr [eax],al
  10004C13: add         dl,dh
  10004C15: add         byte ptr [eax],al
  10004C17: adc         dword ptr [edx],eax
  10004C19: sbb         bl,byte ptr [eax+4Ah]
  10004C1C: or          al,8
  10004C1E: or          al,byte ptr [edx]
  10004C20: dec         edx
  10004C21: sbb         bl,byte ptr [edx+8]
  10004C24: pop         eax
  10004C25: or          eax,dword ptr [esi]
  10004C27: pop         es
  10004C28: clts
  10004C2B: add         ebp,dword ptr [eax]
  10004C2D: dec         edx
  10004C2E: add         byte ptr [eax],al
  10004C30: push        es
  10004C31: push        es
  10004C32: sbb         bl,byte ptr [eax+0Ah]
  10004C35: push        es
  10004C36: pop         es
  10004C37: xor         esi,ecx
  10004C39: add         eax,dword ptr [edi+2Ch]
  10004C3C: and         edx,dword ptr [edx]
  10004C3E: add         eax,dword ptr [edx]
  10004C40: sbb         dword ptr [eax+47h],ebx
  10004C43: push        edx
  10004C44: adc         al,byte ptr [ebx]
  10004C46: pop         ss
  10004C47: pop         eax
  10004C48: add         bl,byte ptr [eax]
  10004C4A: pop         eax
  10004C4B: inc         edi
  10004C4C: push        edx
  10004C4D: adc         al,byte ptr [ebx]
  10004C4F: sbb         byte ptr [eax+2],bl
  10004C52: pop         ss
  10004C53: pop         eax
  10004C54: inc         edi
  10004C55: push        edx
  10004C56: adc         al,byte ptr [ebx]
  10004C58: sbb         dword ptr [eax+2],ebx
  10004C5B: inc         edi
  10004C5C: push        edx
  10004C5D: add         cl,byte ptr [ecx]
  10004C5F: push        esp
  10004C60: sub         cl,ah
  10004C62: int         3
  10004C63: int         3
  10004C64: add         esi,dword ptr [eax]
  10004C66: push        es
  10004C67: add         byte ptr [edi],dl
  10004C6A: add         byte ptr [eax],al
  10004C6C: hlt
  10004C6D: add         byte ptr [eax],al
  10004C6F: adc         dword ptr [ebx],eax
  10004C71: add         bl,byte ptr [ecx+1Fh]
  10004C74: or          al,5Bh
  10004C76: pop         ds
  10004C77: sbb         al,31h
  10004C79: inc         eax
  10004C7A: add         al,16h
  10004C7C: xor         dword ptr [edx+eax],edi
  10004C7F: add         eax,dword ptr [edx]
  10004C81: add         eax,dword ptr [edx]
  10004C83: pop         ecx
  10004C84: pop         ds
  10004C85: or          al,5Bh
  10004C87: sbb         byte ptr [ebx+1Fh],bl
  10004C8A: or          al,5Ah
  10004C8C: add         bl,byte ptr [eax+3]
  10004C8F: pop         ds
  10004C90: or          al,59h
  10004C92: add         eax,9828h
  10004C97: push        es
  10004C98: add         eax,9928h
  10004C9D: push        es
  10004C9E: or          al,byte ptr [edi+edx]
  10004CA1: pop         ecx
  10004CA2: adc         byte ptr [edx],al
  10004CA4: push        es
  10004CA5: add         eax,dword ptr [eax+00009428h]
  10004CAC: push        es
  10004CAD: push        es
  10004CAE: adc         byte ptr [ecx],al
  10004CB0: push        es
  10004CB1: add         bl,byte ptr [ecx+1Fh]
  10004CB4: or          al,5Bh
  10004CB6: pop         ds
  10004CB7: sbb         al,30h
  10004CB9: rol         byte ptr [ebp+25030209h],5
  10004CC1: sub         byte ptr [edx+2A060000h],bl
  10004CC7: int         3
  10004CC8: add         esi,dword ptr [eax]
  10004CCA: add         eax,dword ptr [eax]
  10004CCC: arpl        word ptr [eax],ax
  10004CCE: add         byte ptr [eax],al
  10004CD0: mov         byte ptr [eax],al
  10004CD2: add         byte ptr [ecx],dl
  10004CD4: add         eax,dword ptr [edi+2Ch]
  10004CD7: and         edx,dword ptr [edx]
  10004CD9: add         dword ptr [edx],eax
  10004CDB: sbb         dword ptr [eax+47h],ebx
  10004CDE: push        edx
  10004CDF: adc         al,byte ptr [ecx]
  10004CE1: pop         ss
  10004CE2: pop         eax
  10004CE3: add         bl,byte ptr [eax]
  10004CE5: pop         eax
  10004CE6: inc         edi
  10004CE7: push        edx
  10004CE8: adc         al,byte ptr [ecx]
  10004CEA: sbb         byte ptr [eax+2],bl
  10004CED: pop         ss
  10004CEE: pop         eax
  10004CEF: inc         edi
  10004CF0: push        edx
  10004CF1: adc         al,byte ptr [ecx]
  10004CF3: sbb         dword ptr [eax+2],ebx
  10004CF6: inc         edi
  10004CF7: push        edx
  10004CF8: add         al,byte ptr [edi]
  10004CFA: push        esp
  10004CFB: add         eax,dword ptr [edi+2Ch]
  10004CFE: sub         eax,1E020012h
  10004D03: pop         eax
  10004D04: sbb         dword ptr [eax+47h],ebx
  10004D07: push        edx
  10004D08: adc         al,byte ptr [eax]
  10004D0A: pop         ss
  10004D0B: pop         eax
  10004D0C: add         bl,byte ptr [esi]
  10004D0E: pop         eax
  10004D0F: sbb         byte ptr [eax+47h],bl
  10004D12: push        edx
  10004D13: adc         al,byte ptr [eax]
  10004D15: sbb         byte ptr [eax+2],bl
  10004D18: push        ds
  10004D19: pop         eax
  10004D1A: pop         ss
  10004D1B: pop         eax
  10004D1C: inc         edi
  10004D1D: push        edx
  10004D1E: adc         al,byte ptr [eax]
  10004D20: sbb         dword ptr [eax+2],ebx
  10004D23: push        ds
  10004D24: pop         eax
  10004D25: inc         edi
  10004D26: push        edx
  10004D27: add         bl,byte ptr [esi]
  10004D29: pop         eax
  10004D2A: push        es
  10004D2B: push        esp
  10004D2C: add         bl,byte ptr [edi]
  10004D2E: adc         byte ptr [eax+3],bl
  10004D31: sub         byte ptr [edx],dh
  10004D34: add         byte ptr [esi],al
  10004D36: sub         cl,ah
  10004D38: add         esi,dword ptr [eax]
  10004D3A: add         eax,dword ptr [eax]
  10004D3C: mov         ah,0
  10004D3E: add         byte ptr [eax],al
  10004D40: test        dword ptr [eax],1E021100h
  10004D46: pop         eax
  10004D47: dec         edx
  10004D48: adc         eax,dword ptr [ebx+eax]
  10004D4B: inc         edi
  10004D4C: sub         al,28h
  10004D4E: adc         al,byte ptr [esi]
  10004D50: adc         al,byte ptr [ecx+ebx]
  10004D53: pop         eax
  10004D54: inc         edi
  10004D55: push        edx
  10004D56: adc         al,byte ptr [esi]
  10004D58: pop         ss
  10004D59: pop         eax
  10004D5A: adc         al,byte ptr [eax+ebx]
  10004D5D: pop         eax
  10004D5E: inc         edi
  10004D5F: push        edx
  10004D60: adc         al,byte ptr [esi]
  10004D62: sbb         byte ptr [eax+12h],bl
  10004D65: add         al,17h
  10004D67: pop         eax
  10004D68: inc         edi
  10004D69: push        edx
  10004D6A: adc         al,byte ptr [esi]
  10004D6C: sbb         dword ptr [eax+12h],ebx
  10004D6F: add         al,47h
  10004D71: push        edx
  10004D72: adc         dword ptr [esi],eax
  10004D74: adc         eax,dword ptr [edx+eax]
  10004D77: push        ds
  10004D78: pop         eax
  10004D79: adc         dword ptr [esp+edx*2],eax
  10004D7C: add         bl,byte ptr [edi]
  10004D7E: or          al,58h
  10004D80: or          eax,40280309h
  10004D85: add         byte ptr [eax],al
  10004D87: push        es
  10004D88: or          dword ptr [edi],ebx
  10004D8A: or          al,58h
  10004D8C: add         ebp,dword ptr [eax]
  10004D8E: inc         eax
  10004D8F: add         byte ptr [eax],al
  10004D91: push        es
  10004D92: add         bl,byte ptr [edi]
  10004D94: and         al,58h
  10004D96: or          al,byte ptr [ebx]
  10004D98: inc         edi
  10004D99: sub         al,24h
  10004D9B: adc         al,byte ptr ds:[47581906h]
  10004DA1: push        edx
  10004DA2: adc         al,byte ptr ds:[18065817h]
  10004DA8: pop         eax
  10004DA9: inc         edi
  10004DAA: push        edx
  10004DAB: adc         al,byte ptr ds:[17065818h]
  10004DB1: pop         eax
  10004DB2: inc         edi
  10004DB3: push        edx
  10004DB4: adc         al,byte ptr ds:[47065819h]
  10004DBA: push        edx
  10004DBB: push        es
  10004DBC: adc         dword ptr ds:[581A0654h],eax
  10004DC2: add         ebp,dword ptr [eax]
  10004DC4: inc         eax
  10004DC5: add         byte ptr [eax],al
  10004DC7: push        es
  10004DC8: add         bl,byte ptr [edi]
  10004DCA: xor         al,58h
  10004DCC: add         ebp,dword ptr [eax]
  10004DCE: xchg        al,byte ptr [eax]
  10004DD0: add         byte ptr [esi],al
  10004DD2: add         bl,byte ptr [edi]
  10004DD4: cmp         al,58h
  10004DD6: add         ebp,dword ptr [eax]
  10004DD8: dec         ebx
  10004DD9: add         byte ptr [eax],al
  10004DDB: push        es
  10004DDC: add         bl,byte ptr [edi]
  10004DDE: pop         eax
  10004DDF: pop         eax
  10004DE0: dec         edx
  10004DE1: or          al,8
  10004DE3: sub         al,12h
  10004DE5: or          byte ptr [ebx],cl
  10004DE7: pop         es
  10004DE8: add         ebp,dword ptr [eax]
  10004DEA: push        7060000h
  10004DEF: push        ds
  10004DF0: pop         eax
  10004DF1: add         ebp,dword ptr [eax]
  10004DF3: imul        eax,dword ptr [eax],32A0600h
  10004DF9: xor         byte ptr [eax+eax],al
  10004DFC: push        edx
  10004DFD: add         byte ptr [eax],al
  10004DFF: add         cl,bh
  10004E01: add         byte ptr [eax],al
  10004E03: adc         dword ptr [edx],eax
  10004E05: add         ebp,dword ptr [esi]
  10004E07: dec         ebp
  10004E08: add         eax,dword ptr [edx]
  10004E0A: pop         ecx
  10004E0B: pop         ds
  10004E0C: or          al,5Bh
  10004E0E: or          eax,0B160A09h
  10004E13: push        es
  10004E14: sub         al,0Bh
  10004E16: push        es
  10004E17: pop         ss
  10004E18: arpl        word ptr [edx],cx
  10004E1A: pop         es
  10004E1B: pop         ss
  10004E1C: pop         eax
  10004E1D: or          eax,dword ptr [esi]
  10004E1F: sub         eax,70302F5h
  10004E24: sbb         byte ptr [edx+18h],bl
  10004E27: pop         ecx
  10004E28: add         al,28h
  10004E2A: xchg        eax,esp
  10004E2B: add         byte ptr [eax],al
  10004E2D: push        es
  10004E2E: or          dword ptr [edi],ebx
  10004E30: sbb         al,31h
  10004E32: sbb         al,byte ptr [edx]
  10004E34: and         byte ptr [eax+1],dl
  10004E37: add         byte ptr [eax],al
  10004E39: pop         eax
  10004E3A: or          al,2
  10004E3C: or          byte ptr [eax+ebp],al
  10004E3F: xchg        eax,ebp
  10004E40: add         byte ptr [eax],al
  10004E42: push        es
  10004E43: or          byte ptr [ebx],al
  10004E45: add         al,28h
  10004E47: xchg        eax,esi
  10004E48: add         byte ptr [eax],al
  10004E4A: push        es
  10004E4B: sub         ecx,dword ptr [eax]
  10004E4D: add         al,byte ptr [ebx]
  10004E4F: add         al,28h
  10004E51: xchg        eax,ebp
  10004E52: add         byte ptr [eax],al
  10004E54: push        es
  10004E55: sub         cl,ah
  10004E57: int         3
  10004E58: add         esi,dword ptr [eax]
  10004E5A: add         eax,5800h
  10004E5F: add         dl,bh
  10004E61: add         byte ptr [eax],al
  10004E63: adc         dword ptr [edx],eax
  10004E65: push        ds
  10004E66: pop         eax
  10004E67: dec         edx
  10004E68: sbb         bl,byte ptr [ecx+4Ah]
  10004E6B: or          eax,54090412h
  10004E70: adc         al,byte ptr [edx+ebx]
  10004E73: pop         eax
  10004E74: add         ecx,dword ptr [ecx]
  10004E76: pop         ds
  10004E77: or          al,5Ah
  10004E79: add         bl,byte ptr [edi]
  10004E7B: adc         al,58h
  10004E7D: dec         edx
  10004E7E: pop         eax
  10004E7F: dec         edx
  10004E80: pop         ecx
  10004E81: push        esp
  10004E82: adc         al,byte ptr [esi+ebx]
  10004E85: pop         eax
  10004E86: add         al,54h
  10004E88: add         eax,dword ptr [esp+edx*2]
  10004E8B: add         bl,byte ptr [edi]
  10004E8D: xor         al,58h
  10004E8F: or          eax,dword ptr [edi]
  10004E91: sbb         bl,byte ptr [eax+4Ah]
  10004E94: or          al,byte ptr [esi]
  10004E96: pop         es
  10004E97: push        ds
  10004E98: pop         eax
  10004E99: dec         edx
  10004E9A: xor         al,16h
  10004E9C: push        es
  10004E9D: or          al,7
  10004E9F: sbb         bl,byte ptr [eax+6]
  10004EA2: pop         ds
  10004EA3: or          al,58h
  10004EA5: push        esp
  10004EA6: or          byte ptr [edx+edx],ch
  10004EA9: or          byte ptr [edx],dl
  10004EAB: add         al,1Fh
  10004EAD: or          al,0FEh
  10004EAF: pop         ss
  10004EB0: sub         ecx,dword ptr [ecx]
  10004EB2: pop         es
  10004EB3: push        es
  10004EB4: adc         al,byte ptr [eax+ebp]
  10004EB7: and         byte ptr [eax],al
  10004EB9: add         byte ptr [esi],al
  10004EBB: sub         cl,byte ptr [ebx]
  10004EBD: xor         byte ptr [eax+eax],al
  10004EC0: cmp         byte ptr [eax],al
  10004EC2: add         byte ptr [eax],al
  10004EC4: clc
  10004EC5: add         byte ptr [eax],al
  10004EC7: adc         dword ptr [edx],eax
  10004EC9: push        ds
  10004ECA: pop         eax
  10004ECB: or          al,byte ptr [esi]
  10004ECD: and         eax,581A064Ah
  10004ED2: dec         edx
  10004ED3: sub         byte ptr [ebx],ah
  10004ED5: add         byte ptr [eax],al
  10004ED7: push        es
  10004ED8: fimul       word ptr ds:[002406FEh]
  10004EDE: add         byte ptr [esi],al
  10004EE0: push        es
  10004EE1: sub         byte ptr [ebx],al
  10004EE3: add         dword ptr [eax],eax
  10004EE5: push        es
  10004EE6: fadd        qword ptr [esi]
  10004EE8: dec         edx
  10004EE9: or          eax,dword ptr [edi]
  10004EEB: sub         al,6
  10004EED: pop         es
  10004EEE: sub         byte ptr [edi],bl
  10004EF0: add         dword ptr [eax],eax
  10004EF2: push        es
  10004EF3: add         edx,dword ptr [edi]
  10004EF5: pop         edi
  10004EF6: sub         al,6
  10004EF8: add         ch,byte ptr [eax]
  10004EFA: push        ds
  10004EFB: add         dword ptr [eax],eax
  10004EFD: push        es
  10004EFE: add         ch,byte ptr [edx]
  10004F00: inc         ecx
  10004F01: sbb         al,0
  10004F03: add         byte ptr [eax+eax],al
  10004F06: add         byte ptr [eax],al
  10004F08: add         al,0
  10004F0A: add         byte ptr [eax],al
  10004F0C: push        cs
  10004F0D: add         byte ptr [eax],al
  10004F0F: add         byte ptr [edx],dl
  10004F11: add         byte ptr [eax],al
  10004F13: add         byte ptr ds:[3A000000h],cl
  10004F19: add         byte ptr [eax],al
  10004F1B: add         dword ptr [ebx],ecx
  10004F1D: xor         byte ptr [ebx],al
  10004F1F: add         byte ptr [ebx],ah
  10004F22: add         byte ptr [eax],al
  10004F24: sti
  10004F25: add         byte ptr [eax],al
  10004F27: adc         dword ptr [edx],eax
  10004F29: or          al,3
  10004F2B: push        ss
  10004F2C: pop         esp
  10004F2E: adc         al,byte ptr [edx]
  10004F30: dec         edx
  10004F31: or          edx,dword ptr [edx]
  10004F33: add         cl,byte ptr [edx+0Ah]
  10004F36: adc         al,byte ptr [edx]
  10004F38: dec         edx
  10004F39: sub         eax,123BDE02h
  10004F3E: add         cl,byte ptr [edx+4]
  10004F41: dec         edx
  10004F42: push        esp
  10004F43: adc         al,byte ptr [edx]
  10004F45: dec         edx
  10004F46: sbb         bl,byte ptr [eax+4]
  10004F49: sbb         bl,byte ptr [eax+28h]
  10004F4C: xor         dword ptr [eax],eax
  10004F4E: add         byte ptr [esi],al
  10004F50: adc         al,byte ptr es:[edx]
  10004F53: dec         edx
  10004F54: pop         ds
  10004F55: adc         al,58h
  10004F57: add         al,1Fh
  10004F59: adc         al,58h
  10004F5B: inc         edi
  10004F5C: push        edx
  10004F5D: fimul       word ptr [edi]
  10004F5F: inc         byte ptr [esi]
  10004F61: push        ss
  10004F62: add         byte ptr [eax],al
  10004F64: push        es
  10004F65: push        es
  10004F66: sbb         bl,byte ptr [eax+28h]
  10004F69: add         eax,dword ptr [ecx]
  10004F6B: add         byte ptr [esi],al
  10004F6D: fcomp3      st(6)
  10004F6F: or          byte ptr [esi],al
  10004F71: pop         es
  10004F72: sub         byte ptr [ecx],al
  10004F74: add         byte ptr [eax],al
  10004F76: push        es
  10004F77: fadd        qword ptr [ebx]
  10004F79: pop         ss
  10004F7A: pop         ecx
  10004F7B: adc         byte ptr [ecx],al
  10004F7D: adc         al,byte ptr [edx]
  10004F7F: adc         al,byte ptr [edx]
  10004F81: dec         edx
  10004F82: pop         ds
  10004F83: sbb         byte ptr [eax+54h],bl
  10004F86: add         edx,dword ptr [esi]
  10004F88: xor         eax,41002AA4h
  10004F8D: xor         al,0
  10004F8F: add         byte ptr [eax+eax],al
  10004F92: add         byte ptr [eax],al
  10004F94: sub         dword ptr [eax],eax
  10004F96: add         byte ptr [eax],al
  10004F98: push        cs
  10004F99: add         byte ptr [eax],al
  10004F9B: add         byte ptr [edi],dh
  10004F9D: add         byte ptr [eax],al
  10004F9F: add         byte ptr [edi],cl
  10004FA1: add         byte ptr [eax],al
  10004FA3: add         byte ptr [edx],bh
  10004FA5: add         byte ptr [eax],al
  10004FA7: add         dword ptr [eax+eax],eax
  10004FAA: add         byte ptr [eax],al
  10004FAC: push        cs
  10004FAD: add         byte ptr [eax],al
  10004FAF: add         byte ptr [edx],bh
  10004FB1: add         byte ptr [eax],al
  10004FB3: add         byte ptr [eax],cl
  10004FB6: add         byte ptr [eax],al
  10004FB8: or          byte ptr [eax],al
  10004FBA: add         byte ptr [eax],al
  10004FBC: cmp         al,byte ptr [eax]
  10004FBE: add         byte ptr [ecx],al
  10004FC0: add         esi,dword ptr [eax]
  10004FC2: add         al,0
  10004FC4: add         eax,dword ptr [edx]
  10004FC6: add         byte ptr [eax],al
  10004FC8: std
  10004FC9: add         byte ptr [eax],al
  10004FCB: adc         dword ptr [edx],eax
  10004FCD: pop         ds
  10004FCE: xor         al,58h
  10004FD0: adc         edx,dword ptr [ebx]
  10004FD2: adc         dword ptr [ebx],edx
  10004FD4: sbb         bl,byte ptr [eax+4Ah]
  10004FD7: adc         dword ptr [ebx],edx
  10004FD9: dec         edx
  10004FDA: pop         ecx
  10004FDB: pop         ds
  10004FDC: or          al,5Bh
  10004FDE: push        ss
  10004FDF: sbb         al,byte ptr ss:[edx]
  10004FE2: pop         ds
  10004FE3: xor         al,58h
  10004FE5: adc         edx,dword ptr [edx]
  10004FE7: adc         dword ptr [edx],edx
  10004FE9: sbb         bl,byte ptr [eax+4Ah]
  10004FEC: adc         dword ptr [edx],edx
  10004FEE: dec         edx
  10004FEF: pop         ecx
  10004FF0: pop         ds
  10004FF1: or          al,5Bh
  10004FF3: sbb         bl,byte ptr [edx+1Ah]
  10004FF6: pop         eax
  10004FF7: adc         ecx,dword ptr [ecx]
  10004FF9: sub         eax,dword ptr [ebx]
  10004FFB: push        ss
  10004FFC: adc         ecx,dword ptr [ecx]
  10004FFE: add         bl,byte ptr [edi]
  10005000: and         al,58h
  10005002: adc         edx,dword ptr [ecx]
  10005004: adc         dword ptr [ecx],edx
  10005006: sbb         bl,byte ptr [eax+4Ah]
  10005009: adc         dword ptr [ecx],edx
  1000500B: dec         edx
  1000500C: pop         ecx
  1000500D: pop         ds
  1000500E: or          al,5Bh
  10005010: push        ss
  10005011: sbb         al,byte ptr ss:[edx]
  10005014: pop         ds
  10005015: and         al,58h
  10005017: adc         edx,dword ptr [eax]
  10005019: adc         dword ptr [eax],edx
  1000501B: sbb         bl,byte ptr [eax+4Ah]
  1000501E: adc         dword ptr [eax],edx
  10005020: dec         edx
  10005021: pop         ecx
  10005022: pop         ds
  10005023: or          al,5Bh
  10005025: sbb         bl,byte ptr [edx+1Ah]
  10005028: pop         eax
  10005029: adc         ecx,dword ptr [eax]
  1000502B: sub         eax,dword ptr [ebx]
  1000502D: push        ss
  1000502E: adc         ecx,dword ptr [eax]
  10005030: add         eax,dword ptr [edx]
  10005032: dec         edx
  10005033: adc         dword ptr [eax],ecx
  10005035: adc         dword ptr [ecx],ecx
  10005037: sub         byte ptr [esi],dh
  10005039: add         byte ptr [eax],al
  1000503B: push        es
  1000503C: sub         eax,32A1602h
  10005041: dec         edx
  10005042: adc         eax,dword ptr [esi]
  10005044: adc         dword ptr [esi],eax
  10005046: adc         eax,dword ptr ds:[58541F02h]
  1000504C: dec         edx
  1000504D: adc         ecx,dword ptr [edi]
  1000504F: adc         dword ptr [edi],ecx
  10005051: sub         al,7
  10005053: adc         dword ptr [edi],ecx
  10005055: sub         byte ptr [edi],bl
  10005057: add         dword ptr [eax],eax
  10005059: push        es
  1000505A: add         bl,byte ptr [edi]
  1000505C: adc         al,58h
  1000505E: adc         ecx,dword ptr [esi]
  10005060: adc         dword ptr [esi],ecx
  10005062: sbb         bl,byte ptr [eax+4Ah]
  10005065: adc         dword ptr [esi],ecx
  10005067: dec         edx
  10005068: pop         ecx
  10005069: pop         ds
  1000506A: or          al,5Bh
  1000506C: adc         ecx,dword ptr ds:[FF200D11h]
  10005072: FF
  10005073: FF
  10005074: aas
  10005075: xor         eax,180D1108h
  1000507A: bound       edx,qword ptr [ebx]
  1000507C: or          al,2Bh
  1000507E: add         edx,dword ptr ds:[1F020C13h]
  10005084: push        esp
  10005085: pop         eax
  10005086: adc         dword ptr [eax+ebp],ecx
  10005089: sub         dword ptr [ecx],eax
  1000508B: add         byte ptr [esi],al
  1000508D: push        esp
  1000508E: add         bl,byte ptr [edi]
  10005090: adc         al,58h
  10005092: dec         edx
  10005093: or          al,8
  10005095: add         bl,byte ptr [edi]
  10005097: sbb         byte ptr [eax+4Ah],bl
  1000509A: aaa
  1000509C: push        ss
  1000509D: adc         eax,dword ptr [edi]
  1000509F: adc         dword ptr ds:[1A084A08h],eax
  100050A5: pop         eax
  100050A6: dec         edx
  100050A7: FE
  100050A8: pop         ss
  100050A9: adc         dword ptr [edi],eax
  100050AB: add         bl,byte ptr [edi]
  100050AD: push        esp
  100050AE: pop         eax
  100050AF: dec         edx
  100050B0: pop         eax
  100050B1: adc         dword ptr ds:[54590611h],eax
  100050B7: adc         dword ptr [edi],eax
  100050B9: sbb         bl,byte ptr [eax+13h]
  100050BC: pop         es
  100050BD: or          byte ptr [edx],bl
  100050BF: pop         eax
  100050C0: dec         edx
  100050C1: adc         dword ptr ds:[08051358h],eax
  100050C7: pop         ds
  100050C8: or          al,58h
  100050CA: or          al,8
  100050CC: add         bl,byte ptr [edi]
  100050CE: sbb         byte ptr [eax+4Ah],bl
  100050D1: xor         ecx,esp
  100050D3: adc         dword ptr [eax],ecx
  100050D5: push        ss
  100050D6: inc         ebx
  100050D7: jge         100050D9
  100050D9: add         byte ptr [eax],al
  100050DB: add         ebx,dword ptr [esi]
  100050DD: pop         eax
  100050DE: dec         edx
  100050DF: adc         eax,dword ptr [edx+eax]
  100050E2: pop         ds
  100050E3: and         al,58h
  100050E5: dec         edx
  100050E6: add         bl,byte ptr [edi]
  100050E8: sub         byte ptr [eax+4Ah],bl
  100050EB: jle         100050C6
  100050ED: add         byte ptr [eax],al
  100050EF: add         al,28h
  100050F1: mov         word ptr [eax],es
  100050F3: add         byte ptr [esi],al
  100050F5: add         bl,byte ptr [edi]
  100050F7: and         al,58h
  100050F9: dec         edx
  100050FA: or          eax,dword ptr [edi]
  100050FC: add         bl,byte ptr [edi]
  100050FE: sub         byte ptr [eax+4Ah],bl
  10005101: push        ecx
  10005103: pop         es
  10005104: dec         edx
  10005105: sbb         bl,byte ptr [edx+2]
  10005108: pop         ds
  10005109: push        esp
  1000510A: pop         eax
  1000510B: dec         edx
  1000510C: pop         eax
  1000510D: dec         edx
  1000510E: pop         es
  1000510F: sbb         bl,byte ptr [eax+4Ah]
  10005112: pop         eax
  10005113: adc         ecx,dword ptr [ebx]
  10005115: adc         dword ptr [esp+eax],eax
  10005118: adc         dword ptr [ebx],ecx
  1000511A: add         eax,32858h
  1000511F: add         byte ptr [esi],al
  10005121: push        esp
  10005122: pop         es
  10005123: push        ds
  10005124: pop         eax
  10005125: dec         edx
  10005126: sbb         bl,byte ptr [edx+2]
  10005129: pop         ds
  1000512A: push        esp
  1000512B: pop         eax
  1000512C: dec         edx
  1000512D: pop         eax
  1000512E: dec         edx
  1000512F: adc         edx,dword ptr ds:[06110B11h]
  10005135: pop         eax
  10005136: add         al,11h
  10005138: adc         eax,3285805h
  1000513D: add         byte ptr [eax],al
  1000513F: push        es
  10005140: push        esp
  10005141: adc         dword ptr [edx+ebx],eax
  10005144: pop         eax
  10005145: adc         eax,dword ptr [edi+eax]
  10005148: pop         ds
  10005149: or          al,58h
  1000514B: or          eax,dword ptr [edi]
  1000514D: add         bl,byte ptr [edi]
  1000514F: sub         byte ptr [eax+4Ah],bl
  10005152: xor         ebp,dword ptr [edi+54150411h]
  10005158: adc         dword ptr [ecx],ecx
  1000515A: push        ss
  1000515B: jo          10005161
  1000515E: pop         ds
  1000515F: adc         byte ptr [eax+4Ah],bl
  10005162: or          eax,58341F02h
  10005167: dec         edx
  10005168: add         bl,byte ptr [edi]
  1000516A: cmp         byte ptr [eax+4Ah],bl
  1000516D: jle         10005148
  1000516F: add         byte ptr [eax],al
  10005171: add         al,28h
  10005173: mov         word ptr [eax],es
  10005175: add         byte ptr [esi],al
  10005177: add         bl,byte ptr [edi]
  10005179: xor         al,58h
  1000517B: dec         edx
  1000517C: or          al,byte ptr [esi]
  1000517E: add         bl,byte ptr [edi]
  10005180: cmp         byte ptr [eax+4Ah],bl
  10005183: inc         ebp
  10005185: push        es
  10005186: dec         edx
  10005187: sbb         bl,byte ptr [edx+2]
  1000518A: pop         ds
  1000518B: push        esp
  1000518C: pop         eax
  1000518D: dec         edx
  1000518E: pop         eax
  1000518F: dec         edx
  10005190: push        es
  10005191: sbb         bl,byte ptr [eax+4Ah]
  10005194: pop         eax
  10005195: adc         ecx,dword ptr [edx]
  10005197: or          dword ptr [ecx+edx],eax
  1000519A: or          al,byte ptr ds:[00032858h]
  100051A0: add         byte ptr [esi],al
  100051A2: push        esp
  100051A3: push        es
  100051A4: push        ds
  100051A5: pop         eax
  100051A6: dec         edx
  100051A7: adc         edx,dword ptr [ecx+edx]
  100051AA: or          dl,byte ptr [ecx]
  100051AC: push        es
  100051AD: pop         eax
  100051AE: add         al,11h
  100051B0: adc         al,17h
  100051B2: pop         eax
  100051B3: sub         byte ptr [edx],al
  100051B5: add         byte ptr [eax],al
  100051B7: push        es
  100051B8: push        esp
  100051B9: or          dword ptr [edx],ebx
  100051BB: pop         eax
  100051BC: or          eax,580C1F06h
  100051C1: or          al,byte ptr [esi]
  100051C3: add         bl,byte ptr [edi]
  100051C5: cmp         byte ptr [eax+4Ah],bl
  100051C8: xor         edi,dword ptr [ebx+17541509h]
  100051CE: sub         cl,ah
  100051D0: or          esi,dword ptr [eax]
  100051D2: add         al,0
  100051D4: and         al,1
  100051D6: add         byte ptr [eax],al
  100051D8: add         dword ptr [ecx],eax
  100051DA: add         byte ptr [ecx],dl
  100051DC: adc         al,byte ptr [ebx]
  100051DE: push        ss
  100051DF: push        esp
  100051E0: adc         al,byte ptr [ebx]
  100051E2: sbb         bl,byte ptr [eax+16h]
  100051E5: push        esp
  100051E6: adc         al,byte ptr [ebx]
  100051E8: push        ds
  100051E9: pop         eax
  100051EA: push        ss
  100051EB: push        esp
  100051EC: adc         al,byte ptr [ebx]
  100051EE: pop         ds
  100051EF: or          al,58h
  100051F1: push        ss
  100051F2: push        esp
  100051F3: adc         al,byte ptr [ebx]
  100051F5: pop         ds
  100051F6: adc         byte ptr [eax+16h],bl
  100051F9: push        esp
  100051FA: adc         al,byte ptr [ebx]
  100051FC: pop         ds
  100051FD: adc         al,58h
  100051FF: push        ss
  10005200: push        esp
  10005201: add         edx,dword ptr [edx]
  10005203: add         eax,dword ptr [esi+edx]
  10005206: sub         byte ptr [eax],bh
  10005208: add         byte ptr [eax],al
  1000520A: push        es
  1000520B: add         eax,581A0312h
  10005211: dec         edx
  10005212: lea         esp,[eax+eax]
  10005215: add         byte ptr [ecx],al
  10005217: sub         byte ptr ds:[120A0000h],bl
  1000521D: add         ebx,dword ptr [edx]
  1000521F: pop         eax
  10005220: dec         edx
  10005221: push        ss
  10005222: pop         ds
  10005224: add         eax,1C28h
  10005229: or          dl,byte ptr [esi]
  1000522B: 8F
  1000522C: and         al,0
  1000522E: add         byte ptr [ecx],al
  10005230: or          al,8
  10005232: adc         al,byte ptr [ebx]
  10005234: dec         edx
  10005235: adc         al,byte ptr [ebx]
  10005237: sbb         bl,byte ptr [eax+4Ah]
  1000523A: FE
  1000523B: pop         ss
  1000523C: fiadd       word ptr [ebx]
  1000523E: push        ss
  1000523F: or          al,0DCh
  10005241: push        ss
  10005242: or          al,5
  10005244: adc         al,byte ptr [ebx]
  10005246: pop         ds
  10005247: or          al,58h
  10005249: dec         edx
  1000524A: lea         esp,[eax+eax]
  1000524D: add         byte ptr [ecx],al
  1000524F: sub         byte ptr [edi],bl
  10005251: add         byte ptr [eax],al
  10005253: or          dl,byte ptr [edx]
  10005255: add         ebx,dword ptr [edi]
  10005257: or          al,58h
  10005259: dec         edx
  1000525A: push        ss
  1000525B: and         al,byte ptr ss:[00001E28h]
  10005262: or          dl,byte ptr [esi]
  10005264: 8F
  10005265: and         al,0
  10005267: add         byte ptr [ecx],al
  10005269: or          eax,dword ptr [edi]
  1000526B: adc         al,byte ptr [ebx]
  1000526D: push        ds
  1000526E: pop         eax
  1000526F: dec         edx
  10005270: adc         al,byte ptr [ebx]
  10005272: pop         ds
  10005273: or          al,58h
  10005275: dec         edx
  10005276: FE
  10005277: pop         ss
  10005278: fiadd       word ptr [ebx]
  1000527A: push        ss
  1000527B: or          ebx,esp
  1000527D: push        ss
  1000527E: or          eax,dword ptr ds:[141F0312h]
  10005284: pop         eax
  10005285: dec         edx
  10005286: lea         esp,[eax+eax]
  10005289: add         byte ptr [ecx],al
  1000528B: sub         byte ptr [ecx],ah
  1000528D: add         byte ptr [eax],al
  1000528F: or          dl,byte ptr [edx]
  10005291: add         ebx,dword ptr [edi]
  10005293: adc         al,58h
  10005295: dec         edx
  10005296: push        ss
  10005297: xor         eax,533DE02h
  1000529C: sub         byte ptr [eax],ah
  1000529E: add         byte ptr [eax],al
  100052A0: or          dl,byte ptr [esi]
  100052A2: 8F
  100052A3: and         al,0
  100052A5: add         byte ptr [ecx],al
  100052A7: or          al,byte ptr [esi]
  100052A9: adc         al,byte ptr [ebx]
  100052AB: pop         ds
  100052AC: adc         byte ptr [eax+4Ah],bl
  100052AF: adc         al,byte ptr [ebx]
  100052B1: pop         ds
  100052B2: adc         al,58h
  100052B4: dec         edx
  100052B5: FE
  100052B6: pop         ss
  100052B7: fiadd       word ptr [ebx]
  100052B9: push        ss
  100052BA: or          bl,ah
  100052BC: push        ss
  100052BD: or          bl,dh
  100052BF: push        cs
  100052C0: inc         byte ptr [esi]
  100052C2: xor         eax,12060000h
  100052C7: add         ebp,dword ptr [eax]
  100052C9: add         eax,dword ptr [ecx]
  100052CB: add         byte ptr [esi],al
  100052CD: fcom        qword ptr [edx]
  100052CF: add         ebx,dword ptr [esi]
  100052D1: pop         eax
  100052D2: dec         edx
  100052D3: sub         al,0Ah
  100052D5: adc         al,byte ptr [ebx]
  100052D7: push        ds
  100052D8: pop         eax
  100052D9: dec         edx
  100052DA: sub         byte ptr [eax],ch
  100052DC: add         dword ptr [eax],eax
  100052DE: push        es
  100052DF: adc         al,byte ptr [ebx]
  100052E1: pop         ds
  100052E2: adc         byte ptr [eax+4Ah],bl
  100052E5: sub         al,0Bh
  100052E7: adc         al,byte ptr [ebx]
  100052E9: pop         ds
  100052EA: adc         byte ptr [eax+4Ah],bl
  100052ED: sub         byte ptr [eax],ch
  100052EF: add         dword ptr [eax],eax
  100052F1: push        es
  100052F2: adc         al,byte ptr [ebx]
  100052F4: dec         edx
  100052F5: sub         al,8
  100052F7: adc         al,byte ptr [ebx]
  100052F9: dec         edx
  100052FA: sub         byte ptr [eax],ch
  100052FC: add         dword ptr [eax],eax
  100052FE: push        es
  100052FF: sub         al,byte ptr [ecx+64h]
  10005302: add         byte ptr [eax],al
  10005304: add         al,0
  10005306: add         byte ptr [eax],al
  10005308: push        ebp
  10005309: add         byte ptr [eax],al
  1000530B: add         byte ptr ds:[62000000h],cl
  10005311: add         byte ptr [eax],al
  10005313: add         byte ptr [ebx],al
  10005315: add         byte ptr [eax],al
  10005317: add         byte ptr [edx],bh
  10005319: add         byte ptr [eax],al
  1000531B: add         dword ptr [eax+eax],eax
  1000531E: add         byte ptr [eax],al
  10005320: mov         es,word ptr [eax]
  10005322: add         byte ptr [eax],al
  10005324: adc         byte ptr [eax],al
  10005326: add         byte ptr [eax],al
  10005328: sahf
  10005329: add         byte ptr [eax],al
  1000532B: add         byte ptr [ebx],al
  1000532D: add         byte ptr [eax],al
  1000532F: add         byte ptr [edx],bh
  10005331: add         byte ptr [eax],al
  10005333: add         dword ptr [eax+eax],eax
  10005336: add         byte ptr [eax],al
  10005338: int         3
  10005339: add         byte ptr [eax],al
  1000533B: add         byte ptr [ecx],dl
  1000533D: add         byte ptr [eax],al
  1000533F: add         ch,bl
  10005341: add         byte ptr [eax],al
  10005343: add         byte ptr [ebx],al
  10005345: add         byte ptr [eax],al
  10005347: add         byte ptr [edx],bh
  10005349: add         byte ptr [eax],al
  1000534B: add         dword ptr [eax+eax],eax
  1000534E: add         byte ptr [eax],al
  10005350: and         eax,0BF000000h
  10005355: add         byte ptr [eax],al
  10005357: add         ah,ah
  10005359: add         byte ptr [eax],al
  1000535B: add         byte ptr [esi],cl
  1000535D: add         byte ptr [eax],al
  1000535F: add         byte ptr [edx],bh
  10005361: add         byte ptr [eax],al
  10005363: add         dword ptr [ebx],eax
  10005365: xor         byte ptr [ebx],al
  10005367: add         byte ptr [eax+eax],dh
  1000536A: add         byte ptr [eax],al
  1000536C: xchg        eax,dword ptr [eax]
  1000536E: add         byte ptr [ecx],dl
  10005370: add         ch,byte ptr [eax+esi]
  10005373: add         ah,byte ptr ds:[75294A4Ah]
  10005379: add         byte ptr [eax],al
  1000537B: adc         dword ptr [edi],ebx
  1000537D: pop         esp
  1000537E: sub         byte ptr [esi],ah
  10005380: add         dword ptr [eax],eax
  10005382: push        es
  10005383: or          al,byte ptr [esi]
  10005385: sub         al,11h
  10005387: push        es
  10005388: pop         ss
  10005389: pop         eax
  1000538A: sub         byte ptr ds:[0B060001h],ah
  10005390: add         al,3
  10005392: pop         es
  10005393: sub         byte ptr [ecx],bh
  10005395: add         byte ptr [eax],al
  10005397: push        es
  10005398: add         ah,byte ptr ds:[4A581A4Ah]
  1000539E: sub         dword ptr [eax],edi
  100053A1: add         byte ptr [ecx],dl
  100053A3: sub         cl,byte ptr [ebx]
  100053A5: xor         byte ptr [ebx],al
  100053A7: add         byte ptr ds:[03000001h],dl
  100053AD: add         dword ptr [eax],eax
  100053AF: adc         dword ptr [edx],eax
  100053B1: push        ss
  100053B2: push        esp
  100053B3: add         bl,byte ptr [edx]
  100053B5: pop         eax
  100053B6: adc         ecx,dword ptr [edx]
  100053B8: adc         dword ptr [edx],ecx
  100053BA: adc         eax,dword ptr [esi]
  100053BC: adc         dword ptr [esi],eax
  100053BE: push        ss
  100053BF: push        esp
  100053C0: adc         dword ptr [esi],eax
  100053C2: sbb         bl,byte ptr [eax+16h]
  100053C5: push        esp
  100053C6: adc         dword ptr [esi],eax
  100053C8: push        ds
  100053C9: pop         eax
  100053CA: push        ss
  100053CB: push        esp
  100053CC: add         bl,byte ptr [edi]
  100053CE: adc         al,58h
  100053D0: adc         ecx,dword ptr [ecx]
  100053D2: adc         dword ptr [ecx],ecx
  100053D4: adc         eax,dword ptr ds:[54160511h]
  100053DA: adc         dword ptr ds:[5416581Ah],eax
  100053E0: adc         dword ptr ds:[5416581Eh],eax
  100053E6: add         bl,byte ptr [edi]
  100053E8: and         al,58h
  100053EA: adc         eax,dword ptr [ecx+edx]
  100053ED: add         al,16h
  100053EF: push        esp
  100053F0: adc         dword ptr [edx+ebx],eax
  100053F3: pop         eax
  100053F4: push        ss
  100053F5: push        esp
  100053F6: adc         dword ptr [esi+ebx],eax
  100053F9: pop         eax
  100053FA: push        ss
  100053FB: push        esp
  100053FC: add         bl,byte ptr [edi]
  100053FE: xor         al,58h
  10005400: or          eax,9541609h
  10005405: sbb         bl,byte ptr [eax+16h]
  10005408: push        esp
  10005409: or          dword ptr [esi],ebx
  1000540B: pop         eax
  1000540C: push        ss
  1000540D: push        esp
  1000540E: add         bl,byte ptr [edi]
  10005410: inc         esp
  10005411: pop         eax
  10005412: or          al,8
  10005414: push        ss
  10005415: push        esp
  10005416: or          byte ptr [edx],bl
  10005418: pop         eax
  10005419: push        ss
  1000541A: push        esp
  1000541B: or          byte ptr [esi],bl
  1000541D: pop         eax
  1000541E: push        ss
  1000541F: push        esp
  10005420: add         bl,byte ptr [edi]
  10005422: push        esp
  10005423: pop         eax
  10005424: push        ss
  10005425: push        esp
  10005426: add         dl,byte ptr [edi]
  10005428: pop         ds
  10005429: sbb         al,28h
  1000542B: pop         es
  1000542C: add         byte ptr [eax],al
  1000542E: push        es
  1000542F: adc         ecx,dword ptr [eax]
  10005431: adc         dword ptr [edx],ecx
  10005433: or          eax,dword ptr [edi]
  10005435: sbb         bl,byte ptr [eax+4Ah]
  10005438: or          al,byte ptr [esi]
  1000543A: pop         es
  1000543B: push        ds
  1000543C: pop         eax
  1000543D: dec         edx
  1000543E: xor         al,15h
  10005440: push        es
  10005441: adc         eax,dword ptr [edi]
  10005443: pop         es
  10005444: sbb         bl,byte ptr [eax+6]
  10005447: sbb         bl,byte ptr [eax+54h]
  1000544A: adc         dword ptr [edi],eax
  1000544C: sub         al,10h
  1000544E: adc         dword ptr [edi],eax
  10005450: adc         dword ptr [eax],ecx
  10005452: push        esp
  10005453: sub         ecx,dword ptr [ecx]
  10005455: pop         es
  10005456: push        es
  10005457: adc         cl,byte ptr [eax]
  10005459: sub         byte ptr [edx],ch
  1000545B: add         byte ptr [eax],al
  1000545D: push        es
  1000545E: add         edx,dword ptr [ecx]
  10005460: or          byte ptr [edi],bl
  10005462: or          al,5Ah
  10005464: adc         dword ptr [ecx],ecx
  10005466: dec         edx
  10005467: pop         eax
  10005468: dec         edx
  10005469: push        esp
  1000546A: ficom       word ptr [eax]
  1000546C: inc         byte ptr [esi]
  1000546E: popad
  1000546F: add         byte ptr [eax],al
  10005471: push        es
  10005472: add         bl,byte ptr [edi]
  10005474: inc         esp
  10005475: pop         eax
  10005476: sub         byte ptr [ebx],al
  10005478: add         dword ptr [eax],eax
  1000547A: push        es
  1000547B: fcomp3      st(6)
  1000547D: adc         dh,bh
  1000547F: push        es
  10005480: pushad
  10005481: add         byte ptr [eax],al
  10005483: push        es
  10005484: add         bl,byte ptr [edi]
  10005486: xor         al,58h
  10005488: sub         byte ptr [ebx],al
  1000548A: add         dword ptr [eax],eax
  1000548C: push        es
  1000548D: fcomp3      st(6)
  1000548F: adc         dh,bh
  10005491: push        es
  10005492: pushad
  10005493: add         byte ptr [eax],al
  10005495: push        es
  10005496: add         bl,byte ptr [edi]
  10005498: and         al,58h
  1000549A: sub         byte ptr [ebx],al
  1000549C: add         dword ptr [eax],eax
  1000549E: push        es
  1000549F: fcomp3      st(6)
  100054A1: adc         dh,bh
  100054A3: push        es
  100054A4: pop         edi
  100054A5: add         byte ptr [eax],al
  100054A7: push        es
  100054A8: add         bl,byte ptr [edi]
  100054AA: adc         al,58h
  100054AC: sub         byte ptr [ebx],al
  100054AE: add         dword ptr [eax],eax
  100054B0: push        es
  100054B1: fcomp3      st(6)
  100054B3: paddd       mm0,mmword ptr [esi]
  100054B6: cmp         al,byte ptr [eax]
  100054B8: add         byte ptr [esi],al
  100054BA: add         bl,byte ptr [edx]
  100054BC: pop         eax
  100054BD: sub         byte ptr [ebx],al
  100054BF: add         dword ptr [eax],eax
  100054C1: push        es
  100054C2: fadd        qword ptr [edx]
  100054C4: sub         al,byte ptr [eax]
  100054C6: add         byte ptr [eax],al
  100054C8: inc         ecx
  100054C9: jl          100054CB
  100054CB: add         byte ptr [eax+eax],al
  100054CE: add         byte ptr [eax],al
  100054D0: jo          100054D2
  100054D2: add         byte ptr [eax],al
  100054D4: dec         esp
  100054D5: add         byte ptr [eax],al
  100054D7: add         byte ptr [eax+eax+00100000h],bh
  100054DE: add         byte ptr [eax],al
  100054E0: cmp         al,byte ptr [eax]
  100054E2: add         byte ptr [ecx],al
  100054E4: add         al,0
  100054E6: add         byte ptr [eax],al
  100054E8: pop         esi
  100054E9: add         byte ptr [eax],al
  100054EB: add         byte ptr [eax],dh
  100054EE: add         byte ptr [eax],al
  100054F0: into
  100054F1: add         byte ptr [eax],al
  100054F3: add         byte ptr [eax],dl
  100054F5: add         byte ptr [eax],al
  100054F7: add         byte ptr [edx],bh
  100054F9: add         byte ptr [eax],al
  100054FB: add         dword ptr [eax+eax],eax
  100054FE: add         byte ptr [eax],al
  10005500: dec         esp
  10005501: add         byte ptr [eax],al
  10005503: add         byte ptr [eax+eax+00E00000h],dl
  1000550A: add         byte ptr [eax],al
  1000550C: adc         byte ptr [eax],al
  1000550E: add         byte ptr [eax],al
  10005510: cmp         al,byte ptr [eax]
  10005512: add         byte ptr [ecx],al
  10005514: add         al,0
  10005516: add         byte ptr [eax],al
  10005518: add         byte ptr ss:[eax],al
  1000551B: add         byte ptr [eax+eax+00F20000h],bh
  10005522: add         byte ptr [eax],al
  10005524: adc         byte ptr [eax],al
  10005526: add         byte ptr [eax],al
  10005528: cmp         al,byte ptr [eax]
  1000552A: add         byte ptr [ecx],al
  1000552C: add         al,0
  1000552E: add         byte ptr [eax],al
  10005530: sbb         al,0
  10005532: add         byte ptr [eax],al
  10005534: call        14005539
  10005539: add         dword ptr [eax],eax
  1000553B: add         byte ptr [edi],cl
  1000553D: add         byte ptr [eax],al
  1000553F: add         byte ptr [edx],bh
  10005541: add         byte ptr [eax],al
  10005543: add         dword ptr [ebx],ecx
  10005545: xor         byte ptr [ebx],al
  10005547: add         byte ptr ds:[03000001h],dl
  1000554D: add         dword ptr [eax],eax
  1000554F: adc         dword ptr [edx],eax
  10005551: push        ss
  10005552: push        esp
  10005553: add         bl,byte ptr [edx]
  10005555: pop         eax
  10005556: adc         ecx,dword ptr [edx]
  10005558: adc         dword ptr [edx],ecx
  1000555A: adc         eax,dword ptr [esi]
  1000555C: adc         dword ptr [esi],eax
  1000555E: push        ss
  1000555F: push        esp
  10005560: adc         dword ptr [esi],eax
  10005562: sbb         bl,byte ptr [eax+16h]
  10005565: push        esp
  10005566: adc         dword ptr [esi],eax
  10005568: push        ds
  10005569: pop         eax
  1000556A: push        ss
  1000556B: push        esp
  1000556C: add         bl,byte ptr [edi]
  1000556E: adc         al,58h
  10005570: adc         ecx,dword ptr [ecx]
  10005572: adc         dword ptr [ecx],ecx
  10005574: adc         eax,dword ptr ds:[54160511h]
  1000557A: adc         dword ptr ds:[5416581Ah],eax
  10005580: adc         dword ptr ds:[5416581Eh],eax
  10005586: add         bl,byte ptr [edi]
  10005588: and         al,58h
  1000558A: adc         eax,dword ptr [ecx+edx]
  1000558D: add         al,16h
  1000558F: push        esp
  10005590: adc         dword ptr [edx+ebx],eax
  10005593: pop         eax
  10005594: push        ss
  10005595: push        esp
  10005596: adc         dword ptr [esi+ebx],eax
  10005599: pop         eax
  1000559A: push        ss
  1000559B: push        esp
  1000559C: add         bl,byte ptr [edi]
  1000559E: xor         al,58h
  100055A0: or          eax,9541609h
  100055A5: sbb         bl,byte ptr [eax+16h]
  100055A8: push        esp
  100055A9: or          dword ptr [esi],ebx
  100055AB: pop         eax
  100055AC: push        ss
  100055AD: push        esp
  100055AE: add         bl,byte ptr [edi]
  100055B0: inc         esp
  100055B1: pop         eax
  100055B2: or          al,8
  100055B4: push        ss
  100055B5: push        esp
  100055B6: or          byte ptr [edx],bl
  100055B8: pop         eax
  100055B9: push        ss
  100055BA: push        esp
  100055BB: or          byte ptr [esi],bl
  100055BD: pop         eax
  100055BE: push        ss
  100055BF: push        esp
  100055C0: add         bl,byte ptr [edi]
  100055C2: push        esp
  100055C3: pop         eax
  100055C4: push        ss
  100055C5: push        esp
  100055C6: add         dl,byte ptr [edi]
  100055C8: pop         ds
  100055C9: sbb         byte ptr [eax],ch
  100055CB: pop         es
  100055CC: add         byte ptr [eax],al
  100055CE: push        es
  100055CF: adc         ecx,dword ptr [eax]
  100055D1: adc         dword ptr [edx],ecx
  100055D3: or          eax,dword ptr [edi]
  100055D5: sbb         bl,byte ptr [eax+4Ah]
  100055D8: or          al,byte ptr [esi]
  100055DA: pop         es
  100055DB: push        ds
  100055DC: pop         eax
  100055DD: dec         edx
  100055DE: xor         al,15h
  100055E0: push        es
  100055E1: adc         eax,dword ptr [edi]
  100055E3: pop         es
  100055E4: sbb         bl,byte ptr [eax+6]
  100055E7: sbb         bl,byte ptr [eax+54h]
  100055EA: adc         dword ptr [edi],eax
  100055EC: sub         al,10h
  100055EE: adc         dword ptr [edi],eax
  100055F0: adc         dword ptr [eax],ecx
  100055F2: push        esp
  100055F3: sub         ecx,dword ptr [ecx]
  100055F5: pop         es
  100055F6: push        es
  100055F7: adc         cl,byte ptr [eax]
  100055F9: sub         byte ptr [edx],ch
  100055FB: add         byte ptr [eax],al
  100055FD: push        es
  100055FE: add         edx,dword ptr [ecx]
  10005600: or          byte ptr [edi],bl
  10005602: or          al,5Ah
  10005604: adc         dword ptr [ecx],ecx
  10005606: dec         edx
  10005607: pop         eax
  10005608: dec         edx
  10005609: push        esp
  1000560A: ficom       word ptr [eax]
  1000560C: inc         byte ptr [esi]
  1000560E: popad
  1000560F: add         byte ptr [eax],al
  10005611: push        es
  10005612: add         bl,byte ptr [edi]
  10005614: inc         esp
  10005615: pop         eax
  10005616: sub         byte ptr [ebx],al
  10005618: add         dword ptr [eax],eax
  1000561A: push        es
  1000561B: fcomp3      st(6)
  1000561D: adc         dh,bh
  1000561F: push        es
  10005620: pushad
  10005621: add         byte ptr [eax],al
  10005623: push        es
  10005624: add         bl,byte ptr [edi]
  10005626: xor         al,58h
  10005628: sub         byte ptr [ebx],al
  1000562A: add         dword ptr [eax],eax
  1000562C: push        es
  1000562D: fcomp3      st(6)
  1000562F: adc         dh,bh
  10005631: push        es
  10005632: pushad
  10005633: add         byte ptr [eax],al
  10005635: push        es
  10005636: add         bl,byte ptr [edi]
  10005638: and         al,58h
  1000563A: sub         byte ptr [ebx],al
  1000563C: add         dword ptr [eax],eax
  1000563E: push        es
  1000563F: fcomp3      st(6)
  10005641: adc         dh,bh
  10005643: push        es
  10005644: pop         edi
  10005645: add         byte ptr [eax],al
  10005647: push        es
  10005648: add         bl,byte ptr [edi]
  1000564A: adc         al,58h
  1000564C: sub         byte ptr [ebx],al
  1000564E: add         dword ptr [eax],eax
  10005650: push        es
  10005651: fcomp3      st(6)
  10005653: paddd       mm0,mmword ptr [esi]
  10005656: cmp         al,byte ptr [eax]
  10005658: add         byte ptr [esi],al
  1000565A: add         bl,byte ptr [edx]
  1000565C: pop         eax
  1000565D: sub         byte ptr [ebx],al
  1000565F: add         dword ptr [eax],eax
  10005661: push        es
  10005662: fadd        qword ptr [edx]
  10005664: sub         al,byte ptr [eax]
  10005666: add         byte ptr [eax],al
  10005668: inc         ecx
  10005669: jl          1000566B
  1000566B: add         byte ptr [eax+eax],al
  1000566E: add         byte ptr [eax],al
  10005670: jo          10005672
  10005672: add         byte ptr [eax],al
  10005674: dec         esp
  10005675: add         byte ptr [eax],al
  10005677: add         byte ptr [eax+eax+00100000h],bh
  1000567E: add         byte ptr [eax],al
  10005680: cmp         al,byte ptr [eax]
  10005682: add         byte ptr [ecx],al
  10005684: add         al,0
  10005686: add         byte ptr [eax],al
  10005688: pop         esi
  10005689: add         byte ptr [eax],al
  1000568B: add         byte ptr [eax],dh
  1000568E: add         byte ptr [eax],al
  10005690: into
  10005691: add         byte ptr [eax],al
  10005693: add         byte ptr [eax],dl
  10005695: add         byte ptr [eax],al
  10005697: add         byte ptr [edx],bh
  10005699: add         byte ptr [eax],al
  1000569B: add         dword ptr [eax+eax],eax
  1000569E: add         byte ptr [eax],al
  100056A0: dec         esp
  100056A1: add         byte ptr [eax],al
  100056A3: add         byte ptr [eax+eax+00E00000h],dl
  100056AA: add         byte ptr [eax],al
  100056AC: adc         byte ptr [eax],al
  100056AE: add         byte ptr [eax],al
  100056B0: cmp         al,byte ptr [eax]
  100056B2: add         byte ptr [ecx],al
  100056B4: add         al,0
  100056B6: add         byte ptr [eax],al
  100056B8: add         byte ptr ss:[eax],al
  100056BB: add         byte ptr [eax+eax+00F20000h],bh
  100056C2: add         byte ptr [eax],al
  100056C4: adc         byte ptr [eax],al
  100056C6: add         byte ptr [eax],al
  100056C8: cmp         al,byte ptr [eax]
  100056CA: add         byte ptr [ecx],al
  100056CC: add         al,0
  100056CE: add         byte ptr [eax],al
  100056D0: sbb         al,0
  100056D2: add         byte ptr [eax],al
  100056D4: call        140056D9
  100056D9: add         dword ptr [eax],eax
  100056DB: add         byte ptr [edi],cl
  100056DD: add         byte ptr [eax],al
  100056DF: add         byte ptr [edx],bh
  100056E1: add         byte ptr [eax],al
  100056E3: add         dword ptr [ebx],ecx
  100056E5: xor         byte ptr [ebx],al
  100056E7: add         byte ptr ds:[03000001h],dl
  100056ED: add         dword ptr [eax],eax
  100056EF: adc         dword ptr [edx],eax
  100056F1: push        ss
  100056F2: push        esp
  100056F3: add         bl,byte ptr [edx]
  100056F5: pop         eax
  100056F6: adc         ecx,dword ptr [edx]
  100056F8: adc         dword ptr [edx],ecx
  100056FA: adc         eax,dword ptr [esi]
  100056FC: adc         dword ptr [esi],eax
  100056FE: push        ss
  100056FF: push        esp
  10005700: adc         dword ptr [esi],eax
  10005702: sbb         bl,byte ptr [eax+16h]
  10005705: push        esp
  10005706: adc         dword ptr [esi],eax
  10005708: push        ds
  10005709: pop         eax
  1000570A: push        ss
  1000570B: push        esp
  1000570C: add         bl,byte ptr [edi]
  1000570E: adc         al,58h
  10005710: adc         ecx,dword ptr [ecx]
  10005712: adc         dword ptr [ecx],ecx
  10005714: adc         eax,dword ptr ds:[54160511h]
  1000571A: adc         dword ptr ds:[5416581Ah],eax
  10005720: adc         dword ptr ds:[5416581Eh],eax
  10005726: add         bl,byte ptr [edi]
  10005728: and         al,58h
  1000572A: adc         eax,dword ptr [ecx+edx]
  1000572D: add         al,16h
  1000572F: push        esp
  10005730: adc         dword ptr [edx+ebx],eax
  10005733: pop         eax
  10005734: push        ss
  10005735: push        esp
  10005736: adc         dword ptr [esi+ebx],eax
  10005739: pop         eax
  1000573A: push        ss
  1000573B: push        esp
  1000573C: add         bl,byte ptr [edi]
  1000573E: xor         al,58h
  10005740: or          eax,9541609h
  10005745: sbb         bl,byte ptr [eax+16h]
  10005748: push        esp
  10005749: or          dword ptr [esi],ebx
  1000574B: pop         eax
  1000574C: push        ss
  1000574D: push        esp
  1000574E: add         bl,byte ptr [edi]
  10005750: inc         esp
  10005751: pop         eax
  10005752: or          al,8
  10005754: push        ss
  10005755: push        esp
  10005756: or          byte ptr [edx],bl
  10005758: pop         eax
  10005759: push        ss
  1000575A: push        esp
  1000575B: or          byte ptr [esi],bl
  1000575D: pop         eax
  1000575E: push        ss
  1000575F: push        esp
  10005760: add         bl,byte ptr [edi]
  10005762: push        esp
  10005763: pop         eax
  10005764: push        ss
  10005765: push        esp
  10005766: add         dl,byte ptr [edi]
  10005768: pop         ds
  10005769: pushad
  1000576A: sub         byte ptr [edi],al
  1000576C: add         byte ptr [eax],al
  1000576E: push        es
  1000576F: adc         ecx,dword ptr [eax]
  10005771: adc         dword ptr [edx],ecx
  10005773: or          eax,dword ptr [edi]
  10005775: sbb         bl,byte ptr [eax+4Ah]
  10005778: or          al,byte ptr [esi]
  1000577A: pop         es
  1000577B: push        ds
  1000577C: pop         eax
  1000577D: dec         edx
  1000577E: xor         al,15h
  10005780: push        es
  10005781: adc         eax,dword ptr [edi]
  10005783: pop         es
  10005784: sbb         bl,byte ptr [eax+6]
  10005787: sbb         bl,byte ptr [eax+54h]
  1000578A: adc         dword ptr [edi],eax
  1000578C: sub         al,10h
  1000578E: adc         dword ptr [edi],eax
  10005790: adc         dword ptr [eax],ecx
  10005792: push        esp
  10005793: sub         ecx,dword ptr [ecx]
  10005795: pop         es
  10005796: push        es
  10005797: adc         cl,byte ptr [eax]
  10005799: sub         byte ptr [edx],ch
  1000579B: add         byte ptr [eax],al
  1000579D: push        es
  1000579E: add         edx,dword ptr [ecx]
  100057A0: or          byte ptr [edi],bl
  100057A2: or          al,5Ah
  100057A4: adc         dword ptr [ecx],ecx
  100057A6: dec         edx
  100057A7: pop         eax
  100057A8: dec         edx
  100057A9: push        esp
  100057AA: ficom       word ptr [eax]
  100057AC: inc         byte ptr [esi]
  100057AE: popad
  100057AF: add         byte ptr [eax],al
  100057B1: push        es
  100057B2: add         bl,byte ptr [edi]
  100057B4: inc         esp
  100057B5: pop         eax
  100057B6: sub         byte ptr [ebx],al
  100057B8: add         dword ptr [eax],eax
  100057BA: push        es
  100057BB: fcomp3      st(6)
  100057BD: adc         dh,bh
  100057BF: push        es
  100057C0: pushad
  100057C1: add         byte ptr [eax],al
  100057C3: push        es
  100057C4: add         bl,byte ptr [edi]
  100057C6: xor         al,58h
  100057C8: sub         byte ptr [ebx],al
  100057CA: add         dword ptr [eax],eax
  100057CC: push        es
  100057CD: fcomp3      st(6)
  100057CF: adc         dh,bh
  100057D1: push        es
  100057D2: pushad
  100057D3: add         byte ptr [eax],al
  100057D5: push        es
  100057D6: add         bl,byte ptr [edi]
  100057D8: and         al,58h
  100057DA: sub         byte ptr [ebx],al
  100057DC: add         dword ptr [eax],eax
  100057DE: push        es
  100057DF: fcomp3      st(6)
  100057E1: adc         dh,bh
  100057E3: push        es
  100057E4: pop         edi
  100057E5: add         byte ptr [eax],al
  100057E7: push        es
  100057E8: add         bl,byte ptr [edi]
  100057EA: adc         al,58h
  100057EC: sub         byte ptr [ebx],al
  100057EE: add         dword ptr [eax],eax
  100057F0: push        es
  100057F1: fcomp3      st(6)
  100057F3: paddd       mm0,mmword ptr [esi]
  100057F6: cmp         al,byte ptr [eax]
  100057F8: add         byte ptr [esi],al
  100057FA: add         bl,byte ptr [edx]
  100057FC: pop         eax
  100057FD: sub         byte ptr [ebx],al
  100057FF: add         dword ptr [eax],eax
  10005801: push        es
  10005802: fadd        qword ptr [edx]
  10005804: sub         al,byte ptr [eax]
  10005806: add         byte ptr [eax],al
  10005808: inc         ecx
  10005809: jl          1000580B
  1000580B: add         byte ptr [eax+eax],al
  1000580E: add         byte ptr [eax],al
  10005810: jo          10005812
  10005812: add         byte ptr [eax],al
  10005814: dec         esp
  10005815: add         byte ptr [eax],al
  10005817: add         byte ptr [eax+eax+00100000h],bh
  1000581E: add         byte ptr [eax],al
  10005820: cmp         al,byte ptr [eax]
  10005822: add         byte ptr [ecx],al
  10005824: add         al,0
  10005826: add         byte ptr [eax],al
  10005828: pop         esi
  10005829: add         byte ptr [eax],al
  1000582B: add         byte ptr [eax],dh
  1000582E: add         byte ptr [eax],al
  10005830: into
  10005831: add         byte ptr [eax],al
  10005833: add         byte ptr [eax],dl
  10005835: add         byte ptr [eax],al
  10005837: add         byte ptr [edx],bh
  10005839: add         byte ptr [eax],al
  1000583B: add         dword ptr [eax+eax],eax
  1000583E: add         byte ptr [eax],al
  10005840: dec         esp
  10005841: add         byte ptr [eax],al
  10005843: add         byte ptr [eax+eax+00E00000h],dl
  1000584A: add         byte ptr [eax],al
  1000584C: adc         byte ptr [eax],al
  1000584E: add         byte ptr [eax],al
  10005850: cmp         al,byte ptr [eax]
  10005852: add         byte ptr [ecx],al
  10005854: add         al,0
  10005856: add         byte ptr [eax],al
  10005858: add         byte ptr ss:[eax],al
  1000585B: add         byte ptr [eax+eax+00F20000h],bh
  10005862: add         byte ptr [eax],al
  10005864: adc         byte ptr [eax],al
  10005866: add         byte ptr [eax],al
  10005868: cmp         al,byte ptr [eax]
  1000586A: add         byte ptr [ecx],al
  1000586C: add         al,0
  1000586E: add         byte ptr [eax],al
  10005870: sbb         al,0
  10005872: add         byte ptr [eax],al
  10005874: call        14005879
  10005879: add         dword ptr [eax],eax
  1000587B: add         byte ptr [edi],cl
  1000587D: add         byte ptr [eax],al
  1000587F: add         byte ptr [edx],bh
  10005881: add         byte ptr [eax],al
  10005883: add         dword ptr [ebx],ecx
  10005885: xor         byte ptr [ebx],al
  10005887: add         byte ptr ds:[03000001h],dl
  1000588D: add         dword ptr [eax],eax
  1000588F: adc         dword ptr [edx],eax
  10005891: push        ss
  10005892: push        esp
  10005893: add         bl,byte ptr [edx]
  10005895: pop         eax
  10005896: adc         ecx,dword ptr [edx]
  10005898: adc         dword ptr [edx],ecx
  1000589A: adc         eax,dword ptr [esi]
  1000589C: adc         dword ptr [esi],eax
  1000589E: push        ss
  1000589F: push        esp
  100058A0: adc         dword ptr [esi],eax
  100058A2: sbb         bl,byte ptr [eax+16h]
  100058A5: push        esp
  100058A6: adc         dword ptr [esi],eax
  100058A8: push        ds
  100058A9: pop         eax
  100058AA: push        ss
  100058AB: push        esp
  100058AC: add         bl,byte ptr [edi]
  100058AE: adc         al,58h
  100058B0: adc         ecx,dword ptr [ecx]
  100058B2: adc         dword ptr [ecx],ecx
  100058B4: adc         eax,dword ptr ds:[54160511h]
  100058BA: adc         dword ptr ds:[5416581Ah],eax
  100058C0: adc         dword ptr ds:[5416581Eh],eax
  100058C6: add         bl,byte ptr [edi]
  100058C8: and         al,58h
  100058CA: adc         eax,dword ptr [ecx+edx]
  100058CD: add         al,16h
  100058CF: push        esp
  100058D0: adc         dword ptr [edx+ebx],eax
  100058D3: pop         eax
  100058D4: push        ss
  100058D5: push        esp
  100058D6: adc         dword ptr [esi+ebx],eax
  100058D9: pop         eax
  100058DA: push        ss
  100058DB: push        esp
  100058DC: add         bl,byte ptr [edi]
  100058DE: xor         al,58h
  100058E0: or          eax,9541609h
  100058E5: sbb         bl,byte ptr [eax+16h]
  100058E8: push        esp
  100058E9: or          dword ptr [esi],ebx
  100058EB: pop         eax
  100058EC: push        ss
  100058ED: push        esp
  100058EE: add         bl,byte ptr [edi]
  100058F0: inc         esp
  100058F1: pop         eax
  100058F2: or          al,8
  100058F4: push        ss
  100058F5: push        esp
  100058F6: or          byte ptr [edx],bl
  100058F8: pop         eax
  100058F9: push        ss
  100058FA: push        esp
  100058FB: or          byte ptr [esi],bl
  100058FD: pop         eax
  100058FE: push        ss
  100058FF: push        esp
  10005900: add         bl,byte ptr [edi]
  10005902: push        esp
  10005903: pop         eax
  10005904: push        ss
  10005905: push        esp
  10005906: add         dl,byte ptr [edi]
  10005908: pop         ds
  10005909: xor         byte ptr [eax],ch
  1000590B: pop         es
  1000590C: add         byte ptr [eax],al
  1000590E: push        es
  1000590F: adc         ecx,dword ptr [eax]
  10005911: adc         dword ptr [edx],ecx
  10005913: or          eax,dword ptr [edi]
  10005915: sbb         bl,byte ptr [eax+4Ah]
  10005918: or          al,byte ptr [esi]
  1000591A: pop         es
  1000591B: push        ds
  1000591C: pop         eax
  1000591D: dec         edx
  1000591E: xor         al,15h
  10005920: push        es
  10005921: adc         eax,dword ptr [edi]
  10005923: pop         es
  10005924: sbb         bl,byte ptr [eax+6]
  10005927: sbb         bl,byte ptr [eax+54h]
  1000592A: adc         dword ptr [edi],eax
  1000592C: sub         al,10h
  1000592E: adc         dword ptr [edi],eax
  10005930: adc         dword ptr [eax],ecx
  10005932: push        esp
  10005933: sub         ecx,dword ptr [ecx]
  10005935: pop         es
  10005936: push        es
  10005937: adc         cl,byte ptr [eax]
  10005939: sub         byte ptr [edx],ch
  1000593B: add         byte ptr [eax],al
  1000593D: push        es
  1000593E: add         edx,dword ptr [ecx]
  10005940: or          byte ptr [edi],bl
  10005942: or          al,5Ah
  10005944: adc         dword ptr [ecx],ecx
  10005946: dec         edx
  10005947: pop         eax
  10005948: dec         edx
  10005949: push        esp
  1000594A: ficom       word ptr [eax]
  1000594C: inc         byte ptr [esi]
  1000594E: popad
  1000594F: add         byte ptr [eax],al
  10005951: push        es
  10005952: add         bl,byte ptr [edi]
  10005954: inc         esp
  10005955: pop         eax
  10005956: sub         byte ptr [ebx],al
  10005958: add         dword ptr [eax],eax
  1000595A: push        es
  1000595B: fcomp3      st(6)
  1000595D: adc         dh,bh
  1000595F: push        es
  10005960: pushad
  10005961: add         byte ptr [eax],al
  10005963: push        es
  10005964: add         bl,byte ptr [edi]
  10005966: xor         al,58h
  10005968: sub         byte ptr [ebx],al
  1000596A: add         dword ptr [eax],eax
  1000596C: push        es
  1000596D: fcomp3      st(6)
  1000596F: adc         dh,bh
  10005971: push        es
  10005972: pushad
  10005973: add         byte ptr [eax],al
  10005975: push        es
  10005976: add         bl,byte ptr [edi]
  10005978: and         al,58h
  1000597A: sub         byte ptr [ebx],al
  1000597C: add         dword ptr [eax],eax
  1000597E: push        es
  1000597F: fcomp3      st(6)
  10005981: adc         dh,bh
  10005983: push        es
  10005984: pop         edi
  10005985: add         byte ptr [eax],al
  10005987: push        es
  10005988: add         bl,byte ptr [edi]
  1000598A: adc         al,58h
  1000598C: sub         byte ptr [ebx],al
  1000598E: add         dword ptr [eax],eax
  10005990: push        es
  10005991: fcomp3      st(6)
  10005993: paddd       mm0,mmword ptr [esi]
  10005996: cmp         al,byte ptr [eax]
  10005998: add         byte ptr [esi],al
  1000599A: add         bl,byte ptr [edx]
  1000599C: pop         eax
  1000599D: sub         byte ptr [ebx],al
  1000599F: add         dword ptr [eax],eax
  100059A1: push        es
  100059A2: fadd        qword ptr [edx]
  100059A4: sub         al,byte ptr [eax]
  100059A6: add         byte ptr [eax],al
  100059A8: inc         ecx
  100059A9: jl          100059AB
  100059AB: add         byte ptr [eax+eax],al
  100059AE: add         byte ptr [eax],al
  100059B0: jo          100059B2
  100059B2: add         byte ptr [eax],al
  100059B4: dec         esp
  100059B5: add         byte ptr [eax],al
  100059B7: add         byte ptr [eax+eax+00100000h],bh
  100059BE: add         byte ptr [eax],al
  100059C0: cmp         al,byte ptr [eax]
  100059C2: add         byte ptr [ecx],al
  100059C4: add         al,0
  100059C6: add         byte ptr [eax],al
  100059C8: pop         esi
  100059C9: add         byte ptr [eax],al
  100059CB: add         byte ptr [eax],dh
  100059CE: add         byte ptr [eax],al
  100059D0: into
  100059D1: add         byte ptr [eax],al
  100059D3: add         byte ptr [eax],dl
  100059D5: add         byte ptr [eax],al
  100059D7: add         byte ptr [edx],bh
  100059D9: add         byte ptr [eax],al
  100059DB: add         dword ptr [eax+eax],eax
  100059DE: add         byte ptr [eax],al
  100059E0: dec         esp
  100059E1: add         byte ptr [eax],al
  100059E3: add         byte ptr [eax+eax+00E00000h],dl
  100059EA: add         byte ptr [eax],al
  100059EC: adc         byte ptr [eax],al
  100059EE: add         byte ptr [eax],al
  100059F0: cmp         al,byte ptr [eax]
  100059F2: add         byte ptr [ecx],al
  100059F4: add         al,0
  100059F6: add         byte ptr [eax],al
  100059F8: add         byte ptr ss:[eax],al
  100059FB: add         byte ptr [eax+eax+00F20000h],bh
  10005A02: add         byte ptr [eax],al
  10005A04: adc         byte ptr [eax],al
  10005A06: add         byte ptr [eax],al
  10005A08: cmp         al,byte ptr [eax]
  10005A0A: add         byte ptr [ecx],al
  10005A0C: add         al,0
  10005A0E: add         byte ptr [eax],al
  10005A10: sbb         al,0
  10005A12: add         byte ptr [eax],al
  10005A14: call        14005A19
  10005A19: add         dword ptr [eax],eax
  10005A1B: add         byte ptr [edi],cl
  10005A1D: add         byte ptr [eax],al
  10005A1F: add         byte ptr [edx],bh
  10005A21: add         byte ptr [eax],al
  10005A23: add         dword ptr [ebx],eax
  10005A25: xor         byte ptr [ebx],al
  10005A27: add         byte ptr [eax],bh
  10005A29: add         byte ptr [eax],al
  10005A2B: add         byte ptr [edi],ah
  10005A2E: add         byte ptr [ecx],dl
  10005A30: add         al,0Ah
  10005A32: add         ecx,dword ptr [ebx]
  10005A34: add         eax,dword ptr [edx]
  10005A36: add         eax,dword ptr cs:[ecx+ebx*2]
  10005A3B: or          al,7
  10005A3D: pop         ds
  10005A3E: sbb         byte ptr [ecx+0Bh],bl
  10005A41: push        es
  10005A42: pop         ds
  10005A43: sbb         byte ptr [ecx+0Ah],bl
  10005A46: push        es
  10005A47: pop         es
  10005A48: dec         edx
  10005A49: push        esp
  10005A4A: push        es
  10005A4B: sbb         bl,byte ptr [eax+6]
  10005A4E: or          byte ptr [eax+1Ah],bl
  10005A51: pop         eax
  10005A52: sub         byte ptr [edx],dh
  10005A54: add         byte ptr [eax],al
  10005A56: push        es
  10005A57: push        es
  10005A59: pop         ds
  10005A5A: adc         al,58h
  10005A5C: pop         es
  10005A5D: pop         ds
  10005A5E: adc         al,58h
  10005A60: inc         edi
  10005A61: push        edx
  10005A62: pop         es
  10005A63: add         dh,byte ptr [ebx]
  10005A65: D6
  10005A66: push        es
  10005A67: sub         al,byte ptr [ebx]
  10005A69: xor         byte ptr [edx],al
  10005A6B: add         byte ptr [ecx],dh
  10005A6D: add         byte ptr [eax],al
  10005A6F: add         byte ptr [eax],cl
  10005A71: add         dword ptr [eax],eax
  10005A73: adc         dword ptr [edx],eax
  10005A75: or          al,byte ptr [edx]
  10005A77: add         ebp,dword ptr [esi]
  10005A79: sub         al,byte ptr [edx+ebx]
  10005A7C: pop         eax
  10005A7D: or          eax,58141F04h
  10005A82: or          al,6
  10005A84: add         al,4Ah
  10005A86: push        esp
  10005A87: push        es
  10005A88: pop         ds
  10005A89: adc         al,58h
  10005A8B: or          eax,dword ptr [edi]
  10005A8D: pop         ds
  10005A8E: adc         byte ptr [ecx+9],bl
  10005A91: sub         byte ptr [edx],dh
  10005A93: add         byte ptr [eax],al
  10005A95: push        es
  10005A96: pop         es
  10005A98: or          byte ptr [edi+52h],al
  10005A9B: push        es
  10005A9C: pop         ds
  10005A9D: sbb         byte ptr [eax+0Ah],bl
  10005AA0: push        es
  10005AA1: add         esi,dword ptr [ebx]
  10005AA3: fild        qword ptr [edx]
  10005AA5: int         3
  10005AA6: int         3
  10005AA7: int         3
  10005AA8: add         esi,dword ptr [eax]
  10005AAA: add         eax,4D00h
  10005AAF: add         byte ptr [ecx],cl
  10005AB1: add         dword ptr [eax],eax
  10005AB3: adc         dword ptr [edx],eax
  10005AB5: or          eax,dword ptr [edx]
  10005AB7: inc         esi
  10005AB8: sub         al,8
  10005ABA: pop         es
  10005ABB: pop         ss
  10005ABC: pop         eax
  10005ABD: or          eax,dword ptr [edi]
  10005ABF: inc         esi
  10005AC0: sub         eax,590207F8h
  10005AC5: or          eax,3540903h
  10005ACA: sbb         bl,byte ptr [eax+0Ch]
  10005ACD: add         al,8
  10005ACF: pop         ss
  10005AD0: or          dword ptr [edi],edx
  10005AD2: pop         eax
  10005AD3: sub         byte ptr [esi],al
  10005AD5: add         byte ptr [eax],al
  10005AD7: push        es
  10005AD8: or          byte ptr es:[edx+0Ah],cl
  10005ADC: push        es
  10005ADD: add         al,byte ptr [esi+52h]
  10005AE0: add         dl,byte ptr [edi]
  10005AE2: pop         eax
  10005AE3: adc         byte ptr [eax],al
  10005AE5: push        es
  10005AE6: inc         esi
  10005AE7: adc         eax,dword ptr [esi+eax]
  10005AEA: pop         ss
  10005AEB: pop         eax
  10005AEC: or          dl,byte ptr [ecx]
  10005AEE: add         al,2Dh
  10005AF0: jmp         10005AF6
  10005AF2: sbb         bl,byte ptr [eax+1Ah]
  10005AF5: pop         eax
  10005AF6: add         al,1Ah
  10005AF8: pop         eax
  10005AF9: sbb         bl,byte ptr [eax+4Ah]
  10005AFC: pop         ds
  10005AFD: cld
  10005AFE: pop         eax
  10005AFF: push        esp
  10005B00: sub         cl,ah
  10005B02: int         3
  10005B03: int         3
  10005B04: or          esi,dword ptr [eax]
  10005B06: add         al,0
  10005B08: mov         es,word ptr [eax]
  10005B0A: add         byte ptr [eax],al
  10005B0C: or          al,byte ptr [ecx]
  10005B0E: add         byte ptr [ecx],dl
  10005B10: add         bh,byte ptr [ecx]
  10005B12: xchg        eax,dword ptr [eax]
  10005B14: add         byte ptr [eax],al
  10005B16: add         ah,byte ptr ds:[4A581E4Ah]
  10005B1C: sub         dword ptr [ecx],edi
  10005B1F: add         byte ptr [ecx],dl
  10005B21: or          al,byte ptr [ebx]
  10005B23: push        es
  10005B24: push        esp
  10005B25: push        es
  10005B26: sub         al,69h
  10005B28: add         al,3
  10005B2A: sbb         bl,byte ptr [eax+1Ah]
  10005B2D: push        es
  10005B2E: sub         byte ptr [esi],al
  10005B30: add         byte ptr [eax],al
  10005B32: push        es
  10005B33: push        ss
  10005B35: or          edx,dword ptr [esi]
  10005B37: push        es
  10005B38: xor         al,48h
  10005B3A: add         dl,byte ptr [edx]
  10005B3C: add         eax,dword ptr [edx]
  10005B3E: dec         edx
  10005B3F: sbb         bl,byte ptr [eax+4Ah]
  10005B42: sub         dword ptr [eax+eax],esi
  10005B46: adc         dword ptr [eax+ecx],ecx
  10005B49: dec         edx
  10005B4A: pop         es
  10005B4B: sbb         bl,byte ptr [edx+3]
  10005B4E: sbb         bl,byte ptr [eax+4Ah]
  10005B51: pop         eax
  10005B52: add         al,28h
  10005B54: lea         eax,[eax]
  10005B56: add         byte ptr [esi],al
  10005B58: fimul       word ptr [esi]
  10005B5A: inc         byte ptr [esi]
  10005B5C: xor         al,0
  10005B5E: add         byte ptr [esi],al
  10005B60: adc         al,byte ptr [ebx]
  10005B62: sub         byte ptr [ebx],al
  10005B64: add         dword ptr [eax],eax
  10005B66: push        es
  10005B67: fcom        qword ptr [edx]
  10005B69: add         ecx,dword ptr [edx+2Ch]
  10005B6C: or          eax,124A0312h
  10005B71: add         ecx,dword ptr [edx+4Ah]
  10005B74: dec         edx
  10005B75: sub         dword ptr [eax],edi
  10005B78: add         byte ptr [ecx],dl
  10005B7A: pop         es
  10005B7B: pop         ss
  10005B7C: pop         eax
  10005B7D: or          eax,dword ptr [edi]
  10005B7F: push        es
  10005B80: aaa
  10005B81: mov         eax,1A581A04h
  10005B86: pop         eax
  10005B87: add         al,1Ah
  10005B89: pop         eax
  10005B8A: sbb         bl,byte ptr [eax+4Ah]
  10005B8D: pop         ds
  10005B8E: cld
  10005B8F: pop         eax
  10005B90: push        esp
  10005B91: add         ah,byte ptr ds:[580C1F4Ah]
  10005B97: dec         edx
  10005B98: sub         dword ptr [eax],edi
  10005B9B: add         byte ptr [ecx],dl
  10005B9D: sub         al,byte ptr [eax]
  10005B9F: add         byte ptr [ecx+1Ch],al
  10005BA2: add         byte ptr [eax],al
  10005BA4: add         al,0
  10005BA6: add         byte ptr [eax],al
  10005BA8: cmp         byte ptr [eax],al
  10005BAA: add         byte ptr [eax],al
  10005BAC: adc         al,byte ptr [eax]
  10005BAE: add         byte ptr [eax],al
  10005BB0: dec         edx
  10005BB1: add         byte ptr [eax],al
  10005BB3: add         byte ptr [esi],cl
  10005BB5: add         byte ptr [eax],al
  10005BB7: add         byte ptr [edx],bh
  10005BB9: add         byte ptr [eax],al
  10005BBB: add         dword ptr [ebx],ecx
  10005BBD: xor         byte ptr [eax+eax],al
  10005BC0: mov         es,word ptr [eax]
  10005BC2: add         byte ptr [eax],al
  10005BC4: or          al,byte ptr [ecx]
  10005BC6: add         byte ptr [ecx],dl
  10005BC8: add         bh,byte ptr [ecx]
  10005BCA: xchg        eax,dword ptr [eax]
  10005BCC: add         byte ptr [eax],al
  10005BCE: add         ah,byte ptr ds:[4A581E4Ah]
  10005BD4: sub         dword ptr [ecx],edi
  10005BD7: add         byte ptr [ecx],dl
  10005BD9: or          al,byte ptr [ebx]
  10005BDB: push        es
  10005BDC: push        esp
  10005BDD: push        es
  10005BDE: sub         al,69h
  10005BE0: add         al,3
  10005BE2: sbb         bl,byte ptr [eax+1Eh]
  10005BE5: push        es
  10005BE6: sub         byte ptr [esi],al
  10005BE8: add         byte ptr [eax],al
  10005BEA: push        es
  10005BEB: push        ss
  10005BED: or          edx,dword ptr [esi]
  10005BEF: push        es
  10005BF0: xor         al,48h
  10005BF2: add         dl,byte ptr [edx]
  10005BF4: add         eax,dword ptr [edx]
  10005BF6: dec         edx
  10005BF7: sbb         bl,byte ptr [eax+4Ah]
  10005BFA: sub         dword ptr [eax+eax],esi
  10005BFE: adc         dword ptr [eax+ecx],ecx
  10005C01: dec         edx
  10005C02: pop         es
  10005C03: push        ds
  10005C04: pop         edx
  10005C05: add         ebx,dword ptr [edx]
  10005C07: pop         eax
  10005C08: dec         edx
  10005C09: pop         eax
  10005C0A: add         al,28h
  10005C0C: push        ebx
  10005C0D: add         byte ptr [eax],al
  10005C0F: push        es
  10005C10: fimul       word ptr [esi]
  10005C12: inc         byte ptr [esi]
  10005C14: xor         al,0
  10005C16: add         byte ptr [esi],al
  10005C18: adc         al,byte ptr [ebx]
  10005C1A: sub         byte ptr [ebx],al
  10005C1C: add         dword ptr [eax],eax
  10005C1E: push        es
  10005C1F: fcom        qword ptr [edx]
  10005C21: add         ecx,dword ptr [edx+2Ch]
  10005C24: or          eax,124A0312h
  10005C29: add         ecx,dword ptr [edx+4Ah]
  10005C2C: dec         edx
  10005C2D: sub         dword ptr [eax],edi
  10005C30: add         byte ptr [ecx],dl
  10005C32: pop         es
  10005C33: pop         ss
  10005C34: pop         eax
  10005C35: or          eax,dword ptr [edi]
  10005C37: push        es
  10005C38: aaa
  10005C39: mov         eax,1A581A04h
  10005C3E: pop         eax
  10005C3F: add         al,1Ah
  10005C41: pop         eax
  10005C42: sbb         bl,byte ptr [eax+4Ah]
  10005C45: pop         ds
  10005C46: cld
  10005C47: pop         eax
  10005C48: push        esp
  10005C49: add         ah,byte ptr ds:[580C1F4Ah]
  10005C4F: dec         edx
  10005C50: sub         dword ptr [eax],edi
  10005C53: add         byte ptr [ecx],dl
  10005C55: sub         al,byte ptr [eax]
  10005C57: add         byte ptr [ecx+1Ch],al
  10005C5A: add         byte ptr [eax],al
  10005C5C: add         al,0
  10005C5E: add         byte ptr [eax],al
  10005C60: cmp         byte ptr [eax],al
  10005C62: add         byte ptr [eax],al
  10005C64: adc         al,byte ptr [eax]
  10005C66: add         byte ptr [eax],al
  10005C68: dec         edx
  10005C69: add         byte ptr [eax],al
  10005C6B: add         byte ptr [esi],cl
  10005C6D: add         byte ptr [eax],al
  10005C6F: add         byte ptr [edx],bh
  10005C71: add         byte ptr [eax],al
  10005C73: add         dword ptr [ebx],ecx
  10005C75: xor         byte ptr ds:[0000C800h],al
  10005C7B: add         byte ptr [ebx],cl
  10005C7D: add         dword ptr [eax],eax
  10005C7F: adc         dword ptr [edx],eax
  10005C81: cmp         ecx,eax
  10005C83: add         byte ptr [eax],al
  10005C85: add         byte ptr [edx],al
  10005C87: and         eax,4A581E4Ah
  10005C8C: sub         dword ptr [ecx],edi
  10005C8F: add         byte ptr [ecx],dl
  10005C91: or          al,byte ptr [ebx]
  10005C93: push        es
  10005C94: push        esp
  10005C95: push        es
  10005C96: cmp         dword ptr [eax+04000000h],esp
  10005C9C: add         ebx,dword ptr [edx]
  10005C9E: pop         eax
  10005C9F: pop         ds
  10005CA0: adc         al,6
  10005CA2: sub         byte ptr [esi],al
  10005CA4: add         byte ptr [eax],al
  10005CA6: push        es
  10005CA7: push        ss
  10005CA9: push        es
  10005CAA: inc         ecx
  10005CAB: jge         10005CAD
  10005CAD: add         byte ptr [eax],al
  10005CAF: push        ss
  10005CB0: or          eax,12020C06h
  10005CB5: push        es
  10005CB6: add         cl,byte ptr [edx+1Ah]
  10005CB9: pop         eax
  10005CBA: dec         edx
  10005CBB: sub         dword ptr [eax+eax],esi
  10005CBF: adc         dword ptr [ebx],edx
  10005CC1: add         eax,0B4A0511h
  10005CC6: or          dword ptr [ebx],eax
  10005CC8: sbb         bl,byte ptr [eax+4Ah]
  10005CCB: pop         eax
  10005CCC: adc         eax,dword ptr [edi+eax]
  10005CCF: sub         eax,73ADE02h
  10005CD4: jg          10005D34
  10005CD6: add         byte ptr [eax],al
  10005CD8: add         al,7Fh
  10005CDA: pop         ebp
  10005CDB: add         byte ptr [eax],al
  10005CDD: add         al,7
  10005CDF: dec         edx
  10005CE0: pop         ds
  10005CE1: or          al,58h
  10005CE3: dec         edx
  10005CE4: sub         dword ptr [esi],esi
  10005CE7: add         byte ptr [ecx],dl
  10005CE9: adc         dword ptr [edi+ebx],eax
  10005CEC: adc         byte ptr [eax+4],bl
  10005CEF: sub         byte ptr [ebp],dh
  10005CF2: add         byte ptr [esi],al
  10005CF4: pop         es
  10005CF5: adc         dword ptr [esp+eax],eax
  10005CF8: sub         byte ptr [edx],al
  10005CFB: add         byte ptr [esi],al
  10005CFD: fimul       word ptr [esi]
  10005CFF: inc         byte ptr [esi]
  10005D01: xor         al,0
  10005D03: add         byte ptr [esi],al
  10005D05: adc         al,byte ptr [esi]
  10005D07: sub         byte ptr [ebx],al
  10005D09: add         dword ptr [eax],eax
  10005D0B: push        es
  10005D0C: fcom        qword ptr [edx]
  10005D0E: push        es
  10005D0F: dec         edx
  10005D10: sub         al,0Dh
  10005D12: adc         al,byte ptr [esi]
  10005D14: dec         edx
  10005D15: adc         al,byte ptr [esi]
  10005D17: dec         edx
  10005D18: dec         edx
  10005D19: dec         edx
  10005D1A: sub         dword ptr [eax],edi
  10005D1D: add         byte ptr [ecx],dl
  10005D1F: or          dword ptr [edi],ebx
  10005D21: adc         al,58h
  10005D23: or          eax,0C591708h
  10005D28: or          byte ptr [esi],dl
  10005D2A: xor         eax,581A0487h
  10005D2F: sbb         bl,byte ptr [eax+4]
  10005D32: sbb         bl,byte ptr [eax+1Ah]
  10005D35: pop         eax
  10005D36: dec         edx
  10005D37: pop         ds
  10005D38: cld
  10005D39: pop         eax
  10005D3A: push        esp
  10005D3B: add         ah,byte ptr ds:[580C1F4Ah]
  10005D41: dec         edx
  10005D42: sub         dword ptr [eax],edi
  10005D45: add         byte ptr [ecx],dl
  10005D47: sub         al,byte ptr [ecx+1Ch]
  10005D4A: add         byte ptr [eax],al
  10005D4C: add         al,0
  10005D4E: add         byte ptr [eax],al
  10005D50: inc         edx
  10005D51: add         byte ptr [eax],al
  10005D53: add         byte ptr ds:[7F000000h],bh
  10005D59: add         byte ptr [eax],al
  10005D5B: add         byte ptr [esi],cl
  10005D5D: add         byte ptr [eax],al
  10005D5F: add         byte ptr [edx],bh
  10005D61: add         byte ptr [eax],al
  10005D63: add         dword ptr [ebx],ecx
  10005D65: xor         byte ptr [eax+eax],al
  10005D68: xchg        eax,esp
  10005D69: add         byte ptr [eax],al
  10005D6B: add         byte ptr [ecx+eax],cl
  10005D6E: add         byte ptr [ecx],dl
  10005D70: add         bh,byte ptr [ecx]
  10005D72: lea         eax,[eax]
  10005D74: add         byte ptr [eax],al
  10005D76: add         ah,byte ptr ds:[4A581E4Ah]
  10005D7C: sub         dword ptr [ecx],edi
  10005D7F: add         byte ptr [ecx],dl
  10005D81: or          al,byte ptr [ebx]
  10005D83: push        es
  10005D84: push        esp
  10005D85: push        es
  10005D86: sub         al,6Fh
  10005D88: add         al,3
  10005D8A: sbb         bl,byte ptr [eax+1Fh]
  10005D8D: or          al,6
  10005D8F: sub         byte ptr [esi],al
  10005D91: add         byte ptr [eax],al
  10005D93: push        es
  10005D94: push        ss
  10005D96: push        es
  10005D97: xor         al,4Fh
  10005D99: push        ss
  10005D9A: or          al,6
  10005D9C: or          eax,dword ptr [edx]
  10005D9E: adc         al,byte ptr [edx+eax]
  10005DA1: dec         edx
  10005DA2: sbb         bl,byte ptr [eax+4Ah]
  10005DA5: sub         dword ptr [eax+eax],esi
  10005DA9: adc         dword ptr ds:[03084A09h],ecx
  10005DAF: sbb         bl,byte ptr [eax+4Ah]
  10005DB2: pop         eax
  10005DB3: add         al,28h
  10005DB5: aas
  10005DB6: add         byte ptr [eax],al
  10005DB8: push        es
  10005DB9: fimul       word ptr [esi]
  10005DBB: inc         byte ptr [esi]
  10005DBD: xor         al,0
  10005DBF: add         byte ptr [esi],al
  10005DC1: adc         al,byte ptr [eax+ebp]
  10005DC4: add         eax,dword ptr [ecx]
  10005DC6: add         byte ptr [esi],al
  10005DC8: fcom        qword ptr [edx]
  10005DCA: add         al,4Ah
  10005DCC: sub         al,0Dh
  10005DCE: adc         al,byte ptr [edx+ecx*2]
  10005DD1: adc         al,byte ptr [edx+ecx*2]
  10005DD4: dec         edx
  10005DD5: dec         edx
  10005DD6: sub         dword ptr [eax],edi
  10005DD9: add         byte ptr [ecx],dl
  10005DDB: or          byte ptr [edi],bl
  10005DDD: or          al,58h
  10005DDF: or          al,7
  10005DE1: pop         ss
  10005DE2: pop         ecx
  10005DE3: or          eax,dword ptr [edi]
  10005DE5: push        ss
  10005DE6: xor         eax,581A04B5h
  10005DEB: sbb         bl,byte ptr [eax+4]
  10005DEE: sbb         bl,byte ptr [eax+1Ah]
  10005DF1: pop         eax
  10005DF2: dec         edx
  10005DF3: pop         ds
  10005DF4: cld
  10005DF5: pop         eax
  10005DF6: push        esp
  10005DF7: add         ah,byte ptr ds:[580C1F4Ah]
  10005DFD: dec         edx
  10005DFE: sub         dword ptr [eax],edi
  10005E01: add         byte ptr [ecx],dl
  10005E03: sub         al,byte ptr [ecx+1Ch]
  10005E06: add         byte ptr [eax],al
  10005E08: add         al,0
  10005E0A: add         byte ptr [eax],al
  10005E0C: cmp         eax,dword ptr [eax]
  10005E0E: add         byte ptr [eax],al
  10005E10: adc         byte ptr [eax],al
  10005E12: add         byte ptr [eax],al
  10005E14: dec         ebx
  10005E15: add         byte ptr [eax],al
  10005E17: add         byte ptr [esi],cl
  10005E19: add         byte ptr [eax],al
  10005E1B: add         byte ptr [edx],bh
  10005E1D: add         byte ptr [eax],al
  10005E1F: add         dword ptr [ebx],ecx
  10005E21: xor         byte ptr [eax+eax],al
  10005E24: xchg        eax,esp
  10005E25: add         byte ptr [eax],al
  10005E27: add         byte ptr [ecx+eax],cl
  10005E2A: add         byte ptr [ecx],dl
  10005E2C: add         bh,byte ptr [ecx]
  10005E2E: lea         eax,[eax]
  10005E30: add         byte ptr [eax],al
  10005E32: add         ah,byte ptr ds:[4A581E4Ah]
  10005E38: sub         dword ptr [ecx],edi
  10005E3B: add         byte ptr [ecx],dl
  10005E3D: or          al,byte ptr [ebx]
  10005E3F: push        es
  10005E40: push        esp
  10005E41: push        es
  10005E42: sub         al,6Fh
  10005E44: add         al,3
  10005E46: sbb         bl,byte ptr [eax+1Fh]
  10005E49: adc         byte ptr [esi],al
  10005E4B: sub         byte ptr [esi],al
  10005E4D: add         byte ptr [eax],al
  10005E4F: push        es
  10005E50: push        ss
  10005E52: push        es
  10005E53: xor         al,4Fh
  10005E55: push        ss
  10005E56: or          al,6
  10005E58: or          eax,dword ptr [edx]
  10005E5A: adc         al,byte ptr [edx+eax]
  10005E5D: dec         edx
  10005E5E: sbb         bl,byte ptr [eax+4Ah]
  10005E61: sub         dword ptr [eax+eax],esi
  10005E65: adc         dword ptr ds:[03084A09h],ecx
  10005E6B: sbb         bl,byte ptr [eax+4Ah]
  10005E6E: pop         eax
  10005E6F: add         al,28h
  10005E71: cmp         al,0
  10005E73: add         byte ptr [esi],al
  10005E75: fimul       word ptr [esi]
  10005E77: inc         byte ptr [esi]
  10005E79: xor         al,0
  10005E7B: add         byte ptr [esi],al
  10005E7D: adc         al,byte ptr [eax+ebp]
  10005E80: add         eax,dword ptr [ecx]
  10005E82: add         byte ptr [esi],al
  10005E84: fcom        qword ptr [edx]
  10005E86: add         al,4Ah
  10005E88: sub         al,0Dh
  10005E8A: adc         al,byte ptr [edx+ecx*2]
  10005E8D: adc         al,byte ptr [edx+ecx*2]
  10005E90: dec         edx
  10005E91: dec         edx
  10005E92: sub         dword ptr [eax],edi
  10005E95: add         byte ptr [ecx],dl
  10005E97: or          byte ptr [edi],bl
  10005E99: adc         byte ptr [eax+0Ch],bl
  10005E9C: pop         es
  10005E9D: pop         ss
  10005E9E: pop         ecx
  10005E9F: or          eax,dword ptr [edi]
  10005EA1: push        ss
  10005EA2: xor         eax,581A04B5h
  10005EA7: sbb         bl,byte ptr [eax+4]
  10005EAA: sbb         bl,byte ptr [eax+1Ah]
  10005EAD: pop         eax
  10005EAE: dec         edx
  10005EAF: pop         ds
  10005EB0: cld
  10005EB1: pop         eax
  10005EB2: push        esp
  10005EB3: add         ah,byte ptr ds:[580C1F4Ah]
  10005EB9: dec         edx
  10005EBA: sub         dword ptr [eax],edi
  10005EBD: add         byte ptr [ecx],dl
  10005EBF: sub         al,byte ptr [ecx+1Ch]
  10005EC2: add         byte ptr [eax],al
  10005EC4: add         al,0
  10005EC6: add         byte ptr [eax],al
  10005EC8: cmp         eax,dword ptr [eax]
  10005ECA: add         byte ptr [eax],al
  10005ECC: adc         byte ptr [eax],al
  10005ECE: add         byte ptr [eax],al
  10005ED0: dec         ebx
  10005ED1: add         byte ptr [eax],al
  10005ED3: add         byte ptr [esi],cl
  10005ED5: add         byte ptr [eax],al
  10005ED7: add         byte ptr [edx],bh
  10005ED9: add         byte ptr [eax],al
  10005EDB: add         dword ptr [ebx],ecx
  10005EDD: xor         byte ptr [eax+eax],al
  10005EE0: mov         es,word ptr [eax]
  10005EE2: add         byte ptr [eax],al
  10005EE4: or          al,byte ptr [ecx]
  10005EE6: add         byte ptr [ecx],dl
  10005EE8: add         bh,byte ptr [ecx]
  10005EEA: xchg        eax,dword ptr [eax]
  10005EEC: add         byte ptr [eax],al
  10005EEE: add         ah,byte ptr ds:[4A581E4Ah]
  10005EF4: sub         dword ptr [ecx],edi
  10005EF7: add         byte ptr [ecx],dl
  10005EF9: or          al,byte ptr [ebx]
  10005EFB: push        es
  10005EFC: push        esp
  10005EFD: push        es
  10005EFE: sub         al,69h
  10005F00: add         al,3
  10005F02: sbb         bl,byte ptr [eax+1Eh]
  10005F05: push        es
  10005F06: sub         byte ptr [esi],al
  10005F08: add         byte ptr [eax],al
  10005F0A: push        es
  10005F0B: push        ss
  10005F0D: or          edx,dword ptr [esi]
  10005F0F: push        es
  10005F10: xor         al,48h
  10005F12: add         dl,byte ptr [edx]
  10005F14: add         eax,dword ptr [edx]
  10005F16: dec         edx
  10005F17: sbb         bl,byte ptr [eax+4Ah]
  10005F1A: sub         dword ptr [eax+eax],esi
  10005F1E: adc         dword ptr [eax+ecx],ecx
  10005F21: dec         edx
  10005F22: pop         es
  10005F23: push        ds
  10005F24: pop         edx
  10005F25: add         ebx,dword ptr [edx]
  10005F27: pop         eax
  10005F28: dec         edx
  10005F29: pop         eax
  10005F2A: add         al,28h
  10005F2C: inc         ecx
  10005F2D: add         byte ptr [eax],al
  10005F2F: push        es
  10005F30: fimul       word ptr [esi]
  10005F32: inc         byte ptr [esi]
  10005F34: xor         al,0
  10005F36: add         byte ptr [esi],al
  10005F38: adc         al,byte ptr [ebx]
  10005F3A: sub         byte ptr [ebx],al
  10005F3C: add         dword ptr [eax],eax
  10005F3E: push        es
  10005F3F: fcom        qword ptr [edx]
  10005F41: add         ecx,dword ptr [edx+2Ch]
  10005F44: or          eax,124A0312h
  10005F49: add         ecx,dword ptr [edx+4Ah]
  10005F4C: dec         edx
  10005F4D: sub         dword ptr [eax],edi
  10005F50: add         byte ptr [ecx],dl
  10005F52: pop         es
  10005F53: pop         ss
  10005F54: pop         eax
  10005F55: or          eax,dword ptr [edi]
  10005F57: push        es
  10005F58: aaa
  10005F59: mov         eax,1A581A04h
  10005F5E: pop         eax
  10005F5F: add         al,1Ah
  10005F61: pop         eax
  10005F62: sbb         bl,byte ptr [eax+4Ah]
  10005F65: pop         ds
  10005F66: cld
  10005F67: pop         eax
  10005F68: push        esp
  10005F69: add         ah,byte ptr ds:[580C1F4Ah]
  10005F6F: dec         edx
  10005F70: sub         dword ptr [eax],edi
  10005F73: add         byte ptr [ecx],dl
  10005F75: sub         al,byte ptr [eax]
  10005F77: add         byte ptr [ecx+1Ch],al
  10005F7A: add         byte ptr [eax],al
  10005F7C: add         al,0
  10005F7E: add         byte ptr [eax],al
  10005F80: cmp         byte ptr [eax],al
  10005F82: add         byte ptr [eax],al
  10005F84: adc         al,byte ptr [eax]
  10005F86: add         byte ptr [eax],al
  10005F88: dec         edx
  10005F89: add         byte ptr [eax],al
  10005F8B: add         byte ptr [esi],cl
  10005F8D: add         byte ptr [eax],al
  10005F8F: add         byte ptr [edx],bh
  10005F91: add         byte ptr [eax],al
  10005F93: add         dword ptr [ebx],ecx
  10005F95: xor         byte ptr [eax+eax],al
  10005F98: mov         es,word ptr [eax]
  10005F9A: add         byte ptr [eax],al
  10005F9C: or          al,byte ptr [ecx]
  10005F9E: add         byte ptr [ecx],dl
  10005FA0: add         bh,byte ptr [ecx]
  10005FA2: xchg        eax,dword ptr [eax]
  10005FA4: add         byte ptr [eax],al
  10005FA6: add         ah,byte ptr ds:[4A581E4Ah]
  10005FAC: sub         dword ptr [ecx],edi
  10005FAF: add         byte ptr [ecx],dl
  10005FB1: or          al,byte ptr [ebx]
  10005FB3: push        es
  10005FB4: push        esp
  10005FB5: push        es
  10005FB6: sub         al,69h
  10005FB8: add         al,3
  10005FBA: sbb         bl,byte ptr [eax+1Eh]
  10005FBD: push        es
  10005FBE: sub         byte ptr [esi],al
  10005FC0: add         byte ptr [eax],al
  10005FC2: push        es
  10005FC3: push        ss
  10005FC5: or          edx,dword ptr [esi]
  10005FC7: push        es
  10005FC8: xor         al,48h
  10005FCA: add         dl,byte ptr [edx]
  10005FCC: add         eax,dword ptr [edx]
  10005FCE: dec         edx
  10005FCF: sbb         bl,byte ptr [eax+4Ah]
  10005FD2: sub         dword ptr [eax+eax],esi
  10005FD6: adc         dword ptr [eax+ecx],ecx
  10005FD9: dec         edx
  10005FDA: pop         es
  10005FDB: push        ds
  10005FDC: pop         edx
  10005FDD: add         ebx,dword ptr [edx]
  10005FDF: pop         eax
  10005FE0: dec         edx
  10005FE1: pop         eax
  10005FE2: add         al,28h
  10005FE4: cmp         eax,0DE060000h
  10005FE9: push        cs
  10005FEA: inc         byte ptr [esi]
  10005FEC: xor         al,0
  10005FEE: add         byte ptr [esi],al
  10005FF0: adc         al,byte ptr [ebx]
  10005FF2: sub         byte ptr [ebx],al
  10005FF4: add         dword ptr [eax],eax
  10005FF6: push        es
  10005FF7: fcom        qword ptr [edx]
  10005FF9: add         ecx,dword ptr [edx+2Ch]
  10005FFC: or          eax,124A0312h
  10006001: add         ecx,dword ptr [edx+4Ah]
  10006004: dec         edx
  10006005: sub         dword ptr [eax],edi
  10006008: add         byte ptr [ecx],dl
  1000600A: pop         es
  1000600B: pop         ss
  1000600C: pop         eax
  1000600D: or          eax,dword ptr [edi]
  1000600F: push        es
  10006010: aaa
  10006011: mov         eax,1A581A04h
  10006016: pop         eax
  10006017: add         al,1Ah
  10006019: pop         eax
  1000601A: sbb         bl,byte ptr [eax+4Ah]
  1000601D: pop         ds
  1000601E: cld
  1000601F: pop         eax
  10006020: push        esp
  10006021: add         ah,byte ptr ds:[580C1F4Ah]
  10006027: dec         edx
  10006028: sub         dword ptr [eax],edi
  1000602B: add         byte ptr [ecx],dl
  1000602D: sub         al,byte ptr [eax]
  1000602F: add         byte ptr [ecx+1Ch],al
  10006032: add         byte ptr [eax],al
  10006034: add         al,0
  10006036: add         byte ptr [eax],al
  10006038: cmp         byte ptr [eax],al
  1000603A: add         byte ptr [eax],al
  1000603C: adc         al,byte ptr [eax]
  1000603E: add         byte ptr [eax],al
  10006040: dec         edx
  10006041: add         byte ptr [eax],al
  10006043: add         byte ptr [esi],cl
  10006045: add         byte ptr [eax],al
  10006047: add         byte ptr [edx],bh
  10006049: add         byte ptr [eax],al
  1000604B: add         dword ptr [ebx],eax
  1000604D: xor         byte ptr [eax+eax],al
  10006050: add         byte ptr es:[eax],al
  10006053: add         byte ptr [esi],cl
  10006055: add         dword ptr [eax],eax
  10006057: adc         dword ptr [ebx+eax],eax
  1000605A: pop         ds
  1000605B: adc         byte ptr [edi],dl
  1000605D: sub         byte ptr [esi],al
  1000605F: add         byte ptr [eax],al
  10006061: push        es
  10006062: or          al,byte ptr [edx]
  10006064: push        es
  10006065: add         al,28h
  10006067: dec         esp
  10006068: add         byte ptr [eax],al
  1000606A: push        es
  1000606B: add         al,1Ah
  1000606D: pop         eax
  1000606E: sbb         bl,byte ptr [eax+4]
  10006071: sbb         bl,byte ptr [eax+1Ah]
  10006074: pop         eax
  10006075: dec         edx
  10006076: pop         ds
  10006077: cld
  10006078: pop         eax
  10006079: push        esp
  1000607A: push        es
  1000607B: push        ss
  1000607C: push        esp
  1000607D: sub         cl,ah
  1000607F: int         3
  10006080: or          esi,dword ptr [eax]
  10006082: add         al,0
  10006084: retf
  10006085: add         byte ptr [eax],al
  10006087: add         byte ptr [edi],cl
  10006089: add         dword ptr [eax],eax
  1000608B: adc         dword ptr [edx],eax
  1000608D: cmp         esp,eax
  1000608F: add         byte ptr [eax],al
  10006091: add         byte ptr [edx],al
  10006093: and         eax,4A581E4Ah
  10006098: sub         dword ptr [ecx],edi
  1000609B: add         byte ptr [ecx],dl
  1000609D: or          al,byte ptr [ebx]
  1000609F: push        es
  100060A0: push        esp
  100060A1: push        es
  100060A2: cmp         dword ptr [ebx+04000000h],esp
  100060A8: add         ebx,dword ptr [edx]
  100060AA: pop         eax
  100060AB: sbb         al,byte ptr [esi]
  100060AD: sub         byte ptr [esi],al
  100060AF: add         byte ptr [eax],al
  100060B1: push        es
  100060B2: push        ss
  100060B4: or          edx,dword ptr [esi]
  100060B6: push        es
  100060B7: inc         ecx
  100060B8: jg          100060BA
  100060BA: add         byte ptr [eax],al
  100060BC: add         dl,byte ptr [edx]
  100060BE: pop         es
  100060BF: add         cl,byte ptr [edx+1Ah]
  100060C2: pop         eax
  100060C3: dec         edx
  100060C4: sub         dword ptr [eax+eax],esi
  100060C8: adc         dword ptr [ebx],edx
  100060CA: push        es
  100060CB: adc         dword ptr [esi],eax
  100060CD: dec         edx
  100060CE: or          eax,35A1A07h
  100060D3: sbb         bl,byte ptr [eax+4Ah]
  100060D6: pop         eax
  100060D7: adc         eax,dword ptr ds:[DE022D09h]
  100060DD: inc         ebx
  100060DE: or          dword ptr ds:[58101F4Ah],esp
  100060E4: dec         edx
  100060E5: sub         dword ptr [edx],edi
  100060E8: add         byte ptr [ecx],dl
  100060EA: or          al,8
  100060EC: sub         eax,831DE02h
  100060F1: and         eax,75294A4Ah
  100060F6: add         byte ptr [eax],al
  100060F8: adc         dword ptr [ebx],edx
  100060FA: add         al,11h
  100060FC: add         eax,22280411h
  10006101: add         dword ptr [eax],eax
  10006103: push        es
  10006104: imul        edx,dword ptr [esi+8],25h
  10006108: dec         edx
  10006109: sbb         bl,byte ptr [eax+4Ah]
  1000610C: sub         dword ptr [eax],edi
  1000610F: add         byte ptr [ecx],dl
  10006111: fimul       word ptr [esi]
  10006113: inc         byte ptr [esi]
  10006115: xor         al,0
  10006117: add         byte ptr [esi],al
  10006119: adc         al,byte ptr [edi]
  1000611B: sub         byte ptr [ebx],al
  1000611D: add         dword ptr [eax],eax
  1000611F: push        es
  10006120: fcom        qword ptr [edx]
  10006122: pop         es
  10006123: dec         edx
  10006124: sub         al,0Dh
  10006126: adc         al,byte ptr [edi]
  10006128: dec         edx
  10006129: adc         al,byte ptr [edi]
  1000612B: dec         edx
  1000612C: dec         edx
  1000612D: dec         edx
  1000612E: sub         dword ptr [eax],edi
  10006131: add         byte ptr [ecx],dl
  10006133: pop         es
  10006134: pop         ss
  10006135: pop         eax
  10006136: or          eax,dword ptr [edi]
  10006138: push        es
  10006139: aaa
  1000613A: add         dword ptr [edx+ebx],4581A58h
  10006141: sbb         bl,byte ptr [eax+1Ah]
  10006144: pop         eax
  10006145: dec         edx
  10006146: pop         ds
  10006147: cld
  10006148: pop         eax
  10006149: push        esp
  1000614A: add         ah,byte ptr ds:[580C1F4Ah]
  10006150: dec         edx
  10006151: sub         dword ptr [eax],edi
  10006154: add         byte ptr [ecx],dl
  10006156: sub         al,byte ptr [eax]
  10006158: inc         ecx
  10006159: sbb         al,0
  1000615B: add         byte ptr [eax+eax],al
  1000615E: add         byte ptr [eax],al
  10006160: aas
  10006161: add         byte ptr [eax],al
  10006163: add         byte ptr [eax],cl
  10006166: add         byte ptr [eax],al
  10006168: xchg        eax,dword ptr [eax]
  1000616A: add         byte ptr [eax],al
  1000616C: push        cs
  1000616D: add         byte ptr [eax],al
  1000616F: add         byte ptr [edx],bh
  10006171: add         byte ptr [eax],al
  10006173: add         dword ptr [ebx],eax
  10006175: xor         byte ptr ds:[00003700h],al
  1000617B: add         byte ptr [eax],dl
  1000617D: add         dword ptr [eax],eax
  1000617F: adc         dword ptr [edx],eax
  10006181: sub         al,33h
  10006183: add         bh,byte ptr [edi+3Fh]
  10006186: add         byte ptr [eax],al
  10006188: add         al,16h
  1000618A: add         cl,byte ptr [edx+1Fh]
  1000618D: or          al,58h
  1000618F: dec         edx
  10006190: sub         dword ptr [esi],esi
  10006193: add         byte ptr [ecx],dl
  10006195: or          al,byte ptr [esi]
  10006197: sub         al,1Dh
  10006199: push        es
  1000619A: and         eax,75294A4Ah
  1000619F: add         byte ptr [eax],al
  100061A1: adc         dword ptr [ebx],eax
  100061A3: sbb         bl,byte ptr [eax+4]
  100061A6: sub         byte ptr [ebx],ah
  100061A9: add         byte ptr [esi],al
  100061AB: push        es
  100061AC: and         eax,4A581A4Ah
  100061B1: sub         dword ptr [eax],edi
  100061B4: add         byte ptr [ecx],dl
  100061B6: sub         cl,ah
  100061B8: or          esi,dword ptr [eax]
  100061BA: push        es
  100061BB: add         byte ptr [eax],ah
  100061BE: add         byte ptr [eax],al
  100061C0: adc         dword ptr [ecx],eax
  100061C2: add         byte ptr [ecx],dl
  100061C4: add         ch,byte ptr [esp+ebx*2]
  100061C7: add         dl,byte ptr [edx]
  100061C9: add         bh,byte ptr [edi+44h]
  100061CC: add         byte ptr [eax],al
  100061CE: add         al,16h
  100061D0: add         cl,byte ptr [edx+1Eh]
  100061D3: pop         eax
  100061D4: dec         edx
  100061D5: sub         dword ptr [ebx],esi
  100061D8: add         byte ptr [ecx],dl
  100061DA: or          eax,dword ptr [edi]
  100061DC: dec         edx
  100061DD: or          al,byte ptr [esi]
  100061DF: sub         eax,626DE02h
  100061E4: and         eax,58101F4Ah
  100061E9: dec         edx
  100061EA: sub         dword ptr [edx],edi
  100061ED: add         byte ptr [ecx],dl
  100061EF: add         ebx,dword ptr [edi]
  100061F1: or          al,58h
  100061F3: add         al,28h
  100061F5: jne         100061F7
  100061F7: add         byte ptr [esi],al
  100061F9: fimul       word ptr [esi]
  100061FB: inc         byte ptr [esi]
  100061FD: xor         al,0
  100061FF: add         byte ptr [esi],al
  10006201: adc         al,byte ptr [edx]
  10006203: sub         byte ptr [ebx],al
  10006205: add         dword ptr [eax],eax
  10006207: push        es
  10006208: fcom        qword ptr [edx]
  1000620A: add         cl,byte ptr [edx+2Ch]
  1000620D: or          eax,124A0212h
  10006212: add         cl,byte ptr [edx+4Ah]
  10006215: dec         edx
  10006216: sub         dword ptr [eax],edi
  10006219: add         byte ptr [ecx],dl
  1000621B: add         al,byte ptr [ebx]
  1000621D: add         al,28h
  1000621F: add         byte ptr ds:[eax],al
  10006222: push        es
  10006223: sub         al,byte ptr [ecx+1Ch]
  10006226: add         byte ptr [eax],al
  10006228: add         al,0
  1000622A: add         byte ptr [eax],al
  1000622C: pop         ss
  1000622D: add         byte ptr [eax],al
  1000622F: add         byte ptr [eax],ah
  10006231: add         byte ptr [eax],al
  10006233: add         byte ptr [edi],dh
  10006235: add         byte ptr [eax],al
  10006237: add         byte ptr [esi],cl
  10006239: add         byte ptr [eax],al
  1000623B: add         byte ptr [edx],bh
  1000623D: add         byte ptr [eax],al
  1000623F: add         dword ptr [ebx],ecx
  10006241: xor         byte ptr [esi],al
  10006243: add         byte ptr [edx+1],bl
  10006246: add         byte ptr [eax],al
  10006248: adc         al,byte ptr [ecx]
  1000624A: add         byte ptr [ecx],dl
  1000624C: add         bh,byte ptr [ecx]
  1000624E: push        ebx
  1000624F: add         dword ptr [eax],eax
  10006251: add         byte ptr [edx],al
  10006253: adc         cl,byte ptr [ebx]
  10006255: jg          100062A1
  10006257: add         byte ptr [eax],al
  10006259: add         al,16h
  1000625B: add         cl,byte ptr [edx+1Eh]
  1000625E: pop         eax
  1000625F: dec         edx
  10006260: sub         dword ptr [ebx],esi
  10006263: add         byte ptr [ecx],dl
  10006265: adc         eax,dword ptr [edi]
  10006267: adc         dword ptr [edi],eax
  10006269: dec         edx
  1000626A: add         eax,dword ptr [eax+ebp]
  1000626D: aas
  1000626E: add         byte ptr [eax],al
  10006270: push        es
  10006271: fimul       word ptr [esi]
  10006273: inc         byte ptr [esi]
  10006275: xor         al,0
  10006277: add         byte ptr [esi],al
  10006279: adc         cl,byte ptr [ebx]
  1000627B: sub         byte ptr [ebx],al
  1000627D: add         dword ptr [eax],eax
  1000627F: push        es
  10006280: fcom        qword ptr [edx]
  10006282: or          ecx,dword ptr [edx+2Ch]
  10006285: or          eax,124A0B12h
  1000628A: or          ecx,dword ptr [edx+4Ah]
  1000628D: dec         edx
  1000628E: sub         dword ptr [eax],edi
  10006291: add         byte ptr [ecx],dl
  10006293: add         dl,byte ptr [edx]
  10006295: or          bh,byte ptr [edi+4Bh]
  10006298: add         byte ptr [eax],al
  1000629A: add         al,16h
  1000629C: add         cl,byte ptr [edx+1Eh]
  1000629F: pop         eax
  100062A0: dec         edx
  100062A1: sub         dword ptr [ebx],esi
  100062A4: add         byte ptr [ecx],dl
  100062A6: adc         eax,dword ptr [esi]
  100062A8: adc         dword ptr [esi],eax
  100062AA: dec         edx
  100062AB: add         ebx,dword ptr [edi]
  100062AD: or          al,58h
  100062AF: add         al,28h
  100062B1: aas
  100062B2: add         byte ptr [eax],al
  100062B4: push        es
  100062B5: fimul       word ptr [esi]
  100062B7: inc         byte ptr [esi]
  100062B9: xor         al,0
  100062BB: add         byte ptr [esi],al
  100062BD: adc         cl,byte ptr [edx]
  100062BF: sub         byte ptr [ebx],al
  100062C1: add         dword ptr [eax],eax
  100062C3: push        es
  100062C4: fcom        qword ptr [edx]
  100062C6: or          cl,byte ptr [edx+2Ch]
  100062C9: or          eax,124A0A12h
  100062CE: or          cl,byte ptr [edx+4Ah]
  100062D1: dec         edx
  100062D2: sub         dword ptr [eax],edi
  100062D5: add         byte ptr [ecx],dl
  100062D7: add         dl,byte ptr [edx]
  100062D9: or          dword ptr [edi+4Ch],edi
  100062DC: add         byte ptr [eax],al
  100062DE: add         al,16h
  100062E0: add         cl,byte ptr [edx+1Eh]
  100062E3: pop         eax
  100062E4: dec         edx
  100062E5: sub         dword ptr [ebx],esi
  100062E8: add         byte ptr [ecx],dl
  100062EA: adc         eax,dword ptr ds:[0D4A0511h]
  100062F0: add         ebx,dword ptr [edi]
  100062F2: sbb         byte ptr [eax+0Ch],bl
  100062F5: or          dword ptr ds:[0432DE02h],ebp
  100062FB: or          byte ptr [esi],bl
  100062FD: pop         ss
  100062FE: sub         byte ptr [esi],al
  10006300: add         byte ptr [eax],al
  10006302: push        es
  10006303: or          dword ptr es:[eax],ecx
  10006306: dec         edx
  10006307: add         al,28h
  10006309: inc         esp
  1000630A: add         byte ptr [eax],al
  1000630C: push        es
  1000630D: add         al,1Ah
  1000630F: pop         eax
  10006310: sbb         bl,byte ptr [eax+4]
  10006313: sbb         bl,byte ptr [eax+1Ah]
  10006316: pop         eax
  10006317: dec         edx
  10006318: pop         ds
  10006319: cld
  1000631A: pop         eax
  1000631B: push        esp
  1000631C: fimul       word ptr [esi]
  1000631E: inc         byte ptr [esi]
  10006320: xor         al,0
  10006322: add         byte ptr [esi],al
  10006324: adc         cl,byte ptr [ecx]
  10006326: sub         byte ptr [ebx],al
  10006328: add         dword ptr [eax],eax
  1000632A: push        es
  1000632B: fcom        qword ptr [edx]
  1000632D: or          dword ptr [edx+2Ch],ecx
  10006330: or          eax,124A0912h
  10006335: or          dword ptr [edx+4Ah],ecx
  10006338: dec         edx
  10006339: sub         dword ptr [eax],edi
  1000633C: add         byte ptr [ecx],dl
  1000633E: add         dl,byte ptr [edx]
  10006340: or          byte ptr [edi+4Dh],bh
  10006343: add         byte ptr [eax],al
  10006345: add         al,16h
  10006347: add         cl,byte ptr [edx+1Eh]
  1000634A: pop         eax
  1000634B: dec         edx
  1000634C: sub         dword ptr [ebx],esi
  1000634F: add         byte ptr [ecx],dl
  10006351: adc         eax,dword ptr [ecx+edx]
  10006354: add         al,4Ah
  10006356: or          eax,dword ptr [ebx]
  10006358: pop         ds
  10006359: sbb         al,58h
  1000635B: or          al,byte ptr [edi]
  1000635D: sub         eax,432DE02h
  10006362: push        es
  10006363: push        ds
  10006364: pop         ss
  10006365: sub         byte ptr [esi],al
  10006367: add         byte ptr [eax],al
  10006369: push        es
  1000636A: pop         es
  1000636C: push        es
  1000636D: dec         edx
  1000636E: add         al,28h
  10006370: inc         ebp
  10006371: add         byte ptr [eax],al
  10006373: push        es
  10006374: add         al,1Ah
  10006376: pop         eax
  10006377: sbb         bl,byte ptr [eax+4]
  1000637A: sbb         bl,byte ptr [eax+1Ah]
  1000637D: pop         eax
  1000637E: dec         edx
  1000637F: pop         ds
  10006380: cld
  10006381: pop         eax
  10006382: push        esp
  10006383: fimul       word ptr [esi]
  10006385: inc         byte ptr [esi]
  10006387: xor         al,0
  10006389: add         byte ptr [esi],al
  1000638B: adc         cl,byte ptr [eax]
  1000638D: sub         byte ptr [ebx],al
  1000638F: add         dword ptr [eax],eax
  10006391: push        es
  10006392: fcom        qword ptr [edx]
  10006394: or          byte ptr [edx+2Ch],cl
  10006397: or          eax,124A0812h
  1000639C: or          byte ptr [edx+4Ah],cl
  1000639F: dec         edx
  100063A0: sub         dword ptr [eax],edi
  100063A3: add         byte ptr [ecx],dl
  100063A5: sub         al,byte ptr [eax]
  100063A7: add         byte ptr [ecx+64h],al
  100063AA: add         byte ptr [eax],al
  100063AC: add         al,0
  100063AE: add         byte ptr [eax],al
  100063B0: sbb         eax,dword ptr [eax]
  100063B2: add         byte ptr [eax],al
  100063B4: or          al,0
  100063B6: add         byte ptr [eax],al
  100063B8: daa
  100063B9: add         byte ptr [eax],al
  100063BB: add         byte ptr [esi],cl
  100063BD: add         byte ptr [eax],al
  100063BF: add         byte ptr [edx],bh
  100063C1: add         byte ptr [eax],al
  100063C3: add         dword ptr [eax+eax],eax
  100063C6: add         byte ptr [eax],al
  100063C8: pop         esp
  100063C9: add         byte ptr [eax],al
  100063CB: add         byte ptr [edi],cl
  100063CD: add         byte ptr [eax],al
  100063CF: add         byte ptr [ebx],ch
  100063D2: add         byte ptr [eax],al
  100063D4: push        cs
  100063D5: add         byte ptr [eax],al
  100063D7: add         byte ptr [edx],bh
  100063D9: add         byte ptr [eax],al
  100063DB: add         dword ptr [eax+eax],eax
  100063DE: add         byte ptr [eax],al
  100063E0: mov         al,byte ptr ds:[32000000h]
  100063E5: add         byte ptr [eax],al
  100063E7: add         dl,dl
  100063E9: add         byte ptr [eax],al
  100063EB: add         byte ptr [esi],cl
  100063ED: add         byte ptr [eax],al
  100063EF: add         byte ptr [edx],bh
  100063F1: add         byte ptr [eax],al
  100063F3: add         dword ptr [eax+eax],eax
  100063F6: add         byte ptr [eax],al
  100063F8: pop         es
  100063F9: add         dword ptr [eax],eax
  100063FB: add         byte ptr [edx],dh
  100063FD: add         byte ptr [eax],al
  100063FF: add         byte ptr [ecx],bh
  10006401: add         dword ptr [eax],eax
  10006403: add         byte ptr [esi],cl
  10006405: add         byte ptr [eax],al
  10006407: add         byte ptr [edx],bh
  10006409: add         byte ptr [eax],al
  1000640B: add         dword ptr [ebx],ecx
  1000640D: xor         byte ptr [esi],al
  1000640F: add         dl,dl
  10006411: add         byte ptr [eax],al
  10006413: add         byte ptr [ebx],dl
  10006415: add         dword ptr [eax],eax
  10006417: adc         dword ptr [edx],eax
  10006419: cmp         ebx,ecx
  1000641B: add         byte ptr [eax],al
  1000641D: add         byte ptr [edx],al
  1000641F: jg          1000647B
  10006421: add         byte ptr [eax],al
  10006423: add         al,2
  10006425: dec         edx
  10006426: sbb         bl,byte ptr [eax+4Ah]
  10006429: sub         dword ptr [ebx],edi
  1000642C: add         byte ptr [ecx],dl
  1000642E: add         eax,dword ptr [eax+ebp]
  10006431: add         byte ptr [eax],al
  10006434: push        es
  10006435: add         dl,byte ptr [edx]
  10006437: push        es
  10006438: jg          10006495
  1000643A: add         byte ptr [eax],al
  1000643C: add         al,16h
  1000643E: add         cl,byte ptr [edx+1Eh]
  10006441: pop         eax
  10006442: dec         edx
  10006443: sub         dword ptr [ebx],esi
  10006446: add         byte ptr [ecx],dl
  10006448: adc         eax,dword ptr [ecx+edx]
  1000644B: add         al,4Ah
  1000644D: add         ebx,dword ptr [esi]
  1000644F: pop         eax
  10006450: add         al,28h
  10006452: aas
  10006453: add         byte ptr [eax],al
  10006455: push        es
  10006456: fimul       word ptr [esi]
  10006458: inc         byte ptr [esi]
  1000645A: xor         al,0
  1000645C: add         byte ptr [esi],al
  1000645E: adc         al,byte ptr [esi]
  10006460: sub         byte ptr [ebx],al
  10006462: add         dword ptr [eax],eax
  10006464: push        es
  10006465: fcom        qword ptr [edx]
  10006467: push        es
  10006468: dec         edx
  10006469: sub         al,0Dh
  1000646B: adc         al,byte ptr [esi]
  1000646D: dec         edx
  1000646E: adc         al,byte ptr [esi]
  10006470: dec         edx
  10006471: dec         edx
  10006472: dec         edx
  10006473: sub         dword ptr [eax],edi
  10006476: add         byte ptr [ecx],dl
  10006478: add         dl,byte ptr [edx]
  1000647A: add         eax,5C7Fh
  1000647F: add         al,16h
  10006481: add         cl,byte ptr [edx+1Eh]
  10006484: pop         eax
  10006485: dec         edx
  10006486: sub         dword ptr [ebx],esi
  10006489: add         byte ptr [ecx],dl
  1000648B: or          eax,70B4A09h
  10006490: sub         eax,743DE02h
  10006495: and         eax,58101F4Ah
  1000649A: dec         edx
  1000649B: sub         dword ptr [edx],edi
  1000649E: add         byte ptr [ecx],dl
  100064A0: or          al,byte ptr [esi]
  100064A2: sub         eax,631DE02h
  100064A7: and         eax,75294A4Ah
  100064AC: add         byte ptr [eax],al
  100064AE: adc         dword ptr [ebx+eax],ecx
  100064B1: pop         ds
  100064B2: adc         al,58h
  100064B4: or          byte ptr [eax],ch
  100064B6: and         al,byte ptr [ecx]
  100064B8: add         byte ptr [esi],al
  100064BA: imul        edx,dword ptr [esi+6],25h
  100064BE: dec         edx
  100064BF: sbb         bl,byte ptr [eax+4Ah]
  100064C2: sub         dword ptr [eax],edi
  100064C5: add         byte ptr [ecx],dl
  100064C7: fimul       word ptr [esi]
  100064C9: inc         byte ptr [esi]
  100064CB: xor         al,0
  100064CD: add         byte ptr [esi],al
  100064CF: adc         al,byte ptr ds:[00010328h]
  100064D5: push        es
  100064D6: fcom        qword ptr [edx]
  100064D8: add         eax,120D2C4Ah
  100064DD: add         eax,4A05124Ah
  100064E2: dec         edx
  100064E3: dec         edx
  100064E4: sub         dword ptr [eax],edi
  100064E7: add         byte ptr [ecx],dl
  100064E9: sub         al,byte ptr [eax]
  100064EB: add         byte ptr [ecx+34h],al
  100064EE: add         byte ptr [eax],al
  100064F0: add         al,0
  100064F2: add         byte ptr [eax],al
  100064F4: xor         al,byte ptr [eax]
  100064F6: add         byte ptr [eax],al
  100064F8: push        cs
  100064F9: add         byte ptr [eax],al
  100064FB: add         byte ptr [eax],al
  100064FE: add         byte ptr [eax],al
  10006500: push        cs
  10006501: add         byte ptr [eax],al
  10006503: add         byte ptr [edx],bh
  10006505: add         byte ptr [eax],al
  10006507: add         dword ptr [eax+eax],eax
  1000650A: add         byte ptr [eax],al
  1000650C: je          1000650E
  1000650E: add         byte ptr [eax],al
  10006510: cmp         eax,0B1000000h
  10006515: add         byte ptr [eax],al
  10006517: add         byte ptr [esi],cl
  10006519: add         byte ptr [eax],al
  1000651B: add         byte ptr [edx],bh
  1000651D: add         byte ptr [eax],al
  1000651F: add         dword ptr [ebx],ecx
  10006521: xor         byte ptr [esi],al
  10006523: add         byte ptr [esi],cl
  10006526: add         byte ptr [eax],al
  10006528: adc         al,1
  1000652A: add         byte ptr [ecx],dl
  1000652C: add         ch,byte ptr [edx+ecx*2]
  1000652F: add         dl,byte ptr [edx]
  10006531: add         dword ptr [edi+44h],edi
  10006534: add         byte ptr [eax],al
  10006536: add         al,16h
  10006538: add         cl,byte ptr [edx+1Eh]
  1000653B: pop         eax
  1000653C: dec         edx
  1000653D: sub         dword ptr [ebx],esi
  10006540: add         byte ptr [ecx],dl
  10006542: or          al,byte ptr [esi]
  10006544: dec         edx
  10006545: add         ebx,dword ptr [edi]
  10006547: or          al,58h
  10006549: add         al,28h
  1000654B: je          1000654D
  1000654D: add         byte ptr [esi],al
  1000654F: fimul       word ptr [esi]
  10006551: inc         byte ptr [esi]
  10006553: xor         al,0
  10006555: add         byte ptr [esi],al
  10006557: adc         al,byte ptr [ecx]
  10006559: sub         byte ptr [ebx],al
  1000655B: add         dword ptr [eax],eax
  1000655D: push        es
  1000655E: fcom        qword ptr [edx]
  10006560: add         dword ptr [edx+2Ch],ecx
  10006563: or          eax,124A0112h
  10006568: add         dword ptr [edx+4Ah],ecx
  1000656B: dec         edx
  1000656C: sub         dword ptr [eax],edi
  1000656F: add         byte ptr [ecx],dl
  10006571: add         al,byte ptr [ebx]
  10006573: add         al,28h
  10006575: add         byte ptr ds:[eax],al
  10006578: push        es
  10006579: sub         al,byte ptr [eax]
  1000657B: add         byte ptr [ecx+1Ch],al
  1000657E: add         byte ptr [eax],al
  10006580: add         al,0
  10006582: add         byte ptr [eax],al
  10006584: pop         ss
  10006585: add         byte ptr [eax],al
  10006587: add         byte ptr [esi],cl
  10006589: add         byte ptr [eax],al
  1000658B: add         byte ptr ds:[0E000000h],ah
  10006591: add         byte ptr [eax],al
  10006593: add         byte ptr [edx],bh
  10006595: add         byte ptr [eax],al
  10006597: add         dword ptr [ebx],ecx
  10006599: xor         byte ptr [esi],al
  1000659B: add         byte ptr [eax],ah
  1000659E: add         byte ptr [eax],al
  100065A0: adc         dword ptr [ecx],eax
  100065A2: add         byte ptr [ecx],dl
  100065A4: add         ch,byte ptr [esp+ebx*2]
  100065A7: add         dl,byte ptr [edx]
  100065A9: add         bh,byte ptr [edi+44h]
  100065AC: add         byte ptr [eax],al
  100065AE: add         al,16h
  100065B0: add         cl,byte ptr [edx+1Eh]
  100065B3: pop         eax
  100065B4: dec         edx
  100065B5: sub         dword ptr [ebx],esi
  100065B8: add         byte ptr [ecx],dl
  100065BA: or          eax,dword ptr [edi]
  100065BC: dec         edx
  100065BD: or          al,byte ptr [esi]
  100065BF: sub         eax,626DE02h
  100065C4: and         eax,58101F4Ah
  100065C9: dec         edx
  100065CA: sub         dword ptr [edx],edi
  100065CD: add         byte ptr [ecx],dl
  100065CF: add         ebx,dword ptr [edi]
  100065D1: or          al,58h
  100065D3: add         al,28h
  100065D5: add         byte ptr gs:[eax],al
  100065D8: push        es
  100065D9: fimul       word ptr [esi]
  100065DB: inc         byte ptr [esi]
  100065DD: xor         al,0
  100065DF: add         byte ptr [esi],al
  100065E1: adc         al,byte ptr [edx]
  100065E3: sub         byte ptr [ebx],al
  100065E5: add         dword ptr [eax],eax
  100065E7: push        es
  100065E8: fcom        qword ptr [edx]
  100065EA: add         cl,byte ptr [edx+2Ch]
  100065ED: or          eax,124A0212h
  100065F2: add         cl,byte ptr [edx+4Ah]
  100065F5: dec         edx
  100065F6: sub         dword ptr [eax],edi
  100065F9: add         byte ptr [ecx],dl
  100065FB: add         al,byte ptr [ebx]
  100065FD: add         al,28h
  100065FF: add         byte ptr ds:[eax],al
  10006602: push        es
  10006603: sub         al,byte ptr [ecx+1Ch]
  10006606: add         byte ptr [eax],al
  10006608: add         al,0
  1000660A: add         byte ptr [eax],al
  1000660C: pop         ss
  1000660D: add         byte ptr [eax],al
  1000660F: add         byte ptr [eax],ah
  10006611: add         byte ptr [eax],al
  10006613: add         byte ptr [edi],dh
  10006615: add         byte ptr [eax],al
  10006617: add         byte ptr [esi],cl
  10006619: add         byte ptr [eax],al
  1000661B: add         byte ptr [edx],bh
  1000661D: add         byte ptr [eax],al
  1000661F: add         dword ptr [ebx],ecx
  10006621: xor         byte ptr [eax+eax],al
  10006624: xchg        eax,esp
  10006625: add         byte ptr [eax],al
  10006627: add         byte ptr [ecx+eax],cl
  1000662A: add         byte ptr [ecx],dl
  1000662C: add         bh,byte ptr [ecx]
  1000662E: lea         eax,[eax]
  10006630: add         byte ptr [eax],al
  10006632: add         ah,byte ptr ds:[4A581E4Ah]
  10006638: sub         dword ptr [ecx],edi
  1000663B: add         byte ptr [ecx],dl
  1000663D: or          al,byte ptr [ebx]
  1000663F: push        es
  10006640: push        esp
  10006641: push        es
  10006642: sub         al,6Fh
  10006644: add         al,3
  10006646: sbb         bl,byte ptr [eax+1Fh]
  10006649: and         byte ptr [esi],al
  1000664B: sub         byte ptr [esi],al
  1000664D: add         byte ptr [eax],al
  1000664F: push        es
  10006650: push        ss
  10006652: push        es
  10006653: xor         al,4Fh
  10006655: push        ss
  10006656: or          al,6
  10006658: or          eax,dword ptr [edx]
  1000665A: adc         al,byte ptr [edx+eax]
  1000665D: dec         edx
  1000665E: sbb         bl,byte ptr [eax+4Ah]
  10006661: sub         dword ptr [eax+eax],esi
  10006665: adc         dword ptr ds:[03084A09h],ecx
  1000666B: sbb         bl,byte ptr [eax+4Ah]
  1000666E: pop         eax
  1000666F: add         al,28h
  10006671: inc         esi
  10006672: add         byte ptr [eax],al
  10006674: push        es
  10006675: fimul       word ptr [esi]
  10006677: inc         byte ptr [esi]
  10006679: xor         al,0
  1000667B: add         byte ptr [esi],al
  1000667D: adc         al,byte ptr [eax+ebp]
  10006680: add         eax,dword ptr [ecx]
  10006682: add         byte ptr [esi],al
  10006684: fcom        qword ptr [edx]
  10006686: add         al,4Ah
  10006688: sub         al,0Dh
  1000668A: adc         al,byte ptr [edx+ecx*2]
  1000668D: adc         al,byte ptr [edx+ecx*2]
  10006690: dec         edx
  10006691: dec         edx
  10006692: sub         dword ptr [eax],edi
  10006695: add         byte ptr [ecx],dl
  10006697: or          byte ptr [edi],bl
  10006699: and         byte ptr [eax+0Ch],bl
  1000669C: pop         es
  1000669D: pop         ss
  1000669E: pop         ecx
  1000669F: or          eax,dword ptr [edi]
  100066A1: push        ss
  100066A2: xor         eax,581A04B5h
  100066A7: sbb         bl,byte ptr [eax+4]
  100066AA: sbb         bl,byte ptr [eax+1Ah]
  100066AD: pop         eax
  100066AE: dec         edx
  100066AF: pop         ds
  100066B0: cld
  100066B1: pop         eax
  100066B2: push        esp
  100066B3: add         ah,byte ptr ds:[580C1F4Ah]
  100066B9: dec         edx
  100066BA: sub         dword ptr [eax],edi
  100066BD: add         byte ptr [ecx],dl
  100066BF: sub         al,byte ptr [ecx+1Ch]
  100066C2: add         byte ptr [eax],al
  100066C4: add         al,0
  100066C6: add         byte ptr [eax],al
  100066C8: cmp         eax,dword ptr [eax]
  100066CA: add         byte ptr [eax],al
  100066CC: adc         byte ptr [eax],al
  100066CE: add         byte ptr [eax],al
  100066D0: dec         ebx
  100066D1: add         byte ptr [eax],al
  100066D3: add         byte ptr [esi],cl
  100066D5: add         byte ptr [eax],al
  100066D7: add         byte ptr [edx],bh
  100066D9: add         byte ptr [eax],al
  100066DB: add         dword ptr [ebx],eax
  100066DD: xor         byte ptr [eax+eax],al
  100066E0: sub         al,byte ptr [eax]
  100066E2: add         byte ptr [eax],al
  100066E4: adc         eax,4110001h
  100066E9: add         ebx,dword ptr [edi]
  100066EB: adc         byte ptr [edi],dl
  100066ED: sub         byte ptr [esi],al
  100066EF: add         byte ptr [eax],al
  100066F1: push        es
  100066F2: or          al,byte ptr [edx]
  100066F4: push        es
  100066F5: add         al,28h
  100066F7: inc         ebx
  100066F8: add         byte ptr [eax],al
  100066FA: push        es
  100066FB: add         al,1Ah
  100066FD: pop         eax
  100066FE: sbb         bl,byte ptr [eax+4]
  10006701: sbb         bl,byte ptr [eax+1Ah]
  10006704: pop         eax
  10006705: dec         edx
  10006706: pop         ds
  10006707: cld
  10006708: pop         eax
  10006709: push        esp
  1000670A: push        es
  1000670B: and         byte ptr ds:[54A3F84Ch],bh
  10006711: sub         cl,ah
  10006713: int         3
  10006714: add         esi,dword ptr [eax]
  10006716: add         al,0
  10006718: sub         al,byte ptr [eax]
  1000671A: add         byte ptr [eax],al
  1000671C: push        ss
  1000671D: add         dword ptr [eax],eax
  1000671F: adc         dword ptr [ebx+eax],eax
  10006722: pop         ds
  10006723: adc         byte ptr [edi],dl
  10006725: sub         byte ptr [esi],al
  10006727: add         byte ptr [eax],al
  10006729: push        es
  1000672A: or          al,byte ptr [edx]
  1000672C: push        es
  1000672D: add         al,28h
  1000672F: push        esp
  10006730: add         byte ptr [eax],al
  10006732: push        es
  10006733: add         al,1Ah
  10006735: pop         eax
  10006736: sbb         bl,byte ptr [eax+4]
  10006739: sbb         bl,byte ptr [eax+1Ah]
  1000673C: pop         eax
  1000673D: dec         edx
  1000673E: pop         ds
  1000673F: cld
  10006740: pop         eax
  10006741: push        esp
  10006742: push        es
  10006743: and         byte ptr [esi+54A59096h],ah
  10006749: sub         cl,ah
  1000674B: int         3
  1000674C: add         esi,dword ptr [eax]
  1000674E: add         al,0
  10006750: sub         al,byte ptr [eax]
  10006752: add         byte ptr [eax],al
  10006754: sbb         byte ptr [ecx],al
  10006756: add         byte ptr [ecx],dl
  10006758: add         al,3
  1000675A: pop         ds
  1000675B: adc         byte ptr [edi],dl
  1000675D: sub         byte ptr [esi],al
  1000675F: add         byte ptr [eax],al
  10006761: push        es
  10006762: or          al,byte ptr [edx]
  10006764: push        es
  10006765: add         al,28h
  10006767: push        ecx
  10006768: add         byte ptr [eax],al
  1000676A: push        es
  1000676B: add         al,1Ah
  1000676D: pop         eax
  1000676E: sbb         bl,byte ptr [eax+4]
  10006771: sbb         bl,byte ptr [eax+1Ah]
  10006774: pop         eax
  10006775: dec         edx
  10006776: pop         ds
  10006777: cld
  10006778: pop         eax
  10006779: push        esp
  1000677A: push        es
  1000677B: and         byte ptr [edx+54891819h],al
  10006781: sub         cl,ah
  10006783: int         3
  10006784: add         esi,dword ptr [eax]
  10006786: add         eax,5400h
  1000678B: add         byte ptr [edx],bl
  1000678D: add         dword ptr [eax],eax
  1000678F: adc         dword ptr [ebx+eax],eax
  10006792: pop         ds
  10006793: or          al,17h
  10006795: sub         byte ptr [esi],al
  10006797: add         byte ptr [eax],al
  10006799: push        es
  1000679A: or          eax,dword ptr [edx]
  1000679C: sub         al,33h
  1000679E: add         bh,byte ptr [edi+3Fh]
  100067A1: add         byte ptr [eax],al
  100067A3: add         al,16h
  100067A5: add         cl,byte ptr [edx+1Fh]
  100067A8: or          al,58h
  100067AA: dec         edx
  100067AB: sub         dword ptr [esi],esi
  100067AE: add         byte ptr [ecx],dl
  100067B0: or          al,byte ptr [esi]
  100067B2: sub         al,1Dh
  100067B4: push        es
  100067B5: and         eax,75294A4Ah
  100067BA: add         byte ptr [eax],al
  100067BC: adc         dword ptr [edi],eax
  100067BE: sbb         bl,byte ptr [eax+4]
  100067C1: sub         byte ptr [ebx],ah
  100067C4: add         byte ptr [esi],al
  100067C6: push        es
  100067C7: and         eax,4A581A4Ah
  100067CC: sub         dword ptr [eax],edi
  100067CF: add         byte ptr [ecx],dl
  100067D1: add         al,1Ah
  100067D3: pop         eax
  100067D4: sbb         bl,byte ptr [eax+4]
  100067D7: sbb         bl,byte ptr [eax+1Ah]
  100067DA: pop         eax
  100067DB: dec         edx
  100067DC: pop         ds
  100067DD: cld
  100067DE: pop         eax
  100067DF: push        esp
  100067E0: pop         es
  100067E1: push        ss
  100067E2: push        esp
  100067E3: sub         al,byte ptr [ebx]
  100067E5: xor         byte ptr [eax+eax],al
  100067E8: aaa
  100067E9: add         byte ptr [eax],al
  100067EB: add         byte ptr [ebx],bl
  100067ED: add         dword ptr [eax],eax
  100067EF: adc         dword ptr [edx],eax
  100067F1: sub         al,33h
  100067F3: add         al,3
  100067F5: push        ds
  100067F6: pop         ss
  100067F7: sub         byte ptr [esi],al
  100067F9: add         byte ptr [eax],al
  100067FB: push        es
  100067FC: add         ecx,dword ptr es:[edx+0Ah]
  10006800: add         bh,byte ptr [edi+39h]
  10006803: add         byte ptr [eax],al
  10006805: add         al,2
  10006807: dec         edx
  10006808: sbb         bl,byte ptr [eax+4Ah]
  1000680B: sub         dword ptr [ebx],edi
  1000680E: add         byte ptr [ecx],dl
  10006810: push        es
  10006811: add         al,28h
  10006813: jns         10006815
  10006815: add         byte ptr [esi],al
  10006817: add         al,1Ah
  10006819: pop         eax
  1000681A: sbb         bl,byte ptr [eax+4]
  1000681D: sbb         bl,byte ptr [eax+1Ah]
  10006820: pop         eax
  10006821: dec         edx
  10006822: pop         ds
  10006823: cld
  10006824: pop         eax
  10006825: push        esp
  10006826: sub         cl,ah
  10006828: add         esi,dword ptr [eax]
  1000682A: add         al,0
  1000682C: aaa
  1000682D: add         byte ptr [eax],al
  1000682F: add         byte ptr [ecx+eax],bl
  10006832: add         byte ptr [ecx],dl
  10006834: add         ch,byte ptr [ebx+esi]
  10006837: add         al,3
  10006839: push        ds
  1000683A: pop         ss
  1000683B: sub         byte ptr [esi],al
  1000683D: add         byte ptr [eax],al
  1000683F: push        es
  10006840: add         ecx,dword ptr es:[edx+0Ah]
  10006844: add         bh,byte ptr [edi+62h]
  10006847: add         byte ptr [eax],al
  10006849: add         al,2
  1000684B: dec         edx
  1000684C: sbb         bl,byte ptr [eax+4Ah]
  1000684F: sub         dword ptr [ebx],edi
  10006852: add         byte ptr [ecx],dl
  10006854: push        es
  10006855: add         al,28h
  10006857: jp          10006859
  10006859: add         byte ptr [esi],al
  1000685B: add         al,1Ah
  1000685D: pop         eax
  1000685E: sbb         bl,byte ptr [eax+4]
  10006861: sbb         bl,byte ptr [eax+1Ah]
  10006864: pop         eax
  10006865: dec         edx
  10006866: pop         ds
  10006867: cld
  10006868: pop         eax
  10006869: push        esp
  1000686A: sub         cl,ah
  1000686C: or          esi,dword ptr [eax]
  1000686E: add         al,0
  10006870: stos        dword ptr es:[edi]
  10006871: add         byte ptr [eax],al
  10006873: add         byte ptr ds:[02110001h],bl
  10006879: cmp         dword ptr [eax+eax+25020000h],esp
  10006880: dec         edx
  10006881: push        ds
  10006882: pop         eax
  10006883: dec         edx
  10006884: sub         dword ptr [ecx],edi
  10006887: add         byte ptr [ecx],dl
  10006889: or          al,byte ptr [ebx]
  1000688B: push        es
  1000688C: push        esp
  1000688D: push        es
  1000688E: cmp         dword ptr [ebx+04000000h],eax
  10006894: add         ebx,dword ptr [edx]
  10006896: pop         eax
  10006897: push        ds
  10006898: push        es
  10006899: sub         byte ptr [esi],al
  1000689B: add         byte ptr [eax],al
  1000689D: push        es
  1000689E: push        ss
  100068A0: or          edx,dword ptr [esi]
  100068A2: push        es
  100068A3: xor         al,62h
  100068A5: add         dl,byte ptr [edx]
  100068A7: add         eax,581A4A02h
  100068AC: dec         edx
  100068AD: sub         dword ptr [eax+eax],esi
  100068B1: adc         dword ptr [ebx],edx
  100068B3: add         al,11h
  100068B5: add         al,4Ah
  100068B7: or          al,7
  100068B9: push        ds
  100068BA: pop         edx
  100068BB: add         ebx,dword ptr [edx]
  100068BD: pop         eax
  100068BE: dec         edx
  100068BF: pop         eax
  100068C0: or          eax,0DE022D08h
  100068C5: daa
  100068C6: or          byte ptr [edi+61h],bh
  100068C9: add         byte ptr [eax],al
  100068CB: add         al,8
  100068CD: dec         edx
  100068CE: sbb         bl,byte ptr [eax+4Ah]
  100068D1: sub         dword ptr [ebx],edi
  100068D4: add         byte ptr [ecx],dl
  100068D6: or          dword ptr [eax+ebp],eax
  100068D9: jnp         100068DB
  100068DB: add         byte ptr [esi],al
  100068DD: fimul       word ptr [esi]
  100068DF: inc         byte ptr [esi]
  100068E1: xor         al,0
  100068E3: add         byte ptr [esi],al
  100068E5: adc         al,byte ptr ds:[00010328h]
  100068EB: push        es
  100068EC: fcom        qword ptr [edx]
  100068EE: add         eax,120D2C4Ah
  100068F3: add         eax,4A05124Ah
  100068F8: dec         edx
  100068F9: dec         edx
  100068FA: sub         dword ptr [eax],edi
  100068FD: add         byte ptr [ecx],dl
  100068FF: pop         es
  10006900: pop         ss
  10006901: pop         eax
  10006902: or          eax,dword ptr [edi]
  10006904: push        es
  10006905: aaa
  10006906: sahf
  10006907: add         al,1Ah
  10006909: pop         eax
  1000690A: sbb         bl,byte ptr [eax+4]
  1000690D: sbb         bl,byte ptr [eax+1Ah]
  10006910: pop         eax
  10006911: dec         edx
  10006912: pop         ds
  10006913: cld
  10006914: pop         eax
  10006915: push        esp
  10006916: add         ah,byte ptr ds:[580C1F4Ah]
  1000691C: dec         edx
  1000691D: sub         dword ptr [eax],edi
  10006920: add         byte ptr [ecx],dl
  10006922: sub         al,byte ptr [eax]
  10006924: inc         ecx
  10006925: sbb         al,0
  10006927: add         byte ptr [eax+eax],al
  1000692A: add         byte ptr [eax],al
  1000692C: cmp         al,0
  1000692E: add         byte ptr [eax],al
  10006930: sub         eax,dword ptr [eax]
  10006932: add         byte ptr [eax],al
  10006934: add         byte ptr [bx+si],al
  10006937: add         byte ptr [esi],cl
  10006939: add         byte ptr [eax],al
  1000693B: add         byte ptr [edx],bh
  1000693D: add         byte ptr [eax],al
  1000693F: add         dword ptr [ebx],eax
  10006941: xor         byte ptr [eax+eax],al
  10006944: inc         edi
  10006945: add         byte ptr [eax],al
  10006947: add         dh,bl
  10006949: add         byte ptr [eax],al
  1000694B: adc         dword ptr [ebx+eax],eax
  1000694E: pop         ds
  1000694F: sbb         byte ptr [edi],dl
  10006951: sub         byte ptr [esi],al
  10006953: add         byte ptr [eax],al
  10006955: push        es
  10006956: or          al,byte ptr [edx]
  10006958: sub         al,22h
  1000695A: add         bh,byte ptr [edi+5Fh]
  1000695D: add         byte ptr [eax],al
  1000695F: add         al,2
  10006961: dec         edx
  10006962: sbb         bl,byte ptr [eax+4Ah]
  10006965: sub         dword ptr [ebx],edi
  10006968: add         byte ptr [ecx],dl
  1000696A: push        es
  1000696B: pop         ds
  1000696C: adc         byte ptr [eax+4],bl
  1000696F: sub         byte ptr [esi],dh
  10006972: add         byte ptr [esi],al
  10006974: add         al,byte ptr [esi]
  10006976: add         al,28h
  10006978: dec         esp
  10006979: add         byte ptr [eax],al
  1000697B: push        es
  1000697C: add         al,1Ah
  1000697E: pop         eax
  1000697F: sbb         bl,byte ptr [eax+4]
  10006982: sbb         bl,byte ptr [eax+1Ah]
  10006985: pop         eax
  10006986: dec         edx
  10006987: pop         ds
  10006988: cld
  10006989: pop         eax
  1000698A: push        esp
  1000698B: push        es
  1000698C: and         ch,dh
  1000698E: mov         ss,dx
  10006990: push        eax
  10006991: push        esp
  10006992: sub         cl,ah
  10006994: add         esi,dword ptr [eax]
  10006996: add         al,0
  10006998: inc         edi
  10006999: add         byte ptr [eax],al
  1000699B: add         al,ah
  1000699D: add         byte ptr [eax],al
  1000699F: adc         dword ptr [ebx+eax],eax
  100069A2: pop         ds
  100069A3: sbb         byte ptr [edi],dl
  100069A5: sub         byte ptr [esi],al
  100069A7: add         byte ptr [eax],al
  100069A9: push        es
  100069AA: or          al,byte ptr [edx]
  100069AC: sub         al,22h
  100069AE: add         bh,byte ptr [edi+5Fh]
  100069B1: add         byte ptr [eax],al
  100069B3: add         al,2
  100069B5: dec         edx
  100069B6: sbb         bl,byte ptr [eax+4Ah]
  100069B9: sub         dword ptr [ebx],edi
  100069BC: add         byte ptr [ecx],dl
  100069BE: push        es
  100069BF: pop         ds
  100069C0: adc         byte ptr [eax+4],bl
  100069C3: sub         byte ptr [edi],dh
  100069C6: add         byte ptr [esi],al
  100069C8: add         al,byte ptr [esi]
  100069CA: add         al,28h
  100069CC: dec         esp
  100069CD: add         byte ptr [eax],al
  100069CF: push        es
  100069D0: add         al,1Ah
  100069D2: pop         eax
  100069D3: sbb         bl,byte ptr [eax+4]
  100069D6: sbb         bl,byte ptr [eax+1Ah]
  100069D9: pop         eax
  100069DA: dec         edx
  100069DB: pop         ds
  100069DC: cld
  100069DD: pop         eax
  100069DE: push        esp
  100069DF: push        es
  100069E0: and         byte ptr [eax],ah
  100069E2: fld         qword ptr [edx-0Ah]
  100069E5: push        esp
  100069E6: sub         cl,ah
  100069E8: or          esi,dword ptr [eax]
  100069EA: add         al,0
  100069EC: xchg        eax,esp
  100069ED: add         byte ptr [eax],al
  100069EF: add         byte ptr [ecx+eax],cl
  100069F2: add         byte ptr [ecx],dl
  100069F4: add         bh,byte ptr [ecx]
  100069F6: lea         eax,[eax]
  100069F8: add         byte ptr [eax],al
  100069FA: add         ah,byte ptr ds:[4A581E4Ah]
  10006A00: sub         dword ptr [ecx],edi
  10006A03: add         byte ptr [ecx],dl
  10006A05: or          al,byte ptr [ebx]
  10006A07: push        es
  10006A08: push        esp
  10006A09: push        es
  10006A0A: sub         al,6Fh
  10006A0C: add         al,3
  10006A0E: sbb         bl,byte ptr [eax+1Fh]
  10006A11: sbb         byte ptr [esi],al
  10006A13: sub         byte ptr [esi],al
  10006A15: add         byte ptr [eax],al
  10006A17: push        es
  10006A18: push        ss
  10006A1A: push        es
  10006A1B: xor         al,4Fh
  10006A1D: push        ss
  10006A1E: or          al,6
  10006A20: or          eax,dword ptr [edx]
  10006A22: adc         al,byte ptr [edx+eax]
  10006A25: dec         edx
  10006A26: sbb         bl,byte ptr [eax+4Ah]
  10006A29: sub         dword ptr [eax+eax],esi
  10006A2D: adc         dword ptr ds:[03084A09h],ecx
  10006A33: sbb         bl,byte ptr [eax+4Ah]
  10006A36: pop         eax
  10006A37: add         al,28h
  10006A39: dec         edi
  10006A3A: add         byte ptr [eax],al
  10006A3C: push        es
  10006A3D: fimul       word ptr [esi]
  10006A3F: inc         byte ptr [esi]
  10006A41: xor         al,0
  10006A43: add         byte ptr [esi],al
  10006A45: adc         al,byte ptr [eax+ebp]
  10006A48: add         eax,dword ptr [ecx]
  10006A4A: add         byte ptr [esi],al
  10006A4C: fcom        qword ptr [edx]
  10006A4E: add         al,4Ah
  10006A50: sub         al,0Dh
  10006A52: adc         al,byte ptr [edx+ecx*2]
  10006A55: adc         al,byte ptr [edx+ecx*2]
  10006A58: dec         edx
  10006A59: dec         edx
  10006A5A: sub         dword ptr [eax],edi
  10006A5D: add         byte ptr [ecx],dl
  10006A5F: or          byte ptr [edi],bl
  10006A61: sbb         byte ptr [eax+0Ch],bl
  10006A64: pop         es
  10006A65: pop         ss
  10006A66: pop         ecx
  10006A67: or          eax,dword ptr [edi]
  10006A69: push        ss
  10006A6A: xor         eax,581A04B5h
  10006A6F: sbb         bl,byte ptr [eax+4]
  10006A72: sbb         bl,byte ptr [eax+1Ah]
  10006A75: pop         eax
  10006A76: dec         edx
  10006A77: pop         ds
  10006A78: cld
  10006A79: pop         eax
  10006A7A: push        esp
  10006A7B: add         ah,byte ptr ds:[580C1F4Ah]
  10006A81: dec         edx
  10006A82: sub         dword ptr [eax],edi
  10006A85: add         byte ptr [ecx],dl
  10006A87: sub         al,byte ptr [ecx+1Ch]
  10006A8A: add         byte ptr [eax],al
  10006A8C: add         al,0
  10006A8E: add         byte ptr [eax],al
  10006A90: cmp         eax,dword ptr [eax]
  10006A92: add         byte ptr [eax],al
  10006A94: adc         byte ptr [eax],al
  10006A96: add         byte ptr [eax],al
  10006A98: dec         ebx
  10006A99: add         byte ptr [eax],al
  10006A9B: add         byte ptr [esi],cl
  10006A9D: add         byte ptr [eax],al
  10006A9F: add         byte ptr [edx],bh
  10006AA1: add         byte ptr [eax],al
  10006AA3: add         dword ptr [ebx],ecx
  10006AA5: xor         byte ptr [eax+eax],al
  10006AA8: stos        dword ptr es:[edi]
  10006AA9: add         byte ptr [eax],al
  10006AAB: add         byte ptr [esi],bl
  10006AAD: add         dword ptr [eax],eax
  10006AAF: adc         dword ptr [edx],eax
  10006AB1: cmp         dword ptr [eax+eax+25020000h],esp
  10006AB8: dec         edx
  10006AB9: push        ds
  10006ABA: pop         eax
  10006ABB: dec         edx
  10006ABC: sub         dword ptr [ecx],edi
  10006ABF: add         byte ptr [ecx],dl
  10006AC1: or          al,byte ptr [ebx]
  10006AC3: push        es
  10006AC4: push        esp
  10006AC5: push        es
  10006AC6: cmp         dword ptr [ebx+04000000h],eax
  10006ACC: add         ebx,dword ptr [edx]
  10006ACE: pop         eax
  10006ACF: push        ds
  10006AD0: push        es
  10006AD1: sub         byte ptr [esi],al
  10006AD3: add         byte ptr [eax],al
  10006AD5: push        es
  10006AD6: push        ss
  10006AD8: or          edx,dword ptr [esi]
  10006ADA: push        es
  10006ADB: xor         al,62h
  10006ADD: add         dl,byte ptr [edx]
  10006ADF: add         eax,581A4A02h
  10006AE4: dec         edx
  10006AE5: sub         dword ptr [eax+eax],esi
  10006AE9: adc         dword ptr [ebx],edx
  10006AEB: add         al,11h
  10006AED: add         al,4Ah
  10006AEF: or          al,7
  10006AF1: push        ds
  10006AF2: pop         edx
  10006AF3: add         ebx,dword ptr [edx]
  10006AF5: pop         eax
  10006AF6: dec         edx
  10006AF7: pop         eax
  10006AF8: or          eax,0DE022D08h
  10006AFD: daa
  10006AFE: or          byte ptr [edi+5Ah],bh
  10006B01: add         byte ptr [eax],al
  10006B03: add         al,8
  10006B05: dec         edx
  10006B06: sbb         bl,byte ptr [eax+4Ah]
  10006B09: sub         dword ptr [ebx],edi
  10006B0C: add         byte ptr [ecx],dl
  10006B0E: or          dword ptr [eax+ebp],eax
  10006B11: jns         10006B13
  10006B13: add         byte ptr [esi],al
  10006B15: fimul       word ptr [esi]
  10006B17: inc         byte ptr [esi]
  10006B19: xor         al,0
  10006B1B: add         byte ptr [esi],al
  10006B1D: adc         al,byte ptr ds:[00010328h]
  10006B23: push        es
  10006B24: fcom        qword ptr [edx]
  10006B26: add         eax,120D2C4Ah
  10006B2B: add         eax,4A05124Ah
  10006B30: dec         edx
  10006B31: dec         edx
  10006B32: sub         dword ptr [eax],edi
  10006B35: add         byte ptr [ecx],dl
  10006B37: pop         es
  10006B38: pop         ss
  10006B39: pop         eax
  10006B3A: or          eax,dword ptr [edi]
  10006B3C: push        es
  10006B3D: aaa
  10006B3E: sahf
  10006B3F: add         al,1Ah
  10006B41: pop         eax
  10006B42: sbb         bl,byte ptr [eax+4]
  10006B45: sbb         bl,byte ptr [eax+1Ah]
  10006B48: pop         eax
  10006B49: dec         edx
  10006B4A: pop         ds
  10006B4B: cld
  10006B4C: pop         eax
  10006B4D: push        esp
  10006B4E: add         ah,byte ptr ds:[580C1F4Ah]
  10006B54: dec         edx
  10006B55: sub         dword ptr [eax],edi
  10006B58: add         byte ptr [ecx],dl
  10006B5A: sub         al,byte ptr [eax]
  10006B5C: inc         ecx
  10006B5D: sbb         al,0
  10006B5F: add         byte ptr [eax+eax],al
  10006B62: add         byte ptr [eax],al
  10006B64: cmp         al,0
  10006B66: add         byte ptr [eax],al
  10006B68: sub         eax,dword ptr [eax]
  10006B6A: add         byte ptr [eax],al
  10006B6C: add         byte ptr [bx+si],al
  10006B6F: add         byte ptr [esi],cl
  10006B71: add         byte ptr [eax],al
  10006B73: add         byte ptr [edx],bh
  10006B75: add         byte ptr [eax],al
  10006B77: add         dword ptr [ebx],ecx
  10006B79: xor         byte ptr [eax+eax],al
  10006B7C: stos        dword ptr es:[edi]
  10006B7D: add         byte ptr [eax],al
  10006B7F: add         byte ptr [edi],bl
  10006B81: add         dword ptr [eax],eax
  10006B83: adc         dword ptr [edx],eax
  10006B85: cmp         dword ptr [eax+eax+25020000h],esp
  10006B8C: dec         edx
  10006B8D: push        ds
  10006B8E: pop         eax
  10006B8F: dec         edx
  10006B90: sub         dword ptr [ecx],edi
  10006B93: add         byte ptr [ecx],dl
  10006B95: or          al,byte ptr [ebx]
  10006B97: push        es
  10006B98: push        esp
  10006B99: push        es
  10006B9A: cmp         dword ptr [ebx+04000000h],eax
  10006BA0: add         ebx,dword ptr [edx]
  10006BA2: pop         eax
  10006BA3: push        ds
  10006BA4: push        es
  10006BA5: sub         byte ptr [esi],al
  10006BA7: add         byte ptr [eax],al
  10006BA9: push        es
  10006BAA: push        ss
  10006BAC: or          edx,dword ptr [esi]
  10006BAE: push        es
  10006BAF: xor         al,62h
  10006BB1: add         dl,byte ptr [edx]
  10006BB3: add         eax,581A4A02h
  10006BB8: dec         edx
  10006BB9: sub         dword ptr [eax+eax],esi
  10006BBD: adc         dword ptr [ebx],edx
  10006BBF: add         al,11h
  10006BC1: add         al,4Ah
  10006BC3: or          al,7
  10006BC5: push        ds
  10006BC6: pop         edx
  10006BC7: add         ebx,dword ptr [edx]
  10006BC9: pop         eax
  10006BCA: dec         edx
  10006BCB: pop         eax
  10006BCC: or          eax,0DE022D08h
  10006BD1: daa
  10006BD2: or          byte ptr [edi+60h],bh
  10006BD5: add         byte ptr [eax],al
  10006BD7: add         al,8
  10006BD9: dec         edx
  10006BDA: sbb         bl,byte ptr [eax+4Ah]
  10006BDD: sub         dword ptr [ebx],edi
  10006BE0: add         byte ptr [ecx],dl
  10006BE2: or          dword ptr [eax+ebp],eax
  10006BE5: jns         10006BE7
  10006BE7: add         byte ptr [esi],al
  10006BE9: fimul       word ptr [esi]
  10006BEB: inc         byte ptr [esi]
  10006BED: xor         al,0
  10006BEF: add         byte ptr [esi],al
  10006BF1: adc         al,byte ptr ds:[00010328h]
  10006BF7: push        es
  10006BF8: fcom        qword ptr [edx]
  10006BFA: add         eax,120D2C4Ah
  10006BFF: add         eax,4A05124Ah
  10006C04: dec         edx
  10006C05: dec         edx
  10006C06: sub         dword ptr [eax],edi
  10006C09: add         byte ptr [ecx],dl
  10006C0B: pop         es
  10006C0C: pop         ss
  10006C0D: pop         eax
  10006C0E: or          eax,dword ptr [edi]
  10006C10: push        es
  10006C11: aaa
  10006C12: sahf
  10006C13: add         al,1Ah
  10006C15: pop         eax
  10006C16: sbb         bl,byte ptr [eax+4]
  10006C19: sbb         bl,byte ptr [eax+1Ah]
  10006C1C: pop         eax
  10006C1D: dec         edx
  10006C1E: pop         ds
  10006C1F: cld
  10006C20: pop         eax
  10006C21: push        esp
  10006C22: add         ah,byte ptr ds:[580C1F4Ah]
  10006C28: dec         edx
  10006C29: sub         dword ptr [eax],edi
  10006C2C: add         byte ptr [ecx],dl
  10006C2E: sub         al,byte ptr [eax]
  10006C30: inc         ecx
  10006C31: sbb         al,0
  10006C33: add         byte ptr [eax+eax],al
  10006C36: add         byte ptr [eax],al
  10006C38: cmp         al,0
  10006C3A: add         byte ptr [eax],al
  10006C3C: sub         eax,dword ptr [eax]
  10006C3E: add         byte ptr [eax],al
  10006C40: add         byte ptr [bx+si],al
  10006C43: add         byte ptr [esi],cl
  10006C45: add         byte ptr [eax],al
  10006C47: add         byte ptr [edx],bh
  10006C49: add         byte ptr [eax],al
  10006C4B: add         dword ptr [ebx],ecx
  10006C4D: xor         byte ptr [eax+eax],al
  10006C50: stos        dword ptr es:[edi]
  10006C51: add         byte ptr [eax],al
  10006C53: add         byte ptr [eax],ah
  10006C55: add         dword ptr [eax],eax
  10006C57: adc         dword ptr [edx],eax
  10006C59: cmp         dword ptr [eax+eax+25020000h],esp
  10006C60: dec         edx
  10006C61: push        ds
  10006C62: pop         eax
  10006C63: dec         edx
  10006C64: sub         dword ptr [ecx],edi
  10006C67: add         byte ptr [ecx],dl
  10006C69: or          al,byte ptr [ebx]
  10006C6B: push        es
  10006C6C: push        esp
  10006C6D: push        es
  10006C6E: cmp         dword ptr [ebx+04000000h],eax
  10006C74: add         ebx,dword ptr [edx]
  10006C76: pop         eax
  10006C77: push        ds
  10006C78: push        es
  10006C79: sub         byte ptr [esi],al
  10006C7B: add         byte ptr [eax],al
  10006C7D: push        es
  10006C7E: push        ss
  10006C80: or          edx,dword ptr [esi]
  10006C82: push        es
  10006C83: xor         al,62h
  10006C85: add         dl,byte ptr [edx]
  10006C87: add         eax,581A4A02h
  10006C8C: dec         edx
  10006C8D: sub         dword ptr [eax+eax],esi
  10006C91: adc         dword ptr [ebx],edx
  10006C93: add         al,11h
  10006C95: add         al,4Ah
  10006C97: or          al,7
  10006C99: push        ds
  10006C9A: pop         edx
  10006C9B: add         ebx,dword ptr [edx]
  10006C9D: pop         eax
  10006C9E: dec         edx
  10006C9F: pop         eax
  10006CA0: or          eax,0DE022D08h
  10006CA5: daa
  10006CA6: or          byte ptr [edi+63h],bh
  10006CA9: add         byte ptr [eax],al
  10006CAB: add         al,8
  10006CAD: dec         edx
  10006CAE: sbb         bl,byte ptr [eax+4Ah]
  10006CB1: sub         dword ptr [ebx],edi
  10006CB4: add         byte ptr [ecx],dl
  10006CB6: or          dword ptr [eax+ebp],eax
  10006CB9: jl          10006CBB
  10006CBB: add         byte ptr [esi],al
  10006CBD: fimul       word ptr [esi]
  10006CBF: inc         byte ptr [esi]
  10006CC1: xor         al,0
  10006CC3: add         byte ptr [esi],al
  10006CC5: adc         al,byte ptr ds:[00010328h]
  10006CCB: push        es
  10006CCC: fcom        qword ptr [edx]
  10006CCE: add         eax,120D2C4Ah
  10006CD3: add         eax,4A05124Ah
  10006CD8: dec         edx
  10006CD9: dec         edx
  10006CDA: sub         dword ptr [eax],edi
  10006CDD: add         byte ptr [ecx],dl
  10006CDF: pop         es
  10006CE0: pop         ss
  10006CE1: pop         eax
  10006CE2: or          eax,dword ptr [edi]
  10006CE4: push        es
  10006CE5: aaa
  10006CE6: sahf
  10006CE7: add         al,1Ah
  10006CE9: pop         eax
  10006CEA: sbb         bl,byte ptr [eax+4]
  10006CED: sbb         bl,byte ptr [eax+1Ah]
  10006CF0: pop         eax
  10006CF1: dec         edx
  10006CF2: pop         ds
  10006CF3: cld
  10006CF4: pop         eax
  10006CF5: push        esp
  10006CF6: add         ah,byte ptr ds:[580C1F4Ah]
  10006CFC: dec         edx
  10006CFD: sub         dword ptr [eax],edi
  10006D00: add         byte ptr [ecx],dl
  10006D02: sub         al,byte ptr [eax]
  10006D04: inc         ecx
  10006D05: sbb         al,0
  10006D07: add         byte ptr [eax+eax],al
  10006D0A: add         byte ptr [eax],al
  10006D0C: cmp         al,0
  10006D0E: add         byte ptr [eax],al
  10006D10: sub         eax,dword ptr [eax]
  10006D12: add         byte ptr [eax],al
  10006D14: add         byte ptr [bx+si],al
  10006D17: add         byte ptr [esi],cl
  10006D19: add         byte ptr [eax],al
  10006D1B: add         byte ptr [edx],bh
  10006D1D: add         byte ptr [eax],al
  10006D1F: add         dword ptr [ebx],ecx
  10006D21: xor         byte ptr [esi],al
  10006D23: add         cl,al
  10006D25: add         dword ptr [eax],eax
  10006D27: add         byte ptr [edx],ah
  10006D29: add         dword ptr [eax],eax
  10006D2B: adc         dword ptr [edx],eax
  10006D2D: sbb         bl,byte ptr [eax+4Ah]
  10006D30: or          al,byte ptr [edx+eax]
  10006D33: push        ds
  10006D34: pop         eax
  10006D35: dec         edx
  10006D36: push        es
  10006D37: pop         ecx
  10006D38: pop         ds
  10006D39: sbb         byte ptr [ebx+42h],bl
  10006D3C: push        es
  10006D3D: add         dword ptr [eax],eax
  10006D3F: add         byte ptr [esi+edx],al
  10006D42: inc         ebx
  10006D43: movs        dword ptr es:[edi],dword ptr [esi]
  10006D44: add         dword ptr [eax],eax
  10006D46: add         byte ptr [edx],dl
  10006D48: adc         eax,dword ptr ds:[1312544Ah]
  10006D4E: sbb         bl,byte ptr [eax+5]
  10006D51: sbb         bl,byte ptr [eax+28h]
  10006D54: xor         dword ptr [eax],eax
  10006D56: add         byte ptr [esi],al
  10006D58: adc         dl,byte ptr es:[ebx]
  10006D5B: pop         ds
  10006D5C: adc         al,58h
  10006D5E: add         eax,4758141Fh
  10006D63: push        edx
  10006D64: ficom       word ptr [eax]
  10006D66: inc         byte ptr [esi]
  10006D68: push        ss
  10006D69: add         byte ptr [eax],al
  10006D6B: push        es
  10006D6C: adc         dl,byte ptr [ebx]
  10006D6E: sbb         bl,byte ptr [eax+28h]
  10006D71: add         eax,dword ptr [ecx]
  10006D73: add         byte ptr [esi],al
  10006D75: fadd        qword ptr [eax]
  10006D77: add         bl,byte ptr [edx]
  10006D79: pop         eax
  10006D7A: dec         edx
  10006D7B: add         ebx,dword ptr [ecx+1Fh]
  10006D7E: sbb         byte ptr [ebx+13h],bl
  10006D81: or          byte ptr [edx],al
  10006D83: sbb         bl,byte ptr [eax+4Ah]
  10006D86: or          al,byte ptr [esi]
  10006D88: adc         eax,dword ptr [edi]
  10006D8A: add         al,11h
  10006D8C: or          byte ptr [edx+edi],dh
  10006D8F: add         al,1Fh
  10006D91: sbb         byte ptr [edx+13h],bl
  10006D94: push        es
  10006D95: push        es
  10006D96: adc         dword ptr [esi],eax
  10006D98: pop         ecx
  10006D99: adc         ecx,dword ptr [ecx+edx]
  10006D9C: or          al,6
  10006D9E: and         eax,2628h
  10006DA3: push        es
  10006DA4: add         bl,byte ptr es:[edx]
  10006DA7: pop         eax
  10006DA8: add         bl,byte ptr [edx]
  10006DAA: pop         eax
  10006DAB: dec         edx
  10006DAC: adc         dword ptr [esi],eax
  10006DAE: pop         eax
  10006DAF: push        esp
  10006DB0: add         edx,dword ptr [ecx]
  10006DB2: or          al,11h
  10006DB4: pop         es
  10006DB5: sub         byte ptr [ecx+26060000h],ah
  10006DBB: add         edx,dword ptr [ecx]
  10006DBD: push        es
  10006DBE: add         ebx,dword ptr [eax+12h]
  10006DC1: adc         ebp,dword ptr [eax]
  10006DC3: wait
  10006DC4: add         byte ptr [eax],al
  10006DC6: push        es
  10006DC7: sub         ecx,dword ptr [esi+12h]
  10006DCA: clts
  10006DCC: push        esp
  10006DCD: add         al,11h
  10006DCF: or          byte ptr [ecx+13h],bl
  10006DD2: or          edx,dword ptr [ecx]
  10006DD4: movups      xmmword ptr [ebx],xmm1
  10006DD7: adc         dl,byte ptr [ebx]
  10006DD9: adc         dword ptr [edx],edx
  10006DDB: sub         byte ptr [edi+02060000h],bl
  10006DE1: sbb         bl,byte ptr [eax+2]
  10006DE4: sbb         bl,byte ptr [eax+4Ah]
  10006DE7: adc         dword ptr [ebx],ecx
  10006DE9: pop         ds
  10006DEA: sbb         byte ptr [edx+58h],bl
  10006DED: push        esp
  10006DEE: add         bl,byte ptr [edx]
  10006DF0: pop         eax
  10006DF1: dec         edx
  10006DF2: adc         ecx,dword ptr [esi]
  10006DF4: add         edx,dword ptr [ecx]
  10006DF6: pop         es
  10006DF7: adc         dword ptr [esi],ecx
  10006DF9: sub         byte ptr [esi],ah
  10006DFB: add         byte ptr [eax],al
  10006DFD: push        es
  10006DFE: add         bl,byte ptr es:[edx]
  10006E01: pop         eax
  10006E02: add         bl,byte ptr [edx]
  10006E04: pop         eax
  10006E05: dec         edx
  10006E06: adc         dword ptr [eax],ecx
  10006E08: pop         ds
  10006E09: sbb         byte ptr [edx+58h],bl
  10006E0C: push        esp
  10006E0D: add         edx,dword ptr [ecx]
  10006E0F: pop         es
  10006E10: adc         dl,byte ptr [ebx]
  10006E12: sub         byte ptr [ebx+DE060000h],bl
  10006E18: push        cs
  10006E19: inc         byte ptr [esi]
  10006E1B: push        ds
  10006E1C: add         byte ptr [eax],al
  10006E1E: push        es
  10006E1F: adc         dl,byte ptr [ebx]
  10006E21: sub         byte ptr [ebx],al
  10006E23: add         dword ptr [eax],eax
  10006E25: push        es
  10006E26: fcom        qword ptr [edx]
  10006E28: adc         ebx,dword ptr [edx]
  10006E2A: pop         eax
  10006E2B: adc         edx,dword ptr [ecx]
  10006E2D: adc         dl,byte ptr [ebx]
  10006E2F: sbb         bl,byte ptr [eax+4Ah]
  10006E32: cmp         dword ptr [ebp+12000000h],esi
  10006E38: adc         ebx,dword ptr [edx]
  10006E3A: pop         eax
  10006E3B: dec         edx
  10006E3C: sub         byte ptr [edi],bl
  10006E3E: add         dword ptr [eax],eax
  10006E40: push        es
  10006E41: cmp         byte ptr [esi+06000000h],ah
  10006E47: add         cl,byte ptr [edx+59h]
  10006E4A: pop         ds
  10006E4B: sbb         byte ptr [ebx+13h],bl
  10006E4E: add         eax,36160511h
  10006E53: or          byte ptr [ecx],dl
  10006E55: add         eax,4136217h
  10006E5A: sub         eax,dword ptr [ebx]
  10006E5C: pop         ss
  10006E5D: adc         eax,dword ptr [esp+eax]
  10006E60: adc         dword ptr ds:[110A1358h],eax
  10006E66: add         al,11h
  10006E68: or          dh,byte ptr [esi]
  10006E6A: add         eax,2B0D0411h
  10006E6F: add         edx,dword ptr [ecx]
  10006E71: or          cl,byte ptr ds:[091D2C09h]
  10006E77: pop         ds
  10006E78: sbb         byte ptr [edx+7Fh],bl
  10006E7B: add         al,byte ptr [eax]
  10006E7D: add         byte ptr [esi+edx],al
  10006E80: push        ss
  10006E81: jg          10006E86
  10006E83: add         byte ptr [eax],al
  10006E85: add         al,20h
  10006E87: rol         dword ptr [eax],1
  10006E89: add         byte ptr [eax],al
  10006E8B: sub         byte ptr [edx+0C060000h],ah
  10006E91: sub         eax,dword ptr [edx]
  10006E93: push        ss
  10006E94: or          al,2
  10006E96: dec         edx
  10006E97: add         ecx,dword ptr [eax]
  10006E99: sub         byte ptr [esi],ah
  10006E9B: add         byte ptr [eax],al
  10006E9D: push        es
  10006E9E: or          edx,dword ptr [edx]
  10006EA0: or          eax,0D115407h
  10006EA5: add         al,5
  10006EA7: adc         dword ptr [eax],edx
  10006EA9: sub         byte ptr [edi+03060000h],bl
  10006EAF: add         bl,byte ptr [edx]
  10006EB1: pop         eax
  10006EB2: dec         edx
  10006EB3: add         al,1Fh
  10006EB5: sbb         byte ptr [edx+7],bl
  10006EB8: pop         eax
  10006EB9: sub         byte ptr [esi],ah
  10006EBB: add         byte ptr [eax],al
  10006EBD: push        es
  10006EBE: or          eax,dword ptr [edx]
  10006EC0: and         eax,581A024Ah
  10006EC5: dec         edx
  10006EC6: sub         byte ptr [ebx],ah
  10006EC8: add         byte ptr [eax],al
  10006ECA: push        es
  10006ECB: add         cl,byte ptr [edx+13h]
  10006ECE: or          dword ptr [ecx],edx
  10006ED0: or          dword ptr [edi+eax],ebp
  10006ED3: adc         dword ptr [ecx],ecx
  10006ED5: sub         byte ptr [edi],bl
  10006ED7: add         dword ptr [eax],eax
  10006ED9: push        es
  10006EDA: add         cl,byte ptr [eax]
  10006EDC: push        esp
  10006EDD: add         bl,byte ptr [edx]
  10006EDF: pop         eax
  10006EE0: pop         es
  10006EE1: push        esp
  10006EE2: add         bl,byte ptr [esi]
  10006EE4: pop         eax
  10006EE5: or          dword ptr [edi],ebx
  10006EE7: sbb         byte ptr [edx+8],bl
  10006EEA: pop         eax
  10006EEB: push        esp
  10006EEC: sub         al,byte ptr [eax]
  10006EEE: add         byte ptr [eax],al
  10006EF0: inc         ecx
  10006EF1: xor         al,0
  10006EF3: add         byte ptr [eax+eax],al
  10006EF6: add         byte ptr [eax],al
  10006EF8: sub         eax,0D000000h
  10006EFD: add         byte ptr [eax],al
  10006EFF: add         byte ptr [edx],bh
  10006F01: add         byte ptr [eax],al
  10006F03: add         byte ptr [eax],dl
  10006F05: add         byte ptr [eax],al
  10006F07: add         byte ptr [edx],bh
  10006F09: add         byte ptr [eax],al
  10006F0B: add         dword ptr [eax+eax],eax
  10006F0E: add         byte ptr [eax],al
  10006F10: dec         ebx
  10006F11: add         byte ptr [eax],al
  10006F13: add         byte ptr [edx+ED000000h],ah
  10006F19: add         byte ptr [eax],al
  10006F1B: add         byte ptr [esi],cl
  10006F1D: add         byte ptr [eax],al
  10006F1F: add         byte ptr [edx],bh
  10006F21: add         byte ptr [eax],al
  10006F23: add         dword ptr [ebx],ecx
  10006F25: xor         byte ptr [esi],al
  10006F27: add         byte ptr [edx],dh
  10006F2A: add         byte ptr [eax],al
  10006F2C: adc         dword ptr [ecx],eax
  10006F2E: add         byte ptr [ecx],dl
  10006F30: add         ch,byte ptr [esi+ebp*2]
  10006F33: add         dl,byte ptr [edx]
  10006F35: add         bh,byte ptr [edi+4Eh]
  10006F38: add         byte ptr [eax],al
  10006F3A: add         al,16h
  10006F3C: add         cl,byte ptr [edx+1Eh]
  10006F3F: pop         eax
  10006F40: dec         edx
  10006F41: sub         dword ptr [ebx],esi
  10006F44: add         byte ptr [ecx],dl
  10006F46: or          eax,dword ptr [edi]
  10006F48: dec         edx
  10006F49: or          al,byte ptr [esi]
  10006F4B: sub         eax,627DE02h
  10006F50: jg          10006F97
  10006F52: add         byte ptr [eax],al
  10006F54: add         al,6
  10006F56: dec         edx
  10006F57: sbb         bl,byte ptr [eax+4Ah]
  10006F5A: sub         dword ptr [ebx],edi
  10006F5D: add         byte ptr [ecx],dl
  10006F5F: add         eax,dword ptr [eax+ebp]
  10006F62: add         byte ptr [eax],al
  10006F65: push        es
  10006F66: fimul       word ptr [esi]
  10006F68: inc         byte ptr [esi]
  10006F6A: xor         al,0
  10006F6C: add         byte ptr [esi],al
  10006F6E: adc         al,byte ptr [edx]
  10006F70: sub         byte ptr [ebx],al
  10006F72: add         dword ptr [eax],eax
  10006F74: push        es
  10006F75: fcom        qword ptr [edx]
  10006F77: add         cl,byte ptr [edx+2Ch]
  10006F7A: or          eax,124A0212h
  10006F7F: add         cl,byte ptr [edx+4Ah]
  10006F82: dec         edx
  10006F83: sub         dword ptr [eax],edi
  10006F86: add         byte ptr [ecx],dl
  10006F88: add         bh,byte ptr [edi+4Fh]
  10006F8B: add         byte ptr [eax],al
  10006F8D: add         al,2
  10006F8F: dec         edx
  10006F90: sbb         bl,byte ptr [eax+4Ah]
  10006F93: sub         dword ptr [ebx],edi
  10006F96: add         byte ptr [ecx],dl
  10006F98: add         ebx,dword ptr [esi]
  10006F9A: pop         eax
  10006F9B: add         al,28h
  10006F9D: add         byte ptr [bx+si],al
  10006FA0: push        es
  10006FA1: sub         al,byte ptr [eax]
  10006FA3: add         byte ptr [ecx+1Ch],al
  10006FA6: add         byte ptr [eax],al
  10006FA8: add         al,0
  10006FAA: add         byte ptr [eax],al
  10006FAC: pop         ss
  10006FAD: add         byte ptr [eax],al
  10006FAF: add         byte ptr [ecx],ah
  10006FB1: add         byte ptr [eax],al
  10006FB3: add         byte ptr [eax],bh
  10006FB5: add         byte ptr [eax],al
  10006FB7: add         byte ptr [esi],cl
  10006FB9: add         byte ptr [eax],al
  10006FBB: add         byte ptr [edx],bh
  10006FBD: add         byte ptr [eax],al
  10006FBF: add         dword ptr [ebx],eax
  10006FC1: xor         byte ptr ds:[00006600h],al
  10006FC7: add         byte ptr [ebx],ah
  10006FC9: add         dword ptr [eax],eax
  10006FCB: adc         dword ptr [edx],eax
  10006FCD: sub         al,62h
  10006FCF: add         bh,byte ptr [edi+50h]
  10006FD2: add         byte ptr [eax],al
  10006FD4: add         al,7Fh
  10006FD6: add         byte ptr ss:[eax],al
  10006FD9: add         al,2
  10006FDB: dec         edx
  10006FDC: pop         ds
  10006FDD: or          al,58h
  10006FDF: dec         edx
  10006FE0: sub         dword ptr [esi],esi
  10006FE3: add         byte ptr [ecx],dl
  10006FE5: or          al,byte ptr [esi]
  10006FE7: sub         al,1Ch
  10006FE9: push        es
  10006FEA: and         eax,75294A4Ah
  10006FEF: add         byte ptr [eax],al
  10006FF1: adc         dword ptr [esi],edx
  10006FF3: push        ss
  10006FF4: sub         byte ptr [ebx],ah
  10006FF6: add         dword ptr [eax],eax
  10006FF8: push        es
  10006FF9: or          eax,dword ptr [esi]
  10006FFB: and         eax,4A581A4Ah
  10007000: sub         dword ptr [eax],edi
  10007003: add         byte ptr [ecx],dl
  10007005: pop         es
  10007006: and         ch,dh
  10007008: mov         ss,dx
  1000700A: push        eax
  1000700B: sbb         al,7
  1000700E: and         byte ptr [eax],ah
  10007010: fld         qword ptr [edx-0Ah]
  10007013: or          al,byte ptr cs:[edx]
  10007016: add         eax,dword ptr [eax+ebp]
  10007019: add         dword ptr [eax],0
  1000701C: push        es
  1000701D: sub         edx,dword ptr [edx]
  1000701F: add         al,byte ptr [ebx]
  10007021: add         al,28h
  10007023: add         byte ptr [eax],0
  10007026: push        es
  10007027: sub         ecx,dword ptr [eax]
  10007029: add         al,byte ptr [ebx]
  1000702B: add         al,28h
  1000702D: add         dword ptr [eax],0CC2A0600h
  10007033: int         3
  10007034: add         esi,dword ptr [eax]
  10007036: add         al,0
  10007038: inc         edi
  10007039: add         byte ptr [eax],al
  1000703B: add         byte ptr ds:[04110001h],ah
  10007041: add         ebx,dword ptr [edi]
  10007043: adc         al,17h
  10007045: sub         byte ptr [esi],al
  10007047: add         byte ptr [eax],al
  10007049: push        es
  1000704A: or          al,byte ptr [edx]
  1000704C: sub         al,22h
  1000704E: add         bh,byte ptr [edi+44h]
  10007051: add         byte ptr [eax],al
  10007053: add         al,2
  10007055: dec         edx
  10007056: sbb         bl,byte ptr [eax+4Ah]
  10007059: sub         dword ptr [ebx],edi
  1000705C: add         byte ptr [ecx],dl
  1000705E: push        es
  1000705F: pop         ds
  10007060: or          al,58h
  10007062: add         al,28h
  10007064: pop         dword ptr [eax]
  10007066: add         byte ptr [esi],al
  10007068: add         al,byte ptr [esi]
  1000706A: add         al,28h
  1000706C: add         byte ptr ds:[eax],al
  1000706F: push        es
  10007070: add         al,1Ah
  10007072: pop         eax
  10007073: sbb         bl,byte ptr [eax+4]
  10007076: sbb         bl,byte ptr [eax+1Ah]
  10007079: pop         eax
  1000707A: dec         edx
  1000707B: pop         ds
  1000707C: cld
  1000707D: pop         eax
  1000707E: push        esp
  1000707F: push        es
  10007080: and         byte ptr ds:[54DF08DFh],ah
  10007086: sub         cl,ah
  10007088: or          esi,dword ptr [eax]
  1000708A: add         al,0
  1000708C: mov         es,word ptr [eax]
  1000708E: add         byte ptr [eax],al
  10007090: or          al,byte ptr [ecx]
  10007092: add         byte ptr [ecx],dl
  10007094: add         bh,byte ptr [ecx]
  10007096: xchg        eax,dword ptr [eax]
  10007098: add         byte ptr [eax],al
  1000709A: add         ah,byte ptr ds:[4A581E4Ah]
  100070A0: sub         dword ptr [ecx],edi
  100070A3: add         byte ptr [ecx],dl
  100070A5: or          al,byte ptr [ebx]
  100070A7: push        es
  100070A8: push        esp
  100070A9: push        es
  100070AA: sub         al,69h
  100070AC: add         al,3
  100070AE: sbb         bl,byte ptr [eax+1Ah]
  100070B1: push        es
  100070B2: sub         byte ptr [esi],al
  100070B4: add         byte ptr [eax],al
  100070B6: push        es
  100070B7: push        ss
  100070B9: or          edx,dword ptr [esi]
  100070BB: push        es
  100070BC: xor         al,48h
  100070BE: add         dl,byte ptr [edx]
  100070C0: add         eax,dword ptr [edx]
  100070C2: dec         edx
  100070C3: sbb         bl,byte ptr [eax+4Ah]
  100070C6: sub         dword ptr [eax+eax],esi
  100070CA: adc         dword ptr [eax+ecx],ecx
  100070CD: dec         edx
  100070CE: pop         es
  100070CF: sbb         bl,byte ptr [edx+3]
  100070D2: sbb         bl,byte ptr [eax+4Ah]
  100070D5: pop         eax
  100070D6: add         al,28h
  100070D8: push        edi
  100070D9: add         byte ptr [eax],al
  100070DB: push        es
  100070DC: fimul       word ptr [esi]
  100070DE: inc         byte ptr [esi]
  100070E0: xor         al,0
  100070E2: add         byte ptr [esi],al
  100070E4: adc         al,byte ptr [ebx]
  100070E6: sub         byte ptr [ebx],al
  100070E8: add         dword ptr [eax],eax
  100070EA: push        es
  100070EB: fcom        qword ptr [edx]
  100070ED: add         ecx,dword ptr [edx+2Ch]
  100070F0: or          eax,124A0312h
  100070F5: add         ecx,dword ptr [edx+4Ah]
  100070F8: dec         edx
  100070F9: sub         dword ptr [eax],edi
  100070FC: add         byte ptr [ecx],dl
  100070FE: pop         es
  100070FF: pop         ss
  10007100: pop         eax
  10007101: or          eax,dword ptr [edi]
  10007103: push        es
  10007104: aaa
  10007105: mov         eax,1A581A04h
  1000710A: pop         eax
  1000710B: add         al,1Ah
  1000710D: pop         eax
  1000710E: sbb         bl,byte ptr [eax+4Ah]
  10007111: pop         ds
  10007112: cld
  10007113: pop         eax
  10007114: push        esp
  10007115: add         ah,byte ptr ds:[580C1F4Ah]
  1000711B: dec         edx
  1000711C: sub         dword ptr [eax],edi
  1000711F: add         byte ptr [ecx],dl
  10007121: sub         al,byte ptr [eax]
  10007123: add         byte ptr [ecx+1Ch],al
  10007126: add         byte ptr [eax],al
  10007128: add         al,0
  1000712A: add         byte ptr [eax],al
  1000712C: cmp         byte ptr [eax],al
  1000712E: add         byte ptr [eax],al
  10007130: adc         al,byte ptr [eax]
  10007132: add         byte ptr [eax],al
  10007134: dec         edx
  10007135: add         byte ptr [eax],al
  10007137: add         byte ptr [esi],cl
  10007139: add         byte ptr [eax],al
  1000713B: add         byte ptr [edx],bh
  1000713D: add         byte ptr [eax],al
  1000713F: add         dword ptr [ebx],eax
  10007141: xor         byte ptr ds:[00009500h],al
  10007147: add         byte ptr [esi],ah
  10007149: add         dword ptr [eax],eax
  1000714B: adc         dword ptr [edx],eax
  1000714D: cmp         dword ptr [esi+02000000h],ecx
  10007153: jg          100071A5
  10007155: add         byte ptr [eax],al
  10007157: add         al,7Fh
  10007159: add         byte ptr ss:[eax],al
  1000715C: add         al,2
  1000715E: dec         edx
  1000715F: pop         ds
  10007160: or          al,58h
  10007162: dec         edx
  10007163: sub         dword ptr [esi],esi
  10007166: add         byte ptr [ecx],dl
  10007168: or          eax,dword ptr [edi]
  1000716A: sub         al,1Ch
  1000716C: pop         es
  1000716D: and         eax,75294A4Ah
  10007172: add         byte ptr [eax],al
  10007174: adc         dword ptr [esi],edx
  10007176: push        ss
  10007177: sub         byte ptr [ebx],ah
  10007179: add         dword ptr [eax],eax
  1000717B: push        es
  1000717C: or          al,byte ptr [edi]
  1000717E: and         eax,4A581A4Ah
  10007183: sub         dword ptr [eax],edi
  10007186: add         byte ptr [ecx],dl
  10007188: push        es
  10007189: and         byte ptr [esi+35A59096h],ah
  1000718F: push        es
  10007191: and         byte ptr [esi+2EA59096h],ah
  10007197: and         al,6
  10007199: and         byte ptr [edx+2E891819h],al
  1000719F: adc         al,byte ptr [esi]
  100071A1: and         byte ptr ds:[33A3F84Ch],bh
  100071A7: add         al,byte ptr es:[ebx]
  100071AA: add         al,28h
  100071AC: imul        eax,dword ptr [eax],0
  100071AF: push        es
  100071B0: sub         ebp,dword ptr [esi]
  100071B2: add         al,byte ptr [ebx]
  100071B4: add         al,28h
  100071B6: ins         dword ptr es:[edi],dx
  100071B7: add         byte ptr [eax],al
  100071B9: push        es
  100071BA: sub         esp,dword ptr [edx+eax]
  100071BD: add         eax,dword ptr [eax+ebp]
  100071C0: ins         byte ptr es:[edi],dx
  100071C1: add         byte ptr [eax],al
  100071C3: push        es
  100071C4: sub         ebx,dword ptr [edx]
  100071C6: push        es
  100071C7: and         byte ptr ds:[2EDF08DFh],ah
  100071CD: or          al,byte ptr [edx]
  100071CF: add         eax,dword ptr [eax+ebp]
  100071D2: outs        dx,byte ptr [esi]
  100071D3: add         byte ptr [eax],al
  100071D5: push        es
  100071D6: sub         ecx,dword ptr [eax]
  100071D8: add         al,byte ptr [ebx]
  100071DA: add         al,28h
  100071DC: push        0
  100071DE: add         byte ptr [esi],al
  100071E0: sub         cl,ah
  100071E2: int         3
  100071E3: int         3
  100071E4: or          esi,dword ptr [eax]
  100071E6: push        es
  100071E7: add         bh,ah
  100071E9: add         dword ptr [eax],eax
  100071EB: add         byte ptr [edi],ah
  100071ED: add         dword ptr [eax],eax
  100071EF: adc         dword ptr [edx],eax
  100071F1: cmp         eax,esp
  100071F3: add         dword ptr [eax],eax
  100071F5: add         byte ptr [edx],al
  100071F7: jg          1000725D
  100071F9: add         byte ptr [eax],al
  100071FB: add         al,2
  100071FD: dec         edx
  100071FE: sbb         bl,byte ptr [eax+4Ah]
  10007201: sub         dword ptr [ebx],edi
  10007204: add         byte ptr [ecx],dl
  10007206: add         eax,dword ptr [eax+ebp]
  10007209: nop
  1000720A: add         byte ptr [eax],al
  1000720C: push        es
  1000720D: add         bh,byte ptr [edi+65h]
  10007210: add         byte ptr [eax],al
  10007212: add         al,2
  10007214: dec         edx
  10007215: sbb         bl,byte ptr [eax+4Ah]
  10007218: sub         dword ptr [ebx],edi
  1000721B: add         byte ptr [ecx],dl
  1000721D: add         ebx,dword ptr [esi]
  1000721F: pop         eax
  10007220: add         al,28h
  10007222: xchg        eax,ecx
  10007223: add         byte ptr [eax],al
  10007225: push        es
  10007226: add         dl,byte ptr [edx]
  10007228: or          eax,667Fh
  1000722D: add         al,16h
  1000722F: add         cl,byte ptr [edx+1Eh]
  10007232: pop         eax
  10007233: dec         edx
  10007234: sub         dword ptr [ebx],esi
  10007237: add         byte ptr [ecx],dl
  10007239: adc         ecx,dword ptr [ecx]
  1000723B: adc         dword ptr [ecx],ecx
  1000723D: dec         edx
  1000723E: or          eax,dword ptr [ebx]
  10007240: pop         ds
  10007241: adc         byte ptr [eax+0Dh],bl
  10007244: pop         es
  10007245: sub         eax,445DE02h
  1000724A: or          dword ptr [esi],ebx
  1000724C: pop         ss
  1000724D: sub         byte ptr [esi],al
  1000724F: add         byte ptr [eax],al
  10007251: push        es
  10007252: or          dword ptr es:[edx+13h],ecx
  10007256: or          byte ptr [edi],al
  10007258: jg          100072BB
  1000725A: add         byte ptr [eax],al
  1000725C: add         al,7
  1000725E: dec         edx
  1000725F: sbb         bl,byte ptr [eax+4Ah]
  10007262: sub         dword ptr [ebx],edi
  10007265: add         byte ptr [ecx],dl
  10007267: adc         dword ptr [eax],ecx
  10007269: add         al,28h
  1000726B: jns         1000726D
  1000726D: add         byte ptr [esi],al
  1000726F: add         al,1Ah
  10007271: pop         eax
  10007272: sbb         bl,byte ptr [eax+4]
  10007275: sbb         bl,byte ptr [eax+1Ah]
  10007278: pop         eax
  10007279: dec         edx
  1000727A: pop         ds
  1000727B: cld
  1000727C: pop         eax
  1000727D: push        esp
  1000727E: fimul       word ptr [esi]
  10007280: inc         byte ptr [esi]
  10007282: xor         al,0
  10007284: add         byte ptr [esi],al
  10007286: adc         cl,byte ptr ds:[00010328h]
  1000728C: push        es
  1000728D: fcom        qword ptr [edx]
  1000728F: or          eax,120D2C4Ah
  10007294: or          eax,4A0D124Ah
  10007299: dec         edx
  1000729A: dec         edx
  1000729B: sub         dword ptr [eax],edi
  1000729E: add         byte ptr [ecx],dl
  100072A0: add         dl,byte ptr [edx]
  100072A2: or          al,7Fh
  100072A4: add         byte ptr [bx+si],al
  100072A7: add         al,16h
  100072A9: add         cl,byte ptr [edx+1Eh]
  100072AC: pop         eax
  100072AD: dec         edx
  100072AE: sub         dword ptr [ebx],esi
  100072B1: add         byte ptr [ecx],dl
  100072B3: adc         eax,dword ptr [edi]
  100072B5: adc         dword ptr [edi],eax
  100072B7: dec         edx
  100072B8: add         ebx,dword ptr [edi]
  100072BA: adc         al,58h
  100072BC: add         al,28h
  100072BE: jge         100072C0
  100072C0: add         byte ptr [esi],al
  100072C2: fimul       word ptr [esi]
  100072C4: inc         byte ptr [esi]
  100072C6: xor         al,0
  100072C8: add         byte ptr [esi],al
  100072CA: adc         cl,byte ptr [eax+ebp]
  100072CD: add         eax,dword ptr [ecx]
  100072CF: add         byte ptr [esi],al
  100072D1: fcom        qword ptr [edx]
  100072D3: or          al,4Ah
  100072D5: sub         al,0Dh
  100072D7: adc         cl,byte ptr [edx+ecx*2]
  100072DA: adc         cl,byte ptr [edx+ecx*2]
  100072DD: dec         edx
  100072DE: dec         edx
  100072DF: sub         dword ptr [eax],edi
  100072E2: add         byte ptr [ecx],dl
  100072E4: add         dl,byte ptr [edx]
  100072E6: or          edi,dword ptr [edi+68h]
  100072E9: add         byte ptr [eax],al
  100072EB: add         al,16h
  100072ED: add         cl,byte ptr [edx+1Eh]
  100072F0: pop         eax
  100072F1: dec         edx
  100072F2: sub         dword ptr [ebx],esi
  100072F5: add         byte ptr [ecx],dl
  100072F7: adc         eax,dword ptr [esi]
  100072F9: adc         dword ptr [esi],eax
  100072FB: dec         edx
  100072FC: add         ebx,dword ptr [edi]
  100072FE: sbb         byte ptr [eax+4],bl
  10007301: sub         byte ptr [esi],bh
  10007304: add         byte ptr [esi],al
  10007306: fimul       word ptr [esi]
  10007308: inc         byte ptr [esi]
  1000730A: xor         al,0
  1000730C: add         byte ptr [esi],al
  1000730E: adc         cl,byte ptr [ebx]
  10007310: sub         byte ptr [ebx],al
  10007312: add         dword ptr [eax],eax
  10007314: push        es
  10007315: fcom        qword ptr [edx]
  10007317: or          ecx,dword ptr [edx+2Ch]
  1000731A: or          eax,124A0B12h
  1000731F: or          ecx,dword ptr [edx+4Ah]
  10007322: dec         edx
  10007323: sub         dword ptr [eax],edi
  10007326: add         byte ptr [ecx],dl
  10007328: add         bh,byte ptr [edi+69h]
  1000732B: add         byte ptr [eax],al
  1000732D: add         al,2
  1000732F: dec         edx
  10007330: sbb         bl,byte ptr [eax+4Ah]
  10007333: sub         dword ptr [ebx],edi
  10007336: add         byte ptr [ecx],dl
  10007338: add         ebx,dword ptr [edi]
  1000733A: sbb         al,58h
  1000733C: add         al,28h
  1000733E: jg          10007340
  10007340: add         byte ptr [esi],al
  10007342: add         bh,byte ptr [edi+6Ah]
  10007345: add         byte ptr [eax],al
  10007347: add         al,2
  10007349: dec         edx
  1000734A: sbb         bl,byte ptr [eax+4Ah]
  1000734D: sub         dword ptr [ebx],edi
  10007350: add         byte ptr [ecx],dl
  10007352: add         ebx,dword ptr [edi]
  10007354: and         al,58h
  10007356: add         al,28h
  10007358: xchg        eax,edx
  10007359: add         byte ptr [eax],al
  1000735B: push        es
  1000735C: add         dl,byte ptr [edx]
  1000735E: or          bh,byte ptr [edi+6Bh]
  10007361: add         byte ptr [eax],al
  10007363: add         al,16h
  10007365: add         cl,byte ptr [edx+1Eh]
  10007368: pop         eax
  10007369: dec         edx
  1000736A: sub         dword ptr [ebx],esi
  1000736D: add         byte ptr [ecx],dl
  1000736F: adc         eax,dword ptr ds:[0A4A0511h]
  10007375: add         ebx,dword ptr [edi]
  10007377: sub         al,58h
  10007379: or          al,6
  1000737B: sub         eax,445DE02h
  10007380: or          byte ptr [esi],bl
  10007382: pop         ss
  10007383: sub         byte ptr [esi],al
  10007385: add         byte ptr [eax],al
  10007387: push        es
  10007388: or          byte ptr es:[edx+13h],cl
  1000738C: add         al,6
  1000738E: jg          100073F3
  10007390: add         byte ptr [eax],al
  10007392: add         al,6
  10007394: dec         edx
  10007395: sbb         bl,byte ptr [eax+4Ah]
  10007398: sub         dword ptr [ebx],edi
  1000739B: add         byte ptr [ecx],dl
  1000739D: adc         dword ptr [esp+eax],eax
  100073A0: sub         byte ptr [esi],ah
  100073A3: add         byte ptr [esi],al
  100073A5: add         al,1Ah
  100073A7: pop         eax
  100073A8: sbb         bl,byte ptr [eax+4]
  100073AB: sbb         bl,byte ptr [eax+1Ah]
  100073AE: pop         eax
  100073AF: dec         edx
  100073B0: pop         ds
  100073B1: cld
  100073B2: pop         eax
  100073B3: push        esp
  100073B4: fimul       word ptr [esi]
  100073B6: inc         byte ptr [esi]
  100073B8: xor         al,0
  100073BA: add         byte ptr [esi],al
  100073BC: adc         cl,byte ptr [edx]
  100073BE: sub         byte ptr [ebx],al
  100073C0: add         dword ptr [eax],eax
  100073C2: push        es
  100073C3: fcom        qword ptr [edx]
  100073C5: or          cl,byte ptr [edx+2Ch]
  100073C8: or          eax,124A0A12h
  100073CD: or          cl,byte ptr [edx+4Ah]
  100073D0: dec         edx
  100073D1: sub         dword ptr [eax],edi
  100073D4: add         byte ptr [ecx],dl
  100073D6: sub         al,byte ptr [eax]
  100073D8: inc         ecx
  100073D9: add         byte ptr fs:[eax],al
  100073DC: add         al,0
  100073DE: add         byte ptr [eax],al
  100073E0: dec         ebx
  100073E1: add         byte ptr [eax],al
  100073E3: add         byte ptr [ebp],al
  100073E6: add         byte ptr [eax],al
  100073E8: nop
  100073E9: add         byte ptr [eax],al
  100073EB: add         byte ptr [esi],cl
  100073ED: add         byte ptr [eax],al
  100073EF: add         byte ptr [edx],bh
  100073F1: add         byte ptr [eax],al
  100073F3: add         dword ptr [eax+eax],eax
  100073F6: add         byte ptr [eax],al
  100073F8: lds         eax,fword ptr [eax]
  100073FA: add         byte ptr [eax],al
  100073FC: sldt        word ptr [eax]
  100073FF: add         ah,dl
  10007401: add         byte ptr [eax],al
  10007403: add         byte ptr [esi],cl
  10007405: add         byte ptr [eax],al
  10007407: add         byte ptr [edx],bh
  10007409: add         byte ptr [eax],al
  1000740B: add         dword ptr [eax+eax],eax
  1000740E: add         byte ptr [eax],al
  10007410: or          dword ptr [ecx],eax
  10007412: add         byte ptr [eax],al
  10007414: sldt        word ptr [eax]
  10007417: add         byte ptr [eax],bl
  10007419: add         dword ptr [eax],eax
  1000741B: add         byte ptr [esi],cl
  1000741D: add         byte ptr [eax],al
  1000741F: add         byte ptr [edx],bh
  10007421: add         byte ptr [eax],al
  10007423: add         dword ptr [eax+eax],eax
  10007426: add         byte ptr [eax],al
  10007428: add         dword ptr [ecx],450000h
  1000742E: add         byte ptr [eax],al
  10007430: mov         byte ptr [ecx],0
  10007433: add         byte ptr [esi],cl
  10007435: add         byte ptr [eax],al
  10007437: add         byte ptr [edx],bh
  10007439: add         byte ptr [eax],al
  1000743B: add         dword ptr [ebx],eax
  1000743D: xor         byte ptr [eax+eax],al
  10007440: pop         ecx
  10007441: add         byte ptr [eax],al
  10007443: add         byte ptr [eax],ch
  10007445: add         dword ptr [eax],eax
  10007447: adc         dword ptr [edx],eax
  10007449: sbb         bl,byte ptr [eax+4Ah]
  1000744C: or          al,byte ptr [edx]
  1000744E: dec         edx
  1000744F: adc         eax,dword ptr [esi+eax]
  10007452: adc         dword ptr [ecx+ebx*2],eax
  10007455: pop         ds
  10007456: sbb         byte ptr [ebx+0Dh],bl
  10007459: add         ecx,dword ptr [ecx]
  1000745B: or          eax,9030602h
  10007461: pop         ecx
  10007462: add         al,28h
  10007464: xchg        eax,edi
  10007465: add         byte ptr [eax],al
  10007467: push        es
  10007468: sub         esi,dword ptr [esi]
  1000746A: push        es
  1000746B: or          al,3
  1000746D: pop         ds
  1000746E: sbb         byte ptr [edx+11h],bl
  10007471: add         al,58h
  10007473: or          eax,dword ptr [esi]
  10007475: adc         eax,dword ptr [esi]
  10007477: or          byte ptr [ecx],dl
  10007479: push        es
  1000747A: pop         es
  1000747B: sub         byte ptr [edi],ch
  1000747D: add         byte ptr [eax],al
  1000747F: push        es
  10007480: adc         eax,dword ptr ds:[02051102h]
  10007486: sbb         bl,byte ptr [eax+4Ah]
  10007489: sub         byte ptr [ebx],ah
  1000748B: add         byte ptr [eax],al
  1000748D: push        es
  1000748E: add         bl,byte ptr [edx]
  10007490: pop         eax
  10007491: add         bl,byte ptr [edx]
  10007493: pop         eax
  10007494: dec         edx
  10007495: or          byte ptr [edi],al
  10007497: pop         ecx
  10007498: pop         ds
  10007499: call        6A1893F9
  1000749E: pop         eax
  1000749F: push        esp
  100074A0: sub         cl,ah
  100074A2: int         3
  100074A3: int         3
  100074A4: or          esi,dword ptr [eax]
  100074A6: add         al,0
  100074A8: mov         es,word ptr [eax]
  100074AA: add         byte ptr [eax],al
  100074AC: or          al,byte ptr [ecx]
  100074AE: add         byte ptr [ecx],dl
  100074B0: add         bh,byte ptr [ecx]
  100074B2: xchg        eax,dword ptr [eax]
  100074B4: add         byte ptr [eax],al
  100074B6: add         ah,byte ptr ds:[4A581E4Ah]
  100074BC: sub         dword ptr [ecx],edi
  100074BF: add         byte ptr [ecx],dl
  100074C1: or          al,byte ptr [ebx]
  100074C3: push        es
  100074C4: push        esp
  100074C5: push        es
  100074C6: sub         al,69h
  100074C8: add         al,3
  100074CA: sbb         bl,byte ptr [eax+1Ah]
  100074CD: push        es
  100074CE: sub         byte ptr [esi],al
  100074D0: add         byte ptr [eax],al
  100074D2: push        es
  100074D3: push        ss
  100074D5: or          edx,dword ptr [esi]
  100074D7: push        es
  100074D8: xor         al,48h
  100074DA: add         dl,byte ptr [edx]
  100074DC: add         eax,dword ptr [edx]
  100074DE: dec         edx
  100074DF: sbb         bl,byte ptr [eax+4Ah]
  100074E2: sub         dword ptr [eax+eax],esi
  100074E6: adc         dword ptr [eax+ecx],ecx
  100074E9: dec         edx
  100074EA: pop         es
  100074EB: sbb         bl,byte ptr [edx+3]
  100074EE: sbb         bl,byte ptr [eax+4Ah]
  100074F1: pop         eax
  100074F2: add         al,28h
  100074F4: dec         eax
  100074F5: add         byte ptr [eax],al
  100074F7: push        es
  100074F8: fimul       word ptr [esi]
  100074FA: inc         byte ptr [esi]
  100074FC: xor         al,0
  100074FE: add         byte ptr [esi],al
  10007500: adc         al,byte ptr [ebx]
  10007502: sub         byte ptr [ebx],al
  10007504: add         dword ptr [eax],eax
  10007506: push        es
  10007507: fcom        qword ptr [edx]
  10007509: add         ecx,dword ptr [edx+2Ch]
  1000750C: or          eax,124A0312h
  10007511: add         ecx,dword ptr [edx+4Ah]
  10007514: dec         edx
  10007515: sub         dword ptr [eax],edi
  10007518: add         byte ptr [ecx],dl
  1000751A: pop         es
  1000751B: pop         ss
  1000751C: pop         eax
  1000751D: or          eax,dword ptr [edi]
  1000751F: push        es
  10007520: aaa
  10007521: mov         eax,1A581A04h
  10007526: pop         eax
  10007527: add         al,1Ah
  10007529: pop         eax
  1000752A: sbb         bl,byte ptr [eax+4Ah]
  1000752D: pop         ds
  1000752E: cld
  1000752F: pop         eax
  10007530: push        esp
  10007531: add         ah,byte ptr ds:[580C1F4Ah]
  10007537: dec         edx
  10007538: sub         dword ptr [eax],edi
  1000753B: add         byte ptr [ecx],dl
  1000753D: sub         al,byte ptr [eax]
  1000753F: add         byte ptr [ecx+1Ch],al
  10007542: add         byte ptr [eax],al
  10007544: add         al,0
  10007546: add         byte ptr [eax],al
  10007548: cmp         byte ptr [eax],al
  1000754A: add         byte ptr [eax],al
  1000754C: adc         al,byte ptr [eax]
  1000754E: add         byte ptr [eax],al
  10007550: dec         edx
  10007551: add         byte ptr [eax],al
  10007553: add         byte ptr [esi],cl
  10007555: add         byte ptr [eax],al
  10007557: add         byte ptr [edx],bh
  10007559: add         byte ptr [eax],al
  1000755B: add         dword ptr [ebx],ecx
  1000755D: xor         byte ptr [esi],al
  1000755F: add         byte ptr [esi+1],dl
  10007562: add         byte ptr [eax],al
  10007564: sub         dword ptr [ecx],eax
  10007566: add         byte ptr [ecx],dl
  10007568: add         bh,byte ptr [ecx]
  1000756A: dec         edi
  1000756B: add         dword ptr [eax],eax
  1000756D: add         byte ptr [edx],al
  1000756F: jg          100075DD
  10007571: add         byte ptr [eax],al
  10007573: add         al,16h
  10007575: add         cl,byte ptr [edx+1Fh]
  10007578: or          al,58h
  1000757A: dec         edx
  1000757B: sub         dword ptr [esi],esi
  1000757E: add         byte ptr [ecx],dl
  10007580: add         ebx,dword ptr [edx]
  10007582: pop         eax
  10007583: add         al,28h
  10007585: add         byte ptr [eax],0
  10007588: push        es
  10007589: add         bh,byte ptr [edi+56h]
  1000758C: add         byte ptr [eax],al
  1000758E: add         al,16h
  10007590: add         cl,byte ptr [edx+1Fh]
  10007593: or          al,58h
  10007595: dec         edx
  10007596: sub         dword ptr [esi],esi
  10007599: add         byte ptr [ecx],dl
  1000759B: or          al,8
  1000759D: sub         al,23h
  1000759F: or          byte ptr ds:[75294A4Ah],ah
  100075A5: add         byte ptr [eax],al
  100075A7: adc         dword ptr [ebx],edx
  100075A9: or          byte ptr [ebx],al
  100075AB: push        ds
  100075AC: pop         eax
  100075AD: adc         dword ptr [eax],ecx
  100075AF: push        ss
  100075B0: push        ss
  100075B1: sub         byte ptr [ebx],ah
  100075B3: add         dword ptr [eax],eax
  100075B5: push        es
  100075B6: push        esp
  100075B7: or          byte ptr ds:[4A581A4Ah],ah
  100075BD: sub         dword ptr [eax],edi
  100075C0: add         byte ptr [ecx],dl
  100075C2: add         bh,byte ptr [edi+6Dh]
  100075C5: add         byte ptr [eax],al
  100075C7: add         al,16h
  100075C9: add         cl,byte ptr [edx+1Fh]
  100075CC: or          al,58h
  100075CE: dec         edx
  100075CF: sub         dword ptr [esi],esi
  100075D2: add         byte ptr [ecx],dl
  100075D4: or          eax,dword ptr [edi]
  100075D6: sub         al,24h
  100075D8: pop         es
  100075D9: and         eax,75294A4Ah
  100075DE: add         byte ptr [eax],al
  100075E0: adc         dword ptr [ebx],edx
  100075E2: pop         es
  100075E3: add         ebx,dword ptr [edi]
  100075E5: or          al,58h
  100075E7: adc         dword ptr [edi],eax
  100075E9: push        ss
  100075EA: push        ss
  100075EB: sub         byte ptr [ebx],ah
  100075ED: add         dword ptr [eax],eax
  100075EF: push        es
  100075F0: push        esp
  100075F1: pop         es
  100075F2: and         eax,4A581A4Ah
  100075F7: sub         dword ptr [eax],edi
  100075FA: add         byte ptr [ecx],dl
  100075FC: add         dl,byte ptr [edx]
  100075FE: or          bh,byte ptr [edi+7Bh]
  10007601: add         byte ptr [eax],al
  10007603: add         al,16h
  10007605: add         cl,byte ptr [edx+1Eh]
  10007608: pop         eax
  10007609: dec         edx
  1000760A: sub         dword ptr [ebx],esi
  1000760D: add         byte ptr [ecx],dl
  1000760F: adc         eax,dword ptr [esi]
  10007611: adc         dword ptr [esi],eax
  10007613: dec         edx
  10007614: adc         eax,dword ptr [ebx+eax]
  10007617: pop         ds
  10007618: adc         byte ptr [eax+0Dh],bl
  1000761B: adc         dword ptr [ebp+0434DE02h],eax
  10007622: or          dword ptr [edi],ebx
  10007624: sbb         byte ptr [edi],dl
  10007626: sub         byte ptr [esi],al
  10007628: add         byte ptr [eax],al
  1000762A: push        es
  1000762B: adc         dword ptr es:[ecx+ecx],eax
  1000762F: dec         edx
  10007630: add         al,28h
  10007632: push        esi
  10007633: add         byte ptr [eax],al
  10007635: push        es
  10007636: add         al,1Ah
  10007638: pop         eax
  10007639: sbb         bl,byte ptr [eax+4]
  1000763C: sbb         bl,byte ptr [eax+1Ah]
  1000763F: pop         eax
  10007640: dec         edx
  10007641: pop         ds
  10007642: cld
  10007643: pop         eax
  10007644: push        esp
  10007645: fimul       word ptr [esi]
  10007647: inc         byte ptr [esi]
  10007649: xor         al,0
  1000764B: add         byte ptr [esi],al
  1000764D: adc         cl,byte ptr [edx]
  1000764F: sub         byte ptr [ebx],al
  10007651: add         dword ptr [eax],eax
  10007653: push        es
  10007654: fcom        qword ptr [edx]
  10007656: or          cl,byte ptr [edx+2Ch]
  10007659: or          eax,124A0A12h
  1000765E: or          cl,byte ptr [edx+4Ah]
  10007661: dec         edx
  10007662: sub         dword ptr [eax],edi
  10007665: add         byte ptr [ecx],dl
  10007667: add         dl,byte ptr [edx]
  10007669: or          dword ptr [edi+6Eh],edi
  1000766C: add         byte ptr [eax],al
  1000766E: add         al,16h
  10007670: add         cl,byte ptr [edx+1Eh]
  10007673: pop         eax
  10007674: dec         edx
  10007675: sub         dword ptr [ebx],esi
  10007678: add         byte ptr [ecx],dl
  1000767A: adc         eax,dword ptr ds:[0A4A0511h]
  10007680: push        es
  10007681: sub         eax,626DE02h
  10007686: push        ss
  10007687: push        es
  10007688: dec         edx
  10007689: sbb         bl,byte ptr [eax+4Ah]
  1000768C: sub         dword ptr [ebx],edi
  1000768F: add         byte ptr [ecx],dl
  10007691: add         ebx,dword ptr [edi]
  10007693: adc         al,58h
  10007695: add         al,28h
  10007697: xchg        eax,ebx
  10007698: add         byte ptr [eax],al
  1000769A: push        es
  1000769B: fimul       word ptr [esi]
  1000769D: inc         byte ptr [esi]
  1000769F: xor         al,0
  100076A1: add         byte ptr [esi],al
  100076A3: adc         cl,byte ptr [ecx]
  100076A5: sub         byte ptr [ebx],al
  100076A7: add         dword ptr [eax],eax
  100076A9: push        es
  100076AA: fcom        qword ptr [edx]
  100076AC: or          dword ptr [edx+2Ch],ecx
  100076AF: or          eax,124A0912h
  100076B4: or          dword ptr [edx+4Ah],ecx
  100076B7: dec         edx
  100076B8: sub         dword ptr [eax],edi
  100076BB: add         byte ptr [ecx],dl
  100076BD: sub         al,byte ptr [eax]
  100076BF: add         byte ptr [ecx+34h],al
  100076C2: add         byte ptr [eax],al
  100076C4: add         al,0
  100076C6: add         byte ptr [eax],al
  100076C8: test        eax,36000000h
  100076CD: add         byte ptr [eax],al
  100076CF: add         bh,bl
  100076D1: add         byte ptr [eax],al
  100076D3: add         byte ptr [esi],cl
  100076D5: add         byte ptr [eax],al
  100076D7: add         byte ptr [edx],bh
  100076D9: add         byte ptr [eax],al
  100076DB: add         dword ptr [eax+eax],eax
  100076DE: add         byte ptr [eax],al
  100076E0: adc         al,1
  100076E2: add         byte ptr [eax],al
  100076E4: and         dword ptr [eax],eax
  100076E6: add         byte ptr [eax],al
  100076E8: xor         eax,0E000001h
  100076ED: add         byte ptr [eax],al
  100076EF: add         byte ptr [edx],bh
  100076F1: add         byte ptr [eax],al
  100076F3: add         dword ptr [ebx],ecx
  100076F5: xor         byte ptr ds:[00086200h],al
  100076FB: add         byte ptr ds:[12110001h],dh
  10007701: dec         esp
  10007702: adc         al,byte ptr [eax+ebp]
  10007705: mov         byte ptr [eax],al
  10007707: add         byte ptr [esi],al
  10007709: add         bh,byte ptr es:[ebx+61h]
  1000770D: add         dword ptr [eax],eax
  1000770F: add         al,16h
  10007711: add         edx,dword ptr cs:[edi]
  10007714: sub         eax,dword ptr [ecx]
  10007716: push        ss
  10007717: adc         esi,dword ptr [ebx]
  10007719: adc         cl,byte ptr [ebx+12h]
  1000771C: or          ch,byte ptr [eax]
  1000771E: mov         dword ptr [eax],eax
  10007720: add         byte ptr [esi],al
  10007722: adc         cl,byte ptr es:[edx+11h]
  10007726: xor         edx,dword ptr [edx+1Fh]
  10007729: adc         byte ptr [eax],ch
  1000772B: sbb         eax,13060001h
  10007730: pop         ss
  10007731: adc         dword ptr [edi],edx
  10007733: sub         al,69h
  10007735: adc         cl,byte ptr [ecx+13h]
  10007738: xor         al,byte ptr [ebx]
  1000773A: sub         byte ptr [edi],ah
  1000773C: add         byte ptr [eax],al
  1000773E: or          ch,byte ptr [eax]
  10007740: and         eax,280A0000h
  10007745: xor         byte ptr [eax],al
  10007747: add         byte ptr [edx],cl
  10007749: sub         byte ptr [ebx],dh
  1000774B: add         byte ptr [eax],al
  1000774D: or          dl,byte ptr [ebx]
  1000774F: dec         eax
  10007750: adc         cl,byte ptr [ecx+12h]
  10007753: dec         eax
  10007754: sub         byte ptr [ebx],ch
  10007756: add         byte ptr [eax],al
  10007758: or          dl,byte ptr [edx+edx+47h]
  1000775C: adc         eax,dword ptr [esi+3]
  1000775F: sub         byte ptr [ecx],ch
  10007761: add         byte ptr [eax],al
  10007763: or          ch,byte ptr [edi+36h]
  10007766: add         byte ptr [eax],al
  10007768: or          ch,byte ptr [eax]
  1000776A: xor         byte ptr [eax],al
  1000776C: add         byte ptr [edx],cl
  1000776E: sub         byte ptr [ebx],dh
  10007770: add         byte ptr [eax],al
  10007772: or          dl,byte ptr [ebx]
  10007774: inc         ebp
  10007775: adc         al,byte ptr [edi+12h]
  10007778: inc         ebp
  10007779: sub         byte ptr [ebx],ch
  1000777B: add         byte ptr [eax],al
  1000777D: or          dl,byte ptr [esi+ebx*8+0Eh]
  10007781: inc         byte ptr [esi]
  10007783: pop         esi
  10007784: add         byte ptr [eax],al
  10007786: push        es
  10007787: adc         dword ptr [edx],esi
  10007789: sub         byte ptr [ebx],al
  1000778B: add         dword ptr [eax],eax
  1000778D: push        es
  1000778E: fcom        qword ptr [ecx]
  10007790: pop         ss
  10007791: adc         al,byte ptr [edi+12h]
  10007794: dec         ecx
  10007795: sub         byte ptr [ecx+13060000h],ch
  1000779B: or          esi,ebx
  1000779D: or          eax,0DE091316h
  100077A2: or          byte ptr [ecx],dl
  100077A4: pop         ss
  100077A5: sub         byte ptr [esi],bl
  100077A7: add         dword ptr [eax],eax
  100077A9: push        es
  100077AA: fcom        qword ptr [edx]
  100077AC: inc         esp
  100077AD: adc         dword ptr [ecx],ecx
  100077AF: push        esp
  100077B0: adc         dword ptr [ecx],ecx
  100077B2: adc         dword ptr [edx+edx],eax
  100077B5: dec         esp
  100077B6: sub         byte ptr [eax],bl
  100077B9: add         byte ptr [esi],al
  100077BB: adc         dword ptr [edi+ebx],eax
  100077BE: adc         byte ptr [eax+13h],bl
  100077C1: and         al,11h
  100077C3: and         al,4Ah
  100077C5: sub         al,0Eh
  100077C7: adc         al,byte ptr [ebx+11h]
  100077CA: and         al,4Ah
  100077CC: pop         ds
  100077CD: sbb         dh,bh
  100077CF: pop         ss
  100077D0: cmp         byte ptr [edi],cl
  100077D2: add         dword ptr [eax],eax
  100077D4: add         byte ptr [edx],al
  100077D6: jnp         10007839
  100077D8: add         dword ptr [eax],eax
  100077DA: add         al,13h
  100077DC: inc         edx
  100077DD: adc         al,byte ptr [edx+4Ah]
  100077E0: adc         eax,dword ptr [ecx+12h]
  100077E3: inc         ecx
  100077E4: dec         edx
  100077E5: cmp         dword ptr [eax+12000000h],edi
  100077EB: inc         ecx
  100077EC: dec         edx
  100077ED: pop         ss
  100077EE: ins         dword ptr es:[edi],dx
  100077F0: adc         al,byte ptr [ecx+4Ah]
  100077F3: sbb         byte ptr [esi],ch
  100077F5: and         dl,byte ptr [edi]
  100077F7: lea         ebx,ds:[13010000h]
  100077FD: and         edx,dword ptr [ecx]
  100077FF: and         edx,dword ptr [esi]
  10007801: adc         al,byte ptr [edx+4Ah]
  10007804: mov         word ptr [eax],fs
  10007806: add         byte ptr [eax],al
  10007808: add         dword ptr [edx+002B7217h],esp
  1000780E: add         byte ptr [eax+11h],dh
  10007811: and         esi,dword ptr [ebx+16h]
  10007814: add         byte ptr [eax],al
  10007816: or          bh,byte ptr [edx+12h]
  10007819: inc         ebx
  1000781A: and         ch,byte ptr [edi+12h]
  1000781D: add         edi,dword ptr [ebx]
  1000781F: push        esi
  10007820: adc         al,byte ptr [ebx+1Ah]
  10007823: pop         eax
  10007824: and         ah,byte ptr [esi+563B449Bh]
  1000782A: adc         al,byte ptr [ebx+1Eh]
  1000782D: pop         eax
  1000782E: and         cl,byte ptr [edx]
  10007830: xlat        byte ptr [ebx]
  10007831: and         edi,dword ptr [esi+edx*2]
  10007834: adc         al,byte ptr [ebx+1Fh]
  10007837: or          al,58h
  10007839: and         ch,byte ptr [edi+12h]
  1000783C: cmp         dword ptr [edx],56h
  1000783F: adc         al,byte ptr [ebx+1Fh]
  10007842: adc         byte ptr [eax+22h],bl
  10007845: add         byte ptr [eax],al
  10007847: cmp         byte ptr [edi],56h
  1000784A: adc         al,byte ptr [ebx+1Fh]
  1000784D: adc         al,58h
  1000784F: pop         ss
  10007850: push        edx
  10007851: adc         al,byte ptr [ebx+1Fh]
  10007854: adc         eax,38521758h
  10007859: lds         eax,fword ptr [eax]
  1000785B: add         byte ptr [eax],al
  1000785D: adc         al,byte ptr [ebx+22h]
  10007860: outs        dx,dword ptr [esi]
  10007861: adc         al,byte ptr [ebx]
  10007863: cmp         edx,dword ptr [esi+12h]
  10007866: inc         ebx
  10007867: sbb         bl,byte ptr [eax+22h]
  1000786A: cmps        byte ptr [esi],byte ptr es:[edi]
  1000786B: wait
  1000786C: inc         esp
  1000786D: cmp         edx,dword ptr [esi+12h]
  10007870: inc         ebx
  10007871: push        ds
  10007872: pop         eax
  10007873: and         cl,byte ptr [edx]
  10007875: xlat        byte ptr [ebx]
  10007876: and         edi,dword ptr [esi+edx*2]
  10007879: adc         al,byte ptr [ebx+1Fh]
  1000787C: or          al,58h
  1000787E: and         ch,byte ptr [edi+12h]
  10007881: cmp         dword ptr [edx],56h
  10007884: adc         al,byte ptr [ebx+1Fh]
  10007887: adc         byte ptr [eax+22h],bl
  1000788A: add         byte ptr [eax],al
  1000788C: cmp         byte ptr [edi],56h
  1000788F: adc         al,byte ptr [ebx+1Fh]
  10007892: adc         al,58h
  10007894: pop         ss
  10007895: push        edx
  10007896: adc         al,byte ptr [ebx+1Fh]
  10007899: adc         eax,38521758h
  1000789E: add         byte ptr [eax],0
  100078A1: add         byte ptr [edx],dl
  100078A3: inc         ebx
  100078A4: and         ch,byte ptr [edi+12h]
  100078A7: add         edi,dword ptr [ebx]
  100078A9: push        esi
  100078AA: adc         al,byte ptr [ebx+1Ah]
  100078AD: pop         eax
  100078AE: and         ah,byte ptr [esi+563B449Bh]
  100078B4: adc         al,byte ptr [ebx+1Eh]
  100078B7: pop         eax
  100078B8: and         cl,byte ptr [edx]
  100078BA: xlat        byte ptr [ebx]
  100078BB: and         edi,dword ptr [esi+edx*2]
  100078BE: adc         al,byte ptr [ebx+1Fh]
  100078C1: or          al,58h
  100078C3: and         ch,byte ptr [edi+12h]
  100078C6: cmp         dword ptr [edx],56h
  100078C9: adc         al,byte ptr [ebx+1Fh]
  100078CC: adc         byte ptr [eax+22h],bl
  100078CF: add         byte ptr [eax],al
  100078D1: cmp         byte ptr [edi],56h
  100078D4: adc         al,byte ptr [ebx+1Fh]
  100078D7: adc         al,58h
  100078D9: pop         ss
  100078DA: push        edx
  100078DB: adc         al,byte ptr [ebx+1Fh]
  100078DE: adc         eax,2B521758h
  100078E3: adc         al,byte ptr ds:[ebx+1Fh]
  100078E7: adc         eax,362D4758h
  100078EC: adc         al,byte ptr [ebx+1Fh]
  100078EF: adc         al,58h
  100078F1: inc         edi
  100078F2: sub         eax,1F43122Eh
  100078F7: adc         al,58h
  100078F9: pop         ss
  100078FA: push        edx
  100078FB: adc         al,byte ptr [ebx+22h]
  100078FE: add         byte ptr [eax],al
  10007900: add         byte ptr [eax],al
  10007902: push        esi
  10007903: adc         al,byte ptr [ebx+1Ah]
  10007906: pop         eax
  10007907: and         al,byte ptr [eax]
  10007909: add         byte ptr [eax],al
  1000790B: add         byte ptr [esi+12h],dl
  1000790E: inc         ebx
  1000790F: push        ds
  10007910: pop         eax
  10007911: and         al,byte ptr [eax]
  10007913: add         byte ptr [eax],al
  10007915: add         byte ptr [esi+12h],dl
  10007918: inc         ebx
  10007919: pop         ds
  1000791A: adc         byte ptr [eax+22h],bl
  1000791D: add         byte ptr [eax],al
  1000791F: cmp         byte ptr [edi],56h
  10007922: adc         dword ptr [edx+ebx],eax
  10007925: pop         eax
  10007926: adc         esi,dword ptr [ecx]
  10007928: adc         dword ptr [edx],ecx
  1000792A: sbb         bl,byte ptr [eax+13h]
  1000792D: xor         byte ptr [edx],dl
  1000792F: dec         ebx
  10007930: adc         dword ptr [eax],esi
  10007932: adc         dword ptr [ecx],esi
  10007934: dec         edx
  10007935: sub         byte ptr [ecx],bh
  10007937: add         byte ptr [eax],al
  10007939: push        es
  1000793A: adc         dword ptr [esi+ebx],eax
  1000793D: pop         eax
  1000793E: or          eax,581E0A11h
  10007943: adc         cl,byte ptr [edx+9]
  10007946: dec         edx
  10007947: sub         byte ptr [ebx],al
  10007949: add         byte ptr [eax],al
  1000794B: push        es
  1000794C: push        esp
  1000794D: adc         dword ptr [edx],ecx
  1000794F: pop         ds
  10007950: or          al,58h
  10007952: adc         cl,byte ptr [edx+11h]
  10007955: add         al,1Fh
  10007957: or          al,58h
  10007959: dec         edx
  1000795A: sub         byte ptr [ebx],al
  1000795C: add         byte ptr [eax],al
  1000795E: push        es
  1000795F: push        esp
  10007960: adc         dword ptr [edi+ebx],eax
  10007963: adc         al,58h
  10007965: adc         ecx,dword ptr [esi]
  10007967: adc         dword ptr [esi],ecx
  10007969: dec         edx
  1000796A: adc         ebp,dword ptr [edi]
  1000796C: adc         dword ptr [edx],ecx
  1000796E: pop         ds
  1000796F: adc         al,58h
  10007971: adc         edx,dword ptr [esi]
  10007973: adc         dword ptr [esi],edx
  10007975: adc         ebp,dword ptr [esi]
  10007977: adc         cl,byte ptr [ebx+11h]
  1000797A: sbb         dl,byte ptr cs:[ecx]
  1000797D: das
  1000797E: sub         byte ptr [esi],al
  10007980: add         byte ptr [eax],al
  10007982: push        es
  10007983: adc         dword ptr es:[esi],ecx
  10007986: dec         edx
  10007987: adc         esp,dword ptr [edx]
  10007989: adc         cl,byte ptr [edx+47h]
  1000798C: sub         al,28h
  1000798E: adc         ch,byte ptr ds:[58192212h]
  10007994: inc         edi
  10007995: push        edx
  10007996: adc         ch,byte ptr ds:[22125817h]
  1000799C: sbb         byte ptr [eax+47h],bl
  1000799F: push        edx
  100079A0: adc         ch,byte ptr ds:[22125818h]
  100079A6: pop         ss
  100079A7: pop         eax
  100079A8: inc         edi
  100079A9: push        edx
  100079AA: adc         ch,byte ptr ds:[22125819h]
  100079B0: inc         edi
  100079B1: push        edx
  100079B2: adc         dword ptr ds:[0A112213h],ebp
  100079B8: pop         ds
  100079B9: adc         byte ptr [eax+11h],bl
  100079BC: and         dl,byte ptr [esi+edx+13h]
  100079C0: pop         es
  100079C1: adc         dword ptr [esi],ecx
  100079C3: dec         edx
  100079C4: adc         edx,dword ptr ds:[37151116h]
  100079CA: add         eax,501DDh
  100079CF: add         byte ptr [ecx],dl
  100079D1: add         al,1Fh
  100079D3: sbb         byte ptr [eax+13h],bl
  100079D6: sub         al,11h
  100079D8: pop         es
  100079D9: sbb         bl,byte ptr [edx+11h]
  100079DC: sub         al,4Ah
  100079DE: pop         eax
  100079DF: dec         edx
  100079E0: or          dl,byte ptr [edx]
  100079E2: inc         eax
  100079E3: push        ss
  100079E4: push        esp
  100079E5: adc         al,byte ptr [eax+1Ah]
  100079E8: pop         eax
  100079E9: push        ss
  100079EA: push        esp
  100079EB: adc         al,byte ptr [eax+1Eh]
  100079EE: pop         eax
  100079EF: push        ss
  100079F0: push        esp
  100079F1: push        es
  100079F2: dec         edx
  100079F3: adc         esp,dword ptr [ecx]
  100079F5: adc         dword ptr [ecx],esp
  100079F7: and         byte ptr [eax],ah
  100079F9: fld         qword ptr [edx-0Ah]
  100079FC: cmp         esi,dword ptr [esi]
  100079FE: add         dword ptr [eax],eax
  10007A00: add         byte ptr [ecx],dl
  10007A02: and         dword ptr [eax],esp
  10007A04: cmc
  10007A05: mov         ss,dx
  10007A07: push        eax
  10007A08: add         eax,44CDDh
  10007A0E: add         byte ptr [edx],dl
  10007A10: aas
  10007A11: sbb         bl,byte ptr [eax+13h]
  10007A14: adc         bh,byte ptr ds:[edi]
  10007A17: sbb         bl,byte ptr [eax+16h]
  10007A1A: push        esp
  10007A1B: adc         bh,byte ptr [edi]
  10007A1D: push        ds
  10007A1E: pop         eax
  10007A1F: push        ss
  10007A20: push        esp
  10007A21: adc         bh,byte ptr [edi]
  10007A23: pop         ds
  10007A24: or          al,58h
  10007A26: push        ss
  10007A27: push        esp
  10007A28: adc         bh,byte ptr [edi]
  10007A2A: push        ss
  10007A2B: push        esp
  10007A2C: push        es
  10007A2D: sbb         bl,byte ptr [eax+4Ah]
  10007A30: adc         edx,dword ptr [ecx+edx]
  10007A33: adc         al,16h
  10007A35: das
  10007A36: add         eax,451DDh
  10007A3B: add         byte ptr [ecx],dl
  10007A3D: adc         al,18h
  10007A3F: xor         dword ptr [esi],ebx
  10007A41: adc         dword ptr [edx+ebx],edx
  10007A44: add         eax,442DDh
  10007A4A: add         byte ptr [edx],ah
  10007A4C: add         byte ptr [eax],al
  10007A4E: cmp         byte ptr [edi],13h
  10007A51: cmp         eax,581A3F12h
  10007A56: adc         bh,byte ptr ds:[00001828h]
  10007A5C: push        es
  10007A5D: sub         edx,dword ptr [edx]
  10007A5F: and         al,byte ptr [eax]
  10007A61: add         byte ptr [eax],al
  10007A63: add         byte ptr [ebx],dl
  10007A65: cmp         al,12h
  10007A67: aas
  10007A68: sbb         bl,byte ptr [eax+12h]
  10007A6B: cmp         al,28h
  10007A6D: sbb         byte ptr [eax],al
  10007A6F: add         byte ptr [esi],al
  10007A71: adc         bh,byte ptr [edi]
  10007A73: pop         ds
  10007A74: adc         al,58h
  10007A76: push        ss
  10007A77: push        edx
  10007A78: adc         al,byte ptr [eax+9]
  10007A7B: dec         edx
  10007A7C: adc         bh,byte ptr [edi]
  10007A7E: sub         byte ptr [edi+16060000h],al
  10007A84: adc         ecx,dword ptr ds:[344A0916h]
  10007A8A: pop         ds
  10007A8B: push        ss
  10007A8C: adc         edx,dword ptr [ebx]
  10007A8E: adc         dword ptr [ebx],edx
  10007A90: adc         al,byte ptr [eax+4Ah]
  10007A93: pop         eax
  10007A94: adc         dword ptr ds:[170D1154h],ecx
  10007A9A: pop         eax
  10007A9B: adc         ecx,dword ptr ds:[181F1311h]
  10007AA1: pop         eax
  10007AA2: adc         edx,dword ptr [ebx]
  10007AA4: adc         dword ptr ds:[E4374A09h],ecx
  10007AAA: push        ss
  10007AAB: adc         eax,dword ptr [esi]
  10007AAD: push        es
  10007AAE: pop         ds
  10007AAF: adc         byte ptr [eax+4Ah],bl
  10007AB2: adc         edx,dword ptr [edx]
  10007AB4: push        ss
  10007AB5: adc         dword ptr [edx],edx
  10007AB7: xor         al,4Fh
  10007AB9: push        es
  10007ABA: pop         ds
  10007ABB: adc         al,58h
  10007ABD: adc         ebp,dword ptr [ebx]
  10007ABF: adc         dword ptr [esi],eax
  10007AC1: push        ds
  10007AC2: pop         edx
  10007AC3: adc         dword ptr [ebx],ebp
  10007AC5: dec         edx
  10007AC6: pop         eax
  10007AC7: adc         esp,dword ptr [eax]
  10007AC9: adc         al,byte ptr [eax+4Ah]
  10007ACC: push        es
  10007ACD: push        ds
  10007ACE: pop         eax
  10007ACF: dec         edx
  10007AD0: adc         dword ptr [esi],eax
  10007AD2: pop         eax
  10007AD3: pop         ds
  10007AD4: sbb         byte ptr [edx+58h],bl
  10007AD7: sbb         bl,byte ptr [eax+4Ah]
  10007ADA: adc         dword ptr [eax],esp
  10007ADC: dec         esi
  10007ADD: push        esi
  10007ADE: adc         al,byte ptr [eax+4Ah]
  10007AE1: push        es
  10007AE2: push        ds
  10007AE3: pop         eax
  10007AE4: dec         edx
  10007AE5: adc         dword ptr [esi],eax
  10007AE7: pop         eax
  10007AE8: pop         ds
  10007AE9: sbb         byte ptr [edx+58h],bl
  10007AEC: pop         ds
  10007AED: adc         al,58h
  10007AEF: adc         dword ptr [eax],esp
  10007AF1: sbb         bl,byte ptr [eax+47h]
  10007AF4: push        edx
  10007AF5: adc         dword ptr [esi],eax
  10007AF7: pop         ss
  10007AF8: pop         eax
  10007AF9: adc         eax,dword ptr [esi]
  10007AFB: push        es
  10007AFC: pop         ds
  10007AFD: adc         byte ptr [eax+4Ah],bl
  10007B00: adc         edx,dword ptr [edx]
  10007B02: adc         dword ptr [esi],eax
  10007B04: adc         dword ptr [edx],edx
  10007B06: aaa
  10007B07: mov         bh,0DEh
  10007B09: push        cs
  10007B0A: inc         byte ptr [esi]
  10007B0C: push        ds
  10007B0D: add         byte ptr [eax],al
  10007B0F: push        es
  10007B10: adc         bh,byte ptr [edi]
  10007B12: sub         byte ptr [ebx],al
  10007B14: add         dword ptr [eax],eax
  10007B16: push        es
  10007B17: fcom        qword ptr [edx]
  10007B19: aas
  10007B1A: sbb         bl,byte ptr [eax+13h]
  10007B1D: cmp         edx,dword ptr [edx]
  10007B1F: aas
  10007B20: sbb         bl,byte ptr [eax+4Ah]
  10007B23: cmp         ebx,ebp
  10007B25: add         dword ptr [eax],eax
  10007B27: add         byte ptr [edx],dl
  10007B29: aas
  10007B2A: sbb         bl,byte ptr [eax+4Ah]
  10007B2D: sub         byte ptr [edi],bl
  10007B2F: add         dword ptr [eax],eax
  10007B31: push        es
  10007B32: cmp         ah,bl
  10007B34: add         dword ptr [eax],eax
  10007B36: add         byte ptr [edx],dl
  10007B38: cmp         bl,byte ptr [edx]
  10007B3A: pop         eax
  10007B3B: adc         edi,dword ptr [ecx]
  10007B3D: adc         bh,byte ptr [edx]
  10007B3F: sbb         bl,byte ptr [eax+16h]
  10007B42: push        esp
  10007B43: adc         bh,byte ptr [edx]
  10007B45: push        ds
  10007B46: pop         eax
  10007B47: push        ss
  10007B48: push        esp
  10007B49: adc         bh,byte ptr [edx]
  10007B4B: pop         ds
  10007B4C: or          al,58h
  10007B4E: push        ss
  10007B4F: push        esp
  10007B50: adc         bh,byte ptr [edx]
  10007B52: push        ss
  10007B53: push        esp
  10007B54: and         al,byte ptr [eax]
  10007B56: add         byte ptr [eax],al
  10007B58: add         byte ptr [ebx],dl
  10007B5A: cmp         byte ptr [edx],dl
  10007B5C: cmp         bl,byte ptr [esi]
  10007B5E: pop         eax
  10007B5F: dec         edx
  10007B60: adc         bh,byte ptr [edx]
  10007B62: pop         ds
  10007B63: or          al,58h
  10007B65: dec         edx
  10007B66: xor         al,21h
  10007B68: adc         bh,byte ptr [edx]
  10007B6A: push        ds
  10007B6B: pop         eax
  10007B6C: dec         edx
  10007B6D: adc         ebx,dword ptr [edi]
  10007B6F: adc         bh,byte ptr [edx]
  10007B71: push        ds
  10007B72: pop         eax
  10007B73: adc         bh,byte ptr [edx]
  10007B75: push        ds
  10007B76: pop         eax
  10007B77: dec         edx
  10007B78: sbb         bl,byte ptr [eax+54h]
  10007B7B: adc         dword ptr [edi],ebx
  10007B7D: sub         al,1Ah
  10007B7F: adc         dword ptr [edi],ebx
  10007B81: and         al,byte ptr [eax]
  10007B83: add         byte ptr [eax],al
  10007B85: add         byte ptr [esi+2Bh],dl
  10007B88: adc         byte ptr [edx],dl
  10007B8A: cmp         bl,byte ptr [edx]
  10007B8C: pop         eax
  10007B8D: adc         bh,byte ptr [edx]
  10007B8F: push        ds
  10007B90: pop         eax
  10007B91: dec         edx
  10007B92: adc         bh,byte ptr [eax]
  10007B94: sub         byte ptr [ecx],ah
  10007B96: add         byte ptr [eax],al
  10007B98: push        es
  10007B99: and         al,byte ptr [eax]
  10007B9B: add         byte ptr [eax],al
  10007B9D: add         byte ptr [ebx],dl
  10007B9F: aaa
  10007BA0: adc         bh,byte ptr [edx]
  10007BA2: push        ds
  10007BA3: pop         eax
  10007BA4: dec         edx
  10007BA5: adc         bh,byte ptr [edx]
  10007BA7: pop         ds
  10007BA8: or          al,58h
  10007BAA: dec         edx
  10007BAB: xor         al,21h
  10007BAD: adc         bh,byte ptr [edx]
  10007BAF: push        ds
  10007BB0: pop         eax
  10007BB1: dec         edx
  10007BB2: adc         ebx,dword ptr [esi]
  10007BB4: adc         bh,byte ptr [edx]
  10007BB6: push        ds
  10007BB7: pop         eax
  10007BB8: adc         bh,byte ptr [edx]
  10007BBA: push        ds
  10007BBB: pop         eax
  10007BBC: dec         edx
  10007BBD: sbb         bl,byte ptr [eax+54h]
  10007BC0: adc         dword ptr [esi],ebx
  10007BC2: sub         al,1Ah
  10007BC4: adc         dword ptr [esi],ebx
  10007BC6: and         al,byte ptr [eax]
  10007BC8: add         byte ptr [eax],al
  10007BCA: add         byte ptr [esi+2Bh],dl
  10007BCD: adc         byte ptr [edx],dl
  10007BCF: cmp         bl,byte ptr [edx]
  10007BD1: pop         eax
  10007BD2: adc         bh,byte ptr [edx]
  10007BD4: push        ds
  10007BD5: pop         eax
  10007BD6: dec         edx
  10007BD7: adc         dh,byte ptr [edi]
  10007BD9: sub         byte ptr [ecx],ah
  10007BDB: add         byte ptr [eax],al
  10007BDD: push        es
  10007BDE: and         al,byte ptr [eax]
  10007BE0: add         byte ptr [eax],al
  10007BE2: add         byte ptr [ebx],dl
  10007BE4: adc         bh,byte ptr ss:[edx]
  10007BE7: sbb         bl,byte ptr [eax+12h]
  10007BEA: sub         byte ptr ss:[eax],bl
  10007BED: add         byte ptr [eax],al
  10007BEF: push        es
  10007BF0: and         al,byte ptr [eax]
  10007BF2: add         byte ptr [eax+1235133Fh],al
  10007BF8: cmp         bl,byte ptr [edx]
  10007BFA: pop         eax
  10007BFB: adc         dh,byte ptr ds:[00001828h]
  10007C01: push        es
  10007C02: adc         bh,byte ptr [edx]
  10007C04: pop         ds
  10007C05: adc         al,58h
  10007C07: push        ss
  10007C08: push        edx
  10007C09: adc         al,byte ptr [eax+9]
  10007C0C: dec         edx
  10007C0D: adc         bh,byte ptr [edx]
  10007C0F: sub         byte ptr [edi+16060000h],al
  10007C15: adc         ecx,dword ptr [esi+edx]
  10007C18: or          dword ptr [edx+34h],ecx
  10007C1B: pop         ds
  10007C1C: push        ss
  10007C1D: adc         edx,dword ptr [ecx]
  10007C1F: adc         dword ptr [ecx],edx
  10007C21: adc         al,byte ptr [eax+4Ah]
  10007C24: pop         eax
  10007C25: adc         dword ptr [esp+edx*2],ecx
  10007C28: adc         dword ptr [edi+edx],ecx
  10007C2B: pop         eax
  10007C2C: adc         ecx,dword ptr [ecx+edx]
  10007C2F: adc         dword ptr [edi],ebx
  10007C31: sbb         byte ptr [eax+13h],bl
  10007C34: adc         dword ptr [ecx],edx
  10007C36: or          al,9
  10007C38: dec         edx
  10007C39: aaa
  10007C3A: in          al,16h
  10007C3C: or          al,6
  10007C3E: pop         ds
  10007C3F: adc         byte ptr [eax+4Ah],bl
  10007C42: adc         edx,dword ptr [eax]
  10007C44: push        ss
  10007C45: adc         dword ptr [eax],edx
  10007C47: inc         ecx
  10007C48: mov         al,byte ptr ds:[06000000h]
  10007C4D: pop         ds
  10007C4E: adc         al,58h
  10007C50: adc         ebp,dword ptr [edx]
  10007C52: push        ss
  10007C53: adc         ecx,dword ptr [edi]
  10007C55: adc         dword ptr [edi],ecx
  10007C57: adc         dword ptr [edx],ebp
  10007C59: dec         edx
  10007C5A: pop         eax
  10007C5B: adc         ecx,dword ptr [eax]
  10007C5D: adc         al,byte ptr [eax+4Ah]
  10007C60: push        es
  10007C61: push        ds
  10007C62: pop         eax
  10007C63: dec         edx
  10007C64: or          byte ptr [eax+1Fh],bl
  10007C67: sbb         byte ptr [edx+58h],bl
  10007C6A: sbb         bl,byte ptr [eax+4Ah]
  10007C6D: adc         dword ptr [eax],ecx
  10007C6F: dec         esi
  10007C70: push        esi
  10007C71: adc         al,byte ptr [eax+4Ah]
  10007C74: push        es
  10007C75: push        ds
  10007C76: pop         eax
  10007C77: dec         edx
  10007C78: or          byte ptr [eax+1Fh],bl
  10007C7B: sbb         byte ptr [edx+58h],bl
  10007C7E: sbb         bl,byte ptr [eax+4Ah]
  10007C81: sbb         bl,byte ptr [eax+11h]
  10007C84: or          byte ptr [edx],bl
  10007C86: pop         eax
  10007C87: dec         esi
  10007C88: push        esi
  10007C89: adc         al,byte ptr [eax+4Ah]
  10007C8C: push        es
  10007C8D: push        ds
  10007C8E: pop         eax
  10007C8F: dec         edx
  10007C90: or          byte ptr [eax+1Fh],bl
  10007C93: sbb         byte ptr [edx+58h],bl
  10007C96: sbb         bl,byte ptr [eax+4Ah]
  10007C99: push        ds
  10007C9A: pop         eax
  10007C9B: adc         dword ptr [eax],ecx
  10007C9D: push        ds
  10007C9E: pop         eax
  10007C9F: dec         esi
  10007CA0: push        esi
  10007CA1: adc         al,byte ptr [eax+4Ah]
  10007CA4: push        es
  10007CA5: push        ds
  10007CA6: pop         eax
  10007CA7: dec         edx
  10007CA8: or          byte ptr [eax+1Fh],bl
  10007CAB: sbb         byte ptr [edx+58h],bl
  10007CAE: sbb         bl,byte ptr [eax+4Ah]
  10007CB1: pop         ds
  10007CB2: or          al,58h
  10007CB4: adc         dword ptr [eax],ecx
  10007CB6: pop         ds
  10007CB7: or          al,58h
  10007CB9: dec         esi
  10007CBA: push        esi
  10007CBB: adc         al,byte ptr [eax+4Ah]
  10007CBE: push        es
  10007CBF: push        ds
  10007CC0: pop         eax
  10007CC1: dec         edx
  10007CC2: or          byte ptr [eax+1Fh],bl
  10007CC5: sbb         byte ptr [edx+58h],bl
  10007CC8: pop         ds
  10007CC9: adc         al,58h
  10007CCB: adc         dword ptr [eax],ecx
  10007CCD: pop         ds
  10007CCE: adc         byte ptr [eax+47h],bl
  10007CD1: push        edx
  10007CD2: or          byte ptr [edi],dl
  10007CD4: pop         eax
  10007CD5: or          al,11h
  10007CD7: nop         dword ptr [eax+ebx*2]
  10007CDB: adc         ecx,dword ptr [edi]
  10007CDD: push        es
  10007CDE: pop         ds
  10007CDF: adc         byte ptr [eax+4Ah],bl
  10007CE2: adc         edx,dword ptr [eax]
  10007CE4: or          byte ptr [ecx],dl
  10007CE6: adc         byte ptr [ecx+ebp*2-1],al
  10007CEA: FF
  10007CEB: call        rsi
  10007CED: push        cs
  10007CEE: inc         byte ptr [esi]
  10007CF0: push        ds
  10007CF1: add         byte ptr [eax],al
  10007CF3: push        es
  10007CF4: adc         bh,byte ptr [edx]
  10007CF6: sub         byte ptr [ebx],al
  10007CF8: add         dword ptr [eax],eax
  10007CFA: push        es
  10007CFB: fcom        qword ptr [edx]
  10007CFD: cmp         bl,byte ptr [edx]
  10007CFF: pop         eax
  10007D00: adc         esi,dword ptr [edx+edx]
  10007D03: cmp         bl,byte ptr [edx]
  10007D05: pop         eax
  10007D06: dec         edx
  10007D07: sub         al,0Ah
  10007D09: adc         bh,byte ptr [edx]
  10007D0B: sbb         bl,byte ptr [eax+4Ah]
  10007D0E: sub         byte ptr [edi],bl
  10007D10: add         dword ptr [eax],eax
  10007D12: push        es
  10007D13: push        ss
  10007D14: adc         eax,dword ptr ds:[43120B16h]
  10007D1A: pop         ds
  10007D1B: adc         eax,162C4758h
  10007D20: push        es
  10007D21: adc         al,byte ptr [eax+12h]
  10007D24: inc         ebx
  10007D25: sub         byte ptr [edx],dl
  10007D27: add         byte ptr [eax],al
  10007D29: push        es
  10007D2A: or          eax,dword ptr [edi]
  10007D2C: sub         al,8
  10007D2E: adc         al,byte ptr [ebx+1Fh]
  10007D31: adc         al,58h
  10007D33: inc         edi
  10007D34: sub         al,0Ch
  10007D36: push        es
  10007D37: adc         al,byte ptr [eax+12h]
  10007D3A: inc         ebx
  10007D3B: sub         byte ptr [esi],cl
  10007D3D: add         byte ptr [eax],al
  10007D3F: push        es
  10007D40: adc         eax,dword ptr ds:[11272C07h]
  10007D46: add         eax,5110F2Ch
  10007D4B: sub         byte ptr [edi],cl
  10007D4D: add         byte ptr [eax],al
  10007D4F: push        es
  10007D50: pop         es
  10007D51: sub         byte ptr [eax+eax],dl
  10007D54: add         byte ptr [esi],al
  10007D56: aaa
  10007D57: adc         al,7
  10007D59: adc         cl,byte ptr [ebx+12h]
  10007D5C: dec         edx
  10007D5D: adc         dword ptr [edi],eax
  10007D5F: sbb         bl,byte ptr [edx+11h]
  10007D62: push        ss
  10007D63: dec         edx
  10007D64: pop         eax
  10007D65: sub         byte ptr ds:[2B060000h],dl
  10007D6B: adc         edx,dword ptr [ecx]
  10007D6D: add         eax,4A124B12h
  10007D72: adc         dword ptr [edi],eax
  10007D74: sbb         bl,byte ptr [edx+11h]
  10007D77: push        ss
  10007D78: dec         edx
  10007D79: pop         eax
  10007D7A: sub         byte ptr [eax],dl
  10007D7C: add         byte ptr [eax],al
  10007D7E: push        es
  10007D7F: adc         dword ptr ds:[0511092Ch],eax
  10007D85: pop         ss
  10007D86: sub         byte ptr [ebx],bl
  10007D89: add         byte ptr [esi],al
  10007D8B: pop         es
  10007D8D: adc         ebp,dword ptr [ecx]
  10007D8F: pop         es
  10007D90: sub         al,47h
  10007D92: pop         es
  10007D93: pop         ds
  10007D94: and         byte ptr [eax+13h],bl
  10007D97: sub         byte ptr [ecx],dl
  10007D99: sub         byte ptr [edx+13h],cl
  10007D9C: sbb         eax,22D1D11h
  10007DA1: ficomp      word ptr [edx]
  10007DA3: adc         dword ptr ds:[00011F28h],ebx
  10007DA9: push        es
  10007DAA: ficom       word ptr [ecx]
  10007DAC: inc         byte ptr [esi]
  10007DAE: push        ss
  10007DAF: add         byte ptr [eax],al
  10007DB1: push        es
  10007DB2: adc         dword ptr [ecx],ebp
  10007DB4: pop         ds
  10007DB5: or          al,58h
  10007DB7: sub         byte ptr [ebx],al
  10007DB9: add         dword ptr [eax],eax
  10007DBB: push        es
  10007DBC: fadd        qword ptr [edi]
  10007DBE: pop         ds
  10007DBF: or          al,58h
  10007DC1: adc         esp,dword ptr [edi]
  10007DC3: adc         dword ptr [edi],esp
  10007DC5: dec         edx
  10007DC6: adc         ebx,dword ptr [ecx+edx]
  10007DC9: sbb         al,2Ch
  10007DCB: pop         es
  10007DCC: adc         dword ptr [eax+ebp],ebx
  10007DCF: pop         ds
  10007DD0: add         dword ptr [eax],eax
  10007DD2: push        es
  10007DD3: pop         es
  10007DD4: sub         byte ptr [esi],bl
  10007DD6: add         dword ptr [eax],eax
  10007DD8: push        es
  10007DD9: fimul       word ptr [esi]
  10007DDB: inc         byte ptr [esi]
  10007DDD: sbb         dword ptr [eax],eax
  10007DDF: add         byte ptr [esi],al
  10007DE1: adc         al,byte ptr [eax+28h]
  10007DE4: add         eax,dword ptr [ecx]
  10007DE6: add         byte ptr [esi],al
  10007DE8: fadd        qword ptr [eax]
  10007DEA: adc         al,byte ptr [eax+1Ah]
  10007DED: pop         eax
  10007DEE: dec         edx
  10007DEF: adc         esp,dword ptr [esi]
  10007DF1: adc         al,byte ptr [eax+4Ah]
  10007DF4: adc         ecx,dword ptr [ebx]
  10007DF6: adc         al,byte ptr [eax+4Ah]
  10007DF9: adc         al,byte ptr [eax+1Ah]
  10007DFC: pop         eax
  10007DFD: dec         edx
  10007DFE: aaa
  10007DFF: add         bl,dh
  10007E01: xor         edx,dword ptr [ecx]
  10007E03: or          ebx,dword ptr [edx]
  10007E05: pop         eax
  10007E06: adc         esp,dword ptr ds:[134A2511h]
  10007E0C: sbb         edx,dword ptr [ecx]
  10007E0E: sbb         ebp,dword ptr [edi+eax]
  10007E11: adc         dword ptr [ebx],ebx
  10007E13: sub         byte ptr [edi],bl
  10007E15: add         dword ptr [eax],eax
  10007E17: push        es
  10007E18: adc         dword ptr [ebx],ecx
  10007E1A: pop         ds
  10007E1B: sbb         byte ptr [eax+13h],bl
  10007E1E: or          edx,dword ptr [ecx]
  10007E20: or          edx,dword ptr [ecx]
  10007E22: aaa
  10007E24: fstp        st(6)
  10007E26: push        cs
  10007E27: inc         byte ptr [esi]
  10007E29: and         al,0
  10007E2B: add         byte ptr [esi],al
  10007E2D: adc         al,byte ptr [eax+28h]
  10007E30: add         eax,dword ptr [ecx]
  10007E32: add         byte ptr [esi],al
  10007E34: fcom        qword ptr [edx]
  10007E36: inc         eax
  10007E37: dec         edx
  10007E38: sub         al,8
  10007E3A: adc         al,byte ptr [eax+4Ah]
  10007E3D: sub         byte ptr [edi],bl
  10007E3F: add         dword ptr [eax],eax
  10007E41: push        es
  10007E42: adc         dword ptr [edi],eax
  10007E44: pop         ss
  10007E45: pop         eax
  10007E46: adc         eax,dword ptr [edi]
  10007E48: adc         dword ptr [esi],ecx
  10007E4A: dec         edx
  10007E4B: adc         edx,dword ptr ds:[15110711h]
  10007E51: inc         esp
  10007E52: cmp         ebx,76DDFFFFh
  10007E58: add         byte ptr [eax],al
  10007E5A: add         byte ptr [eax],al
  10007E5C: pop         ss
  10007E5D: lea         ebx,ds:[13010000h]
  10007E63: sbb         dl,byte ptr [ecx]
  10007E65: sbb         dl,byte ptr [esi]
  10007E67: push        es
  10007E68: dec         edx
  10007E69: mov         word ptr ds:[A2010000h],fs
  10007E6F: pop         ss
  10007E70: jb          10007E4F
  10007E72: add         byte ptr [eax],al
  10007E74: jo          10007E87
  10007E76: sbb         dh,byte ptr [ebx+16h]
  10007E79: add         byte ptr [eax],al
  10007E7B: or          bh,byte ptr [edx-22h]
  10007E7E: push        cs
  10007E7F: inc         byte ptr [esi]
  10007E81: sbb         dword ptr [eax],eax
  10007E83: add         byte ptr [esi],al
  10007E85: adc         al,byte ptr [eax+28h]
  10007E88: add         eax,dword ptr [ecx]
  10007E8A: add         byte ptr [esi],al
  10007E8C: fadd        qword ptr [eax]
  10007E8E: pop         ss
  10007E8F: lea         ebx,ds:[13010000h]
  10007E95: sbb         dword ptr [ecx],edx
  10007E97: sbb         dword ptr [esi],edx
  10007E99: push        es
  10007E9A: sbb         bl,byte ptr [eax+4Ah]
  10007E9D: mov         word ptr ds:[A2010000h],fs
  10007EA3: pop         ss
  10007EA4: jb          10007F1B
  10007EA6: add         byte ptr [eax],al
  10007EA8: jo          10007EBB
  10007EAA: sbb         dword ptr [ebx+16h],esi
  10007EAD: add         byte ptr [eax],al
  10007EAF: or          bh,byte ptr [edx-22h]
  10007EB2: push        cs
  10007EB3: inc         byte ptr [esi]
  10007EB5: push        ds
  10007EB6: add         byte ptr [eax],al
  10007EB8: push        es
  10007EB9: adc         bh,byte ptr [edi]
  10007EBB: sub         byte ptr [ebx],al
  10007EBD: add         dword ptr [eax],eax
  10007EBF: push        es
  10007EC0: fcomp3      st(6)
  10007EC2: push        cs
  10007EC3: inc         byte ptr [esi]
  10007EC5: sbb         dword ptr [eax],eax
  10007EC7: add         byte ptr [esi],al
  10007EC9: adc         al,byte ptr [eax+28h]
  10007ECC: add         eax,dword ptr [ecx]
  10007ECE: add         byte ptr [esi],al
  10007ED0: fadd        qword ptr [eax]
  10007ED2: adc         cl,byte ptr [ebx+1Eh]
  10007ED5: pop         eax
  10007ED6: adc         cl,byte ptr [ebx+1Eh]
  10007ED9: pop         eax
  10007EDA: dec         edx
  10007EDB: sbb         bl,byte ptr [ecx+54h]
  10007EDE: jae         10007EFB
  10007EE0: add         byte ptr [eax],al
  10007EE2: or          dl,byte ptr [ebx]
  10007EE4: sbb         byte ptr [edx],al
  10007EE6: adc         cl,byte ptr [ebx+12h]
  10007EE9: dec         edx
  10007EEA: adc         dword ptr [eax],ebx
  10007EEC: sub         byte ptr [ecx+eax],al
  10007EF0: push        es
  10007EF1: fimul       word ptr [esi]
  10007EF3: inc         byte ptr [esi]
  10007EF5: push        ds
  10007EF6: add         byte ptr [eax],al
  10007EF8: push        es
  10007EF9: adc         bh,byte ptr [edi]
  10007EFB: sub         byte ptr [ebx],al
  10007EFD: add         dword ptr [eax],eax
  10007EFF: push        es
  10007F00: fcomp3      st(6)
  10007F02: push        cs
  10007F03: inc         byte ptr [esi]
  10007F05: sbb         dword ptr [eax],eax
  10007F07: add         byte ptr [esi],al
  10007F09: adc         al,byte ptr [eax+28h]
  10007F0C: add         eax,dword ptr [ecx]
  10007F0E: add         byte ptr [esi],al
  10007F10: fcomp3      st(6)
  10007F12: push        cs
  10007F13: inc         byte ptr [esi]
  10007F15: xor         al,0
  10007F17: add         byte ptr [esi],al
  10007F19: adc         al,byte ptr [eax+ebp+3]
  10007F1D: add         dword ptr [eax],eax
  10007F1F: push        es
  10007F20: fcom        qword ptr [ecx]
  10007F22: or          dword ptr ds:[111ADE02h],ebp
  10007F28: or          dword ptr ds:[78294A4Ah],esp
  10007F2E: add         byte ptr [eax],al
  10007F30: adc         esi,ebx
  10007F32: push        cs
  10007F33: inc         byte ptr [esi]
  10007F35: aaa
  10007F36: add         byte ptr [eax],al
  10007F38: push        es
  10007F39: adc         cl,byte ptr [ebx+28h]
  10007F3C: add         eax,dword ptr [ecx]
  10007F3E: add         byte ptr [esi],al
  10007F40: fcom        qword ptr [edx]
  10007F42: dec         ebx
  10007F43: sub         byte ptr [edi],dh
  10007F45: add         byte ptr [eax],al
  10007F47: push        es
  10007F48: fimul       word ptr [esi]
  10007F4A: inc         byte ptr [esi]
  10007F4C: aaa
  10007F4D: add         byte ptr [eax],al
  10007F4F: push        es
  10007F50: adc         cl,byte ptr [eax+ebp+3]
  10007F54: add         dword ptr [eax],eax
  10007F56: push        es
  10007F57: fcom        qword ptr [edx]
  10007F59: dec         esp
  10007F5A: sub         byte ptr [edi],dh
  10007F5C: add         byte ptr [eax],al
  10007F5E: push        es
  10007F5F: adc         dword ptr [eax],ebx
  10007F61: sub         al,byte ptr [eax]
  10007F63: add         byte ptr [ecx+6Ch],al
  10007F66: add         dword ptr [eax],eax
  10007F68: add         al,0
  10007F6A: add         byte ptr [eax],al
  10007F6C: pop         edx
  10007F6D: add         byte ptr [eax],al
  10007F6F: add         byte ptr [edi],ah
  10007F71: add         byte ptr [eax],al
  10007F73: add         byte ptr [ecx+0E000000h],al
  10007F79: add         byte ptr [eax],al
  10007F7B: add         byte ptr [edx],bh
  10007F7D: add         byte ptr [eax],al
  10007F7F: add         dword ptr [eax+eax],eax
  10007F82: add         byte ptr [eax],al
  10007F84: xor         dword ptr [eax],eax
  10007F86: add         byte ptr [eax],al
  10007F88: jb          10007F8A
  10007F8A: add         byte ptr [eax],al
  10007F8C: mov         dword ptr ds:[08000000h],eax
  10007F91: add         byte ptr [eax],al
  10007F93: add         byte ptr [edx],bh
  10007F95: add         byte ptr [eax],al
  10007F97: add         dword ptr [eax+eax],eax
  10007F9A: add         byte ptr [eax],al
  10007F9C: sub         byte ptr [ebx],al
  10007F9E: add         byte ptr [eax],al
  10007FA0: loop        10007FA2
  10007FA2: add         byte ptr [eax],al
  10007FA4: or          al,byte ptr [eax+eax]
  10007FA7: add         byte ptr [esi],cl
  10007FA9: add         byte ptr [eax],al
  10007FAB: add         byte ptr [edx],bh
  10007FAD: add         byte ptr [eax],al
  10007FAF: add         dword ptr [eax+eax],eax
  10007FB2: add         byte ptr [eax],al
  10007FB4: push        eax
  10007FB5: add         al,0
  10007FB7: add         byte ptr [esi+EE000001h],bl
  10007FBD: add         eax,0E0000h
  10007FC2: add         byte ptr [eax],al
  10007FC4: cmp         al,byte ptr [eax]
  10007FC6: add         byte ptr [ecx],al
  10007FC8: add         al,0
  10007FCA: add         byte ptr [eax],al
  10007FCC: xchg        eax,edx
  10007FCD: push        es
  10007FCE: add         byte ptr [eax],al
  10007FD0: sbb         al,byte ptr [eax]
  10007FD2: add         byte ptr [eax],al
  10007FD4: lods        byte ptr [esi]
  10007FD5: push        es
  10007FD6: add         byte ptr [eax],al
  10007FD8: adc         dword ptr [eax],eax
  10007FDA: add         byte ptr [eax],al
  10007FDC: cmp         al,byte ptr [eax]
  10007FDE: add         byte ptr [ecx],al
  10007FE0: add         al,0
  10007FE2: add         byte ptr [eax],al
  10007FE4: F1
  10007FE5: add         al,byte ptr [eax]
  10007FE7: add         dl,ch
  10007FE9: add         eax,dword ptr [eax]
  10007FEB: add         bl,bl
  10007FED: push        es
  10007FEE: add         byte ptr [eax],al
  10007FF0: push        cs
  10007FF1: add         byte ptr [eax],al
  10007FF3: add         byte ptr [edx],bh
  10007FF5: add         byte ptr [eax],al
  10007FF7: add         dword ptr [eax+eax],eax
  10007FFA: add         byte ptr [eax],al
  10007FFC: jmp         0000:3D000006
  10008003: add         byte ptr [edi],ah
  10008005: pop         es
  10008006: add         byte ptr [eax],al
  10008008: push        cs
  10008009: add         byte ptr [eax],al
  1000800B: add         byte ptr [edx],bh
  1000800D: add         byte ptr [eax],al
  1000800F: add         dword ptr [eax+eax],eax
  10008012: add         byte ptr [eax],al
  10008014: pop         esp
  10008015: pop         es
  10008016: add         byte ptr [eax],al
  10008018: and         eax,dword ptr [eax]
  1000801A: add         byte ptr [eax],al
  1000801C: jg          10008025
  1000801E: add         byte ptr [eax],al
  10008020: push        cs
  10008021: add         byte ptr [eax],al
  10008023: add         byte ptr [edx],bh
  10008025: add         byte ptr [eax],al
  10008027: add         dword ptr [eax+eax],eax
  1000802A: add         byte ptr [eax],al
  1000802C: mov         es,word ptr [edi]
  1000802E: add         byte ptr [eax],al
  10008030: and         eax,0B3000000h
  10008035: pop         es
  10008036: add         byte ptr [eax],al
  10008038: push        cs
  10008039: add         byte ptr [eax],al
  1000803B: add         byte ptr [edx],bh
  1000803D: add         byte ptr [eax],al
  1000803F: add         dword ptr [eax+eax],eax
  10008042: add         byte ptr [eax],al
  10008044: mov         es,word ptr [edi]
  10008046: add         byte ptr [eax],al
  10008048: xor         eax,0C3000000h
  1000804D: pop         es
  1000804E: add         byte ptr [eax],al
  10008050: push        cs
  10008051: add         byte ptr [eax],al
  10008053: add         byte ptr [edx],bh
  10008055: add         byte ptr [eax],al
  10008057: add         dword ptr [eax+eax],eax
  1000805A: add         byte ptr [eax],al
  1000805C: rol         byte ptr [edi],cl
  1000805E: add         byte ptr [eax],al
  10008060: and         dword ptr [eax],eax
  10008062: add         byte ptr [eax],al
  10008064: rep pop     es
  10008066: add         byte ptr [eax],al
  10008068: push        cs
  10008069: add         byte ptr [eax],al
  1000806B: add         byte ptr [edx],bh
  1000806D: add         byte ptr [eax],al
  1000806F: add         dword ptr [eax+eax],eax
  10008072: add         byte ptr [eax],al
  10008074: rol         byte ptr [edi],cl
  10008076: add         byte ptr [eax],al
  10008078: xor         dword ptr [eax],eax
  1000807A: add         byte ptr [eax],al
  1000807C: add         ecx,dword ptr [eax]
  1000807E: add         byte ptr [eax],al
  10008080: push        cs
  10008081: add         byte ptr [eax],al
  10008083: add         byte ptr [edx],bh
  10008085: add         byte ptr [eax],al
  10008087: add         dword ptr [eax+eax],eax
  1000808A: add         byte ptr [eax],al
  1000808C: mov         al,0
  1000808E: add         byte ptr [eax],al
  10008090: arpl        word ptr [edi],ax
  10008092: add         byte ptr [eax],al
  10008094: adc         ecx,dword ptr [eax]
  10008096: add         byte ptr [eax],al
  10008098: push        cs
  10008099: add         byte ptr [eax],al
  1000809B: add         byte ptr [edx],bh
  1000809D: add         byte ptr [eax],al
  1000809F: add         dword ptr [eax+eax],eax
  100080A2: add         byte ptr [eax],al
  100080A4: and         eax,dword ptr [eax]
  100080A6: add         byte ptr [eax],al
  100080A8: adc         byte ptr [eax],cl
  100080AA: add         byte ptr [eax],al
  100080AC: xor         ecx,dword ptr [eax]
  100080AE: add         byte ptr [eax],al
  100080B0: push        cs
  100080B1: add         byte ptr [eax],al
  100080B3: add         byte ptr [edx],bh
  100080B5: add         byte ptr [eax],al
  100080B7: add         dword ptr [eax+eax],eax
  100080BA: add         byte ptr [eax],al
  100080BC: or          al,byte ptr [eax]
  100080BE: add         byte ptr [eax],al
  100080C0: inc         eax
  100080C1: or          byte ptr [eax],al
  100080C3: add         byte ptr [edx+8],cl
  100080C6: add         byte ptr [eax],al
  100080C8: push        cs
  100080C9: add         byte ptr [eax],al
  100080CB: add         byte ptr [edx],bh
  100080CD: add         byte ptr [eax],al
  100080CF: add         dword ptr [ebx],ecx
  100080D1: xor         byte ptr [esi],al
  100080D3: add         byte ptr [ebx],al
  100080D5: add         dword ptr [eax],eax
  100080D7: add         byte ptr [esi],dh
  100080D9: add         dword ptr [eax],eax
  100080DB: adc         dword ptr [edx],eax
  100080DD: cmp         esp,edi
  100080DF: add         byte ptr [eax],al
  100080E1: add         byte ptr [edx],al
  100080E3: jg          10008136
  100080E5: add         byte ptr [eax],al
  100080E7: add         al,16h
  100080E9: add         cl,byte ptr [edx+1Fh]
  100080EC: or          al,58h
  100080EE: dec         edx
  100080EF: sub         dword ptr [esi],esi
  100080F2: add         byte ptr [ecx],dl
  100080F4: or          eax,91B2C09h
  100080F9: and         eax,75294A4Ah
  100080FE: add         byte ptr [eax],al
  10008100: adc         dword ptr [ebx],eax
  10008102: add         al,28h
  10008104: arpl        word ptr [eax],ax
  10008106: add         byte ptr [esi],al
  10008108: or          dword ptr ds:[4A581A4Ah],esp
  1000810E: sub         dword ptr [eax],edi
  10008111: add         byte ptr [ecx],dl
  10008113: add         bh,byte ptr [edi+52h]
  10008116: add         byte ptr [eax],al
  10008118: add         al,7Fh
  1000811A: cmp         al,0
  1000811C: add         byte ptr [edx+eax],al
  1000811F: dec         edx
  10008120: pop         ds
  10008121: or          al,58h
  10008123: dec         edx
  10008124: sub         dword ptr [esi],esi
  10008127: add         byte ptr [ecx],dl
  10008129: or          al,8
  1000812B: sub         al,1Dh
  1000812D: or          byte ptr ds:[75294A4Ah],ah
  10008133: add         byte ptr [eax],al
  10008135: adc         dword ptr [ebx],eax
  10008137: push        ds
  10008138: pop         eax
  10008139: add         al,28h
  1000813B: arpl        word ptr [eax],ax
  1000813D: add         byte ptr [esi],al
  1000813F: or          byte ptr ds:[4A581A4Ah],ah
  10008145: sub         dword ptr [eax],edi
  10008148: add         byte ptr [ecx],dl
  1000814A: add         bh,byte ptr [edi+53h]
  1000814D: add         byte ptr [eax],al
  1000814F: add         al,7Fh
  10008151: add         byte ptr ss:[eax],al
  10008154: add         al,2
  10008156: dec         edx
  10008157: pop         ds
  10008158: or          al,58h
  1000815A: dec         edx
  1000815B: sub         dword ptr [esi],esi
  1000815E: add         byte ptr [ecx],dl
  10008160: or          eax,dword ptr [edi]
  10008162: sub         al,24h
  10008164: pop         es
  10008165: and         eax,75294A4Ah
  1000816A: add         byte ptr [eax],al
  1000816C: adc         dword ptr [ebx],edx
  1000816E: add         eax,58181F03h
  10008173: adc         dword ptr ds:[23281616h],eax
  10008179: add         dword ptr [eax],eax
  1000817B: push        es
  1000817C: push        edx
  1000817D: pop         es
  1000817E: and         eax,4A581A4Ah
  10008183: sub         dword ptr [eax],edi
  10008186: add         byte ptr [ecx],dl
  10008188: add         dl,byte ptr [edx]
  1000818A: push        es
  1000818B: jg          100081E1
  1000818D: add         byte ptr [eax],al
  1000818F: add         al,16h
  10008191: add         cl,byte ptr [edx+1Eh]
  10008194: pop         eax
  10008195: dec         edx
  10008196: sub         dword ptr [ebx],esi
  10008199: add         byte ptr [ecx],dl
  1000819B: adc         eax,dword ptr [ecx+edx]
  1000819E: add         al,4Ah
  100081A0: or          al,byte ptr [esi]
  100081A2: sub         eax,626DE02h
  100081A7: push        ss
  100081A8: push        es
  100081A9: dec         edx
  100081AA: sbb         bl,byte ptr [eax+4Ah]
  100081AD: sub         dword ptr [ebx],edi
  100081B0: add         byte ptr [ecx],dl
  100081B2: add         ebx,dword ptr [edi]
  100081B4: adc         byte ptr [eax+4],bl
  100081B7: sub         byte ptr [esi+DE060000h],cl
  100081BD: push        cs
  100081BE: inc         byte ptr [esi]
  100081C0: xor         al,0
  100081C2: add         byte ptr [esi],al
  100081C4: adc         al,byte ptr [esi]
  100081C6: sub         byte ptr [ebx],al
  100081C8: add         dword ptr [eax],eax
  100081CA: push        es
  100081CB: fcom        qword ptr [edx]
  100081CD: push        es
  100081CE: dec         edx
  100081CF: sub         al,0Dh
  100081D1: adc         al,byte ptr [esi]
  100081D3: dec         edx
  100081D4: adc         al,byte ptr [esi]
  100081D6: dec         edx
  100081D7: dec         edx
  100081D8: dec         edx
  100081D9: sub         dword ptr [eax],edi
  100081DC: add         byte ptr [ecx],dl
  100081DE: sub         al,byte ptr [eax]
  100081E0: inc         ecx
  100081E1: sbb         al,0
  100081E3: add         byte ptr [eax+eax],al
  100081E6: add         byte ptr [eax],al
  100081E8: rol         dword ptr [eax],0
  100081EB: add         byte ptr [ecx],ah
  100081ED: add         byte ptr [eax],al
  100081EF: add         dl,ah
  100081F1: add         byte ptr [eax],al
  100081F3: add         byte ptr [esi],cl
  100081F5: add         byte ptr [eax],al
  100081F7: add         byte ptr [edx],bh
  100081F9: add         byte ptr [eax],al
  100081FB: add         dword ptr [ebx],ecx
  100081FD: xor         byte ptr [esi],al
  100081FF: add         byte ptr [esi],ch
  10008201: add         al,byte ptr [eax]
  10008203: add         byte ptr [edi],dh
  10008205: add         dword ptr [eax],eax
  10008207: adc         dword ptr [edx],eax
  10008209: cmp         dword ptr [edi],esp
  1000820B: add         al,byte ptr [eax]
  1000820D: add         byte ptr [edx],al
  1000820F: jg          1000828D
  10008211: add         byte ptr [eax],al
  10008213: add         al,7Fh
  10008215: pop         ebp
  10008216: add         byte ptr [eax],al
  10008218: add         al,2
  1000821A: dec         edx
  1000821B: pop         ds
  1000821C: or          al,58h
  1000821E: dec         edx
  1000821F: sub         dword ptr [esi],esi
  10008222: add         byte ptr [ecx],dl
  10008224: add         ebx,dword ptr [edi]
  10008226: pop         esp
  10008227: pop         eax
  10008228: add         al,28h
  1000822A: jne         1000822C
  1000822C: add         byte ptr [esi],al
  1000822E: add         bh,byte ptr [edi+7Dh]
  10008231: add         byte ptr [eax],al
  10008233: add         al,7Fh
  10008235: pop         ebp
  10008236: add         byte ptr [eax],al
  10008238: add         al,2
  1000823A: dec         edx
  1000823B: pop         ds
  1000823C: or          al,58h
  1000823E: dec         edx
  1000823F: sub         dword ptr [esi],esi
  10008242: add         byte ptr [ecx],dl
  10008244: add         ebx,dword ptr [edi]
  10008246: pop         ebp
  10008247: pop         eax
  10008248: add         al,28h
  1000824A: jne         1000824C
  1000824C: add         byte ptr [esi],al
  1000824E: add         bh,byte ptr [edi+7Eh]
  10008251: add         byte ptr [eax],al
  10008253: add         al,16h
  10008255: add         cl,byte ptr [edx+1Fh]
  10008258: or          al,58h
  1000825A: dec         edx
  1000825B: sub         dword ptr [esi],esi
  1000825E: add         byte ptr [ecx],dl
  10008260: add         ebx,dword ptr [esi]
  10008262: pop         eax
  10008263: add         al,28h
  10008265: test        dword ptr [eax],eax
  10008267: add         byte ptr [esi],al
  10008269: add         bh,byte ptr [edi+7Fh]
  1000826C: add         byte ptr [eax],al
  1000826E: add         al,7Fh
  10008270: add         byte ptr ss:[eax],al
  10008273: add         al,2
  10008275: dec         edx
  10008276: pop         ds
  10008277: or          al,58h
  10008279: dec         edx
  1000827A: sub         dword ptr [esi],esi
  1000827D: add         byte ptr [ecx],dl
  1000827F: or          eax,dword ptr [edi]
  10008281: sub         al,24h
  10008283: pop         es
  10008284: and         eax,75294A4Ah
  10008289: add         byte ptr [eax],al
  1000828B: adc         dword ptr [ebx],edx
  1000828D: or          dword ptr [ebx],eax
  1000828F: pop         ds
  10008290: pop         esi
  10008291: pop         eax
  10008292: adc         dword ptr [ecx],ecx
  10008294: push        ss
  10008295: push        ss
  10008296: sub         byte ptr [ebx],ah
  10008298: add         dword ptr [eax],eax
  1000829A: push        es
  1000829B: push        edx
  1000829C: pop         es
  1000829D: and         eax,4A581A4Ah
  100082A2: sub         dword ptr [eax],edi
  100082A5: add         byte ptr [ecx],dl
  100082A7: add         dl,byte ptr [edx]
  100082A9: push        cs
  100082AA: jg          1000822C
  100082AC: add         byte ptr [eax],al
  100082AE: add         al,16h
  100082B0: add         cl,byte ptr [edx+1Eh]
  100082B3: pop         eax
  100082B4: dec         edx
  100082B5: sub         dword ptr [ebx],esi
  100082B8: add         byte ptr [ecx],dl
  100082BA: adc         ecx,dword ptr [eax]
  100082BC: adc         dword ptr [eax],ecx
  100082BE: dec         edx
  100082BF: add         ebx,dword ptr [edi]
  100082C1: or          al,58h
  100082C3: add         al,28h
  100082C5: dec         esi
  100082C6: add         byte ptr [eax],al
  100082C8: push        es
  100082C9: fimul       word ptr [esi]
  100082CB: inc         byte ptr [esi]
  100082CD: xor         al,0
  100082CF: add         byte ptr [esi],al
  100082D1: adc         cl,byte ptr [esi]
  100082D3: sub         byte ptr [ebx],al
  100082D5: add         dword ptr [eax],eax
  100082D7: push        es
  100082D8: fcom        qword ptr [edx]
  100082DA: push        cs
  100082DB: dec         edx
  100082DC: sub         al,0Dh
  100082DE: adc         cl,byte ptr [esi]
  100082E0: dec         edx
  100082E1: adc         cl,byte ptr [esi]
  100082E3: dec         edx
  100082E4: dec         edx
  100082E5: dec         edx
  100082E6: sub         dword ptr [eax],edi
  100082E9: add         byte ptr [ecx],dl
  100082EB: add         dl,byte ptr [edx]
  100082ED: or          eax,817Fh
  100082F2: add         al,16h
  100082F4: add         cl,byte ptr [edx+1Eh]
  100082F7: pop         eax
  100082F8: dec         edx
  100082F9: sub         dword ptr [ebx],esi
  100082FC: add         byte ptr [ecx],dl
  100082FE: adc         eax,dword ptr [edi]
  10008300: adc         dword ptr [edi],eax
  10008302: dec         edx
  10008303: add         ebx,dword ptr [edi]
  10008305: and         al,58h
  10008307: add         al,28h
  10008309: dec         ebp
  1000830A: add         byte ptr [eax],al
  1000830C: push        es
  1000830D: fimul       word ptr [esi]
  1000830F: inc         byte ptr [esi]
  10008311: xor         al,0
  10008313: add         byte ptr [esi],al
  10008315: adc         cl,byte ptr ds:[00010328h]
  1000831B: push        es
  1000831C: fcom        qword ptr [edx]
  1000831E: or          eax,120D2C4Ah
  10008323: or          eax,4A0D124Ah
  10008328: dec         edx
  10008329: dec         edx
  1000832A: sub         dword ptr [eax],edi
  1000832D: add         byte ptr [ecx],dl
  1000832F: add         dl,byte ptr [edx]
  10008331: or          al,7Fh
  10008333: add         byte ptr [eax],0
  10008336: add         al,16h
  10008338: add         cl,byte ptr [edx+1Eh]
  1000833B: pop         eax
  1000833C: dec         edx
  1000833D: sub         dword ptr [ebx],esi
  10008340: add         byte ptr [ecx],dl
  10008342: adc         eax,dword ptr [esi]
  10008344: adc         dword ptr [esi],eax
  10008346: dec         edx
  10008347: or          al,byte ptr [esi]
  10008349: sub         eax,62ADE02h
  1000834E: jg          100083B1
  10008350: add         byte ptr [eax],al
  10008352: add         al,6
  10008354: dec         edx
  10008355: sbb         bl,byte ptr [eax+4Ah]
  10008358: sub         dword ptr [ebx],edi
  1000835B: add         byte ptr [ecx],dl
  1000835D: add         ebx,dword ptr [edi]
  1000835F: xor         al,58h
  10008361: add         al,28h
  10008363: test        byte ptr [eax],al
  10008365: add         byte ptr [esi],al
  10008367: fimul       word ptr [esi]
  10008369: inc         byte ptr [esi]
  1000836B: xor         al,0
  1000836D: add         byte ptr [esi],al
  1000836F: adc         cl,byte ptr [eax+ebp]
  10008372: add         eax,dword ptr [ecx]
  10008374: add         byte ptr [esi],al
  10008376: fcom        qword ptr [edx]
  10008378: or          al,4Ah
  1000837A: sub         al,0Dh
  1000837C: adc         cl,byte ptr [edx+ecx*2]
  1000837F: adc         cl,byte ptr [edx+ecx*2]
  10008382: dec         edx
  10008383: dec         edx
  10008384: sub         dword ptr [eax],edi
  10008387: add         byte ptr [ecx],dl
  10008389: add         dl,byte ptr [edx]
  1000838B: or          edi,dword ptr [edi-7Dh]
  1000838E: add         byte ptr [eax],al
  10008390: add         al,16h
  10008392: add         cl,byte ptr [edx+1Eh]
  10008395: pop         eax
  10008396: dec         edx
  10008397: sub         dword ptr [ebx],esi
  1000839A: add         byte ptr [ecx],dl
  1000839C: adc         eax,dword ptr ds:[034A0511h]
  100083A2: pop         ds
  100083A3: cmp         al,58h
  100083A5: add         al,28h
  100083A7: dec         ecx
  100083A8: add         byte ptr [eax],al
  100083AA: push        es
  100083AB: fimul       word ptr [esi]
  100083AD: inc         byte ptr [esi]
  100083AF: xor         al,0
  100083B1: add         byte ptr [esi],al
  100083B3: adc         cl,byte ptr [ebx]
  100083B5: sub         byte ptr [ebx],al
  100083B7: add         dword ptr [eax],eax
  100083B9: push        es
  100083BA: fcom        qword ptr [edx]
  100083BC: or          ecx,dword ptr [edx+2Ch]
  100083BF: or          eax,124A0B12h
  100083C4: or          ecx,dword ptr [edx+4Ah]
  100083C7: dec         edx
  100083C8: sub         dword ptr [eax],edi
  100083CB: add         byte ptr [ecx],dl
  100083CD: add         dl,byte ptr [edx]
  100083CF: or          bh,byte ptr [edi+1Fh]
  100083D2: add         byte ptr [eax],al
  100083D4: add         al,16h
  100083D6: add         cl,byte ptr [edx+1Eh]
  100083D9: pop         eax
  100083DA: dec         edx
  100083DB: sub         dword ptr [ebx],esi
  100083DE: add         byte ptr [ecx],dl
  100083E0: adc         eax,dword ptr [ecx+edx]
  100083E3: add         al,4Ah
  100083E5: or          eax,58581F03h
  100083EA: or          al,9
  100083EC: sub         eax,433DE02h
  100083F1: or          byte ptr [edi],bl
  100083F3: adc         byte ptr [edi],dl
  100083F5: sub         byte ptr [esi],al
  100083F7: add         byte ptr [eax],al
  100083F9: push        es
  100083FA: or          dword ptr es:[eax],ecx
  100083FD: dec         edx
  100083FE: add         al,28h
  10008400: inc         edi
  10008401: add         byte ptr [eax],al
  10008403: push        es
  10008404: add         al,1Ah
  10008406: pop         eax
  10008407: sbb         bl,byte ptr [eax+4]
  1000840A: sbb         bl,byte ptr [eax+1Ah]
  1000840D: pop         eax
  1000840E: dec         edx
  1000840F: pop         ds
  10008410: cld
  10008411: pop         eax
  10008412: push        esp
  10008413: fimul       word ptr [esi]
  10008415: inc         byte ptr [esi]
  10008417: xor         al,0
  10008419: add         byte ptr [esi],al
  1000841B: adc         cl,byte ptr [edx]
  1000841D: sub         byte ptr [ebx],al
  1000841F: add         dword ptr [eax],eax
  10008421: push        es
  10008422: fcom        qword ptr [edx]
  10008424: or          cl,byte ptr [edx+2Ch]
  10008427: or          eax,124A0A12h
  1000842C: or          cl,byte ptr [edx+4Ah]
  1000842F: dec         edx
  10008430: sub         dword ptr [eax],edi
  10008433: add         byte ptr [ecx],dl
  10008435: sub         al,byte ptr [eax]
  10008437: add         byte ptr [ecx+7Ch],al
  1000843A: add         byte ptr [eax],al
  1000843C: add         al,0
  1000843E: add         byte ptr [eax],al
  10008440: mov         ah,0
  10008442: add         byte ptr [eax],al
  10008444: sldt        word ptr [eax]
  10008447: add         bl,al
  10008449: add         byte ptr [eax],al
  1000844B: add         byte ptr [esi],cl
  1000844D: add         byte ptr [eax],al
  1000844F: add         byte ptr [edx],bh
  10008451: add         byte ptr [eax],al
  10008453: add         dword ptr [eax+eax],eax
  10008456: add         byte ptr [eax],al
  10008458: clc
  10008459: add         byte ptr [eax],al
  1000845B: add         byte ptr [edi],cl
  1000845D: add         byte ptr [eax],al
  1000845F: add         byte ptr [edi],al
  10008461: add         dword ptr [eax],eax
  10008463: add         byte ptr [esi],cl
  10008465: add         byte ptr [eax],al
  10008467: add         byte ptr [edx],bh
  10008469: add         byte ptr [eax],al
  1000846B: add         dword ptr [eax+eax],eax
  1000846E: add         byte ptr [eax],al
  10008470: cmp         al,1
  10008472: add         byte ptr [eax],al
  10008474: and         eax,61000000h
  10008479: add         dword ptr [eax],eax
  1000847B: add         byte ptr [esi],cl
  1000847D: add         byte ptr [eax],al
  1000847F: add         byte ptr [edx],bh
  10008481: add         byte ptr [eax],al
  10008483: add         dword ptr [eax+eax],eax
  10008486: add         byte ptr [eax],al
  10008488: xchg        eax,esi
  10008489: add         dword ptr [eax],eax
  1000848B: add         byte ptr [edi],cl
  1000848D: add         byte ptr [eax],al
  1000848F: add         byte ptr [ebp+0E000001h],ah
  10008495: add         byte ptr [eax],al
  10008497: add         byte ptr [edx],bh
  10008499: add         byte ptr [eax],al
  1000849B: add         dword ptr [eax+eax],eax
  1000849E: add         byte ptr [eax],al
  100084A0: fiadd       dword ptr [ecx]
  100084A2: add         byte ptr [eax],al
  100084A4: xor         eax,dword ptr [eax]
  100084A6: add         byte ptr [eax],al
  100084A8: or          eax,0E000002h
  100084AD: add         byte ptr [eax],al
  100084AF: add         byte ptr [edx],bh
  100084B1: add         byte ptr [eax],al
  100084B3: add         dword ptr [ebx],ecx
  100084B5: xor         byte ptr ds:[00016000h],al
  100084BB: add         byte ptr [edx],bh
  100084BD: add         dword ptr [eax],eax
  100084BF: adc         dword ptr [edx],eax
  100084C1: jnp         10008524
  100084C3: add         dword ptr [eax],eax
  100084C5: add         al,16h
  100084C7: add         edx,dword ptr cs:[edi]
  100084CA: sub         eax,dword ptr [ecx]
  100084CC: push        ss
  100084CD: adc         ecx,dword ptr [eax]
  100084CF: pop         ds
  100084D0: adc         byte ptr [eax],ch
  100084D2: sbb         eax,0C060001h
  100084D7: or          byte ptr [edi],ch
  100084DA: adc         dl,byte ptr [ecx]
  100084DC: adc         eax,dword ptr [edi]
  100084DE: add         ebp,dword ptr [eax]
  100084E0: daa
  100084E1: add         byte ptr [eax],al
  100084E3: or          ch,byte ptr [eax]
  100084E5: and         eax,280A0000h
  100084EA: xor         byte ptr [eax],al
  100084EC: add         byte ptr [edx],cl
  100084EE: sub         byte ptr [ebx],dh
  100084F0: add         byte ptr [eax],al
  100084F2: or          dl,byte ptr [ebx]
  100084F4: adc         byte ptr [edx],dl
  100084F6: adc         dword ptr [edx],edx
  100084F8: adc         byte ptr [eax],ch
  100084FA: sub         eax,dword ptr [eax]
  100084FC: add         byte ptr [edx],cl
  100084FE: push        esp
  100084FF: adc         cl,byte ptr [edi]
  10008501: adc         ecx,dword ptr [esi]
  10008503: add         ebp,dword ptr [eax]
  10008505: sub         dword ptr [eax],eax
  10008507: add         byte ptr [edx],cl
  10008509: outs        dx,dword ptr [esi]
  1000850A: add         byte ptr ss:[eax],al
  1000850D: or          ch,byte ptr [eax]
  1000850F: xor         byte ptr [eax],al
  10008511: add         byte ptr [edx],cl
  10008513: sub         byte ptr [ebx],dh
  10008515: add         byte ptr [eax],al
  10008517: or          dl,byte ptr [ebx]
  10008519: or          eax,0D120F12h
  1000851E: sub         byte ptr [ebx],ch
  10008520: add         byte ptr [eax],al
  10008522: or          dl,byte ptr [esi+ebx*8+0Eh]
  10008526: inc         byte ptr [esi]
  10008528: pop         esi
  10008529: add         byte ptr [eax],al
  1000852B: push        es
  1000852C: adc         dword ptr [edi],eax
  1000852E: sub         byte ptr [ebx],al
  10008530: add         dword ptr [eax],eax
  10008532: push        es
  10008533: fmul        qword ptr [eax]
  10008535: adc         cl,byte ptr [edi]
  10008537: adc         dl,byte ptr [ecx]
  10008539: sub         byte ptr [ecx+0A060000h],ch
  1000853F: fimul       word ptr [ebx]
  10008541: push        ss
  10008542: or          bl,dh
  10008544: pop         es
  10008545: or          byte ptr [eax],ch
  10008547: push        ds
  10008548: add         dword ptr [eax],eax
  1000854A: push        es
  1000854B: fcom        qword ptr [edx]
  1000854D: or          al,6
  1000854F: push        esp
  10008550: adc         cl,byte ptr [ebx]
  10008552: adc         al,byte ptr [ecx]
  10008554: sub         byte ptr [edx+26060000h],cl
  1000855A: adc         cl,byte ptr [edx]
  1000855C: adc         dword ptr [eax],ecx
  1000855E: push        edx
  1000855F: push        es
  10008560: cmp         dword ptr [ebp],esi
  10008563: add         byte ptr [eax],al
  10008565: push        ss
  10008566: adc         eax,dword ptr ds:[05120912h]
  1000856C: sub         byte ptr [ebx+26060000h],cl
  10008572: push        es
  10008573: adc         dword ptr ds:[55280912h],eax
  10008579: add         byte ptr [eax],al
  1000857B: push        es
  1000857C: push        es
  1000857D: pop         es
  1000857E: adc         cl,byte ptr [ebx]
  10008580: sub         byte ptr [ecx],bl
  10008583: add         byte ptr [esi],al
  10008585: pop         es
  10008586: adc         cl,byte ptr [edx]
  10008588: sub         byte ptr [edx],bl
  1000858B: add         byte ptr [esi],al
  1000858D: pop         es
  1000858E: sbb         bl,byte ptr [eax+13h]
  10008591: add         al,11h
  10008593: add         al,13h
  10008595: push        es
  10008596: adc         cl,byte ptr [ebx]
  10008598: adc         dword ptr [esi],eax
  1000859A: pop         ds
  1000859B: sbb         al,17h
  1000859D: sub         byte ptr [esi],al
  1000859F: add         byte ptr [eax],al
  100085A1: push        es
  100085A2: adc         dword ptr es:[124A0411h],eax
  100085A9: or          edx,dword ptr [edx]
  100085AB: or          al,byte ptr [edx]
  100085AD: jnp         10008610
  100085AF: add         dword ptr [eax],eax
  100085B1: add         al,28h
  100085B3: into
  100085B4: add         byte ptr [eax],al
  100085B6: push        es
  100085B7: adc         cl,byte ptr [ebx]
  100085B9: push        ds
  100085BA: pop         eax
  100085BB: adc         cl,byte ptr [ebx]
  100085BD: push        ds
  100085BE: pop         eax
  100085BF: dec         edx
  100085C0: sbb         bl,byte ptr [ecx+54h]
  100085C3: fimul       word ptr [esi]
  100085C5: inc         byte ptr [esi]
  100085C7: aaa
  100085C8: add         byte ptr [eax],al
  100085CA: push        es
  100085CB: adc         cl,byte ptr [ecx]
  100085CD: sub         byte ptr [ebx],al
  100085CF: add         dword ptr [eax],eax
  100085D1: push        es
  100085D2: fcom        qword ptr [edx]
  100085D4: or          dword ptr [eax],ebp
  100085D6: aaa
  100085D7: add         byte ptr [eax],al
  100085D9: push        es
  100085DA: jae         100085F7
  100085DC: add         byte ptr [eax],al
  100085DE: or          cl,byte ptr ds:[120B1202h]
  100085E4: or          cl,byte ptr [ecx]
  100085E6: sub         byte ptr [ecx+eax],al
  100085EA: push        es
  100085EB: fimul       word ptr [esi]
  100085ED: inc         byte ptr [esi]
  100085EF: aaa
  100085F0: add         byte ptr [eax],al
  100085F2: push        es
  100085F3: adc         cl,byte ptr [ebx]
  100085F5: sub         byte ptr [ebx],al
  100085F7: add         dword ptr [eax],eax
  100085F9: push        es
  100085FA: fcom        qword ptr [edx]
  100085FC: or          ebp,dword ptr [eax]
  100085FE: aaa
  100085FF: add         byte ptr [eax],al
  10008601: push        es
  10008602: fimul       word ptr [esi]
  10008604: inc         byte ptr [esi]
  10008606: xor         al,0
  10008608: add         byte ptr [esi],al
  1000860A: adc         cl,byte ptr [eax+ebp]
  1000860D: add         eax,dword ptr [ecx]
  1000860F: add         byte ptr [esi],al
  10008611: fadd        qword ptr [esi]
  10008613: sub         al,9
  10008615: push        es
  10008616: and         eax,78294A4Ah
  1000861B: add         byte ptr [eax],al
  1000861D: adc         dword ptr [ecx],ecx
  1000861F: sub         al,byte ptr [ecx+7Ch]
  10008622: add         byte ptr [eax],al
  10008624: add         al,0
  10008626: add         byte ptr [eax],al
  10008628: aas
  10008629: add         byte ptr [eax],al
  1000862B: add         byte ptr [edi],ah
  1000862D: add         byte ptr [eax],al
  1000862F: add         byte ptr [esi],ah
  10008632: add         byte ptr [eax],al
  10008634: push        cs
  10008635: add         byte ptr [eax],al
  10008637: add         byte ptr [edx],bh
  10008639: add         byte ptr [eax],al
  1000863B: add         dword ptr [eax+eax],eax
  1000863E: add         byte ptr [eax],al
  10008640: pop         ss
  10008641: add         byte ptr [eax],al
  10008643: add         byte ptr [esi],ch
  10008646: add         byte ptr [eax],al
  10008648: test        dword ptr [eax],eax
  1000864A: add         byte ptr [eax],al
  1000864C: pop         es
  1000864D: add         byte ptr [eax],al
  1000864F: add         byte ptr [edx],bh
  10008651: add         byte ptr [eax],al
  10008653: add         dword ptr [eax+eax],eax
  10008656: add         byte ptr [eax],al
  10008658: mov         dl,0
  1000865A: add         byte ptr [eax],al
  1000865C: push        ebx
  1000865D: add         byte ptr [eax],al
  1000865F: add         byte ptr ds:[0E000001h],al
  10008665: add         byte ptr [eax],al
  10008667: add         byte ptr [edx],bh
  10008669: add         byte ptr [eax],al
  1000866B: add         dword ptr [eax+eax],eax
  1000866E: add         byte ptr [eax],al
  10008670: call        0000:93000000
  10008677: add         byte ptr ds:[0E000001h],ch
  1000867D: add         byte ptr [eax],al
  1000867F: add         byte ptr [edx],bh
  10008681: add         byte ptr [eax],al
  10008683: add         dword ptr [eax+eax],eax
  10008686: add         byte ptr [eax],al
  10008688: nop
  10008689: add         byte ptr [eax],al
  1000868B: add         byte ptr [eax+eax+01440000h],dh
  10008692: add         byte ptr [eax],al
  10008694: push        cs
  10008695: add         byte ptr [eax],al
  10008697: add         byte ptr [edx],bh
  10008699: add         byte ptr [eax],al
  1000869B: add         dword ptr [ebx],eax
  1000869D: xor         byte ptr [edx],al
  1000869F: add         byte ptr [ecx],bh
  100086A1: add         byte ptr [eax],al
  100086A3: add         byte ptr [ecx],cl
  100086A5: add         byte ptr [eax],al
  100086A7: adc         dword ptr [ebx],eax
  100086A9: sub         byte ptr [eax],ch
  100086AB: add         byte ptr [eax],al
  100086AD: or          ch,byte ptr [eax]
  100086AF: and         al,byte ptr [eax]
  100086B1: add         byte ptr [edx],cl
  100086B3: or          al,byte ptr [esi]
  100086B5: and         byte ptr [eax],dh
  100086B7: scas        byte ptr es:[edi]
  100086B8: dec         eax
  100086B9: and         al,2Eh
  100086BB: sbb         eax,0A2622006h
  100086C0: mov         cl,0C2h
  100086C2: or          eax,14372h
  100086C8: jo          100086CD
  100086CA: sub         byte ptr [edi],dh
  100086CC: add         byte ptr [eax],al
  100086CE: or          dl,byte ptr [edx+ebp]
  100086D1: add         al,byte ptr [ebx]
  100086D3: sub         byte ptr [esi+1],al
  100086D6: add         byte ptr [esi],al
  100086D8: sub         al,byte ptr [edx]
  100086DA: add         ebp,dword ptr [eax]
  100086DC: inc         ebp
  100086DD: add         dword ptr [eax],eax
  100086DF: push        es
  100086E0: sub         cl,ah
  100086E2: int         3
  100086E3: int         3
  100086E4: add         esi,dword ptr [eax]
  100086E6: add         dword ptr [eax],eax
  100086E8: pop         es
  100086E9: add         byte ptr [eax],al
  100086EB: add         byte ptr [eax],al
  100086ED: add         byte ptr [eax],al
  100086EF: add         byte ptr [edx],al
  100086F1: sub         byte ptr [ecx],ch
  100086F3: add         dword ptr [eax],eax
  100086F5: push        es
  100086F6: sub         cl,ah
  100086F8: add         esi,dword ptr [eax]
  100086FA: add         al,byte ptr [eax]
  100086FC: or          eax,dword ptr [eax]
  100086FE: add         byte ptr [eax],al
  10008700: add         byte ptr [eax],al
  10008702: add         byte ptr [eax],al
  10008704: add         bh,byte ptr [edi-9]
  10008707: add         byte ptr [eax],al
  10008709: add         al,0FEh
  1000870B: adc         al,byte ptr [ecx]
  1000870D: push        esp
  1000870E: sub         cl,ah
  10008710: add         esi,dword ptr [eax]
  10008712: add         al,0
  10008714: cmp         al,0
  10008716: add         byte ptr [eax],al
  10008718: cmp         eax,3110001h
  1000871D: sbb         byte ptr [edi+2Ch],bl
  10008720: and         byte ptr [edx],al
  10008722: sbb         bl,byte ptr [ecx+0Ah]
  10008725: add         bl,byte ptr [edx]
  10008727: push        es
  10008728: dec         edx
  10008729: inc         byte ptr [esi]
  1000872B: mov         dword ptr ds:[28060000h],eax
  10008730: add         al,1
  10008732: add         byte ptr [esi],al
  10008734: add         edx,dword ptr [edi]
  10008736: pop         edi
  10008737: sub         al,6
  10008739: push        es
  1000873A: sub         byte ptr [esi],bl
  1000873C: add         dword ptr [eax],eax
  1000873E: push        es
  1000873F: push        es
  10008740: sub         al,byte ptr [edx]
  10008742: jg          1000873B
  10008744: add         byte ptr [eax],al
  10008746: add         al,0FEh
  10008748: adc         al,byte ptr [ecx]
  1000874A: push        esp
  1000874B: add         edx,dword ptr [edi]
  1000874D: pop         edi
  1000874E: sub         al,6
  10008750: add         ch,byte ptr [eax]
  10008752: push        ds
  10008753: add         dword ptr [eax],eax
  10008755: push        es
  10008756: add         ch,byte ptr [edx]
  10008758: int         3
  10008759: int         3
  1000875A: int         3
  1000875B: int         3
  1000875C: int         3
  1000875D: int         3
  1000875E: int         3
  1000875F: int         3
  10008760: jmp         dword ptr ds:[100244E8h]
  10008766: int         3
  10008767: int         3
  10008768: add         esi,dword ptr [eax]
  1000876A: add         al,byte ptr [eax]
  1000876C: or          eax,dword ptr [eax]
  1000876E: add         byte ptr [eax],al
  10008770: add         byte ptr [eax],al
  10008772: add         byte ptr [eax],al
  10008774: add         bh,byte ptr [edi-15h]
  10008777: add         byte ptr [eax],al
  10008779: add         al,0FEh
  1000877B: adc         al,byte ptr [ecx]
  1000877D: push        esp
  1000877E: sub         cl,ah
  10008780: add         esi,dword ptr [eax]
  10008782: add         al,0
  10008784: cmp         al,0
  10008786: add         byte ptr [eax],al
  10008788: aas
  10008789: add         dword ptr [eax],eax
  1000878B: adc         dword ptr [ebx],eax
  1000878D: sbb         byte ptr [edi+2Ch],bl
  10008790: and         byte ptr [edx],al
  10008792: sbb         bl,byte ptr [ecx+0Ah]
  10008795: add         bl,byte ptr [edx]
  10008797: push        es
  10008798: dec         edx
  10008799: inc         byte ptr [esi]
  1000879B: movs        dword ptr es:[edi],dword ptr [esi]
  1000879C: add         byte ptr [eax],al
  1000879E: push        es
  1000879F: sub         byte ptr [ecx+eax],al
  100087A2: add         byte ptr [esi],al
  100087A4: add         edx,dword ptr [edi]
  100087A6: pop         edi
  100087A7: sub         al,6
  100087A9: push        es
  100087AA: sub         byte ptr [esi],bl
  100087AC: add         dword ptr [eax],eax
  100087AE: push        es
  100087AF: push        es
  100087B0: sub         al,byte ptr [edx]
  100087B2: jg          1000879F
  100087B4: add         byte ptr [eax],al
  100087B6: add         al,0FEh
  100087B8: adc         al,byte ptr [ecx]
  100087BA: push        esp
  100087BB: add         edx,dword ptr [edi]
  100087BD: pop         edi
  100087BE: sub         al,6
  100087C0: add         ch,byte ptr [eax]
  100087C2: push        ds
  100087C3: add         dword ptr [eax],eax
  100087C5: push        es
  100087C6: add         ch,byte ptr [edx]
  100087C8: int         3
  100087C9: int         3
  100087CA: int         3
  100087CB: int         3
  100087CC: int         3
  100087CD: int         3
  100087CE: int         3
  100087CF: int         3
  100087D0: jmp         dword ptr ds:[10024528h]
  100087D6: int         3
  100087D7: int         3
  100087D8: add         esi,dword ptr [eax]
  100087DA: add         al,byte ptr [eax]
  100087DC: or          eax,dword ptr [eax]
  100087DE: add         byte ptr [eax],al
  100087E0: add         byte ptr [eax],al
  100087E2: add         byte ptr [eax],al
  100087E4: add         bh,byte ptr [edi-1]
  100087E7: add         byte ptr [eax],al
  100087E9: add         al,0FEh
  100087EB: adc         al,byte ptr [ecx]
  100087ED: push        esp
  100087EE: sub         cl,ah
  100087F0: add         esi,dword ptr [eax]
  100087F2: add         al,0
  100087F4: cmp         al,0
  100087F6: add         byte ptr [eax],al
  100087F8: inc         ecx
  100087F9: add         dword ptr [eax],eax
  100087FB: adc         dword ptr [ebx],eax
  100087FD: sbb         byte ptr [edi+2Ch],bl
  10008800: and         byte ptr [edx],al
  10008802: sbb         bl,byte ptr [ecx+0Ah]
  10008805: add         bl,byte ptr [edx]
  10008807: push        es
  10008808: dec         edx
  10008809: inc         byte ptr [esi]
  1000880B: cmps        dword ptr [esi],dword ptr es:[edi]
  1000880C: add         byte ptr [eax],al
  1000880E: push        es
  1000880F: sub         byte ptr [ecx+eax],al
  10008812: add         byte ptr [esi],al
  10008814: add         edx,dword ptr [edi]
  10008816: pop         edi
  10008817: sub         al,6
  10008819: push        es
  1000881A: sub         byte ptr [esi],bl
  1000881C: add         dword ptr [eax],eax
  1000881E: push        es
  1000881F: push        es
  10008820: sub         al,byte ptr [edx]
  10008822: jg          10008823
  10008824: add         byte ptr [eax],al
  10008826: add         al,0FEh
  10008828: adc         al,byte ptr [ecx]
  1000882A: push        esp
  1000882B: add         edx,dword ptr [edi]
  1000882D: pop         edi
  1000882E: sub         al,6
  10008830: add         ch,byte ptr [eax]
  10008832: push        ds
  10008833: add         dword ptr [eax],eax
  10008835: push        es
  10008836: add         ch,byte ptr [edx]
  10008838: int         3
  10008839: int         3
  1000883A: int         3
  1000883B: int         3
  1000883C: int         3
  1000883D: int         3
  1000883E: int         3
  1000883F: int         3
  10008840: jmp         dword ptr ds:[10024564h]
  10008846: int         3
  10008847: int         3
  10008848: add         esi,dword ptr [eax]
  1000884A: add         al,0
  1000884C: adc         al,byte ptr [eax]
  1000884E: add         byte ptr [eax],al
  10008850: add         byte ptr [eax],al
  10008852: add         byte ptr [eax],al
  10008854: add         ch,byte ptr [esi+ecx]
  10008857: add         dl,byte ptr [edi]
  10008859: add         cl,byte ptr [edx+1Fh]
  1000885C: adc         al,58h
  1000885E: dec         edx
  1000885F: sub         dword ptr [ebx],edi
  10008861: add         dword ptr [eax],eax
  10008863: adc         dword ptr [esi],esp
  10008865: sub         cl,ah
  10008867: int         3
  10008868: int         3
  10008869: int         3
  1000886A: int         3
  1000886B: int         3
  1000886C: int         3
  1000886D: int         3
  1000886E: int         3
  1000886F: int         3
  10008870: jmp         dword ptr ds:[10024568h]
  10008876: int         3
  10008877: int         3
  10008878: add         esi,dword ptr [eax]
  1000887A: add         al,0
  1000887C: adc         al,byte ptr [eax]
  1000887E: add         byte ptr [eax],al
  10008880: add         byte ptr [eax],al
  10008882: add         byte ptr [eax],al
  10008884: add         ch,byte ptr [esi+ecx]
  10008887: add         dl,byte ptr [edi]
  10008889: add         cl,byte ptr [edx+1Fh]
  1000888C: adc         byte ptr [eax+4Ah],bl
  1000888F: sub         dword ptr [ebx],edi
  10008891: add         dword ptr [eax],eax
  10008893: adc         dword ptr [esi],esp
  10008895: sub         cl,ah
  10008897: int         3
  10008898: int         3
  10008899: int         3
  1000889A: int         3
  1000889B: int         3
  1000889C: int         3
  1000889D: int         3
  1000889E: int         3
  1000889F: int         3
  100088A0: jmp         dword ptr ds:[1002456Ch]
  100088A6: int         3
  100088A7: int         3
  100088A8: add         esi,dword ptr [eax]
  100088AA: add         al,byte ptr [eax]
  100088AC: add         eax,0
  100088B1: add         byte ptr [eax],al
  100088B3: add         byte ptr [edx],al
  100088B5: sbb         bl,byte ptr [eax+4Ah]
  100088B8: sub         cl,ah
  100088BA: int         3
  100088BB: int         3
  100088BC: int         3
  100088BD: int         3
  100088BE: int         3
  100088BF: int         3
  100088C0: jmp         dword ptr ds:[10024570h]
  100088C6: int         3
  100088C7: int         3
  100088C8: add         esi,dword ptr [eax]
  100088CA: add         al,0
  100088CC: adc         dword ptr [eax],eax
  100088CE: add         byte ptr [eax],al
  100088D0: add         byte ptr [eax],al
  100088D2: add         byte ptr [eax],al
  100088D4: add         ch,byte ptr [ecx+4A021702h]
  100088DB: push        ds
  100088DC: pop         eax
  100088DD: dec         edx
  100088DE: sub         dword ptr [ebx],edi
  100088E0: add         dword ptr [eax],eax
  100088E2: adc         dword ptr [esi],esp
  100088E4: sub         cl,ah
  100088E6: int         3
  100088E7: int         3
  100088E8: int         3
  100088E9: int         3
  100088EA: int         3
  100088EB: int         3
  100088EC: int         3
  100088ED: int         3
  100088EE: int         3
  100088EF: int         3
  100088F0: jmp         dword ptr ds:[10024574h]
  100088F6: int         3
  100088F7: int         3
  100088F8: or          esi,dword ptr [eax]
  100088FA: add         al,byte ptr [eax]
  100088FC: xor         al,byte ptr [eax]
  100088FE: add         byte ptr [eax],al
  10008900: add         byte ptr [eax],al
  10008902: add         byte ptr [eax],al
  10008904: add         bh,byte ptr [edi-1Ch]
  10008907: add         byte ptr [eax],al
  10008909: add         al,0FEh
  1000890B: adc         al,byte ptr [ecx]
  1000890D: push        esp
  1000890E: add         bl,byte ptr [edx]
  10008910: pop         eax
  10008911: dec         edx
  10008912: sub         byte ptr [eax],bh
  10008914: add         byte ptr [eax],al
  10008916: or          ch,byte ptr [eax]
  10008918: cmp         eax,dword ptr [eax]
  1000891A: add         byte ptr [edx],cl
  1000891C: fimul       word ptr ds:[00A306FEh]
  10008922: add         byte ptr [esi],al
  10008924: add         ch,byte ptr [eax]
  10008926: add         eax,dword ptr [ecx]
  10008928: add         byte ptr [esi],al
  1000892A: fadd        qword ptr [edx]
  1000892C: jg          10008925
  1000892E: add         byte ptr [eax],al
  10008930: add         al,0FEh
  10008932: adc         al,byte ptr [ecx]
  10008934: push        esp
  10008935: sub         al,byte ptr [eax]
  10008937: add         byte ptr [ecx+1Ch],al
  1000893A: add         byte ptr [eax],al
  1000893C: add         al,0
  1000893E: add         byte ptr [eax],al
  10008940: or          al,byte ptr [eax]
  10008942: add         byte ptr [eax],al
  10008944: adc         byte ptr [eax],al
  10008946: add         byte ptr [eax],al
  10008948: sbb         al,byte ptr [eax]
  1000894A: add         byte ptr [eax],al
  1000894C: or          eax,25000000h
  10008951: add         byte ptr [eax],al
  10008953: add         dword ptr [ebx],eax
  10008955: xor         byte ptr [edx],al
  10008957: add         byte ptr [eax],bl
  10008959: add         byte ptr [eax],al
  1000895B: add         byte ptr [edx+12110000h],ah
  10008961: add         byte ptr [edx],al
  10008963: dec         edx
  10008964: sub         byte ptr [edx],ch
  10008966: add         byte ptr [eax],al
  10008968: or          al,byte ptr [esi]
  1000896A: sub         byte ptr [edx],dh
  1000896C: add         byte ptr [eax],al
  1000896E: or          cl,byte ptr [ebx]
  10008970: adc         al,byte ptr [ecx]
  10008972: sub         byte ptr [eax+eax],dh
  10008975: add         byte ptr [edx],cl
  10008977: sub         cl,byte ptr [ebx]
  10008979: xor         byte ptr [ebx],al
  1000897B: add         byte ptr [edx],dl
  1000897D: add         dword ptr [eax],eax
  1000897F: add         byte ptr [edx+1],cl
  10008982: add         byte ptr [ecx],dl
  10008984: add         bh,byte ptr [edi-15h]
  10008987: add         byte ptr [eax],al
  10008989: add         al,0FEh
  1000898B: adc         al,byte ptr [ecx]
  1000898D: push        esp
  1000898E: add         bh,byte ptr [edi-1Ah]
  10008991: add         byte ptr [eax],al
  10008993: add         al,0FEh
  10008995: adc         al,byte ptr [ecx]
  10008997: push        esp
  10008998: add         bl,byte ptr [edx]
  1000899A: pop         eax
  1000899B: adc         al,byte ptr [ebx]
  1000899D: add         ecx,dword ptr [edx+28h]
  100089A0: sub         al,byte ptr [eax]
  100089A2: add         byte ptr [edx],cl
  100089A4: or          dword ptr [eax],ebp
  100089A6: xor         al,byte ptr [eax]
  100089A8: add         byte ptr [edx],cl
  100089AA: adc         ecx,dword ptr [edx]
  100089AC: adc         cl,byte ptr [edx]
  100089AE: sub         byte ptr [eax+eax],dh
  100089B1: add         byte ptr [edx],cl
  100089B3: sub         byte ptr [eax],dh
  100089B5: add         byte ptr [eax],al
  100089B7: or          ch,byte ptr [eax]
  100089B9: xor         eax,dword ptr [eax]
  100089BB: add         byte ptr [edx],cl
  100089BD: adc         ecx,dword ptr [ecx]
  100089BF: adc         cl,byte ptr [ecx]
  100089C1: sub         byte ptr [ebx],ch
  100089C3: add         byte ptr [eax],al
  100089C5: or          dl,byte ptr [edx+eax+1Eh]
  100089C9: pop         eax
  100089CA: adc         al,28h
  100089CC: xor         byte ptr [eax],al
  100089CE: add         byte ptr [edx],cl
  100089D0: sub         byte ptr [ebx],dh
  100089D2: add         byte ptr [eax],al
  100089D4: or          dl,byte ptr [ebx]
  100089D6: or          byte ptr [edx],dl
  100089D8: or          byte ptr [eax],ch
  100089DA: sub         eax,dword ptr [eax]
  100089DC: add         byte ptr [edx],cl
  100089DE: push        esp
  100089DF: add         bl,byte ptr [edi]
  100089E1: or          al,58h
  100089E3: adc         al,byte ptr [edx]
  100089E5: add         al,4Ah
  100089E7: sub         byte ptr [edx],ch
  100089E9: add         byte ptr [eax],al
  100089EB: or          cl,byte ptr [eax]
  100089ED: sub         byte ptr [edx],dh
  100089EF: add         byte ptr [eax],al
  100089F1: or          dl,byte ptr [ebx]
  100089F3: pop         es
  100089F4: adc         al,byte ptr [edi]
  100089F6: sub         byte ptr [eax+eax],dh
  100089F9: add         byte ptr [edx],cl
  100089FB: sub         byte ptr [eax],dh
  100089FD: add         byte ptr [eax],al
  100089FF: or          ch,byte ptr [eax]
  10008A01: xor         eax,dword ptr [eax]
  10008A03: add         byte ptr [edx],cl
  10008A05: adc         eax,dword ptr [esi]
  10008A07: adc         al,byte ptr [esi]
  10008A09: sub         byte ptr [ebx],ch
  10008A0B: add         byte ptr [eax],al
  10008A0D: or          dl,byte ptr [esi+ebx*8+0Fh]
  10008A11: inc         byte ptr [esi]
  10008A13: mov         edi,2060000h
  10008A18: push        ds
  10008A19: pop         eax
  10008A1A: sub         byte ptr [ebx],al
  10008A1C: add         dword ptr [eax],eax
  10008A1E: push        es
  10008A1F: fcomp3      st(6)
  10008A21: paddd       mm0,mmword ptr [esi]
  10008A24: pop         esp
  10008A25: add         byte ptr [eax],al
  10008A27: push        es
  10008A28: add         bl,byte ptr [edx]
  10008A2A: pop         eax
  10008A2B: sub         byte ptr [ebx],al
  10008A2D: add         dword ptr [eax],eax
  10008A2F: push        es
  10008A30: fcomp3      st(6)
  10008A32: or          eax,0A506FEh
  10008A37: add         byte ptr [esi],al
  10008A39: add         ch,byte ptr [eax]
  10008A3B: add         eax,dword ptr [ecx]
  10008A3D: add         byte ptr [esi],al
  10008A3F: fcomp3      st(6)
  10008A41: or          eax,5C06FEh
  10008A46: add         byte ptr [esi],al
  10008A48: add         ebp,dword ptr [eax]
  10008A4A: add         eax,dword ptr [ecx]
  10008A4C: add         byte ptr [esi],al
  10008A4E: fcom        qword ptr [edx]
  10008A50: add         dword ptr [ebx],eax
  10008A52: dec         edx
  10008A53: sub         byte ptr [edx],ch
  10008A55: add         byte ptr [eax],al
  10008A57: or          al,byte ptr [edi]
  10008A59: sub         byte ptr [edx],dh
  10008A5B: add         byte ptr [eax],al
  10008A5D: or          dl,byte ptr [ebx]
  10008A5F: add         eax,31280512h
  10008A64: add         byte ptr [eax],al
  10008A66: or          al,byte ptr [ebx]
  10008A68: push        ss
  10008A69: push        esp
  10008A6A: fimul       word ptr ds:[005E06FEh]
  10008A70: add         byte ptr [esi],al
  10008A72: add         al,28h
  10008A74: add         eax,dword ptr [ecx]
  10008A76: add         byte ptr [esi],al
  10008A78: fcom        qword ptr [edx]
  10008A7A: add         byte ptr [edx+ecx*2],al
  10008A7D: sub         byte ptr [edx],ch
  10008A7F: add         byte ptr [eax],al
  10008A81: or          al,byte ptr [esi]
  10008A83: sub         byte ptr [edx],dh
  10008A85: add         byte ptr [eax],al
  10008A87: or          dl,byte ptr [ebx]
  10008A89: add         al,12h
  10008A8B: add         al,28h
  10008A8D: xor         dword ptr [eax],eax
  10008A8F: add         byte ptr [edx],cl
  10008A91: add         al,16h
  10008A93: push        esp
  10008A94: add         ch,byte ptr [edx]
  10008A96: add         byte ptr [eax],al
  10008A98: inc         ecx
  10008A99: jl          10008A9B
  10008A9B: add         byte ptr [eax+eax],al
  10008A9E: add         byte ptr [eax],al
  10008AA0: pop         ebx
  10008AA1: add         byte ptr [eax],al
  10008AA3: add         byte ptr [edx],dh
  10008AA5: add         byte ptr [eax],al
  10008AA7: add         byte ptr [ebp+0F000000h],cl
  10008AAD: add         byte ptr [eax],al
  10008AAF: add         byte ptr ds:[04010000h],ah
  10008AB5: add         byte ptr [eax],al
  10008AB7: add         byte ptr [ebx],al
  10008ABA: add         byte ptr [eax],al
  10008ABC: pop         ebx
  10008ABD: add         byte ptr [eax],al
  10008ABF: add         byte ptr [esi+0F000000h],bl
  10008AC5: add         byte ptr [eax],al
  10008AC7: add         byte ptr ds:[04010000h],ah
  10008ACD: add         byte ptr [eax],al
  10008ACF: add         byte ptr [edx],cl
  10008AD1: add         byte ptr [eax],al
  10008AD3: add         byte ptr [ebp+AF000000h],ah
  10008AD9: add         byte ptr [eax],al
  10008ADB: add         byte ptr ds:[25000000h],cl
  10008AE1: add         byte ptr [eax],al
  10008AE3: add         dword ptr [eax+eax],eax
  10008AE6: add         byte ptr [eax],al
  10008AE8: add         byte ptr [eax],al
  10008AEA: add         byte ptr [eax],al
  10008AEC: mov         esi,0BE000000h
  10008AF1: add         byte ptr [eax],al
  10008AF3: add         byte ptr ds:[25000000h],cl
  10008AF9: add         byte ptr [eax],al
  10008AFB: add         dword ptr [eax+eax],eax
  10008AFE: add         byte ptr [eax],al
  10008B00: add         byte ptr [eax],al
  10008B02: add         byte ptr [eax],al
  10008B04: call        F8008B09
  10008B09: add         byte ptr [eax],al
  10008B0B: add         byte ptr ds:[25000000h],cl
  10008B11: add         byte ptr [eax],al
  10008B13: add         dword ptr [ebx],ecx
  10008B15: xor         byte ptr [ebx],al
  10008B17: add         bh,cl
  10008B19: add         byte ptr [eax],al
  10008B1B: add         byte ptr [ecx+eax],cl
  10008B1F: adc         dword ptr [edx],eax
  10008B21: jg          10008B0E
  10008B23: add         byte ptr [eax],al
  10008B25: add         al,0FEh
  10008B27: adc         al,byte ptr [ecx]
  10008B29: push        esp
  10008B2A: add         bh,byte ptr [edi-1Ah]
  10008B2D: add         byte ptr [eax],al
  10008B2F: add         al,0FEh
  10008B31: adc         al,byte ptr [ecx]
  10008B33: push        esp
  10008B34: add         bl,byte ptr [edx]
  10008B36: pop         eax
  10008B37: adc         al,28h
  10008B39: xor         byte ptr [eax],al
  10008B3B: add         byte ptr [edx],cl
  10008B3D: sub         byte ptr [ebx],dh
  10008B3F: add         byte ptr [eax],al
  10008B41: or          dl,byte ptr [ebx]
  10008B43: push        es
  10008B44: adc         al,byte ptr [esi]
  10008B46: sub         byte ptr [ebx],ch
  10008B48: add         byte ptr [eax],al
  10008B4A: or          dl,byte ptr [edx+eax+1Eh]
  10008B4E: pop         eax
  10008B4F: adc         al,byte ptr [ecx]
  10008B51: add         ecx,dword ptr [edx+28h]
  10008B54: sub         al,byte ptr [eax]
  10008B56: add         byte ptr [edx],cl
  10008B58: pop         es
  10008B59: sub         byte ptr [edx],dh
  10008B5B: add         byte ptr [eax],al
  10008B5D: or          dl,byte ptr [ebx]
  10008B5F: add         eax,34280512h
  10008B64: add         byte ptr [eax],al
  10008B66: or          ch,byte ptr [eax]
  10008B68: xor         byte ptr [eax],al
  10008B6A: add         byte ptr [edx],cl
  10008B6C: sub         byte ptr [ebx],dh
  10008B6E: add         byte ptr [eax],al
  10008B70: or          dl,byte ptr [ebx]
  10008B72: add         al,12h
  10008B74: add         al,28h
  10008B76: sub         eax,dword ptr [eax]
  10008B78: add         byte ptr [edx],cl
  10008B7A: push        esp
  10008B7B: add         bl,byte ptr [edi]
  10008B7D: or          al,58h
  10008B7F: adc         al,28h
  10008B81: xor         byte ptr [eax],al
  10008B83: add         byte ptr [edx],cl
  10008B85: sub         byte ptr [ebx],dh
  10008B87: add         byte ptr [eax],al
  10008B89: or          cl,byte ptr ds:[2B280312h]
  10008B8F: add         byte ptr [eax],al
  10008B91: or          dl,byte ptr [esi+ebx*8+0Fh]
  10008B95: inc         byte ptr [esi]
  10008B97: mov         edi,2060000h
  10008B9C: push        ds
  10008B9D: pop         eax
  10008B9E: sub         byte ptr [ebx],al
  10008BA0: add         dword ptr [eax],eax
  10008BA2: push        es
  10008BA3: fcomp3      st(6)
  10008BA5: paddd       mm0,mmword ptr [esi]
  10008BA8: pop         esp
  10008BA9: add         byte ptr [eax],al
  10008BAB: push        es
  10008BAC: add         bl,byte ptr [edx]
  10008BAE: pop         eax
  10008BAF: sub         byte ptr [ebx],al
  10008BB1: add         dword ptr [eax],eax
  10008BB3: push        es
  10008BB4: fcomp3      st(6)
  10008BB6: or          eax,0A506FEh
  10008BBB: add         byte ptr [esi],al
  10008BBD: add         ch,byte ptr [eax]
  10008BBF: add         eax,dword ptr [ecx]
  10008BC1: add         byte ptr [esi],al
  10008BC3: fcomp3      st(6)
  10008BC5: or          eax,0BF06FEh
  10008BCA: add         byte ptr [esi],al
  10008BCC: add         ebp,dword ptr [eax]
  10008BCE: add         eax,dword ptr [ecx]
  10008BD0: add         byte ptr [esi],al
  10008BD2: fcom        qword ptr [edx]
  10008BD4: add         byte ptr [ebx],al
  10008BD6: dec         edx
  10008BD7: sub         byte ptr [edx],ch
  10008BD9: add         byte ptr [eax],al
  10008BDB: or          al,byte ptr [esi]
  10008BDD: sub         byte ptr [edx],dh
  10008BDF: add         byte ptr [eax],al
  10008BE1: or          cl,byte ptr [edx+edx]
  10008BE4: add         ch,byte ptr [eax]
  10008BE6: xor         dword ptr [eax],eax
  10008BE8: add         byte ptr [edx],cl
  10008BEA: add         edx,dword ptr [esi]
  10008BEC: push        esp
  10008BED: add         ch,byte ptr [edx]
  10008BEF: add         byte ptr [ecx+64h],al
  10008BF2: add         byte ptr [eax],al
  10008BF4: add         al,0
  10008BF6: add         byte ptr [eax],al
  10008BF8: pop         ebx
  10008BF9: add         byte ptr [eax],al
  10008BFB: add         byte ptr [edx],bl
  10008BFD: add         byte ptr [eax],al
  10008BFF: add         byte ptr [ebp],dh
  10008C02: add         byte ptr [eax],al
  10008C04: sldt        word ptr [eax]
  10008C07: add         byte ptr ds:[04010000h],ah
  10008C0D: add         byte ptr [eax],al
  10008C0F: add         byte ptr [eax+eax],ch
  10008C12: add         byte ptr [eax],al
  10008C14: pop         edx
  10008C15: add         byte ptr [eax],al
  10008C17: add         byte ptr [esi+0F000000h],al
  10008C1D: add         byte ptr [eax],al
  10008C1F: add         byte ptr ds:[04010000h],ah
  10008C25: add         byte ptr [eax],al
  10008C27: add         byte ptr [edx],cl
  10008C29: add         byte ptr [eax],al
  10008C2B: add         byte ptr [ebp+97000000h],cl
  10008C31: add         byte ptr [eax],al
  10008C33: add         byte ptr ds:[25000000h],cl
  10008C39: add         byte ptr [eax],al
  10008C3B: add         dword ptr [eax+eax],eax
  10008C3E: add         byte ptr [eax],al
  10008C40: add         byte ptr [eax],al
  10008C42: add         byte ptr [eax],al
  10008C44: cmps        byte ptr [esi],byte ptr es:[edi]
  10008C45: add         byte ptr [eax],al
  10008C47: add         byte ptr [esi+0D000000h],ah
  10008C4D: add         byte ptr [eax],al
  10008C4F: add         byte ptr ds:[03010000h],ah
  10008C55: xor         byte ptr [edx],al
  10008C57: add         byte ptr [eax+eax],ch
  10008C5A: add         byte ptr [eax],al
  10008C5C: mov         al,byte ptr ds:[12110000h]
  10008C61: add         byte ptr [ebx],al
  10008C63: dec         edx
  10008C64: sub         byte ptr [edx],ch
  10008C66: add         byte ptr [eax],al
  10008C68: or          al,byte ptr [esi]
  10008C6A: sub         byte ptr [edx],dh
  10008C6C: add         byte ptr [eax],al
  10008C6E: or          cl,byte ptr [edx+edx]
  10008C71: add         ch,byte ptr [eax]
  10008C73: xor         al,0
  10008C75: add         byte ptr [edx],cl
  10008C77: sub         byte ptr [eax],dh
  10008C79: add         byte ptr [eax],al
  10008C7B: or          ch,byte ptr [eax]
  10008C7D: xor         eax,dword ptr [eax]
  10008C7F: add         byte ptr [edx],cl
  10008C81: or          eax,dword ptr [edx]
  10008C83: adc         al,byte ptr [ecx]
  10008C85: sub         byte ptr [ebx],ch
  10008C87: add         byte ptr [eax],al
  10008C89: or          dl,byte ptr [edx+ebp+0Bh]
  10008C8D: xor         byte ptr [ebx],al
  10008C8F: add         bl,al
  10008C91: add         dword ptr [eax],eax
  10008C93: add         byte ptr [edi+1],cl
  10008C96: add         byte ptr [ecx],dl
  10008C98: push        ss
  10008C99: or          dl,byte ptr [esi]
  10008C9B: adc         eax,dword ptr [edx+edx]
  10008C9E: push        cs
  10008C9F: add         bl,byte ptr [edx]
  10008CA1: pop         eax
  10008CA2: dec         edx
  10008CA3: sub         byte ptr [edx],ch
  10008CA5: add         byte ptr [eax],al
  10008CA7: or          dl,byte ptr [ecx]
  10008CA9: push        cs
  10008CAA: sub         byte ptr [edx],dh
  10008CAC: add         byte ptr [eax],al
  10008CAE: or          dl,byte ptr [ebx]
  10008CB0: sbb         dl,byte ptr [edx]
  10008CB2: sbb         ch,byte ptr [eax]
  10008CB4: xor         al,0
  10008CB6: add         byte ptr [edx],cl
  10008CB8: cmp         dword ptr [edx],edx
  10008CBA: add         dword ptr [eax],eax
  10008CBC: add         byte ptr [edx],dl
  10008CBE: or          eax,4A581A02h
  10008CC3: sub         byte ptr [edx],ch
  10008CC5: add         byte ptr [eax],al
  10008CC7: or          dl,byte ptr [ecx]
  10008CC9: or          eax,3228h
  10008CCE: or          dl,byte ptr [ebx]
  10008CD0: sbb         dword ptr [edx],edx
  10008CD2: sbb         dword ptr [eax],ebp
  10008CD4: xor         al,0
  10008CD6: add         byte ptr [edx],cl
  10008CD8: adc         ecx,dword ptr [edx+edx]
  10008CDB: or          eax,dword ptr [edx]
  10008CDD: sbb         bl,byte ptr [eax+4Ah]
  10008CE0: sub         byte ptr [edx],ch
  10008CE2: add         byte ptr [eax],al
  10008CE4: or          dl,byte ptr [ecx]
  10008CE6: or          ebp,dword ptr [eax]
  10008CE8: xor         al,byte ptr [eax]
  10008CEA: add         byte ptr [edx],cl
  10008CEC: adc         ebx,dword ptr [eax]
  10008CEE: adc         bl,byte ptr [eax]
  10008CF0: sub         byte ptr [eax+eax],dh
  10008CF3: add         byte ptr [edx],cl
  10008CF5: add         al,73h
  10008CF7: xor         eax,110A0000h
  10008CFC: or          al,6Fh
  10008CFE: inc         esp
  10008CFF: add         byte ptr [eax],al
  10008D01: or          ch,byte ptr [edi+41h]
  10008D04: add         byte ptr [eax],al
  10008D06: or          bh,byte ptr [ecx]
  10008D08: ret
  10008D09: add         byte ptr [eax],al
  10008D0B: add         byte ptr [edi],bl
  10008D0D: adc         byte ptr [eax],ch
  10008D0F: sbb         eax,0D060001h
  10008D14: or          dword ptr [eax+ebp*2],ebp
  10008D17: adc         dl,byte ptr [edi]
  10008D19: adc         ecx,dword ptr [edx]
  10008D1B: adc         dl,byte ptr [edi]
  10008D1D: add         bl,byte ptr [edi]
  10008D1F: or          al,58h
  10008D21: sub         byte ptr [ebp],bl
  10008D24: add         byte ptr [esi],al
  10008D26: adc         ecx,dword ptr [ecx]
  10008D28: adc         dl,byte ptr [esi]
  10008D2A: adc         edx,dword ptr ds:[1A020812h]
  10008D30: pop         eax
  10008D31: dec         edx
  10008D32: sub         byte ptr [edx],ch
  10008D34: add         byte ptr [eax],al
  10008D36: or          dl,byte ptr [ecx]
  10008D38: or          byte ptr [eax],ch
  10008D3A: xor         al,byte ptr [eax]
  10008D3C: add         byte ptr [edx],cl
  10008D3E: adc         edx,dword ptr [edx+edx]
  10008D41: adc         al,28h
  10008D43: xor         al,0
  10008D45: add         byte ptr [edx],cl
  10008D47: outs        dx,dword ptr [esi]
  10008D48: add         byte ptr ds:[eax],al
  10008D4B: or          ch,byte ptr [eax]
  10008D4D: xor         byte ptr [eax],al
  10008D4F: add         byte ptr [edx],cl
  10008D51: sub         byte ptr [ebx],dh
  10008D53: add         byte ptr [eax],al
  10008D55: or          dl,byte ptr [ebx]
  10008D57: adc         edx,dword ptr [edx]
  10008D59: push        ss
  10008D5A: adc         dl,byte ptr [ebx]
  10008D5C: sub         byte ptr [ebx],ch
  10008D5E: add         byte ptr [eax],al
  10008D60: or          dl,byte ptr [esi+ebx*8+0Eh]
  10008D64: inc         byte ptr [esi]
  10008D66: pop         esi
  10008D67: add         byte ptr [eax],al
  10008D69: push        es
  10008D6A: adc         dword ptr [edx],ecx
  10008D6C: sub         byte ptr [ebx],al
  10008D6E: add         dword ptr [eax],eax
  10008D70: push        es
  10008D71: fmul        qword ptr [ecx]
  10008D73: adc         dl,byte ptr [esi]
  10008D75: adc         dword ptr [ecx],ecx
  10008D77: sub         byte ptr [ecx+0C060000h],ch
  10008D7D: fimul       word ptr [ebx]
  10008D7F: push        ss
  10008D80: or          al,0DEh
  10008D82: pop         es
  10008D83: or          dword ptr [eax],ebp
  10008D85: push        ds
  10008D86: add         dword ptr [eax],eax
  10008D88: push        es
  10008D89: fmul        qword ptr [eax]
  10008D8B: adc         eax,dword ptr [edx+edx]
  10008D8E: pop         es
  10008D8F: add         bl,byte ptr [edx]
  10008D91: pop         eax
  10008D92: dec         edx
  10008D93: sub         byte ptr [edx],ch
  10008D95: add         byte ptr [eax],al
  10008D97: or          dl,byte ptr [ecx]
  10008D99: pop         es
  10008D9A: sub         byte ptr [edx],dh
  10008D9C: add         byte ptr [eax],al
  10008D9E: or          dl,byte ptr [ebx]
  10008DA0: adc         dl,byte ptr [edx]
  10008DA2: adc         ch,byte ptr [eax]
  10008DA4: xor         al,0
  10008DA6: add         byte ptr [edx],cl
  10008DA8: outs        dx,dword ptr [esi]
  10008DA9: inc         eax
  10008DAA: add         byte ptr [eax],al
  10008DAC: or          ah,byte ptr [esi]
  10008DAE: or          byte ptr [eax+00007FDDh],ch
  10008DB5: add         dh,bl
  10008DB7: pop         ss
  10008DB8: push        es
  10008DB9: pop         ss
  10008DBA: pop         edi
  10008DBB: sub         al,11h
  10008DBD: push        es
  10008DBE: pop         ds
  10008DBF: FE
  10008DC0: pop         edi
  10008DC1: or          bh,dh
  10008DC3: push        es
  10008DC4: xor         al,0
  10008DC6: add         byte ptr [esi],al
  10008DC8: add         ebp,dword ptr [eax]
  10008DCA: add         eax,dword ptr [ecx]
  10008DCC: add         byte ptr [esi],al
  10008DCE: fadd        qword ptr [eax]
  10008DD0: add         eax,60DE022Dh
  10008DD5: pop         ds
  10008DD6: adc         byte ptr [eax],ch
  10008DD8: sbb         eax,0B060001h
  10008DDD: pop         es
  10008DDE: sub         al,2Ch
  10008DE0: adc         dl,byte ptr [ecx]
  10008DE2: adc         edx,dword ptr [eax]
  10008DE4: add         eax,3573h
  10008DE9: or          ch,byte ptr [eax]
  10008DEB: xor         byte ptr [eax],al
  10008DED: add         byte ptr [edx],cl
  10008DEF: sub         byte ptr [ebx],dh
  10008DF1: add         byte ptr [eax],al
  10008DF3: or          dl,byte ptr [ebx]
  10008DF5: movlps      xmm2,qword ptr [ecx]
  10008DF8: adc         cl,byte ptr [edi]
  10008DFA: sub         byte ptr [ebx],ch
  10008DFC: add         byte ptr [eax],al
  10008DFE: or          dl,byte ptr [edi+eax+12h]
  10008E02: adc         dword ptr [eax],ebp
  10008E04: lods        byte ptr [esi]
  10008E05: add         byte ptr [eax],al
  10008E07: push        es
  10008E08: adc         eax,dword ptr ds:[13160CDEh]
  10008E0E: add         eax,280707DEh
  10008E13: push        ds
  10008E14: add         dword ptr [eax],eax
  10008E16: push        es
  10008E17: fcom        qword ptr [ecx]
  10008E19: add         eax,17DE0413h
  10008E1E: push        es
  10008E1F: pop         ss
  10008E20: pop         edi
  10008E21: sub         al,11h
  10008E23: push        es
  10008E24: pop         ds
  10008E25: FE
  10008E26: pop         edi
  10008E27: or          bh,dh
  10008E29: push        es
  10008E2A: xor         al,0
  10008E2C: add         byte ptr [esi],al
  10008E2E: add         ebp,dword ptr [eax]
  10008E30: add         eax,dword ptr [ecx]
  10008E32: add         byte ptr [esi],al
  10008E34: fadd        qword ptr [eax]
  10008E36: add         edx,dword ptr [ecx]
  10008E38: add         al,54h
  10008E3A: pop         ss
  10008E3B: or          al,byte ptr [ebx]
  10008E3D: adc         eax,dword ptr [esi]
  10008E3F: ficom       word ptr [edi]
  10008E41: push        es
  10008E42: pop         ss
  10008E43: pop         edi
  10008E44: sub         al,11h
  10008E46: push        es
  10008E47: pop         ds
  10008E48: FE
  10008E49: pop         edi
  10008E4A: or          bh,dh
  10008E4C: push        es
  10008E4D: xor         al,0
  10008E4F: add         byte ptr [esi],al
  10008E51: add         ebp,dword ptr [eax]
  10008E53: add         eax,dword ptr [ecx]
  10008E55: add         byte ptr [esi],al
  10008E57: fcom        qword ptr [ecx]
  10008E59: push        es
  10008E5A: sub         al,byte ptr [eax]
  10008E5C: inc         ecx
  10008E5D: xchg        eax,esp
  10008E5E: add         byte ptr [eax],al
  10008E60: add         al,0
  10008E62: add         byte ptr [eax],al
  10008E64: nop
  10008E65: add         byte ptr [eax],al
  10008E67: add         byte ptr [eax+eax],bh
  10008E6A: add         byte ptr [eax],al
  10008E6C: int         3
  10008E6D: add         byte ptr [eax],al
  10008E6F: add         byte ptr [esi],cl
  10008E71: add         byte ptr [eax],al
  10008E73: add         byte ptr ds:[04010000h],ah
  10008E79: add         byte ptr [eax],al
  10008E7B: add         byte ptr [eax+eax],bh
  10008E7F: add         byte ptr [edi],ch
  10008E82: add         byte ptr [eax],al
  10008E84: jmp         10008E86
  10008E86: add         byte ptr [eax],al
  10008E88: pop         es
  10008E89: add         byte ptr [eax],al
  10008E8B: add         byte ptr ds:[04010000h],ah
  10008E91: add         byte ptr [eax],al
  10008E93: add         byte ptr [eax+eax],bh
  10008E97: add         byte ptr [eax+eax+01200000h],ah
  10008E9E: add         byte ptr [eax],al
  10008EA0: pop         ss
  10008EA1: add         byte ptr [eax],al
  10008EA3: add         byte ptr ds:[04010000h],ah
  10008EA9: add         byte ptr [eax],al
  10008EAB: add         byte ptr [ebp+1],al
  10008EAE: add         byte ptr [eax],al
  10008EB0: xor         al,0
  10008EB2: add         byte ptr [eax],al
  10008EB4: jns         10008EB7
  10008EB6: add         byte ptr [eax],al
  10008EB8: pop         es
  10008EB9: add         byte ptr [eax],al
  10008EBB: add         byte ptr ds:[04010000h],ah
  10008EC1: add         byte ptr [eax],al
  10008EC3: add         byte ptr [eax],bh
  10008EC5: add         dword ptr [eax],eax
  10008EC7: add         byte ptr [esi],cl
  10008ECA: add         byte ptr [eax],al
  10008ECC: xchg        al,byte ptr [ecx]
  10008ECE: add         byte ptr [eax],al
  10008ED0: pop         ss
  10008ED1: add         byte ptr [eax],al
  10008ED3: add         byte ptr ds:[04010000h],ah
  10008ED9: add         byte ptr [eax],al
  10008EDB: add         byte ptr [esi+0B000001h],bl
  10008EE1: add         byte ptr [eax],al
  10008EE3: add         byte ptr [ecx+17000001h],ch
  10008EE9: add         byte ptr [eax],al
  10008EEB: add         byte ptr ds:[FF010000h],ah
  10008EF1: and         eax,100245CCh
  10008EF6: int         3
  10008EF7: int         3
  10008EF8: or          esi,dword ptr [eax]
  10008EFA: add         eax,dword ptr [eax]
  10008EFC: xor         al,byte ptr [ecx]
  10008EFE: add         byte ptr [eax],al
  10008F00: push        eax
  10008F01: add         dword ptr [eax],eax
  10008F03: adc         dword ptr [edx],eax
  10008F05: jg          10008F06
  10008F07: add         byte ptr [eax],al
  10008F09: add         al,0FEh
  10008F0B: adc         al,byte ptr [ecx]
  10008F0D: push        esp
  10008F0E: add         bh,byte ptr [edi-21h]
  10008F11: add         byte ptr [eax],al
  10008F13: add         al,0FEh
  10008F15: adc         al,byte ptr [ecx]
  10008F17: push        esp
  10008F18: add         bl,byte ptr [edx]
  10008F1A: pop         eax
  10008F1B: adc         al,byte ptr ds:[2A284A03h]
  10008F21: add         byte ptr [eax],al
  10008F23: or          dl,byte ptr [ecx]
  10008F25: add         eax,3228h
  10008F2A: or          dl,byte ptr [ebx]
  10008F2C: or          eax,34280D12h
  10008F31: add         byte ptr [eax],al
  10008F33: or          ch,byte ptr [eax]
  10008F35: xor         byte ptr [eax],al
  10008F37: add         byte ptr [edx],cl
  10008F39: sub         byte ptr [ebx],dh
  10008F3B: add         byte ptr [eax],al
  10008F3D: or          dl,byte ptr [ebx]
  10008F3F: or          al,12h
  10008F41: or          al,28h
  10008F43: sub         eax,dword ptr [eax]
  10008F45: add         byte ptr [edx],cl
  10008F47: push        esp
  10008F48: adc         al,byte ptr [ebx+eax]
  10008F4B: dec         edx
  10008F4C: sub         byte ptr [edx],ch
  10008F4E: add         byte ptr [eax],al
  10008F50: or          dl,byte ptr [ecx]
  10008F52: add         al,28h
  10008F54: xor         al,byte ptr [eax]
  10008F56: add         byte ptr [edx],cl
  10008F58: adc         ecx,dword ptr [ebx]
  10008F5A: adc         cl,byte ptr [ebx]
  10008F5C: sub         byte ptr [eax+eax],dh
  10008F5F: add         byte ptr [edx],cl
  10008F61: outs        dx,dword ptr [esi]
  10008F62: inc         esi
  10008F63: add         byte ptr [eax],al
  10008F65: or          al,byte ptr [edx]
  10008F67: push        ds
  10008F68: pop         eax
  10008F69: or          eax,3028h
  10008F6E: or          ch,byte ptr [eax]
  10008F70: xor         eax,dword ptr [eax]
  10008F72: add         byte ptr [edx],cl
  10008F74: adc         ecx,dword ptr [edx]
  10008F76: or          dword ptr [edx],edx
  10008F78: or          ch,byte ptr [eax]
  10008F7A: sub         eax,dword ptr [eax]
  10008F7C: add         byte ptr [edx],cl
  10008F7E: push        esp
  10008F7F: add         bl,byte ptr [edi]
  10008F81: or          al,58h
  10008F83: adc         al,byte ptr [edx]
  10008F85: add         al,4Ah
  10008F87: sub         byte ptr [edx],ch
  10008F89: add         byte ptr [eax],al
  10008F8B: or          cl,byte ptr [eax]
  10008F8D: sub         byte ptr [edx],dh
  10008F8F: add         byte ptr [eax],al
  10008F91: or          dl,byte ptr [ebx]
  10008F93: or          dword ptr [edx],edx
  10008F95: or          dword ptr [eax],ebp
  10008F97: xor         al,0
  10008F99: add         byte ptr [edx],cl
  10008F9B: sub         byte ptr [eax],dh
  10008F9D: add         byte ptr [eax],al
  10008F9F: or          ch,byte ptr [eax]
  10008FA1: xor         eax,dword ptr [eax]
  10008FA3: add         byte ptr [edx],cl
  10008FA5: adc         ecx,dword ptr [eax]
  10008FA7: adc         cl,byte ptr [eax]
  10008FA9: sub         byte ptr [ebx],ch
  10008FAB: add         byte ptr [eax],al
  10008FAD: or          dl,byte ptr [esi+ebx*8+0Fh]
  10008FB1: inc         byte ptr [esi]
  10008FB3: rol         dword ptr [eax],0
  10008FB6: push        es
  10008FB7: add         bl,byte ptr [esi]
  10008FB9: pop         eax
  10008FBA: sub         byte ptr [ebx],al
  10008FBC: add         dword ptr [eax],eax
  10008FBE: push        es
  10008FBF: fcomp3      st(6)
  10008FC1: paddd       mm0,mmword ptr [esi]
  10008FC4: rol         dword ptr [eax],0
  10008FC7: push        es
  10008FC8: add         bl,byte ptr [edx]
  10008FCA: pop         eax
  10008FCB: sub         byte ptr [ebx],al
  10008FCD: add         dword ptr [eax],eax
  10008FCF: push        es
  10008FD0: fcomp3      st(6)
  10008FD2: or          eax,0A706FEh
  10008FD7: add         byte ptr [esi],al
  10008FD9: add         ch,byte ptr [eax]
  10008FDB: add         eax,dword ptr [ecx]
  10008FDD: add         byte ptr [esi],al
  10008FDF: fcomp3      st(6)
  10008FE1: or          eax,0C106FEh
  10008FE6: add         byte ptr [esi],al
  10008FE8: add         ebp,dword ptr [eax]
  10008FEA: add         eax,dword ptr [ecx]
  10008FEC: add         byte ptr [esi],al
  10008FEE: fcom        qword ptr [edx]
  10008FF0: add         dword ptr [ebx],eax
  10008FF2: dec         edx
  10008FF3: sub         byte ptr [edx],ch
  10008FF5: add         byte ptr [eax],al
  10008FF7: or          al,byte ptr [edi]
  10008FF9: sub         byte ptr [edx],dh
  10008FFB: add         byte ptr [eax],al
  10008FFD: or          dl,byte ptr [ebx]
  10008FFF: pop         es
  10009000: adc         al,byte ptr [edi]
  10009002: sub         byte ptr [ecx],dh
  10009004: add         byte ptr [eax],al
  10009006: or          al,byte ptr [ebx]
  10009008: push        ss
  10009009: push        esp
  1000900A: fimul       word ptr ds:[005E06FEh]
  10009010: add         byte ptr [esi],al
  10009012: add         al,28h
  10009014: add         eax,dword ptr [ecx]
  10009016: add         byte ptr [esi],al
  10009018: fcom        qword ptr [edx]
  1000901A: add         byte ptr [edx+ecx*2],al
  1000901D: sub         byte ptr [edx],ch
  1000901F: add         byte ptr [eax],al
  10009021: or          al,byte ptr [esi]
  10009023: sub         byte ptr [edx],dh
  10009025: add         byte ptr [eax],al
  10009027: or          dl,byte ptr [ebx]
  10009029: push        es
  1000902A: adc         al,byte ptr [esi]
  1000902C: sub         byte ptr [ecx],dh
  1000902E: add         byte ptr [eax],al
  10009030: or          al,byte ptr [esi+edx]
  10009033: push        esp
  10009034: add         ch,byte ptr [edx]
  10009036: add         byte ptr [eax],al
  10009038: inc         ecx
  10009039: jl          1000903B
  1000903B: add         byte ptr [eax+eax],al
  1000903E: add         byte ptr [eax],al
  10009040: jnp         10009042
  10009042: add         byte ptr [eax],al
  10009044: xor         al,byte ptr [eax]
  10009046: add         byte ptr [eax],al
  10009048: lods        dword ptr [esi]
  10009049: add         byte ptr [eax],al
  1000904B: add         byte ptr [edi],cl
  1000904D: add         byte ptr [eax],al
  1000904F: add         byte ptr ds:[04010000h],ah
  10009055: add         byte ptr [eax],al
  10009057: add         byte ptr [eax+eax],al
  1000905B: add         byte ptr [edx],bh
  1000905E: add         byte ptr [eax],al
  10009060: mov         esi,0F000000h
  10009065: add         byte ptr [eax],al
  10009067: add         byte ptr ds:[04010000h],ah
  1000906D: add         byte ptr [eax],al
  1000906F: add         byte ptr [edx],cl
  10009071: add         byte ptr [eax],al
  10009073: add         ch,al
  10009075: add         byte ptr [eax],al
  10009077: add         bh,cl
  10009079: add         byte ptr [eax],al
  1000907B: add         byte ptr ds:[25000000h],cl
  10009081: add         byte ptr [eax],al
  10009083: add         dword ptr [eax+eax],eax
  10009086: add         byte ptr [eax],al
  10009088: add         byte ptr [eax],al
  1000908A: add         byte ptr [eax],al
  1000908C: fiadd       word ptr [eax]
  1000908E: add         byte ptr [eax],al
  10009090: fiadd       word ptr [eax]
  10009092: add         byte ptr [eax],al
  10009094: or          eax,25000000h
  10009099: add         byte ptr [eax],al
  1000909B: add         dword ptr [eax+eax],eax
  1000909E: add         byte ptr [eax],al
  100090A0: add         byte ptr [eax],al
  100090A2: add         byte ptr [eax],al
  100090A4: or          byte ptr [ecx],al
  100090A6: add         byte ptr [eax],al
  100090A8: or          byte ptr [ecx],al
  100090AA: add         byte ptr [eax],al
  100090AC: or          eax,25000000h
  100090B1: add         byte ptr [eax],al
  100090B3: add         dword ptr [ebx],eax
  100090B5: xor         byte ptr [ebx],al
  100090B7: add         byte ptr [edi],bl
  100090B9: add         byte ptr [eax],al
  100090BB: add         byte ptr [edx+12110000h],ah
  100090C1: add         byte ptr [edx],al
  100090C3: sbb         bl,byte ptr [eax+4Ah]
  100090C6: sub         byte ptr [edx],ch
  100090C8: add         byte ptr [eax],al
  100090CA: or          al,byte ptr [esi]
  100090CC: sub         byte ptr [edx],dh
  100090CE: add         byte ptr [eax],al
  100090D0: or          cl,byte ptr [ebx]
  100090D2: adc         al,byte ptr [ecx]
  100090D4: sub         byte ptr [eax+eax],dh
  100090D7: add         byte ptr [edx],cl
  100090D9: outs        dx,dword ptr [esi]
  100090DA: dec         ecx
  100090DB: add         byte ptr [eax],al
  100090DD: or          ch,byte ptr [edx]
  100090DF: int         3
  100090E0: jmp         dword ptr ds:[100245FCh]
  100090E6: int         3
  100090E7: int         3
  100090E8: or          esi,dword ptr [eax]
  100090EA: add         eax,dword ptr [eax]
  100090EC: adc         al,1
  100090EE: add         byte ptr [eax],al
  100090F0: push        ecx
  100090F1: add         dword ptr [eax],eax
  100090F3: adc         dword ptr [esi],edx
  100090F5: or          dl,byte ptr [edx]
  100090F7: pop         es
  100090F8: add         bl,byte ptr [edx]
  100090FA: pop         eax
  100090FB: dec         edx
  100090FC: sub         byte ptr [edx],ch
  100090FE: add         byte ptr [eax],al
  10009100: or          dl,byte ptr [ecx]
  10009102: pop         es
  10009103: sub         byte ptr [edx],dh
  10009105: add         byte ptr [eax],al
  10009107: or          dl,byte ptr [ebx]
  10009109: movlps      xmm1,qword ptr [edi]
  1000910C: sub         byte ptr [eax+eax],dh
  1000910F: add         byte ptr [edx],cl
  10009111: outs        dx,dword ptr [esi]
  10009112: inc         edi
  10009113: add         byte ptr [eax],al
  10009115: or          bh,byte ptr [ecx]
  10009117: retf
  10009118: add         byte ptr [eax],al
  1000911A: add         byte ptr [edi],bl
  1000911C: adc         byte ptr [eax],ch
  1000911E: sbb         eax,0B060001h
  10009123: pop         es
  10009124: cmp         dword ptr [edx+12000000h],edx
  1000912A: push        cs
  1000912B: adc         eax,dword ptr [esi]
  1000912D: adc         al,byte ptr ds:[580C1F02h]
  10009133: dec         edx
  10009134: sub         byte ptr [edx],ch
  10009136: add         byte ptr [eax],al
  10009138: or          dl,byte ptr [ecx]
  1000913A: add         eax,3228h
  1000913F: or          dl,byte ptr [ebx]
  10009141: or          eax,34280D12h
  10009146: add         byte ptr [eax],al
  10009148: or          ch,byte ptr [eax]
  1000914A: xor         byte ptr [eax],al
  1000914C: add         byte ptr [edx],cl
  1000914E: sub         byte ptr [ebx],dh
  10009150: add         byte ptr [eax],al
  10009152: or          dl,byte ptr [ebx]
  10009154: or          al,12h
  10009156: push        cs
  10009157: adc         cl,byte ptr [eax+ebp]
  1000915A: sub         eax,dword ptr [eax]
  1000915C: add         byte ptr [edx],cl
  1000915E: push        esp
  1000915F: adc         cl,byte ptr [ebx]
  10009161: adc         ecx,dword ptr [edx]
  10009163: adc         al,byte ptr [edx+eax]
  10009166: sbb         bl,byte ptr [eax+4Ah]
  10009169: sub         byte ptr [edx],ch
  1000916B: add         byte ptr [eax],al
  1000916D: or          dl,byte ptr [ecx]
  1000916F: add         al,28h
  10009171: xor         al,byte ptr [eax]
  10009173: add         byte ptr [edx],cl
  10009175: adc         ecx,dword ptr [ecx]
  10009177: adc         cl,byte ptr [ecx]
  10009179: sub         byte ptr [eax+eax],dh
  1000917C: add         byte ptr [edx],cl
  1000917E: outs        dx,dword ptr [esi]
  1000917F: dec         eax
  10009180: add         byte ptr [eax],al
  10009182: or          ch,byte ptr [edi+3Eh]
  10009185: add         byte ptr [eax],al
  10009187: or          ch,byte ptr [eax]
  10009189: xor         byte ptr [eax],al
  1000918B: add         byte ptr [edx],cl
  1000918D: sub         byte ptr [ebx],dh
  1000918F: add         byte ptr [eax],al
  10009191: or          dl,byte ptr [ebx]
  10009193: or          byte ptr [edx],dl
  10009195: or          edx,dword ptr [edx]
  10009197: or          byte ptr [eax],ch
  10009199: sub         eax,dword ptr [eax]
  1000919B: add         byte ptr [edx],cl
  1000919D: push        esp
  1000919E: fimul       word ptr [esi]
  100091A0: inc         byte ptr [esi]
  100091A2: pop         esi
  100091A3: add         byte ptr [eax],al
  100091A5: push        es
  100091A6: adc         dword ptr [esi],eax
  100091A8: sub         byte ptr [ebx],al
  100091AA: add         dword ptr [eax],eax
  100091AC: push        es
  100091AD: fadd        qword ptr [edi]
  100091AF: adc         cl,byte ptr [ebx]
  100091B1: adc         cl,byte ptr [esi]
  100091B3: sub         byte ptr [ecx+0D060000h],ch
  100091B9: fimul       word ptr [ebx]
  100091BB: push        ss
  100091BC: or          eax,280707DEh
  100091C1: push        ds
  100091C2: add         dword ptr [eax],eax
  100091C4: push        es
  100091C5: fadd        qword ptr [ebx]
  100091C7: or          dword ptr [edi+edx+0Ah],edx
  100091CB: add         ecx,dword ptr [esi+ebx*8]
  100091CE: aaa
  100091CF: push        es
  100091D0: pop         ss
  100091D1: pop         edi
  100091D2: sub         al,11h
  100091D4: push        es
  100091D5: pop         ds
  100091D6: FE
  100091D7: pop         edi
  100091D8: or          bh,dh
  100091DA: push        es
  100091DB: xor         al,0
  100091DD: add         byte ptr [esi],al
  100091DF: add         ebp,dword ptr [eax]
  100091E1: add         eax,dword ptr [ecx]
  100091E3: add         byte ptr [esi],al
  100091E5: fadd        qword ptr [ebx]
  100091E7: push        ss
  100091E8: push        esp
  100091E9: pop         ss
  100091EA: or          al,byte ptr [ebx]
  100091EC: or          al,0DEh
  100091EE: pop         ss
  100091EF: push        es
  100091F0: pop         ss
  100091F1: pop         edi
  100091F2: sub         al,11h
  100091F4: push        es
  100091F5: pop         ds
  100091F6: FE
  100091F7: pop         edi
  100091F8: or          bh,dh
  100091FA: push        es
  100091FB: xor         al,0
  100091FD: add         byte ptr [esi],al
  100091FF: add         ebp,dword ptr [eax]
  10009201: add         eax,dword ptr [ecx]
  10009203: add         byte ptr [esi],al
  10009205: fmul        qword ptr [eax]
  10009207: sub         al,byte ptr [ecx+64h]
  1000920A: add         byte ptr [eax],al
  1000920C: add         al,0
  1000920E: add         byte ptr [eax],al
  10009210: imul        eax,dword ptr [eax],0
  10009213: add         byte ptr [ecx],al
  10009216: add         byte ptr [eax],al
  10009218: lods        byte ptr [esi]
  10009219: add         byte ptr [eax],al
  1000921B: add         byte ptr [esi],cl
  1000921D: add         byte ptr [eax],al
  1000921F: add         byte ptr ds:[04010000h],ah
  10009225: add         byte ptr [eax],al
  10009227: add         byte ptr [edi],ch
  10009229: add         byte ptr [eax],al
  1000922B: add         byte ptr [eax+eax+00CB0000h],bl
  10009232: add         byte ptr [eax],al
  10009234: pop         es
  10009235: add         byte ptr [eax],al
  10009237: add         byte ptr ds:[04010000h],ah
  1000923D: add         byte ptr [eax],al
  1000923F: add         byte ptr [edi],ch
  10009241: add         byte ptr [eax],al
  10009243: add         byte ptr [eax+eax+00DB0000h],ch
  1000924A: add         byte ptr [eax],al
  1000924C: pop         ss
  1000924D: add         byte ptr [eax],al
  1000924F: add         byte ptr ds:[04010000h],ah
  10009255: add         byte ptr [eax],al
  10009257: add         ch,dh
  10009259: add         byte ptr [eax],al
  1000925B: add         byte ptr [esi],al
  1000925D: add         byte ptr [eax],al
  1000925F: add         bl,bh
  10009261: add         byte ptr [eax],al
  10009263: add         byte ptr [edi],dl
  10009265: add         byte ptr [eax],al
  10009267: add         byte ptr ds:[CC010000h],ah
  1000926D: int         3
  1000926E: int         3
  1000926F: int         3
  10009270: jmp         dword ptr ds:[10024600h]
  10009276: int         3
  10009277: int         3
  10009278: add         esi,dword ptr [eax]
  1000927A: add         eax,dword ptr [eax]
  1000927C: cmp         eax,dword ptr [eax]
  1000927E: add         byte ptr [eax],al
  10009280: push        edx
  10009281: add         dword ptr [eax],eax
  10009283: adc         dword ptr [edx],edx
  10009285: add         al,byte ptr [edx]
  10009287: push        ds
  10009288: pop         eax
  10009289: dec         edx
  1000928A: sub         byte ptr [edx],ch
  1000928C: add         byte ptr [eax],al
  1000928E: or          cl,byte ptr [eax]
  10009290: sub         byte ptr [edx],dh
  10009292: add         byte ptr [eax],al
  10009294: or          dl,byte ptr [ebx]
  10009296: add         al,12h
  10009298: add         al,28h
  1000929A: xor         al,0
  1000929C: add         byte ptr [edx],cl
  1000929E: outs        dx,dword ptr [esi]
  1000929F: inc         esi
  100092A0: add         byte ptr [eax],al
  100092A2: or          cl,byte ptr [ebx]
  100092A4: adc         al,byte ptr [eax]
  100092A6: add         bl,byte ptr [edx]
  100092A8: pop         eax
  100092A9: dec         edx
  100092AA: sub         byte ptr [edx],ch
  100092AC: add         byte ptr [eax],al
  100092AE: or          al,byte ptr [esi]
  100092B0: sub         byte ptr [edx],dh
  100092B2: add         byte ptr [eax],al
  100092B4: or          cl,byte ptr ds:[28070312h]
  100092BA: cmp         al,byte ptr [eax]
  100092BC: add         byte ptr [edx],cl
  100092BE: sub         cl,ah
  100092C0: jmp         dword ptr ds:[10024604h]
  100092C6: int         3
  100092C7: int         3
  100092C8: or          esi,dword ptr [eax]
  100092CA: add         al,byte ptr [eax]
  100092CC: ja          100092CE
  100092CE: add         byte ptr [eax],al
  100092D0: push        ebx
  100092D1: add         dword ptr [eax],eax
  100092D3: adc         dword ptr [edx],eax
  100092D5: jg          100092CE
  100092D7: add         byte ptr [eax],al
  100092D9: add         al,0FEh
  100092DB: adc         al,byte ptr [ecx]
  100092DD: push        esp
  100092DE: add         bh,byte ptr [edi-1Ch]
  100092E1: add         byte ptr [eax],al
  100092E3: add         al,0FEh
  100092E5: adc         al,byte ptr [ecx]
  100092E7: push        esp
  100092E8: adc         al,byte ptr [ecx]
  100092EA: add         ecx,dword ptr [edx+28h]
  100092ED: sub         al,byte ptr [eax]
  100092EF: add         byte ptr [edx],cl
  100092F1: pop         es
  100092F2: sub         byte ptr [edx],dh
  100092F4: add         byte ptr [eax],al
  100092F6: or          dl,byte ptr [ebx]
  100092F8: add         al,12h
  100092FA: add         al,28h
  100092FC: xor         al,0
  100092FE: add         byte ptr [edx],cl
  10009300: sub         byte ptr [eax+eax],bh
  10009303: add         byte ptr [edx],cl
  10009305: or          eax,12581A02h
  1000930A: add         ebp,dword ptr [eax]
  1000930C: sub         eax,dword ptr [eax]
  1000930E: add         byte ptr [edx],cl
  10009310: push        esp
  10009311: fimul       word ptr ds:[00A306FEh]
  10009317: add         byte ptr [esi],al
  10009319: add         ch,byte ptr [eax]
  1000931B: add         eax,dword ptr [ecx]
  1000931D: add         byte ptr [esi],al
  1000931F: fcomp3      st(6)
  10009321: or          eax,0BF06FEh
  10009326: add         byte ptr [esi],al
  10009328: add         ebp,dword ptr [eax]
  1000932A: add         eax,dword ptr [ecx]
  1000932C: add         byte ptr [esi],al
  1000932E: fcom        qword ptr [edx]
  10009330: add         byte ptr [ebx],al
  10009332: dec         edx
  10009333: sub         byte ptr [edx],ch
  10009335: add         byte ptr [eax],al
  10009337: or          al,byte ptr [esi]
  10009339: sub         byte ptr [edx],dh
  1000933B: add         byte ptr [eax],al
  1000933D: or          cl,byte ptr [edx+edx]
  10009340: add         ch,byte ptr [eax]
  10009342: xor         dword ptr [eax],eax
  10009344: add         byte ptr [edx],cl
  10009346: add         edx,dword ptr [esi]
  10009348: push        esp
  10009349: add         ch,byte ptr [edx]
  1000934B: add         byte ptr [ecx+34h],al
  1000934E: add         byte ptr [eax],al
  10009350: add         al,0
  10009352: add         byte ptr [eax],al
  10009354: or          al,byte ptr [eax]
  10009356: add         byte ptr [eax],al
  10009358: xor         eax,3F000000h
  1000935D: add         byte ptr [eax],al
  1000935F: add         byte ptr ds:[25000000h],cl
  10009365: add         byte ptr [eax],al
  10009367: add         dword ptr [eax+eax],eax
  1000936A: add         byte ptr [eax],al
  1000936C: add         byte ptr [eax],al
  1000936E: add         byte ptr [eax],al
  10009370: dec         esi
  10009371: add         byte ptr [eax],al
  10009373: add         byte ptr [esi],cl
  10009376: add         byte ptr [eax],al
  10009378: or          eax,25000000h
  1000937D: add         byte ptr [eax],al
  1000937F: add         dword ptr [ebx],ecx
  10009381: xor         byte ptr [eax+eax],al
  10009384: arpl        word ptr [eax],ax
  10009386: add         byte ptr [eax],al
  10009388: push        esp
  10009389: add         dword ptr [eax],eax
  1000938B: adc         dword ptr [ebx],eax
  1000938D: sbb         byte ptr [edi+2Ch],bl
  10009390: and         byte ptr [edx],al
  10009392: sbb         bl,byte ptr [ecx+0Ah]
  10009395: add         bl,byte ptr [esi]
  10009397: push        es
  10009398: dec         edx
  10009399: inc         byte ptr [esi]
  1000939B: mov         ebp,28060000h
  100093A0: add         al,1
  100093A2: add         byte ptr [esi],al
  100093A4: add         edx,dword ptr [edi]
  100093A6: pop         edi
  100093A7: sub         al,6
  100093A9: push        es
  100093AA: sub         byte ptr [edi],bl
  100093AC: add         dword ptr [eax],eax
  100093AE: push        es
  100093AF: push        es
  100093B0: sub         al,byte ptr [edx]
  100093B2: jg          10009398
  100093B4: add         byte ptr [eax],al
  100093B6: add         al,0FEh
  100093B8: adc         al,byte ptr [ecx]
  100093BA: push        esp
  100093BB: add         bl,byte ptr [edx]
  100093BD: pop         eax
  100093BE: dec         edx
  100093BF: sub         byte ptr [eax],bh
  100093C1: add         byte ptr [eax],al
  100093C3: or          ch,byte ptr [eax]
  100093C5: cmp         eax,dword ptr [eax]
  100093C7: add         byte ptr [edx],cl
  100093C9: fimul       word ptr ds:[00A306FEh]
  100093CF: add         byte ptr [esi],al
  100093D1: add         ch,byte ptr [eax]
  100093D3: add         eax,dword ptr [ecx]
  100093D5: add         byte ptr [esi],al
  100093D7: fadd        qword ptr [edx]
  100093D9: jg          100093D2
  100093DB: add         byte ptr [eax],al
  100093DD: add         al,0FEh
  100093DF: adc         al,byte ptr [ecx]
  100093E1: push        esp
  100093E2: add         edx,dword ptr [edi]
  100093E4: pop         edi
  100093E5: sub         al,6
  100093E7: add         ch,byte ptr [eax]
  100093E9: push        ds
  100093EA: add         dword ptr [eax],eax
  100093EC: push        es
  100093ED: add         ch,byte ptr [edx]
  100093EF: add         byte ptr [ecx+1Ch],al
  100093F2: add         byte ptr [eax],al
  100093F4: add         al,0
  100093F6: add         byte ptr [eax],al
  100093F8: das
  100093F9: add         byte ptr [eax],al
  100093FB: add         byte ptr [eax],dl
  100093FD: add         byte ptr [eax],al
  100093FF: add         byte ptr [edi],bh
  10009401: add         byte ptr [eax],al
  10009403: add         byte ptr ds:[25000000h],cl
  10009409: add         byte ptr [eax],al
  1000940B: add         esp,ecx
  1000940D: int         3
  1000940E: int         3
  1000940F: int         3
  10009410: jmp         dword ptr ds:[10024608h]
  10009416: int         3
  10009417: int         3
  10009418: add         esi,dword ptr [eax]
  1000941A: add         al,0
  1000941C: cmp         dword ptr [eax],eax
  1000941E: add         byte ptr [eax],al
  10009420: push        ebp
  10009421: add         dword ptr [eax],eax
  10009423: adc         dword ptr [ebx],eax
  10009425: sbb         byte ptr [edi+2Ch],bl
  10009428: and         dword ptr [edx],eax
  1000942A: sbb         bl,byte ptr [ecx+0Ah]
  1000942D: add         bl,byte ptr [edi]
  1000942F: adc         byte ptr [esi],al
  10009431: dec         edx
  10009432: inc         byte ptr [esi]
  10009434: stos        dword ptr es:[edi]
  10009435: add         byte ptr [eax],al
  10009437: push        es
  10009438: sub         byte ptr [ecx+eax],al
  1000943B: add         byte ptr [esi],al
  1000943D: add         edx,dword ptr [edi]
  1000943F: pop         edi
  10009440: sub         al,6
  10009442: push        es
  10009443: sub         byte ptr [edi],bl
  10009445: add         dword ptr [eax],eax
  10009447: push        es
  10009448: push        es
  10009449: sub         al,byte ptr [edx]
  1000944B: sub         byte ptr [ebx+03060000h],ch
  10009451: pop         ss
  10009452: pop         edi
  10009453: sub         al,6
  10009455: add         ch,byte ptr [eax]
  10009457: push        ds
  10009458: add         dword ptr [eax],eax
  1000945A: push        es
  1000945B: add         ch,byte ptr [edx]
  1000945D: int         3
  1000945E: int         3
  1000945F: int         3
  10009460: or          esi,dword ptr [eax]
  10009462: add         eax,dword ptr [eax]
  10009464: pushfd
  10009465: add         byte ptr [eax],al
  10009467: add         byte ptr [esi+1],dl
  1000946A: add         byte ptr [ecx],dl
  1000946C: add         bl,byte ptr [edi]
  1000946E: or          al,58h
  10009470: or          al,12h
  10009472: add         eax,2A284A08h
  10009477: add         byte ptr [eax],al
  10009479: or          dl,byte ptr [ecx]
  1000947B: add         eax,3228h
  10009480: or          dl,byte ptr [ebx]
  10009482: or          byte ptr [edx],dl
  10009484: or          byte ptr [eax],ch
  10009486: xor         dword ptr [eax],eax
  10009488: add         byte ptr [edx],cl
  1000948A: or          byte ptr [esi],dl
  1000948C: push        esp
  1000948D: fimul       word ptr [edi]
  1000948F: inc         byte ptr [esi]
  10009491: mov         edi,2060000h
  10009496: push        ds
  10009497: pop         eax
  10009498: sub         byte ptr [ebx],al
  1000949A: add         dword ptr [eax],eax
  1000949C: push        es
  1000949D: fadd        qword ptr [edx]
  1000949F: push        ds
  100094A0: pop         eax
  100094A1: or          edx,dword ptr [edx]
  100094A3: add         al,7
  100094A5: dec         edx
  100094A6: sub         byte ptr [edx],ch
  100094A8: add         byte ptr [eax],al
  100094AA: or          dl,byte ptr [ecx]
  100094AC: add         al,28h
  100094AE: xor         al,byte ptr [eax]
  100094B0: add         byte ptr [edx],cl
  100094B2: adc         eax,dword ptr [edi]
  100094B4: adc         al,byte ptr [edi]
  100094B6: sub         byte ptr [ecx],dh
  100094B8: add         byte ptr [eax],al
  100094BA: or          al,byte ptr [edi]
  100094BC: push        ss
  100094BD: push        esp
  100094BE: fimul       word ptr [edi]
  100094C0: inc         byte ptr [esi]
  100094C2: pop         esp
  100094C3: add         byte ptr [eax],al
  100094C5: push        es
  100094C6: add         bl,byte ptr [edx]
  100094C8: pop         eax
  100094C9: sub         byte ptr [ebx],al
  100094CB: add         dword ptr [eax],eax
  100094CD: push        es
  100094CE: fadd        qword ptr [edx]
  100094D0: sbb         bl,byte ptr [eax+0Ah]
  100094D3: adc         al,byte ptr [ebx]
  100094D5: push        es
  100094D6: dec         edx
  100094D7: sub         byte ptr [edx],ch
  100094D9: add         byte ptr [eax],al
  100094DB: or          cl,byte ptr [ecx]
  100094DD: sub         byte ptr [edx],dh
  100094DF: add         byte ptr [eax],al
  100094E1: or          dl,byte ptr [ebx]
  100094E3: push        es
  100094E4: adc         al,byte ptr [esi]
  100094E6: sub         byte ptr [ecx],dh
  100094E8: add         byte ptr [eax],al
  100094EA: or          al,byte ptr [esi]
  100094EC: push        ss
  100094ED: push        esp
  100094EE: fimul       word ptr ds:[00A506FEh]
  100094F4: add         byte ptr [esi],al
  100094F6: add         ch,byte ptr [eax]
  100094F8: add         eax,dword ptr [ecx]
  100094FA: add         byte ptr [esi],al
  100094FC: fadd        qword ptr [edx]
  100094FE: jg          100094EB
  10009500: add         byte ptr [eax],al
  10009502: add         al,0FEh
  10009504: adc         al,byte ptr [ecx]
  10009506: push        esp
  10009507: sub         al,byte ptr [ecx+4Ch]
  1000950A: add         byte ptr [eax],al
  1000950C: add         al,0
  1000950E: add         byte ptr [eax],al
  10009510: add         byte ptr [eax],al
  10009512: add         byte ptr [eax],al
  10009514: and         eax,dword ptr [eax]
  10009516: add         byte ptr [eax],al
  10009518: and         eax,dword ptr [eax]
  1000951A: add         byte ptr [eax],al
  1000951C: sldt        word ptr [eax]
  1000951F: add         byte ptr ds:[04010000h],ah
  10009525: add         byte ptr [eax],al
  10009527: add         byte ptr [eax],al
  10009529: add         byte ptr [eax],al
  1000952B: add         byte ptr [eax+eax],dl
  1000952F: add         byte ptr [eax+eax],dl
  10009533: add         byte ptr [edi],cl
  10009535: add         byte ptr [eax],al
  10009537: add         byte ptr ds:[04010000h],ah
  1000953D: add         byte ptr [eax],al
  1000953F: add         byte ptr [eax],al
  10009541: add         byte ptr [eax],al
  10009543: add         byte ptr [eax+eax+00840000h],al
  1000954A: add         byte ptr [eax],al
  1000954C: or          eax,25000000h
  10009551: add         byte ptr [eax],al
  10009553: add         esp,ecx
  10009555: int         3
  10009556: int         3
  10009557: int         3
  10009558: int         3
  10009559: int         3
  1000955A: int         3
  1000955B: int         3
  1000955C: int         3
  1000955D: int         3
  1000955E: int         3
  1000955F: int         3
  10009560: jmp         dword ptr ds:[1002460Ch]
  10009566: int         3
  10009567: int         3
  10009568: or          esi,dword ptr [eax]
  1000956A: add         eax,dword ptr [eax]
  1000956C: arpl        word ptr [ecx],ax
  1000956E: add         byte ptr [eax],al
  10009570: push        edi
  10009571: add         dword ptr [eax],eax
  10009573: adc         dword ptr [edx],edx
  10009575: or          eax,4A581A02h
  1000957A: sub         byte ptr [edx],ch
  1000957C: add         byte ptr [eax],al
  1000957E: or          dl,byte ptr [ecx]
  10009580: or          eax,3228h
  10009585: or          dl,byte ptr [ebx]
  10009587: sbb         dword ptr [edx],edx
  10009589: sbb         dword ptr [eax],ebp
  1000958B: xor         al,0
  1000958D: add         byte ptr [edx],cl
  1000958F: cmp         dword ptr [ecx+1],eax
  10009592: add         byte ptr [eax],al
  10009594: add         edi,dword ptr [ecx]
  10009596: mov         edx,1F000000h
  1000959B: adc         byte ptr [eax],ch
  1000959D: sbb         eax,0B060001h
  100095A2: pop         es
  100095A3: cmp         dword ptr [edi+12000000h],ebx
  100095A9: sbb         byte ptr [ebx],dl
  100095AB: or          al,2
  100095AD: pop         ds
  100095AE: or          al,58h
  100095B0: adc         eax,dword ptr [edx+edx]
  100095B3: sbb         byte ptr [ecx],dl
  100095B5: add         al,28h
  100095B7: pop         ebp
  100095B8: add         byte ptr [eax],al
  100095BA: push        es
  100095BB: adc         ecx,dword ptr [ebx]
  100095BD: adc         dl,byte ptr [edi]
  100095BF: adc         edx,dword ptr [esi]
  100095C1: adc         cl,byte ptr [edx]
  100095C3: adc         dword ptr [edx+ecx*2],eax
  100095C6: sub         byte ptr [edx],ch
  100095C8: add         byte ptr [eax],al
  100095CA: or          dl,byte ptr [ecx]
  100095CC: or          ch,byte ptr [eax]
  100095CE: xor         al,byte ptr [eax]
  100095D0: add         byte ptr [edx],cl
  100095D2: adc         edx,dword ptr ds:[34281512h]
  100095D8: add         byte ptr [eax],al
  100095DA: or          dl,byte ptr [ebx]
  100095DC: or          dword ptr [edx],edx
  100095DE: or          byte ptr [edx],al
  100095E0: sbb         bl,byte ptr [eax+4Ah]
  100095E3: sub         byte ptr [edx],ch
  100095E5: add         byte ptr [eax],al
  100095E7: or          dl,byte ptr [ecx]
  100095E9: or          byte ptr [eax],ch
  100095EB: xor         al,byte ptr [eax]
  100095ED: add         byte ptr [edx],cl
  100095EF: adc         edx,dword ptr [edx+edx]
  100095F2: adc         al,28h
  100095F4: xor         al,0
  100095F6: add         byte ptr [edx],cl
  100095F8: jb          100095B1
  100095FA: add         dword ptr [eax],eax
  100095FC: jo          10009601
  100095FE: jae         10009635
  10009600: add         byte ptr [eax],al
  10009602: or          ch,byte ptr [eax]
  10009604: cmp         eax,110A0000h
  10009609: or          dword ptr [edi+42h],ebp
  1000960C: add         byte ptr [eax],al
  1000960E: or          dh,byte ptr [ecx+edi]
  10009612: add         byte ptr [ecx],al
  10009614: sub         byte ptr [eax],dh
  10009616: add         byte ptr [eax],al
  10009618: or          ch,byte ptr [eax]
  1000961A: xor         eax,dword ptr [eax]
  1000961C: add         byte ptr [edx],cl
  1000961E: adc         edx,dword ptr [ebx]
  10009620: adc         dl,byte ptr [edi]
  10009622: adc         dl,byte ptr [ebx]
  10009624: sub         byte ptr [ebx],ch
  10009626: add         byte ptr [eax],al
  10009628: or          dl,byte ptr [esi+ebx*8+0Eh]
  1000962C: inc         byte ptr [esi]
  1000962E: pop         esi
  1000962F: add         byte ptr [eax],al
  10009631: push        es
  10009632: adc         dword ptr [eax+ebp],ecx
  10009635: add         eax,dword ptr [ecx]
  10009637: add         byte ptr [esi],al
  10009639: fadd        qword ptr [edi]
  1000963B: adc         dl,byte ptr [edi]
  1000963D: adc         dword ptr [ebx],ecx
  1000963F: sub         byte ptr [edx+0D060000h],dh
  10009645: fimul       word ptr [ebx]
  10009647: push        ss
  10009648: or          eax,280707DEh
  1000964D: push        ds
  1000964E: add         dword ptr [eax],eax
  10009650: push        es
  10009651: fmul        qword ptr [ecx]
  10009653: sub         bl,byte ptr [edi]
  10009655: adc         byte ptr [eax],ch
  10009657: sbb         eax,0A060001h
  1000965C: push        es
  1000965D: sub         al,69h
  1000965F: adc         dl,byte ptr [edx]
  10009661: adc         eax,dword ptr [edi]
  10009663: adc         dl,byte ptr [edx]
  10009665: add         bl,byte ptr [edi]
  10009667: or          al,58h
  10009669: sub         byte ptr [ebp],bl
  1000966C: add         byte ptr [esi],al
  1000966E: adc         eax,dword ptr [esi]
  10009670: adc         dl,byte ptr [ecx]
  10009672: adc         edx,dword ptr [eax]
  10009674: adc         al,byte ptr ds:[4A581A02h]
  1000967A: sub         byte ptr [edx],ch
  1000967C: add         byte ptr [eax],al
  1000967E: or          dl,byte ptr [ecx]
  10009680: add         eax,3228h
  10009685: or          dl,byte ptr [ebx]
  10009687: movlps      xmm1,qword ptr [edi]
  1000968A: sub         byte ptr [eax+eax],dh
  1000968D: add         byte ptr [edx],cl
  1000968F: pop         ss
  10009690: outs        dx,dword ptr [esi]
  10009691: inc         ebx
  10009692: add         byte ptr [eax],al
  10009694: or          ch,byte ptr [eax]
  10009696: xor         byte ptr [eax],al
  10009698: add         byte ptr [edx],cl
  1000969A: sub         byte ptr [ebx],dh
  1000969C: add         byte ptr [eax],al
  1000969E: or          dl,byte ptr [ebx]
  100096A0: push        cs
  100096A1: adc         dl,byte ptr [ecx]
  100096A3: adc         cl,byte ptr [esi]
  100096A5: sub         byte ptr [ebx],ch
  100096A7: add         byte ptr [eax],al
  100096A9: or          dl,byte ptr [esi+ebx*8+0Eh]
  100096AD: inc         byte ptr [esi]
  100096AF: pop         esi
  100096B0: add         byte ptr [eax],al
  100096B2: push        es
  100096B3: adc         dword ptr [edi],eax
  100096B5: sub         byte ptr [ebx],al
  100096B7: add         dword ptr [eax],eax
  100096B9: push        es
  100096BA: fadd        qword ptr [esi]
  100096BC: adc         dl,byte ptr [ecx]
  100096BE: adc         dword ptr [esi],eax
  100096C0: sub         byte ptr [edx+0C060000h],dh
  100096C6: fimul       word ptr [ebx]
  100096C8: push        ss
  100096C9: or          al,0DEh
  100096CB: pop         es
  100096CC: push        es
  100096CD: sub         byte ptr [esi],bl
  100096CF: add         dword ptr [eax],eax
  100096D1: push        es
  100096D2: fmul        qword ptr [eax]
  100096D4: sub         dl,byte ptr [esi]
  100096D6: sub         al,byte ptr [eax]
  100096D8: inc         ecx
  100096D9: add         byte ptr fs:[eax],al
  100096DC: add         al,0
  100096DE: add         byte ptr [eax],al
  100096E0: dec         ecx
  100096E1: add         byte ptr [eax],al
  100096E3: add         byte ptr [edi],ch
  100096E6: add         byte ptr [eax],al
  100096E8: mov         eax,0E000000h
  100096ED: add         byte ptr [eax],al
  100096EF: add         byte ptr ds:[04010000h],ah
  100096F5: add         byte ptr [eax],al
  100096F7: add         byte ptr [esi],ch
  100096F9: add         byte ptr [eax],al
  100096FB: add         byte ptr [ecx+D7000000h],ch
  10009701: add         byte ptr [eax],al
  10009703: add         byte ptr [edi],al
  10009705: add         byte ptr [eax],al
  10009707: add         byte ptr ds:[04010000h],ah
  1000970D: add         byte ptr [eax],al
  1000970F: add         ah,bh
  10009711: add         byte ptr [eax],al
  10009713: add         byte ptr ds:[39000000h],bh
  10009719: add         dword ptr [eax],eax
  1000971B: add         byte ptr [esi],cl
  1000971D: add         byte ptr [eax],al
  1000971F: add         byte ptr ds:[04010000h],ah
  10009725: add         byte ptr [eax],al
  10009727: add         al,ch
  10009729: add         byte ptr [eax],al
  1000972B: add         byte ptr [eax],dh
  1000972E: add         byte ptr [eax],al
  10009730: pop         eax
  10009731: add         dword ptr [eax],eax
  10009733: add         byte ptr [edi],al
  10009735: add         byte ptr [eax],al
  10009737: add         byte ptr ds:[CC010000h],ah
  1000973D: int         3
  1000973E: int         3
  1000973F: int         3
  10009740: jmp         dword ptr ds:[10024610h]
  10009746: int         3
  10009747: int         3
  10009748: or          esi,dword ptr [eax]
  1000974A: add         eax,dword ptr [eax]
  1000974C: sbb         al,1
  1000974E: add         byte ptr [eax],al
  10009750: pop         ecx
  10009751: add         dword ptr [eax],eax
  10009753: adc         dword ptr [esi],edx
  10009755: or          eax,1A020812h
  1000975A: pop         eax
  1000975B: dec         edx
  1000975C: sub         byte ptr [edx],ch
  1000975E: add         byte ptr [eax],al
  10009760: or          dl,byte ptr [ecx]
  10009762: or          byte ptr [eax],ch
  10009764: xor         al,byte ptr [eax]
  10009766: add         byte ptr [edx],cl
  10009768: adc         edx,dword ptr [edx]
  1000976A: adc         dl,byte ptr [edx]
  1000976C: sub         byte ptr [eax+eax],dh
  1000976F: add         byte ptr [edx],cl
  10009771: cmp         dword ptr [eax+12000000h],esi
  10009777: pop         es
  10009778: add         bl,byte ptr [edx]
  1000977A: pop         eax
  1000977B: dec         edx
  1000977C: sub         byte ptr [edx],ch
  1000977E: add         byte ptr [eax],al
  10009780: or          dl,byte ptr [ecx]
  10009782: pop         es
  10009783: sub         byte ptr [edx],dh
  10009785: add         byte ptr [eax],al
  10009787: or          dl,byte ptr [ebx]
  10009789: adc         dword ptr [edx],edx
  1000978B: adc         dword ptr [eax],ebp
  1000978D: xor         al,0
  1000978F: add         byte ptr [edx],cl
  10009791: add         esi,dword ptr [ebx+35h]
  10009794: add         byte ptr [eax],al
  10009796: or          bh,byte ptr [esi+39h]
  10009799: add         byte ptr [eax],al
  1000979B: or          ch,byte ptr [edi+3Fh]
  1000979E: add         byte ptr [eax],al
  100097A0: or          bh,byte ptr [ecx]
  100097A2: add         byte ptr [eax],0
  100097A5: add         byte ptr [esi],bl
  100097A7: sub         byte ptr ds:[0C060001h],bl
  100097AD: or          byte ptr [eax*2+0F131012h],ch
  100097B4: adc         al,byte ptr [esi]
  100097B6: add         bl,byte ptr [edx]
  100097B8: pop         eax
  100097B9: dec         edx
  100097BA: sub         byte ptr [edx],ch
  100097BC: add         byte ptr [eax],al
  100097BE: or          dl,byte ptr [ecx]
  100097C0: push        es
  100097C1: sub         byte ptr [edx],dh
  100097C3: add         byte ptr [eax],al
  100097C5: or          dl,byte ptr [ebx]
  100097C7: push        cs
  100097C8: adc         cl,byte ptr [esi]
  100097CA: sub         byte ptr [eax+eax],dh
  100097CD: add         byte ptr [edx],cl
  100097CF: outs        dx,dword ptr [esi]
  100097D0: inc         ebp
  100097D1: add         byte ptr [eax],al
  100097D3: or          ch,byte ptr [eax]
  100097D5: xor         byte ptr [eax],al
  100097D7: add         byte ptr [edx],cl
  100097D9: sub         byte ptr [ebx],dh
  100097DB: add         byte ptr [eax],al
  100097DD: or          dl,byte ptr [ebx]
  100097DF: or          eax,0D121012h
  100097E4: sub         byte ptr [ebx],ch
  100097E6: add         byte ptr [eax],al
  100097E8: or          dl,byte ptr [eax+ecx+12h]
  100097EC: adc         byte ptr [eax],ch
  100097EE: mov         ecx,0B060000h
  100097F3: fimul       word ptr [ebx]
  100097F5: push        ss
  100097F6: or          ebx,esi
  100097F8: pop         es
  100097F9: or          byte ptr [eax],ch
  100097FB: push        ds
  100097FC: add         dword ptr [eax],eax
  100097FE: push        es
  100097FF: fadd        qword ptr [edi]
  10009801: or          eax,1A020512h
  10009806: pop         eax
  10009807: dec         edx
  10009808: sub         byte ptr [edx],ch
  1000980A: add         byte ptr [eax],al
  1000980C: or          dl,byte ptr [ecx]
  1000980E: add         eax,3228h
  10009813: or          dl,byte ptr [ebx]
  10009815: or          al,12h
  10009817: or          al,28h
  10009819: xor         al,0
  1000981B: add         byte ptr [edx],cl
  1000981D: outs        dx,dword ptr [esi]
  1000981E: inc         eax
  1000981F: add         byte ptr [eax],al
  10009821: or          ah,byte ptr [esi]
  10009823: pop         es
  10009824: sub         eax,452C0448h
  10009829: push        ds
  1000982A: sub         byte ptr ds:[0A060001h],bl
  10009830: push        es
  10009831: sub         al,2Ch
  10009833: adc         cl,byte ptr [ebx]
  10009835: adc         ecx,dword ptr [edx]
  10009837: add         al,73h
  10009839: xor         eax,280A0000h
  1000983E: xor         byte ptr [eax],al
  10009840: add         byte ptr [edx],cl
  10009842: sub         byte ptr [ebx],dh
  10009844: add         byte ptr [eax],al
  10009846: or          dl,byte ptr [ebx]
  10009848: or          dword ptr [edx],edx
  1000984A: or          edx,dword ptr [edx]
  1000984C: or          dword ptr [eax],ebp
  1000984E: sub         eax,dword ptr [eax]
  10009850: add         byte ptr [edx],cl
  10009852: push        esp
  10009853: push        es
  10009854: adc         cl,byte ptr [ebx]
  10009856: sub         byte ptr [ecx+13060000h],bh
  1000985C: add         al,0DEh
  1000985E: or          al,16h
  10009860: adc         eax,dword ptr [esi+ebx*8]
  10009863: pop         es
  10009864: push        es
  10009865: sub         byte ptr [esi],bl
  10009867: add         dword ptr [eax],eax
  10009869: push        es
  1000986A: fcom        qword ptr [ecx]
  1000986C: add         al,0Dh
  1000986E: or          dword ptr [edx],ebp
  10009870: inc         ecx
  10009871: xor         al,0
  10009873: add         byte ptr [eax+eax],al
  10009876: add         byte ptr [eax],al
  10009878: pop         ecx
  10009879: add         byte ptr [eax],al
  1000987B: add         byte ptr [eax+eax],cl
  1000987F: add         byte ptr [ebp+07000000h],ah
  10009885: add         byte ptr [eax],al
  10009887: add         byte ptr ds:[04010000h],ah
  1000988D: add         byte ptr [eax],al
  1000988F: add         ah,bl
  10009891: add         byte ptr [eax],al
  10009893: add         byte ptr [eax+eax],dh
  10009896: add         byte ptr [eax],al
  10009898: adc         byte ptr [ecx],al
  1000989A: add         byte ptr [eax],al
  1000989C: pop         es
  1000989D: add         byte ptr [eax],al
  1000989F: add         byte ptr ds:[CC010000h],ah
  100098A5: int         3
  100098A6: int         3
  100098A7: int         3
  100098A8: int         3
  100098A9: int         3
  100098AA: int         3
  100098AB: int         3
  100098AC: int         3
  100098AD: int         3
  100098AE: int         3
  100098AF: int         3
  100098B0: jmp         dword ptr ds:[10024614h]
  100098B6: int         3
  100098B7: int         3
  100098B8: or          esi,dword ptr [eax]
  100098BA: add         eax,dword ptr [eax]
  100098BC: int         0
  100098BE: add         byte ptr [eax],al
  100098C0: pop         edx
  100098C1: add         dword ptr [eax],eax
  100098C3: adc         dword ptr [edx],edx
  100098C5: or          byte ptr [edx],al
  100098C7: sbb         bl,byte ptr [eax+4Ah]
  100098CA: sub         byte ptr [edx],ch
  100098CC: add         byte ptr [eax],al
  100098CE: or          dl,byte ptr [ecx]
  100098D0: or          byte ptr [eax],ch
  100098D2: xor         al,byte ptr [eax]
  100098D4: add         byte ptr [edx],cl
  100098D6: adc         edx,dword ptr [eax]
  100098D8: adc         dl,byte ptr [eax]
  100098DA: sub         byte ptr [eax+eax],dh
  100098DD: add         byte ptr [edx],cl
  100098DF: sub         al,5Fh
  100098E1: push        ds
  100098E2: sub         byte ptr ds:[0B060001h],bl
  100098E8: pop         es
  100098E9: sub         al,46h
  100098EB: adc         cl,byte ptr [edi]
  100098ED: adc         ecx,dword ptr [esi]
  100098EF: adc         al,byte ptr [edi]
  100098F1: add         bl,byte ptr [edx]
  100098F3: pop         eax
  100098F4: dec         edx
  100098F5: sub         byte ptr [edx],ch
  100098F7: add         byte ptr [eax],al
  100098F9: or          dl,byte ptr [ecx]
  100098FB: pop         es
  100098FC: sub         byte ptr [edx],dh
  100098FE: add         byte ptr [eax],al
  10009900: or          dl,byte ptr [ebx]
  10009902: or          eax,34280D12h
  10009907: add         byte ptr [eax],al
  10009909: or          ch,byte ptr [edi+45h]
  1000990C: add         byte ptr [eax],al
  1000990E: or          ch,byte ptr [eax]
  10009910: xor         byte ptr [eax],al
  10009912: add         byte ptr [edx],cl
  10009914: sub         byte ptr [ebx],dh
  10009916: add         byte ptr [eax],al
  10009918: or          dl,byte ptr [ebx]
  1000991A: or          al,12h
  1000991C: movlps      xmm1,qword ptr [eax+ebp]
  10009920: sub         eax,dword ptr [eax]
  10009922: add         byte ptr [edx],cl
  10009924: push        esp
  10009925: pop         es
  10009926: adc         cl,byte ptr [edi]
  10009928: sub         byte ptr [ecx+13060000h],bh
  1000992E: add         al,0DEh
  10009930: or          al,16h
  10009932: adc         eax,dword ptr [esi+ebx*8]
  10009935: pop         es
  10009936: pop         es
  10009937: sub         byte ptr [esi],bl
  10009939: add         dword ptr [eax],eax
  1000993B: push        es
  1000993C: fcom        qword ptr [ecx]
  1000993E: add         al,2Ah
  10009940: add         bl,byte ptr [esi]
  10009942: pop         eax
  10009943: or          eax,4A090612h
  10009948: sub         byte ptr [edx],ch
  1000994A: add         byte ptr [eax],al
  1000994C: or          dl,byte ptr [ecx]
  1000994E: push        es
  1000994F: sub         byte ptr [edx],dh
  10009951: add         byte ptr [eax],al
  10009953: or          dl,byte ptr [ebx]
  10009955: or          edx,dword ptr [edx]
  10009957: or          ebp,dword ptr [eax]
  10009959: xor         al,0
  1000995B: add         byte ptr [edx],cl
  1000995D: sub         al,30h
  1000995F: push        ds
  10009960: sub         byte ptr ds:[0A060001h],bl
  10009966: push        es
  10009967: sub         al,19h
  10009969: adc         cl,byte ptr [edx]
  1000996B: adc         ecx,dword ptr [ecx]
  1000996D: adc         cl,byte ptr [edx]
  1000996F: or          dword ptr [eax],ebp
  10009971: mov         esi,13060000h
  10009976: add         eax,28051106h
  1000997B: mov         ecx,0C060000h
  10009980: fimul       word ptr [ebx]
  10009982: push        ss
  10009983: or          al,0DEh
  10009985: pop         es
  10009986: push        es
  10009987: sub         byte ptr [esi],bl
  10009989: add         dword ptr [eax],eax
  1000998B: push        es
  1000998C: fmul        qword ptr [eax]
  1000998E: sub         dl,byte ptr [esi]
  10009990: sub         al,byte ptr [eax]
  10009992: add         byte ptr [eax],al
  10009994: inc         ecx
  10009995: xor         al,0
  10009997: add         byte ptr [eax+eax],al
  1000999A: add         byte ptr [eax],al
  1000999C: and         al,0
  1000999E: add         byte ptr [eax],al
  100099A0: dec         esi
  100099A1: add         byte ptr [eax],al
  100099A3: add         byte ptr [edx],dh
  100099A6: add         byte ptr [eax],al
  100099A8: pop         es
  100099A9: add         byte ptr [eax],al
  100099AB: add         byte ptr ds:[04010000h],ah
  100099B1: add         byte ptr [eax],al
  100099B3: add         byte ptr [edx+20000000h],ah
  100099B9: add         byte ptr [eax],al
  100099BB: add         dl,al
  100099BD: add         byte ptr [eax],al
  100099BF: add         byte ptr [edi],al
  100099C1: add         byte ptr [eax],al
  100099C3: add         byte ptr ds:[CC010000h],ah
  100099C9: int         3
  100099CA: int         3
  100099CB: int         3
  100099CC: int         3
  100099CD: int         3
  100099CE: int         3
  100099CF: int         3
  100099D0: jmp         dword ptr ds:[10024618h]
  100099D6: int         3
  100099D7: int         3
  100099D8: add         esi,dword ptr [eax]
  100099DA: add         al,0
  100099DC: cmp         dword ptr [eax],eax
  100099DE: add         byte ptr [eax],al
  100099E0: pop         ebx
  100099E1: add         dword ptr [eax],eax
  100099E3: adc         dword ptr [ebx],eax
  100099E5: sbb         byte ptr [edi+2Ch],bl
  100099E8: and         dword ptr [edx],eax
  100099EA: sbb         bl,byte ptr [ecx+0Ah]
  100099ED: add         bl,byte ptr [edi]
  100099EF: adc         byte ptr [esi],al
  100099F1: dec         edx
  100099F2: inc         byte ptr [esi]
  100099F4: mov         ah,0
  100099F6: add         byte ptr [esi],al
  100099F8: sub         byte ptr [ecx+eax],al
  100099FB: add         byte ptr [esi],al
  100099FD: add         edx,dword ptr [edi]
  100099FF: pop         edi
  10009A00: sub         al,6
  10009A02: push        es
  10009A03: sub         byte ptr [edi],bl
  10009A05: add         dword ptr [eax],eax
  10009A07: push        es
  10009A08: push        es
  10009A09: sub         al,byte ptr [edx]
  10009A0B: sub         byte ptr [eax+eax+17030600h],dh
  10009A12: pop         edi
  10009A13: sub         al,6
  10009A15: add         ch,byte ptr [eax]
  10009A17: push        ds
  10009A18: add         dword ptr [eax],eax
  10009A1A: push        es
  10009A1B: add         ch,byte ptr [edx]
  10009A1D: int         3
  10009A1E: int         3
  10009A1F: int         3
  10009A20: or          esi,dword ptr [eax]
  10009A22: add         eax,dword ptr [eax]
  10009A24: pushfd
  10009A25: add         byte ptr [eax],al
  10009A27: add         byte ptr [ecx+eax],bl
  10009A2B: adc         dword ptr [edx],eax
  10009A2D: pop         ds
  10009A2E: or          al,58h
  10009A30: or          al,12h
  10009A32: add         eax,2A284A08h
  10009A37: add         byte ptr [eax],al
  10009A39: or          dl,byte ptr [ecx]
  10009A3B: add         eax,3228h
  10009A40: or          dl,byte ptr [ebx]
  10009A42: or          byte ptr [edx],dl
  10009A44: or          byte ptr [eax],ch
  10009A46: xor         dword ptr [eax],eax
  10009A48: add         byte ptr [edx],cl
  10009A4A: or          byte ptr [esi],dl
  10009A4C: push        esp
  10009A4D: fimul       word ptr [edi]
  10009A4F: inc         byte ptr [esi]
  10009A51: rol         dword ptr [eax],0
  10009A54: push        es
  10009A55: add         bl,byte ptr [esi]
  10009A57: pop         eax
  10009A58: sub         byte ptr [ebx],al
  10009A5A: add         dword ptr [eax],eax
  10009A5C: push        es
  10009A5D: fadd        qword ptr [edx]
  10009A5F: push        ds
  10009A60: pop         eax
  10009A61: or          edx,dword ptr [edx]
  10009A63: add         al,7
  10009A65: dec         edx
  10009A66: sub         byte ptr [edx],ch
  10009A68: add         byte ptr [eax],al
  10009A6A: or          dl,byte ptr [ecx]
  10009A6C: add         al,28h
  10009A6E: xor         al,byte ptr [eax]
  10009A70: add         byte ptr [edx],cl
  10009A72: adc         eax,dword ptr [edi]
  10009A74: adc         al,byte ptr [edi]
  10009A76: sub         byte ptr [ecx],dh
  10009A78: add         byte ptr [eax],al
  10009A7A: or          al,byte ptr [edi]
  10009A7C: push        ss
  10009A7D: push        esp
  10009A7E: fimul       word ptr [edi]
  10009A80: inc         byte ptr [esi]
  10009A82: rol         dword ptr [eax],0
  10009A85: push        es
  10009A86: add         bl,byte ptr [edx]
  10009A88: pop         eax
  10009A89: sub         byte ptr [ebx],al
  10009A8B: add         dword ptr [eax],eax
  10009A8D: push        es
  10009A8E: fadd        qword ptr [edx]
  10009A90: sbb         bl,byte ptr [eax+0Ah]
  10009A93: adc         al,byte ptr [ebx]
  10009A95: push        es
  10009A96: dec         edx
  10009A97: sub         byte ptr [edx],ch
  10009A99: add         byte ptr [eax],al
  10009A9B: or          cl,byte ptr [ecx]
  10009A9D: sub         byte ptr [edx],dh
  10009A9F: add         byte ptr [eax],al
  10009AA1: or          dl,byte ptr [ebx]
  10009AA3: push        es
  10009AA4: adc         al,byte ptr [esi]
  10009AA6: sub         byte ptr [ecx],dh
  10009AA8: add         byte ptr [eax],al
  10009AAA: or          al,byte ptr [esi]
  10009AAC: push        ss
  10009AAD: push        esp
  10009AAE: fimul       word ptr ds:[00A706FEh]
  10009AB4: add         byte ptr [esi],al
  10009AB6: add         ch,byte ptr [eax]
  10009AB8: add         eax,dword ptr [ecx]
  10009ABA: add         byte ptr [esi],al
  10009ABC: fadd        qword ptr [edx]
  10009ABE: jg          10009ABF
  10009AC0: add         byte ptr [eax],al
  10009AC2: add         al,0FEh
  10009AC4: adc         al,byte ptr [ecx]
  10009AC6: push        esp
  10009AC7: sub         al,byte ptr [ecx+4Ch]
  10009ACA: add         byte ptr [eax],al
  10009ACC: add         al,0
  10009ACE: add         byte ptr [eax],al
  10009AD0: add         byte ptr [eax],al
  10009AD2: add         byte ptr [eax],al
  10009AD4: and         eax,dword ptr [eax]
  10009AD6: add         byte ptr [eax],al
  10009AD8: and         eax,dword ptr [eax]
  10009ADA: add         byte ptr [eax],al
  10009ADC: sldt        word ptr [eax]
  10009ADF: add         byte ptr ds:[04010000h],ah
  10009AE5: add         byte ptr [eax],al
  10009AE7: add         byte ptr [eax],al
  10009AE9: add         byte ptr [eax],al
  10009AEB: add         byte ptr [eax+eax],dl
  10009AEF: add         byte ptr [eax+eax],dl
  10009AF3: add         byte ptr [edi],cl
  10009AF5: add         byte ptr [eax],al
  10009AF7: add         byte ptr ds:[04010000h],ah
  10009AFD: add         byte ptr [eax],al
  10009AFF: add         byte ptr [eax],al
  10009B01: add         byte ptr [eax],al
  10009B03: add         byte ptr [eax+eax+00840000h],al
  10009B0A: add         byte ptr [eax],al
  10009B0C: or          eax,25000000h
  10009B11: add         byte ptr [eax],al
  10009B13: add         esp,ecx
  10009B15: int         3
  10009B16: int         3
  10009B17: int         3
  10009B18: int         3
  10009B19: int         3
  10009B1A: int         3
  10009B1B: int         3
  10009B1C: int         3
  10009B1D: int         3
  10009B1E: int         3
  10009B1F: int         3
  10009B20: jmp         dword ptr ds:[1002461Ch]
  10009B26: int         3
  10009B27: int         3
  10009B28: add         esi,dword ptr [eax]
  10009B2A: add         eax,dword ptr [eax]
  10009B2C: call        0001:60000000
  10009B33: adc         dword ptr [edx],eax
  10009B35: cmp         dword ptr [ebx+0E000000h],edx
  10009B3B: add         eax,4A58141Fh
  10009B40: or          al,byte ptr [ebx]
  10009B42: dec         esi
  10009B43: adc         eax,dword ptr [esi+eax]
  10009B46: inc         edi
  10009B47: sub         al,28h
  10009B49: adc         al,byte ptr [ebx]
  10009B4B: adc         al,byte ptr [ecx+ebx]
  10009B4E: pop         eax
  10009B4F: inc         edi
  10009B50: push        edx
  10009B51: adc         al,byte ptr [ebx]
  10009B53: pop         ss
  10009B54: pop         eax
  10009B55: adc         al,byte ptr [eax+ebx]
  10009B58: pop         eax
  10009B59: inc         edi
  10009B5A: push        edx
  10009B5B: adc         al,byte ptr [ebx]
  10009B5D: sbb         byte ptr [eax+12h],bl
  10009B60: add         al,17h
  10009B62: pop         eax
  10009B63: inc         edi
  10009B64: push        edx
  10009B65: adc         al,byte ptr [ebx]
  10009B67: sbb         dword ptr [eax+12h],ebx
  10009B6A: add         al,47h
  10009B6C: push        edx
  10009B6D: adc         al,byte ptr [ecx+ecx]
  10009B70: push        esp
  10009B71: add         eax,23560411h
  10009B76: add         byte ptr [eax],al
  10009B78: add         byte ptr [eax],al
  10009B7A: add         byte ptr [eax],al
  10009B7C: lock aas
  10009B7E: add         ebx,dword ptr [edx]
  10009B80: pop         eax
  10009B81: dec         esi
  10009B82: ins         byte ptr es:[edi],dx
  10009B83: pop         ecx
  10009B84: imul        ecx,dword ptr [esi+eax],47h
  10009B88: sub         al,28h
  10009B8A: adc         al,byte ptr [ecx]
  10009B8C: adc         al,byte ptr [edx]
  10009B8E: sbb         dword ptr [eax+47h],ebx
  10009B91: push        edx
  10009B92: adc         al,byte ptr [ecx]
  10009B94: pop         ss
  10009B95: pop         eax
  10009B96: adc         al,byte ptr [edx]
  10009B98: sbb         byte ptr [eax+47h],bl
  10009B9B: push        edx
  10009B9C: adc         al,byte ptr [ecx]
  10009B9E: sbb         byte ptr [eax+12h],bl
  10009BA1: add         dl,byte ptr [edi]
  10009BA3: pop         eax
  10009BA4: inc         edi
  10009BA5: push        edx
  10009BA6: adc         al,byte ptr [ecx]
  10009BA8: sbb         dword ptr [eax+12h],ebx
  10009BAB: add         al,byte ptr [edi+52h]
  10009BAE: adc         al,byte ptr [edx]
  10009BB0: pop         es
  10009BB1: push        esp
  10009BB2: add         eax,5608581Ah
  10009BB7: add         al,3
  10009BB9: pop         eax
  10009BBA: adc         byte ptr [ecx],al
  10009BBC: push        cs
  10009BBD: add         al,5
  10009BBF: pop         eax
  10009BC0: adc         byte ptr [ebx],al
  10009BC2: add         dl,byte ptr [edi]
  10009BC4: pop         ecx
  10009BC5: adc         byte ptr [eax],al
  10009BC7: add         bh,byte ptr [edx]
  10009BC9: je          10009BCA
  10009BCB: FF
  10009BCC: jmp         fword ptr [edx]
  10009BCE: int         3
  10009BCF: int         3
  10009BD0: jmp         dword ptr ds:[10024624h]
  10009BD6: int         3
  10009BD7: int         3
  10009BD8: add         esi,dword ptr [eax]
  10009BDA: add         al,0
  10009BDC: push        edi
  10009BDD: add         dword ptr [eax],eax
  10009BDF: add         byte ptr [ecx+1],ah
  10009BE2: add         byte ptr [ecx],dl
  10009BE4: add         bh,byte ptr [ecx]
  10009BE6: push        eax
  10009BE7: add         dword ptr [eax],eax
  10009BE9: add         byte ptr [ebx],al
  10009BEB: dec         esi
  10009BEC: adc         ecx,dword ptr [ebx]
  10009BEE: and         eax,dword ptr [eax]
  10009BF0: add         byte ptr [eax],al
  10009BF2: add         byte ptr [eax],al
  10009BF4: add         al,dh
  10009BF6: aas
  10009BF7: add         ebx,dword ptr [edx]
  10009BF9: pop         eax
  10009BFA: dec         esi
  10009BFB: ins         byte ptr es:[edi],dx
  10009BFC: pop         ecx
  10009BFD: imul        edx,dword ptr [ebx],0Ah
  10009C00: adc         dword ptr [ebx],ecx
  10009C02: adc         ecx,dword ptr ds:[204A0D12h]
  10009C08: FF
  10009C09: FF
  10009C0A: FF
  10009C0B: jg          10009C6C
  10009C0D: or          edx,dword ptr [edx]
  10009C0F: or          eax,64101F4Ah
  10009C14: and         byte ptr [eax],al
  10009C16: add         byte ptr [eax],0
  10009C19: pop         edi
  10009C1A: adc         eax,dword ptr [edi]
  10009C1C: pop         es
  10009C1D: and         bh,bh
  10009C1F: out         dx,eax
  10009C20: inc         dword ptr [edi+36h]
  10009C23: or          eax,20D10711h
  10009C28: FF
  10009C29: jg          10009C2B
  10009C2B: add         byte ptr [eax+13h],ah
  10009C2E: push        es
  10009C2F: sub         edi,dword ptr [esi]
  10009C31: pop         es
  10009C32: and         byte ptr [eax],al
  10009C34: add         byte ptr [eax+07183438h],al
  10009C3A: and         bh,bh
  10009C3C: FF
  10009C3D: jg          10009C3F
  10009C3F: pop         edi
  10009C40: and         byte ptr [eax],al
  10009C42: add         byte ptr [eax+711F6000h],al
  10009C48: pop         es
  10009C49: pop         ds
  10009C4A: pop         ss
  10009C4B: pop         ecx
  10009C4D: or          ebp,dword ptr fs:[ebx]
  10009C50: or          byte ptr [edi],al
  10009C52: and         byte ptr [eax],al
  10009C54: add         byte ptr [eax],al
  10009C56: cmp         byte ptr [ecx+0Bh],bl
  10009C59: pop         es
  10009C5A: and         eax,17640D1Fh
  10009C5F: pop         edi
  10009C60: pop         eax
  10009C61: and         bh,bh
  10009C63: sldt        word ptr [eax]
  10009C66: pop         eax
  10009C67: pop         ds
  10009C68: or          eax,60071164h
  10009C6D: adc         eax,dword ptr [esi]
  10009C6F: adc         dword ptr [edx],ecx
  10009C71: adc         ecx,dword ptr [edx+edx]
  10009C74: or          al,4Ah
  10009C76: and         bh,bh
  10009C78: FF
  10009C79: FF
  10009C7A: jg          10009CDB
  10009C7C: or          dl,byte ptr [edx]
  10009C7E: or          al,4Ah
  10009C80: pop         ds
  10009C81: adc         byte ptr [eax],ah
  10009C85: add         byte ptr [eax],0
  10009C88: pop         edi
  10009C89: adc         eax,dword ptr ds:[EFFF2006h]
  10009C8F: inc         dword ptr [edi+36h]
  10009C92: or          eax,20D10511h
  10009C97: FF
  10009C98: jg          10009C9A
  10009C9A: add         byte ptr [eax+13h],ah
  10009C9D: add         al,2Bh
  10009C9F: push        es
  10009CA1: and         byte ptr [eax],al
  10009CA3: add         byte ptr [eax+06183438h],al
  10009CA9: and         bh,bh
  10009CAB: FF
  10009CAC: jg          10009CAE
  10009CAE: pop         edi
  10009CAF: and         byte ptr [eax],al
  10009CB1: add         byte ptr [eax+711F6000h],al
  10009CB7: push        es
  10009CB8: pop         ds
  10009CB9: pop         ss
  10009CBA: pop         ecx
  10009CBC: or          ch,byte ptr fs:[ebx]
  10009CBF: or          byte ptr [esi],al
  10009CC1: and         byte ptr [eax],al
  10009CC3: add         byte ptr [eax],al
  10009CC5: cmp         byte ptr [ecx+0Ah],bl
  10009CC8: push        es
  10009CC9: and         eax,17640D1Fh
  10009CCE: pop         edi
  10009CCF: pop         eax
  10009CD0: and         bh,bh
  10009CD2: sldt        word ptr [eax]
  10009CD5: pop         eax
  10009CD6: pop         ds
  10009CD7: or          eax,60051164h
  10009CDC: adc         eax,dword ptr [ecx+edx]
  10009CDF: push        es
  10009CE0: or          eax,141F050Eh
  10009CE5: pop         eax
  10009CE6: dec         edx
  10009CE7: inc         edi
  10009CE8: sub         al,13h
  10009CEA: adc         cl,byte ptr [ecx]
  10009CEC: adc         al,byte ptr [esi]
  10009CEE: pop         ss
  10009CEF: pop         eax
  10009CF0: inc         edi
  10009CF1: push        edx
  10009CF2: adc         cl,byte ptr [ecx]
  10009CF4: pop         ss
  10009CF5: pop         eax
  10009CF6: adc         al,byte ptr [esi]
  10009CF8: inc         edi
  10009CF9: push        edx
  10009CFA: adc         dword ptr [ecx],ecx
  10009CFC: or          eax,11530905h
  10009D01: add         al,0Ch
  10009D03: push        cs
  10009D04: add         eax,4A58141Fh
  10009D09: inc         edi
  10009D0A: sub         al,13h
  10009D0C: adc         cl,byte ptr [eax]
  10009D0E: adc         al,byte ptr [edi+edx]
  10009D11: pop         eax
  10009D12: inc         edi
  10009D13: push        edx
  10009D14: adc         cl,byte ptr [eax]
  10009D16: pop         ss
  10009D17: pop         eax
  10009D18: adc         al,byte ptr [edi+eax*2]
  10009D1B: push        edx
  10009D1C: adc         dword ptr [eax],ecx
  10009D1E: or          al,5
  10009D20: sbb         byte ptr [eax+8],bl
  10009D23: push        ebx
  10009D24: add         al,3
  10009D26: pop         eax
  10009D27: adc         byte ptr [ecx],al
  10009D29: push        cs
  10009D2A: add         al,5
  10009D2C: pop         eax
  10009D2D: adc         byte ptr [ebx],al
  10009D2F: add         dl,byte ptr [edi]
  10009D31: pop         ecx
  10009D32: adc         byte ptr [eax],al
  10009D34: add         bh,byte ptr [edx]
  10009D36: mov         al,0FEh
  10009D38: FF
  10009D39: jmp         fword ptr [edx]
  10009D3B: int         3
  10009D3C: int         3
  10009D3D: int         3
  10009D3E: int         3
  10009D3F: int         3
  10009D40: jmp         dword ptr ds:[10024628h]
  10009D46: int         3
  10009D47: int         3
  10009D48: add         esi,dword ptr [eax]
  10009D4A: add         al,0
  10009D4C: mov         al,byte ptr [edx]
  10009D4E: add         byte ptr [eax],al
  10009D50: bound       eax,qword ptr [ecx]
  10009D52: add         byte ptr [ecx],dl
  10009D54: add         bh,byte ptr [ecx]
  10009D56: add         dword ptr [edx],0
  10009D59: add         byte ptr [edx],ah
  10009D5B: add         byte ptr [eax],al
  10009D5D: add         byte ptr [eax],al
  10009D5F: adc         ebx,dword ptr [ebx]
  10009D61: adc         bl,byte ptr [ebx]
  10009D63: dec         edx
  10009D64: and         bh,bh
  10009D66: FF
  10009D67: FF
  10009D68: jg          10009DC9
  10009D6A: adc         edx,dword ptr [edi]
  10009D6C: adc         bl,byte ptr [ebx]
  10009D6E: dec         edx
  10009D6F: pop         ds
  10009D70: adc         byte ptr [eax],ah
  10009D74: add         byte ptr [eax],0
  10009D77: pop         edi
  10009D78: adc         ecx,dword ptr [edi]
  10009D7A: add         ecx,dword ptr [esi+13h]
  10009D7D: push        ss
  10009D7E: add         ebx,dword ptr [edx]
  10009D80: pop         eax
  10009D81: dec         esi
  10009D82: adc         edx,dword ptr ds:[4E581E03h]
  10009D88: adc         edx,dword ptr [ecx+edx]
  10009D8B: push        ss
  10009D8C: adc         ebx,dword ptr [edx]
  10009D8E: adc         bl,byte ptr [edx]
  10009D90: dec         edx
  10009D91: and         bh,bh
  10009D93: FF
  10009D94: FF
  10009D95: jg          10009DF6
  10009D97: or          eax,1F4A1A12h
  10009D9C: adc         byte ptr [eax],ah
  10009DA0: add         byte ptr [eax],0
  10009DA3: pop         edi
  10009DA4: adc         ecx,dword ptr [esi]
  10009DA6: or          dword ptr [eax],esp
  10009DA8: jmp         rdi
  10009DAA: inc         dword ptr [edi+36h]
  10009DAD: or          eax,20D10E11h
  10009DB2: FF
  10009DB3: jg          10009DB5
  10009DB5: add         byte ptr [eax+13h],ah
  10009DB8: or          eax,20093E2Bh
  10009DBD: add         byte ptr [eax],al
  10009DBF: cmp         byte ptr [eax],34h
  10009DC2: sbb         byte ptr [ecx],cl
  10009DC4: and         bh,bh
  10009DC6: FF
  10009DC7: jg          10009DC9
  10009DC9: pop         edi
  10009DCA: and         byte ptr [eax],al
  10009DCC: add         byte ptr [eax+711F6000h],al
  10009DD2: or          dword ptr [edi],ebx
  10009DD4: pop         ss
  10009DD5: pop         ecx
  10009DD7: or          eax,2009082Bh
  10009DDD: add         byte ptr [eax],al
  10009DDF: add         byte ptr [eax],bh
  10009DE1: pop         ecx
  10009DE2: or          eax,0D1F2509h
  10009DE7: pop         ss
  10009DE9: pop         edi
  10009DEA: pop         eax
  10009DEB: and         bh,bh
  10009DED: sldt        word ptr [eax]
  10009DF0: pop         eax
  10009DF1: pop         ds
  10009DF2: or          eax,600E1164h
  10009DF7: adc         ecx,dword ptr ds:[19131511h]
  10009DFD: adc         bl,byte ptr [ecx]
  10009DFF: dec         edx
  10009E00: and         bh,bh
  10009E02: FF
  10009E03: FF
  10009E04: jg          10009E65
  10009E06: or          al,12h
  10009E08: sbb         dword ptr [edx+1Fh],ecx
  10009E0B: adc         byte ptr [eax],ah
  10009E0F: add         byte ptr [eax],0
  10009E12: pop         edi
  10009E13: adc         ecx,dword ptr [eax+ecx]
  10009E16: and         bh,bh
  10009E18: out         dx,eax
  10009E19: inc         dword ptr [edi+36h]
  10009E1C: or          eax,20D10C11h
  10009E21: FF
  10009E22: jg          10009E24
  10009E24: add         byte ptr [eax+13h],ah
  10009E27: or          ebp,dword ptr [ebx]
  10009E29: or          byte ptr ds:[eax],ah
  10009E2C: add         byte ptr [eax],al
  10009E2E: cmp         byte ptr [eax],34h
  10009E31: sbb         byte ptr [eax],cl
  10009E33: and         bh,bh
  10009E35: FF
  10009E36: jg          10009E38
  10009E38: pop         edi
  10009E39: and         byte ptr [eax],al
  10009E3B: add         byte ptr [eax+711F6000h],al
  10009E41: or          byte ptr [edi],bl
  10009E43: pop         ss
  10009E44: pop         ecx
  10009E46: or          al,2Bh
  10009E49: or          byte ptr [eax],cl
  10009E4B: and         byte ptr [eax],al
  10009E4D: add         byte ptr [eax],al
  10009E4F: cmp         byte ptr [ecx+0Ch],bl
  10009E52: or          byte ptr ds:[17640D1Fh],ah
  10009E58: pop         edi
  10009E59: pop         eax
  10009E5A: and         bh,bh
  10009E5C: sldt        word ptr [eax]
  10009E5F: pop         eax
  10009E60: pop         ds
  10009E61: or          eax,600C1164h
  10009E66: adc         ecx,dword ptr [ebx]
  10009E68: adc         dword ptr [ebx+edx],edx
  10009E6B: sbb         byte ptr [edx],dl
  10009E6D: sbb         byte ptr [edx+20h],cl
  10009E70: FF
  10009E71: FF
  10009E72: FF
  10009E73: jg          10009ED4
  10009E75: or          edx,dword ptr [edx]
  10009E77: sbb         byte ptr [edx+1Fh],cl
  10009E7A: adc         byte ptr [eax],ah
  10009E7E: add         byte ptr [eax],0
  10009E81: pop         edi
  10009E82: adc         ecx,dword ptr [edx]
  10009E84: pop         es
  10009E85: and         bh,bh
  10009E87: out         dx,eax
  10009E88: inc         dword ptr [edi+36h]
  10009E8B: or          eax,20D10A11h
  10009E90: FF
  10009E91: jg          10009E93
  10009E93: add         byte ptr [eax+13h],ah
  10009E96: or          dword ptr [ebx],ebp
  10009E98: pop         es
  10009E9A: and         byte ptr [eax],al
  10009E9C: add         byte ptr [eax+07183438h],al
  10009EA2: and         bh,bh
  10009EA4: FF
  10009EA5: jg          10009EA7
  10009EA7: pop         edi
  10009EA8: and         byte ptr [eax],al
  10009EAA: add         byte ptr [eax+711F6000h],al
  10009EB0: pop         es
  10009EB1: pop         ds
  10009EB2: pop         ss
  10009EB3: pop         ecx
  10009EB5: or          ebp,dword ptr fs:[ebx]
  10009EB8: or          byte ptr [edi],al
  10009EBA: and         byte ptr [eax],al
  10009EBC: add         byte ptr [eax],al
  10009EBE: cmp         byte ptr [ecx+0Bh],bl
  10009EC1: pop         es
  10009EC2: and         eax,17640D1Fh
  10009EC7: pop         edi
  10009EC8: pop         eax
  10009EC9: and         bh,bh
  10009ECB: sldt        word ptr [eax]
  10009ECE: pop         eax
  10009ECF: pop         ds
  10009ED0: or          eax,600A1164h
  10009ED5: adc         ecx,dword ptr [ecx]
  10009ED7: adc         dword ptr [edi],edx
  10009ED9: or          al,byte ptr [esi]
  10009EDB: and         bh,bh
  10009EDD: out         dx,eax
  10009EDE: inc         dword ptr [edi+36h]
  10009EE1: or          eax,20D10F11h
  10009EE6: FF
  10009EE7: jg          10009EE9
  10009EE9: add         byte ptr [eax+13h],ah
  10009EEC: or          byte ptr [ebx],ch
  10009EEE: push        es
  10009EF0: and         byte ptr [eax],al
  10009EF2: add         byte ptr [eax+06183438h],al
  10009EF8: and         bh,bh
  10009EFA: FF
  10009EFB: jg          10009EFD
  10009EFD: pop         edi
  10009EFE: and         byte ptr [eax],al
  10009F00: add         byte ptr [eax+711F6000h],al
  10009F06: push        es
  10009F07: pop         ds
  10009F08: pop         ss
  10009F09: pop         ecx
  10009F0B: or          ch,byte ptr fs:[ebx]
  10009F0E: or          byte ptr [esi],al
  10009F10: and         byte ptr [eax],al
  10009F12: add         byte ptr [eax],al
  10009F14: cmp         byte ptr [ecx+0Ah],bl
  10009F17: push        es
  10009F18: and         eax,17640D1Fh
  10009F1D: pop         edi
  10009F1E: pop         eax
  10009F1F: and         bh,bh
  10009F21: sldt        word ptr [eax]
  10009F24: pop         eax
  10009F25: pop         ds
  10009F26: or          eax,600F1164h
  10009F2B: adc         ecx,dword ptr [eax]
  10009F2D: adc         dword ptr ds:[050E0713h],ecx
  10009F33: pop         ds
  10009F34: adc         al,58h
  10009F36: dec         edx
  10009F37: inc         edi
  10009F38: sub         al,14h
  10009F3A: adc         dl,byte ptr [ebx]
  10009F3C: adc         cl,byte ptr ds:[52475817h]
  10009F42: adc         dl,byte ptr [ebx]
  10009F44: pop         ss
  10009F45: pop         eax
  10009F46: adc         cl,byte ptr ds:[13115247h]
  10009F4C: adc         eax,dword ptr [edi]
  10009F4E: add         eax,11530711h
  10009F53: or          edx,dword ptr [ebx]
  10009F55: push        es
  10009F56: push        cs
  10009F57: add         eax,4A58141Fh
  10009F5C: inc         edi
  10009F5D: sub         al,14h
  10009F5F: adc         dl,byte ptr [edx]
  10009F61: adc         cl,byte ptr [ebx]
  10009F63: pop         ss
  10009F64: pop         eax
  10009F65: inc         edi
  10009F66: push        edx
  10009F67: adc         dl,byte ptr [edx]
  10009F69: pop         ss
  10009F6A: pop         eax
  10009F6B: adc         cl,byte ptr [ebx]
  10009F6D: inc         edi
  10009F6E: push        edx
  10009F6F: adc         dword ptr [edx],edx
  10009F71: adc         eax,dword ptr [esi]
  10009F73: add         eax,6115818h
  10009F78: push        ebx
  10009F79: adc         dword ptr [ecx],ecx
  10009F7B: adc         eax,dword ptr ds:[141F050Eh]
  10009F81: pop         eax
  10009F82: dec         edx
  10009F83: inc         edi
  10009F84: sub         al,14h
  10009F86: adc         dl,byte ptr [ecx]
  10009F88: adc         cl,byte ptr [ecx]
  10009F8A: pop         ss
  10009F8B: pop         eax
  10009F8C: inc         edi
  10009F8D: push        edx
  10009F8E: adc         dl,byte ptr [ecx]
  10009F90: pop         ss
  10009F91: pop         eax
  10009F92: adc         cl,byte ptr [ecx]
  10009F94: inc         edi
  10009F95: push        edx
  10009F96: adc         dword ptr [ecx],edx
  10009F98: adc         eax,dword ptr ds:[11581A05h]
  10009F9E: add         eax,13081153h
  10009FA3: add         al,0Eh
  10009FA5: add         eax,4A58141Fh
  10009FAA: inc         edi
  10009FAB: sub         al,14h
  10009FAD: adc         dl,byte ptr [eax]
  10009FAF: adc         cl,byte ptr [eax]
  10009FB1: pop         ss
  10009FB2: pop         eax
  10009FB3: inc         edi
  10009FB4: push        edx
  10009FB5: adc         dl,byte ptr [eax]
  10009FB7: pop         ss
  10009FB8: pop         eax
  10009FB9: adc         cl,byte ptr [eax]
  10009FBB: inc         edi
  10009FBC: push        edx
  10009FBD: adc         dword ptr [eax],edx
  10009FBF: adc         eax,dword ptr [eax+0411581Ch]
  10009FC6: push        ebx
  10009FC7: add         al,3
  10009FC9: pop         eax
  10009FCA: adc         byte ptr [ecx],al
  10009FCC: push        cs
  10009FCD: add         al,5
  10009FCF: pop         eax
  10009FD0: adc         byte ptr [ebx],al
  10009FD2: add         dl,byte ptr [edi]
  10009FD4: pop         ecx
  10009FD5: adc         byte ptr [eax],al
  10009FD7: add         bh,byte ptr [edx]
  10009FD9: popfd
  10009FDA: std
  10009FDB: FF
  10009FDC: jmp         fword ptr [edx]
  10009FDE: int         3
  10009FDF: int         3
  10009FE0: jmp         dword ptr ds:[1002462Ch]
  10009FE6: int         3
  10009FE7: int         3
  10009FE8: add         esi,dword ptr [eax]
  10009FEA: add         eax,dword ptr [eax]
  10009FEC: cmp         dword ptr [eax],eax
  10009FEE: add         byte ptr [eax],al
  10009FF0: xchg        al,byte ptr [eax]
  10009FF2: add         byte ptr [ecx],dl
  10009FF4: add         ch,byte ptr [esi+050A4E03h]
  10009FFB: push        es
  10009FFC: ins         byte ptr es:[edi],dx
  10009FFD: and         eax,dword ptr [eax]
  10009FFF: add         byte ptr [eax],al
  1000A001: add         byte ptr [eax],al
  1000A003: loopne      1000A074
  1000A005: inc         eax
  1000A006: pop         edx
  1000A007: and         eax,dword ptr [eax]
  1000A009: add         byte ptr [eax],al
  1000A00B: add         byte ptr [eax],al
  1000A00D: add         al,ah
  1000A00F: aas
  1000A010: pop         eax
  1000A011: ins         dword ptr es:[edi],dx
  1000A012: and         bh,bh
  1000A014: add         byte ptr [eax],al
  1000A016: add         byte ptr [edi+52h],bl
  1000A019: add         al,3
  1000A01B: pop         eax
  1000A01C: adc         byte ptr [ecx],al
  1000A01E: push        cs
  1000A01F: add         al,5
  1000A021: pop         eax
  1000A022: adc         byte ptr [ebx],al
  1000A024: add         dl,byte ptr [edi]
  1000A026: pop         ecx
  1000A027: adc         byte ptr [eax],al
  1000A029: add         ch,byte ptr ds:[CCCC2ACBh]
  1000A02F: int         3
  1000A030: jmp         dword ptr ds:[10024630h]
  1000A036: int         3
  1000A037: int         3
  1000A038: add         esi,dword ptr [eax]
  1000A03A: add         eax,dword ptr [eax]
  1000A03C: cmp         byte ptr [eax],al
  1000A03E: add         byte ptr [eax],al
  1000A040: add         dword ptr fs:[eax],eax
  1000A043: adc         dword ptr [esi],ecx
  1000A045: add         eax,4A58141Fh
  1000A04A: inc         edi
  1000A04B: sub         al,12h
  1000A04D: jg          1000A054
  1000A04F: add         dword ptr [eax],eax
  1000A051: add         al,0Ah
  1000A053: adc         al,byte ptr [eax]
  1000A055: jg          1000A060
  1000A057: add         dword ptr [eax],eax
  1000A059: add         al,28h
  1000A05B: sub         eax,2060001h
  1000A060: sub         al,19h
  1000A062: add         eax,0FE0C1F03h
  1000A067: pop         ss
  1000A068: add         al,3
  1000A06A: pop         eax
  1000A06B: adc         byte ptr [ecx],al
  1000A06D: push        cs
  1000A06E: add         al,5
  1000A070: pop         eax
  1000A071: adc         byte ptr [ebx],al
  1000A073: add         dl,byte ptr [edi]
  1000A075: pop         ecx
  1000A076: adc         byte ptr [eax],al
  1000A078: add         ch,byte ptr ds:[CCCC2AE7h]
  1000A07E: int         3
  1000A07F: int         3
  1000A080: jmp         dword ptr ds:[10024654h]
  1000A086: int         3
  1000A087: int         3
  1000A088: add         esi,dword ptr [eax]
  1000A08A: add         eax,dword ptr [eax]
  1000A08C: dec         eax
  1000A08D: add         byte ptr [eax],al
  1000A08F: add         byte ptr [ebx+1],ch
  1000A092: add         byte ptr [ecx],dl
  1000A094: add         ch,byte ptr [esp+eax*2]
  1000A097: push        cs
  1000A098: add         eax,30C581Ah
  1000A09D: dec         ecx
  1000A09E: or          ecx,dword ptr [esi]
  1000A0A0: add         eax,8070A4Ah
  1000A0A5: dec         edx
  1000A0A6: push        es
  1000A0A7: pop         ecx
  1000A0A8: pop         ss
  1000A0A9: arpl        word ptr [ebx+5A180705h],si
  1000A0B0: push        es
  1000A0B1: pop         eax
  1000A0B2: dec         ecx
  1000A0B3: push        edx
  1000A0B4: add         al,3
  1000A0B6: pop         eax
  1000A0B7: adc         byte ptr [ecx],al
  1000A0B9: push        cs
  1000A0BA: add         al,5
  1000A0BC: pop         eax
  1000A0BD: adc         byte ptr [ebx],al
  1000A0BF: add         dl,byte ptr [edi]
  1000A0C1: pop         ecx
  1000A0C2: adc         byte ptr [eax],al
  1000A0C4: add         ch,byte ptr ds:[7F122BD5h]
  1000A0CA: add         byte ptr [ecx],al
  1000A0CC: add         byte ptr [ecx+097F0312h],al
  1000A0D3: add         dword ptr [eax],eax
  1000A0D5: add         al,28h
  1000A0D7: sub         eax,2A060001h
  1000A0DC: int         3
  1000A0DD: int         3
  1000A0DE: int         3
  1000A0DF: int         3
  1000A0E0: jmp         dword ptr ds:[10024658h]
  1000A0E6: int         3
  1000A0E7: int         3
  1000A0E8: add         esi,dword ptr [eax]
  1000A0EA: add         eax,dword ptr [eax]
  1000A0EC: pop         ecx
  1000A0ED: add         dword ptr [eax],eax
  1000A0EF: add         byte ptr [ecx+eax],ch
  1000A0F3: adc         dword ptr [edx],eax
  1000A0F5: cmp         dword ptr [edx+1],edx
  1000A0F8: add         byte ptr [eax],al
  1000A0FA: push        cs
  1000A0FB: add         eax,1358141Fh
  1000A100: or          eax,dword ptr [ebx]
  1000A102: dec         esi
  1000A103: adc         ecx,dword ptr [ecx]
  1000A105: add         ebx,dword ptr [edx]
  1000A107: pop         eax
  1000A108: dec         esi
  1000A109: adc         ecx,dword ptr [eax]
  1000A10B: add         ebx,dword ptr [esi]
  1000A10D: pop         eax
  1000A10E: dec         esi
  1000A10F: adc         eax,dword ptr [edi]
  1000A111: and         eax,dword ptr [eax]
  1000A113: add         byte ptr [eax],al
  1000A115: add         byte ptr [eax],al
  1000A117: add         al,dh
  1000A119: mov         edi,366C0911h
  1000A11E: or          byte ptr [edx],ah
  1000A120: add         byte ptr [eax],al
  1000A122: cmp         byte ptr [edi+11032B0Ch],9
  1000A129: or          al,23h
  1000A12B: add         byte ptr [eax],al
  1000A12D: add         byte ptr [eax],al
  1000A12F: add         byte ptr [eax],al
  1000A131: lock mov    edi,366C0811h
  1000A137: or          byte ptr [edx],ah
  1000A139: add         byte ptr [eax],al
  1000A13B: cmp         byte ptr [edi+11032B0Bh],8
  1000A142: or          esp,dword ptr [ebx]
  1000A144: add         byte ptr [eax],al
  1000A146: add         byte ptr [eax],al
  1000A148: add         byte ptr [eax],al
  1000A14A: lock mov    edi,366C0711h
  1000A150: or          byte ptr [edx],ah
  1000A152: add         byte ptr [eax],al
  1000A154: cmp         byte ptr [edi+11032B0Ah],7
  1000A15B: or          ah,byte ptr [ebx]
  1000A15D: add         byte ptr [eax],al
  1000A15F: add         byte ptr [eax],al
  1000A161: add         byte ptr [eax],al
  1000A163: lock aas
  1000A165: or          byte ptr [esp+esi+9],ch
  1000A169: and         al,byte ptr [eax]
  1000A16B: add         byte ptr [eax+2B06133Fh],al
  1000A171: add         ecx,dword ptr [eax]
  1000A173: adc         eax,dword ptr [esi]
  1000A175: and         eax,dword ptr [eax]
  1000A177: add         byte ptr [eax],al
  1000A179: add         byte ptr [eax],al
  1000A17B: add         al,dh
  1000A17D: aas
  1000A17E: pop         es
  1000A17F: ins         byte ptr es:[edi],dx
  1000A180: xor         al,9
  1000A182: and         al,byte ptr [eax]
  1000A184: add         byte ptr [eax+2B05133Fh],al
  1000A18A: add         eax,dword ptr [edi]
  1000A18C: adc         eax,dword ptr ds:[00000023h]
  1000A192: add         byte ptr [eax],al
  1000A194: add         al,dh
  1000A196: aas
  1000A197: push        es
  1000A198: ins         byte ptr es:[edi],dx
  1000A199: xor         al,9
  1000A19B: and         al,byte ptr [eax]
  1000A19D: add         byte ptr [eax+2B04133Fh],al
  1000A1A3: add         eax,dword ptr [esi]
  1000A1A5: adc         eax,dword ptr [edx+edx]
  1000A1A8: or          al,11h
  1000A1AA: push        es
  1000A1AB: ins         byte ptr es:[edi],dx
  1000A1AC: and         eax,dword ptr [eax]
  1000A1AE: add         byte ptr [eax],al
  1000A1B0: add         byte ptr [eax],al
  1000A1B2: clc
  1000A1B3: pop         dword ptr [eax+5Ah]
  1000A1B6: imul        edx,dword ptr [esi+12h],0Ch
  1000A1BA: sbb         bl,byte ptr [eax+11h]
  1000A1BD: add         eax,236Ch
  1000A1C2: add         byte ptr [eax],al
  1000A1C4: add         al,bh
  1000A1C6: pop         dword ptr [eax+5Ah]
  1000A1C9: imul        edx,dword ptr [esi+12h],0Ch
  1000A1CD: push        ds
  1000A1CE: pop         eax
  1000A1CF: adc         dword ptr [esp+ebp*2],eax
  1000A1D2: and         eax,dword ptr [eax]
  1000A1D4: add         byte ptr [eax],al
  1000A1D6: add         byte ptr [eax],al
  1000A1D8: lock jg     1000A21B
  1000A1DB: pop         edx
  1000A1DC: imul        edx,dword ptr [esi+12h],0Ch
  1000A1E0: sbb         bl,byte ptr [eax+4Eh]
  1000A1E3: ins         byte ptr es:[edi],dx
  1000A1E4: ins         dword ptr es:[edi],dx
  1000A1E5: and         bh,bh
  1000A1E7: pop         es
  1000A1E8: add         byte ptr [eax],al
  1000A1EA: pop         edi
  1000A1EB: adc         cl,byte ptr [esi+ebx]
  1000A1EE: pop         eax
  1000A1EF: dec         esi
  1000A1F0: ins         byte ptr es:[edi],dx
  1000A1F1: ins         dword ptr es:[edi],dx
  1000A1F2: pop         ds
  1000A1F3: or          esp,dword ptr [edx+60h]
  1000A1F6: pop         ds
  1000A1F7: or          esp,dword ptr [edx+12h]
  1000A1FA: or          al,4Eh
  1000A1FC: ins         byte ptr es:[edi],dx
  1000A1FD: ins         dword ptr es:[edi],dx
  1000A1FE: and         bh,bh
  1000A200: pop         es
  1000A201: add         byte ptr [eax],al
  1000A203: pop         edi
  1000A204: pushad
  1000A205: or          eax,474A0B11h
  1000A20A: sub         al,27h
  1000A20C: adc         cl,byte ptr [edx]
  1000A20E: adc         al,byte ptr [ebx]
  1000A210: sbb         dword ptr [eax+47h],ebx
  1000A213: push        edx
  1000A214: adc         cl,byte ptr [edx]
  1000A216: pop         ss
  1000A217: pop         eax
  1000A218: adc         al,byte ptr [ebx]
  1000A21A: sbb         byte ptr [eax+47h],bl
  1000A21D: push        edx
  1000A21E: adc         cl,byte ptr [edx]
  1000A220: sbb         byte ptr [eax+12h],bl
  1000A223: add         edx,dword ptr [edi]
  1000A225: pop         eax
  1000A226: inc         edi
  1000A227: push        edx
  1000A228: adc         cl,byte ptr [edx]
  1000A22A: sbb         dword ptr [eax+12h],ebx
  1000A22D: add         eax,dword ptr [edi+52h]
  1000A230: adc         dword ptr [edx],ecx
  1000A232: or          eax,4540905h
  1000A237: add         ebx,dword ptr [eax+10h]
  1000A23A: add         dword ptr [esi],ecx
  1000A23C: add         al,5
  1000A23E: pop         eax
  1000A23F: adc         byte ptr [ebx],al
  1000A241: add         dl,byte ptr [edi]
  1000A243: pop         ecx
  1000A244: adc         byte ptr [eax],al
  1000A246: add         bh,byte ptr [edx]
  1000A248: mov         ch,0FEh
  1000A24A: FF
  1000A24B: jmp         fword ptr [edx]
  1000A24D: int         3
  1000A24E: int         3
  1000A24F: int         3
  1000A250: jmp         dword ptr ds:[1002465Ch]
  1000A256: int         3
  1000A257: int         3
  1000A258: add         esi,dword ptr [eax]
  1000A25A: add         al,0
  1000A25C: add         byte ptr [eax],al
  1000A25F: add         byte ptr [edi+1],ch
  1000A262: add         byte ptr [ecx],dl
  1000A264: push        ss
  1000A265: or          eax,dword ptr [edx]
  1000A267: dec         edx
  1000A268: or          al,byte ptr [esi]
  1000A26A: add         bl,byte ptr [edx]
  1000A26C: pop         eax
  1000A26D: dec         edx
  1000A26E: pop         eax
  1000A270: push        es
  1000A271: pop         ds
  1000A272: adc         byte ptr [eax+7],bl
  1000A275: push        esp
  1000A276: push        es
  1000A277: dec         edx
  1000A278: or          al,8
  1000A27A: sbb         eax,1C08042Eh
  1000A27F: xor         ebx,dword ptr [eax]
  1000A281: add         eax,0E142C47h
  1000A286: add         al,18h
  1000A288: clts
  1000A28B: pop         ds
  1000A28C: adc         byte ptr [eax+7],bl
  1000A28F: push        es
  1000A290: sbb         bl,byte ptr [eax+4Ah]
  1000A293: pop         ss
  1000A294: bound       ebx,qword ptr [ecx+19h]
  1000A297: pop         eax
  1000A298: push        esp
  1000A299: add         ecx,dword ptr [eax]
  1000A29B: pop         ds
  1000A29C: adc         byte ptr [edx+58h],bl
  1000A29F: push        ds
  1000A2A0: pop         eax
  1000A2A1: dec         edx
  1000A2A2: pop         es
  1000A2A3: pop         eax
  1000A2A4: or          eax,dword ptr [edx]
  1000A2A6: sbb         bl,byte ptr [eax+4Ah]
  1000A2A9: adc         eax,dword ptr [esi+eax]
  1000A2AC: pop         ds
  1000A2AD: adc         al,58h
  1000A2AF: or          eax,2E041109h
  1000A2B4: add         eax,2E084A09h
  1000A2B9: pop         es
  1000A2BA: pop         es
  1000A2BB: sbb         dword ptr [eax+1Fh],ebx
  1000A2BE: cld
  1000A2BF: pop         edi
  1000A2C0: or          ecx,dword ptr [ecx]
  1000A2C2: or          al,byte ptr [esi]
  1000A2C4: adc         dword ptr [ebx+esi],eax
  1000A2C7: test        al,7
  1000A2C9: sub         cl,ah
  1000A2CB: int         3
  1000A2CC: add         esi,dword ptr [eax]
  1000A2CE: add         al,byte ptr [eax]
  1000A2D0: sbb         eax,71000000h
  1000A2D5: add         dword ptr [eax],eax
  1000A2D7: adc         dword ptr [ebx],eax
  1000A2D9: sub         al,19h
  1000A2DB: add         al,byte ptr [ebx]
  1000A2DD: dec         edx
  1000A2DE: sub         bh,dl
  1000A2E0: add         byte ptr [eax],al
  1000A2E2: push        es
  1000A2E3: add         ebx,dword ptr [edx]
  1000A2E5: pop         eax
  1000A2E6: dec         edx
  1000A2E7: or          al,byte ptr [ebx]
  1000A2E9: sub         byte ptr [edi],bl
  1000A2EB: add         dword ptr [eax],eax
  1000A2ED: push        es
  1000A2EE: push        es
  1000A2EF: adc         byte ptr [ecx],al
  1000A2F1: push        es
  1000A2F2: sub         eax,0CCCC2AE7h
  1000A2F7: int         3
  1000A2F8: or          esi,dword ptr [eax]
  1000A2FA: add         eax,dword ptr [eax]
  1000A2FC: inc         esi
  1000A2FD: add         byte ptr [eax],al
  1000A2FF: add         byte ptr [ebx+1],dh
  1000A302: add         byte ptr [ecx],dl
  1000A304: add         cl,byte ptr [edi]
  1000A306: add         ebx,dword ptr [edx]
  1000A308: FE
  1000A309: pop         ss
  1000A30A: sidt        fword ptr [edx+0Fh]
  1000A30E: add         cl,byte ptr [edx+33h]
  1000A311: add         edx,dword ptr [esi]
  1000A313: sub         eax,dword ptr [ecx]
  1000A315: pop         ss
  1000A316: shr         byte ptr [edi+ebp],cl
  1000A319: add         cl,byte ptr [edx+0Bh]
  1000A31C: pop         es
  1000A31D: or          al,byte ptr [esi]
  1000A31F: or          al,6
  1000A321: sub         eax,612DE02h
  1000A326: sidt        fword ptr [edx+1Fh]
  1000A32A: adc         al,0FEh
  1000A32C: pop         ss
  1000A32D: fimul       word ptr [eax]
  1000A32F: or          byte ptr [esi],al
  1000A331: sub         byte ptr [ecx],al
  1000A333: add         byte ptr [eax],al
  1000A335: push        es
  1000A336: fmul        qword ptr [edi]
  1000A338: add         dword ptr [edi],ecx
  1000A33A: add         dword ptr [edx+1Fh],ecx
  1000A33D: adc         al,58h
  1000A33F: push        esp
  1000A340: add         al,byte ptr [edi]
  1000A342: pop         ds
  1000A343: adc         al,58h
  1000A345: push        esp
  1000A346: sub         eax,edx
  1000A348: add         ch,byte ptr [edx]
  1000A34A: add         byte ptr [eax],al
  1000A34C: inc         ecx
  1000A34D: sbb         al,0
  1000A34F: add         byte ptr [eax+eax],al
  1000A352: add         byte ptr [eax],al
  1000A354: sbb         al,0
  1000A356: add         byte ptr [eax],al
  1000A358: sldt        word ptr [eax]
  1000A35B: add         byte ptr [ebx],ch
  1000A35D: add         byte ptr [eax],al
  1000A35F: add         byte ptr [eax],cl
  1000A361: add         byte ptr [eax],al
  1000A363: add         byte ptr [edx],ah
  1000A365: add         byte ptr [eax],al
  1000A367: add         dword ptr [ebx],eax
  1000A369: xor         byte ptr [eax+eax],al
  1000A36C: push        edi
  1000A36D: add         eax,dword ptr [eax]
  1000A36F: add         byte ptr [esi+1],dh
  1000A372: add         byte ptr [ecx],dl
  1000A374: add         bh,byte ptr [ecx]
  1000A376: push        eax
  1000A377: add         eax,dword ptr [eax]
  1000A379: add         byte ptr [edx],dl
  1000A37B: sbb         dword ptr [edi],ebx
  1000A37D: or          al,58h
  1000A37F: and         al,byte ptr [eax]
  1000A381: add         byte ptr [eax],al
  1000A383: aas
  1000A384: push        esi
  1000A385: adc         bl,byte ptr [ecx]
  1000A387: push        ds
  1000A388: pop         eax
  1000A389: and         al,byte ptr [eax]
  1000A38B: add         byte ptr [eax],al
  1000A38D: aas
  1000A38E: push        esi
  1000A38F: adc         bl,byte ptr [ecx]
  1000A391: sbb         bl,byte ptr [eax+22h]
  1000A394: add         byte ptr [eax],al
  1000A396: add         byte ptr [edi],bh
  1000A398: push        esi
  1000A399: adc         bl,byte ptr [ecx]
  1000A39B: and         al,byte ptr [eax]
  1000A39D: add         byte ptr [eax],al
  1000A39F: aas
  1000A3A0: push        esi
  1000A3A1: adc         bl,byte ptr [eax]
  1000A3A3: pop         ds
  1000A3A4: or          al,58h
  1000A3A6: and         al,byte ptr [eax]
  1000A3A8: add         byte ptr [eax],al
  1000A3AA: mov         edi,1E181256h
  1000A3AF: pop         eax
  1000A3B0: and         al,byte ptr [eax]
  1000A3B2: add         byte ptr [eax],al
  1000A3B4: mov         edi,1A181256h
  1000A3B9: pop         eax
  1000A3BA: and         al,byte ptr [eax]
  1000A3BC: add         byte ptr [eax],al
  1000A3BE: mov         edi,22181256h
  1000A3C3: add         byte ptr [eax],al
  1000A3C5: add         byte ptr [edi+1F050E56h],bh
  1000A3CB: adc         al,58h
  1000A3CD: adc         edx,dword ptr [edx]
  1000A3CF: add         ecx,dword ptr [esi+13h]
  1000A3D2: lsl         ebx,word ptr [edx]
  1000A3D5: pop         eax
  1000A3D6: dec         esi
  1000A3D7: adc         ecx,dword ptr [esi]
  1000A3D9: add         ebx,dword ptr [esi]
  1000A3DB: pop         eax
  1000A3DC: dec         esi
  1000A3DD: adc         ecx,dword ptr ds:[580C1F03h]
  1000A3E3: dec         esi
  1000A3E4: adc         ecx,dword ptr [ebx]
  1000A3E7: add         byte ptr [eax],al
  1000A3E9: add         byte ptr [eax],al
  1000A3EB: add         byte ptr [eax],al
  1000A3ED: add         byte ptr [eax],al
  1000A3EF: adc         dword ptr [edi],ecx
  1000A3F1: ins         byte ptr es:[edi],dx
  1000A3F2: or          dword ptr ss:[edx],esp
  1000A3F5: add         byte ptr [eax],al
  1000A3F7: add         byte ptr [eax],al
  1000A3F9: adc         eax,dword ptr [edi]
  1000A3FB: sub         eax,dword ptr [ecx+edx]
  1000A3FE: movlps      qword ptr [edi],xmm0
  1000A401: and         eax,dword ptr [eax]
  1000A403: add         byte ptr [eax],al
  1000A405: add         byte ptr [eax],al
  1000A407: add         byte ptr [eax],al
  1000A409: add         byte ptr [ecx],dl
  1000A40B: push        cs
  1000A40C: ins         byte ptr es:[edi],dx
  1000A40D: or          dword ptr ss:[edx],esp
  1000A410: add         byte ptr [eax],al
  1000A412: add         byte ptr [eax],al
  1000A414: adc         eax,dword ptr [esi]
  1000A416: sub         eax,dword ptr [ecx+edx]
  1000A419: push        cs
  1000A41A: adc         eax,dword ptr [esi]
  1000A41C: and         eax,dword ptr [eax]
  1000A41E: add         byte ptr [eax],al
  1000A420: add         byte ptr [eax],al
  1000A422: add         byte ptr [eax],al
  1000A424: add         byte ptr [ecx],dl
  1000A426: or          eax,2209366Ch
  1000A42B: add         byte ptr [eax],al
  1000A42D: add         byte ptr [eax],al
  1000A42F: adc         eax,dword ptr ds:[0D11042Bh]
  1000A435: adc         eax,dword ptr ds:[00000023h]
  1000A43B: add         byte ptr [eax],al
  1000A43D: add         byte ptr [eax],al
  1000A43F: add         byte ptr [ecx],dl
  1000A441: or          al,6Ch
  1000A443: or          dword ptr ss:[edx],esp
  1000A446: add         byte ptr [eax],al
  1000A448: add         byte ptr [eax],al
  1000A44A: adc         eax,dword ptr [ebx+ebp]
  1000A44D: add         al,11h
  1000A44F: or          al,13h
  1000A451: add         al,23h
  1000A453: add         byte ptr [eax],al
  1000A455: add         byte ptr [eax],al
  1000A457: add         byte ptr [eax],al
  1000A459: lock aas
  1000A45B: adc         dword ptr [edi],eax
  1000A45D: ins         byte ptr es:[edi],dx
  1000A45E: xor         al,9
  1000A460: and         al,byte ptr [eax]
  1000A462: add         byte ptr [eax+2B0B133Fh],al
  1000A468: add         al,11h
  1000A46A: pop         es
  1000A46B: adc         ecx,dword ptr [ebx]
  1000A46D: and         eax,dword ptr [eax]
  1000A46F: add         byte ptr [eax],al
  1000A471: add         byte ptr [eax],al
  1000A473: add         al,dh
  1000A475: aas
  1000A476: adc         dword ptr [esi],eax
  1000A478: ins         byte ptr es:[edi],dx
  1000A479: xor         al,9
  1000A47B: and         al,byte ptr [eax]
  1000A47D: add         byte ptr [eax+2B0A133Fh],al
  1000A483: add         al,11h
  1000A485: push        es
  1000A486: adc         ecx,dword ptr [edx]
  1000A488: and         eax,dword ptr [eax]
  1000A48A: add         byte ptr [eax],al
  1000A48C: add         byte ptr [eax],al
  1000A48E: add         al,dh
  1000A490: aas
  1000A491: adc         dword ptr ds:[2209346Ch],eax
  1000A497: add         byte ptr [eax],al
  1000A499: cmp         byte ptr [edi],13h
  1000A49C: or          dword ptr [ebx],ebp
  1000A49E: add         al,11h
  1000A4A0: add         eax,230913h
  1000A4A5: add         byte ptr [eax],al
  1000A4A7: add         byte ptr [eax],al
  1000A4A9: add         al,dh
  1000A4AB: aas
  1000A4AC: adc         dword ptr [esp+ebp*2],eax
  1000A4AF: xor         al,9
  1000A4B1: and         al,byte ptr [eax]
  1000A4B3: add         byte ptr [eax+2B08133Fh],al
  1000A4B9: add         al,11h
  1000A4BB: add         al,13h
  1000A4BD: or          byte ptr [edx],dl
  1000A4BF: pop         ss
  1000A4C0: adc         dword ptr [ebx],ecx
  1000A4C2: ins         byte ptr es:[edi],dx
  1000A4C3: and         eax,dword ptr [eax]
  1000A4C5: add         byte ptr [eax],al
  1000A4C7: add         byte ptr [eax],al
  1000A4C9: loopne      1000A53A
  1000A4CB: inc         eax
  1000A4CC: pop         edx
  1000A4CD: imul        edx,dword ptr [esi+12h],17h
  1000A4D1: sbb         bl,byte ptr [eax+11h]
  1000A4D4: or          ch,byte ptr [ebx]
  1000A4D8: add         byte ptr [eax],al
  1000A4DA: add         byte ptr [eax],al
  1000A4DC: loopne      1000A54D
  1000A4DE: inc         eax
  1000A4DF: pop         edx
  1000A4E0: imul        edx,dword ptr [esi+12h],17h
  1000A4E4: push        ds
  1000A4E5: pop         eax
  1000A4E6: adc         dword ptr [ecx],ecx
  1000A4E8: ins         byte ptr es:[edi],dx
  1000A4E9: and         eax,dword ptr [eax]
  1000A4EB: add         byte ptr [eax],al
  1000A4ED: add         byte ptr [eax],al
  1000A4EF: loopne      1000A560
  1000A4F1: inc         eax
  1000A4F2: pop         edx
  1000A4F3: imul        edx,dword ptr [esi+12h],17h
  1000A4F7: pop         ds
  1000A4F8: or          al,58h
  1000A4FA: adc         dword ptr [eax],ecx
  1000A4FC: ins         byte ptr es:[edi],dx
  1000A4FD: and         eax,dword ptr [eax]
  1000A4FF: add         byte ptr [eax],al
  1000A501: add         byte ptr [eax],al
  1000A503: loopne      1000A574
  1000A505: inc         eax
  1000A506: pop         edx
  1000A507: imul        edx,dword ptr [esi+12h],17h
  1000A50B: dec         esi
  1000A50C: and         al,byte ptr [eax]
  1000A50E: add         byte ptr [eax],al
  1000A510: add         byte ptr [esp+eax],dh
  1000A513: adc         eax,16022B0Dh
  1000A518: or          eax,581A1712h
  1000A51D: dec         esi
  1000A51E: and         al,byte ptr [eax]
  1000A520: add         byte ptr [eax],al
  1000A522: add         byte ptr [esp+eax],dh
  1000A525: adc         eax,16022B0Ch
  1000A52A: or          al,12h
  1000A52C: pop         ss
  1000A52D: push        ds
  1000A52E: pop         eax
  1000A52F: dec         esi
  1000A530: and         al,byte ptr [eax]
  1000A532: add         byte ptr [eax],al
  1000A534: add         byte ptr [esp+eax],dh
  1000A537: adc         eax,16022B0Bh
  1000A53C: or          edx,dword ptr [edx]
  1000A53E: pop         ss
  1000A53F: pop         ds
  1000A540: or          al,58h
  1000A542: dec         esi
  1000A543: and         al,byte ptr [eax]
  1000A545: add         byte ptr [eax],al
  1000A547: add         byte ptr [esp+eax],dh
  1000A54A: adc         eax,16022B0Ah
  1000A54F: or          dl,byte ptr [edx]
  1000A551: push        ss
  1000A552: or          dword ptr [esi+12h],esp
  1000A555: sbb         dword ptr [edx+5Fh],ecx
  1000A558: adc         bl,byte ptr [eax]
  1000A55A: dec         edx
  1000A55B: or          dword ptr [edi+60h],ebx
  1000A55E: push        esp
  1000A55F: adc         dl,byte ptr [esi]
  1000A561: sbb         bl,byte ptr [eax+8]
  1000A564: adc         bl,byte ptr [ecx]
  1000A567: sbb         bl,byte ptr [eax+4Ah]
  1000A56A: pop         edi
  1000A56B: adc         bl,byte ptr [eax]
  1000A56D: sbb         bl,byte ptr [eax+4Ah]
  1000A570: or          byte ptr [edi+60h],bl
  1000A573: push        esp
  1000A574: adc         dl,byte ptr [esi]
  1000A576: push        ds
  1000A577: pop         eax
  1000A578: pop         es
  1000A579: adc         bl,byte ptr [ecx]
  1000A57C: push        ds
  1000A57D: pop         eax
  1000A57E: dec         edx
  1000A57F: pop         edi
  1000A580: adc         bl,byte ptr [eax]
  1000A582: push        ds
  1000A583: pop         eax
  1000A584: dec         edx
  1000A585: pop         es
  1000A586: pop         edi
  1000A587: pushad
  1000A588: push        esp
  1000A589: adc         dl,byte ptr [esi]
  1000A58B: pop         ds
  1000A58C: or          al,58h
  1000A58E: push        es
  1000A58F: adc         bl,byte ptr [ecx]
  1000A592: pop         ds
  1000A593: or          al,58h
  1000A595: dec         edx
  1000A596: pop         edi
  1000A597: adc         bl,byte ptr [eax]
  1000A599: pop         ds
  1000A59A: or          al,58h
  1000A59C: dec         edx
  1000A59D: push        es
  1000A59E: pop         edi
  1000A59F: pushad
  1000A5A0: push        esp
  1000A5A1: adc         dl,byte ptr ds:[6C4E1612h]
  1000A5A7: adc         dl,byte ptr [edi]
  1000A5A9: dec         esi
  1000A5AA: ins         byte ptr es:[edi],dx
  1000A5AB: pop         eax
  1000A5AC: imul        edx,dword ptr [esi+12h],15h
  1000A5B0: sbb         bl,byte ptr [eax+12h]
  1000A5B3: push        ss
  1000A5B4: sbb         bl,byte ptr [eax+4Eh]
  1000A5B7: ins         byte ptr es:[edi],dx
  1000A5B8: adc         dl,byte ptr [edi]
  1000A5BA: sbb         bl,byte ptr [eax+4Eh]
  1000A5BD: ins         byte ptr es:[edi],dx
  1000A5BE: pop         eax
  1000A5BF: imul        edx,dword ptr [esi+12h],15h
  1000A5C3: push        ds
  1000A5C4: pop         eax
  1000A5C5: adc         dl,byte ptr [esi]
  1000A5C7: push        ds
  1000A5C8: pop         eax
  1000A5C9: dec         esi
  1000A5CA: ins         byte ptr es:[edi],dx
  1000A5CB: adc         dl,byte ptr [edi]
  1000A5CD: push        ds
  1000A5CE: pop         eax
  1000A5CF: dec         esi
  1000A5D0: ins         byte ptr es:[edi],dx
  1000A5D1: pop         eax
  1000A5D2: imul        edx,dword ptr [esi+12h],15h
  1000A5D6: pop         ds
  1000A5D7: or          al,58h
  1000A5D9: adc         dl,byte ptr [esi]
  1000A5DB: pop         ds
  1000A5DC: or          al,58h
  1000A5DE: dec         esi
  1000A5DF: ins         byte ptr es:[edi],dx
  1000A5E0: adc         dl,byte ptr [edi]
  1000A5E2: pop         ds
  1000A5E3: or          al,58h
  1000A5E5: dec         esi
  1000A5E6: ins         byte ptr es:[edi],dx
  1000A5E7: pop         eax
  1000A5E8: imul        edx,dword ptr [esi+12h],14h
  1000A5EC: adc         dl,byte ptr ds:[6B696C4Eh]
  1000A5F2: push        esi
  1000A5F3: adc         dl,byte ptr [edx+ebx]
  1000A5F6: pop         eax
  1000A5F7: adc         dl,byte ptr ds:[6C4E581Ah]
  1000A5FD: imul        ebp,dword ptr [ebx+56h],581E1412h
  1000A604: adc         dl,byte ptr ds:[6C4E581Eh]
  1000A60A: imul        ebp,dword ptr [ebx+56h],0C1F1412h
  1000A611: pop         eax
  1000A612: adc         dl,byte ptr ds:[4E580C1Fh]
  1000A618: ins         byte ptr es:[edi],dx
  1000A619: imul        ebp,dword ptr [ebx+56h],14121312h
  1000A620: dec         esi
  1000A621: ins         byte ptr es:[edi],dx
  1000A622: ins         dword ptr es:[edi],dx
  1000A623: and         bh,bh
  1000A625: add         byte ptr [eax],al
  1000A627: add         byte ptr [edi+52h],bl
  1000A62A: adc         dl,byte ptr [ebx]
  1000A62C: pop         ss
  1000A62D: pop         eax
  1000A62E: adc         dl,byte ptr [edx+ebx]
  1000A631: pop         eax
  1000A632: dec         esi
  1000A633: ins         byte ptr es:[edi],dx
  1000A634: ins         dword ptr es:[edi],dx
  1000A635: and         bh,bh
  1000A637: add         byte ptr [eax],al
  1000A639: add         byte ptr [edi+52h],bl
  1000A63C: adc         dl,byte ptr [ebx]
  1000A63E: sbb         byte ptr [eax+12h],bl
  1000A641: adc         al,1Eh
  1000A643: pop         eax
  1000A644: dec         esi
  1000A645: ins         byte ptr es:[edi],dx
  1000A646: ins         dword ptr es:[edi],dx
  1000A647: and         bh,bh
  1000A649: add         byte ptr [eax],al
  1000A64B: add         byte ptr [edi+52h],bl
  1000A64E: adc         dl,byte ptr [ebx]
  1000A650: sbb         dword ptr [eax+12h],ebx
  1000A653: adc         al,1Fh
  1000A655: or          al,58h
  1000A657: dec         esi
  1000A658: ins         byte ptr es:[edi],dx
  1000A659: ins         dword ptr es:[edi],dx
  1000A65A: and         bh,bh
  1000A65C: add         byte ptr [eax],al
  1000A65E: add         byte ptr [edi+52h],bl
  1000A661: adc         dl,byte ptr [ebx]
  1000A663: dec         edx
  1000A664: adc         edx,dword ptr [ecx]
  1000A666: adc         dword ptr [edx],edx
  1000A668: dec         edx
  1000A669: inc         edi
  1000A66A: sub         al,28h
  1000A66C: adc         dl,byte ptr [eax]
  1000A66E: adc         dl,byte ptr [ebx]
  1000A670: sbb         dword ptr [eax+47h],ebx
  1000A673: push        edx
  1000A674: adc         dl,byte ptr [eax]
  1000A676: pop         ss
  1000A677: pop         eax
  1000A678: adc         dl,byte ptr [ebx]
  1000A67A: sbb         byte ptr [eax+47h],bl
  1000A67D: push        edx
  1000A67E: adc         dl,byte ptr [eax]
  1000A680: sbb         byte ptr [eax+12h],bl
  1000A683: adc         edx,dword ptr [edi]
  1000A685: pop         eax
  1000A686: inc         edi
  1000A687: push        edx
  1000A688: adc         dl,byte ptr [eax]
  1000A68A: sbb         dword ptr [eax+12h],ebx
  1000A68D: adc         eax,dword ptr [edi+52h]
  1000A690: adc         dword ptr [eax],edx
  1000A692: adc         edx,dword ptr [ecx]
  1000A694: add         eax,52471112h
  1000A699: add         eax,11125817h
  1000A69E: pop         ss
  1000A69F: pop         eax
  1000A6A0: inc         edi
  1000A6A1: push        edx
  1000A6A2: add         eax,11125818h
  1000A6A7: sbb         byte ptr [eax+47h],bl
  1000A6AA: push        edx
  1000A6AB: add         eax,11125819h
  1000A6B0: sbb         dword ptr [eax+47h],ebx
  1000A6B3: push        edx
  1000A6B4: add         al,3
  1000A6B6: pop         eax
  1000A6B7: adc         byte ptr [ecx],al
  1000A6B9: push        cs
  1000A6BA: add         al,5
  1000A6BC: pop         eax
  1000A6BD: adc         byte ptr [ebx],al
  1000A6BF: add         dl,byte ptr [edi]
  1000A6C1: pop         ecx
  1000A6C2: adc         byte ptr [eax],al
  1000A6C4: add         bh,byte ptr [edx]
  1000A6C6: add         eax,2AFFFFFDh
  1000A6CB: int         3
  1000A6CC: int         3
  1000A6CD: int         3
  1000A6CE: int         3
  1000A6CF: int         3
  1000A6D0: jmp         dword ptr ds:[10024660h]
  1000A6D6: int         3
  1000A6D7: int         3
  1000A6D8: add         esi,dword ptr [eax]
  1000A6DA: add         eax,1C00h
  1000A6DF: add         byte ptr [edx+1],bh
  1000A6E2: add         byte ptr [ecx],dl
  1000A6E4: adc         al,byte ptr [edx]
  1000A6E6: add         al,54h
  1000A6E8: adc         al,byte ptr [ecx]
  1000A6EA: add         edx,dword ptr [edx+edx]
  1000A6EE: add         dl,byte ptr [edx+edx+4]
  1000A6F2: push        es
  1000A6F3: pop         es
  1000A6F4: or          byte ptr [ecx],cl
  1000A6F6: sub         dh,bl
  1000A6F8: add         byte ptr [eax],al
  1000A6FA: push        es
  1000A6FB: adc         al,byte ptr es:[edx+ecx*2]
  1000A6FF: sub         al,byte ptr [ebx]
  1000A701: xor         byte ptr [esi],al
  1000A703: add         byte ptr [ebp],bl
  1000A706: add         byte ptr [eax],al
  1000A708: jl          1000A70B
  1000A70A: add         byte ptr [ecx],dl
  1000A70C: push        cs
  1000A70D: add         al,2Dh
  1000A70F: push        ss
  1000A710: add         al,2
  1000A712: sbb         bl,byte ptr [eax+2Eh]
  1000A715: adc         byte ptr ds:[101F0449h],al
  1000A71B: pop         eax
  1000A71C: dec         ecx
  1000A71D: inc         byte ptr ds:[17042DD2h]
  1000A723: or          al,2Bh
  1000A725: add         dl,byte ptr [esi]
  1000A727: or          al,1Fh
  1000A729: adc         al,7Fh
  1000A72B: add         al,byte ptr [eax]
  1000A72D: add         byte ptr [esi+edx],al
  1000A730: push        ss
  1000A731: jg          1000A736
  1000A733: add         byte ptr [eax],al
  1000A735: add         al,20h
  1000A737: rol         dword ptr [eax],1
  1000A739: add         byte ptr [eax],al
  1000A73B: sub         byte ptr [edx+0A060000h],ah
  1000A741: push        es
  1000A742: pop         ds
  1000A743: adc         byte ptr [eax+0Bh],bl
  1000A746: pop         es
  1000A747: sub         al,4
  1000A749: pop         es
  1000A74A: add         eax,4065349h
  1000A74F: add         bl,byte ptr [edx]
  1000A751: pop         eax
  1000A752: or          byte ptr [eax],ch
  1000A754: sub         al,1
  1000A756: add         byte ptr [esi],al
  1000A758: add         bl,byte ptr [edi]
  1000A75A: adc         al,58h
  1000A75C: add         bl,byte ptr [edi]
  1000A75E: adc         al,58h
  1000A760: dec         edx
  1000A761: pop         ss
  1000A762: pop         eax
  1000A763: push        esp
  1000A764: add         eax,dword ptr [esi]
  1000A766: push        esp
  1000A767: add         ebp,dword ptr [edx]
  1000A769: int         3
  1000A76A: int         3
  1000A76B: int         3
  1000A76C: add         esi,dword ptr [eax]
  1000A76E: add         al,byte ptr [eax]
  1000A770: and         al,byte ptr [eax]
  1000A772: add         byte ptr [eax],al
  1000A774: ja          1000A777
  1000A776: add         byte ptr [ecx],dl
  1000A778: add         bl,byte ptr [edi]
  1000A77A: or          al,58h
  1000A77C: dec         edx
  1000A77D: or          al,byte ptr [esi]
  1000A77F: sub         al,18h
  1000A781: add         al,byte ptr [esi]
  1000A783: dec         edx
  1000A784: sub         bh,dl
  1000A786: add         byte ptr [eax],al
  1000A788: push        es
  1000A789: push        es
  1000A78A: sbb         bl,byte ptr [eax+4Ah]
  1000A78D: or          eax,dword ptr [esi]
  1000A78F: sub         byte ptr [edi],bl
  1000A791: add         dword ptr [eax],eax
  1000A793: push        es
  1000A794: pop         es
  1000A795: or          al,byte ptr [edi]
  1000A797: sub         eax,2AE8h
  1000A79C: add         byte ptr [eax],al
  1000A79E: add         byte ptr [eax],al
  1000A7A0: add         esi,dword ptr [eax]
  1000A7A2: add         eax,9400h
  1000A7A7: add         byte ptr [esi+1],bh
  1000A7AA: add         byte ptr [ecx],dl
  1000A7AC: add         bl,byte ptr [edi]
  1000A7AE: or          al,58h
  1000A7B0: dec         edx
  1000A7B1: or          eax,dword ptr [edx]
  1000A7B3: sbb         bl,byte ptr [eax+0Ah]
  1000A7B6: pop         ss
  1000A7B7: or          al,7
  1000A7B9: sub         al,21h
  1000A7BB: add         al,49h
  1000A7BD: adc         eax,dword ptr [ecx+edx]
  1000A7C0: add         al,7
  1000A7C2: pop         ds
  1000A7C3: adc         byte ptr [eax+49h],bl
  1000A7C6: inc         byte ptr ds:[0A070CD2h]
  1000A7CC: or          byte ptr [edi+eax],ch
  1000A7CF: pop         es
  1000A7D0: sbb         bl,byte ptr [eax+4Ah]
  1000A7D3: or          ebp,dword ptr [ebx]
  1000A7D5: add         eax,dword ptr [edi]
  1000A7D7: dec         edx
  1000A7D8: or          eax,dword ptr [edi]
  1000A7DA: sub         eax,80D06E3h
  1000A7DF: sub         al,29h
  1000A7E1: push        es
  1000A7E2: add         bl,byte ptr [esi]
  1000A7E4: pop         eax
  1000A7E5: dec         edx
  1000A7E6: or          dword ptr cs:[esi],eax
  1000A7E9: sub         byte ptr [ebx],ch
  1000A7EB: add         dword ptr [eax],eax
  1000A7ED: push        es
  1000A7EE: or          ch,byte ptr [ebx]
  1000A7F0: sbb         dword ptr [edx],eax
  1000A7F2: adc         al,byte ptr [edi]
  1000A7F4: push        es
  1000A7F5: add         al,16h
  1000A7F7: sub         bl,bl
  1000A7F9: add         byte ptr [eax],al
  1000A7FB: push        es
  1000A7FC: add         edx,dword ptr es:[edx]
  1000A7FF: pop         es
  1000A800: sbb         bh,dh
  1000A802: pop         ss
  1000A803: add         ebx,dword ptr [edx]
  1000A805: pop         eax
  1000A806: pop         ss
  1000A807: push        edx
  1000A808: add         ebp,dword ptr [edx]
  1000A80A: push        es
  1000A80B: pop         ds
  1000A80C: adc         byte ptr [eax+49h],bl
  1000A80F: add         al,49h
  1000A811: inc         byte ptr ds:[02192CD2h]
  1000A817: adc         al,byte ptr [esi]
  1000A819: or          dword ptr [esi+edx],eax
  1000A81C: sub         bl,bl
  1000A81E: add         byte ptr [eax],al
  1000A820: push        es
  1000A821: add         edx,dword ptr es:[edx]
  1000A824: push        es
  1000A825: sbb         bh,dh
  1000A827: pop         ss
  1000A828: add         ebx,dword ptr [edx]
  1000A82A: pop         eax
  1000A82B: pop         ss
  1000A82C: push        edx
  1000A82D: add         ebp,dword ptr [edx]
  1000A82F: adc         al,byte ptr ds:[12035406h]
  1000A835: add         eax,317FE1Ah
  1000A83A: sbb         bl,byte ptr [eax+16h]
  1000A83D: push        edx
  1000A83E: add         ebp,dword ptr [edx]
  1000A840: add         esi,dword ptr [eax]
  1000A842: add         eax,dword ptr [eax]
  1000A844: das
  1000A845: add         byte ptr [eax],al
  1000A847: add         byte ptr [ecx+eax],dh
  1000A84B: adc         dword ptr [edx+ecx],eax
  1000A84E: add         ecx,dword ptr [ebx]
  1000A850: adc         al,byte ptr [ecx]
  1000A852: dec         edx
  1000A853: str         word ptr [edx+33h]
  1000A857: add         edx,dword ptr [esi]
  1000A859: sub         eax,dword ptr [ecx]
  1000A85B: pop         ss
  1000A85C: shr         byte ptr [edx+ebx],cl
  1000A85F: push        es
  1000A860: sbb         byte ptr [ecx+0Ah],bl
  1000A863: adc         al,byte ptr [ecx]
  1000A865: adc         al,byte ptr [ecx]
  1000A867: dec         edx
  1000A868: sub         byte ptr [ebx],ch
  1000A86A: add         dword ptr [eax],eax
  1000A86C: push        es
  1000A86D: push        esp
  1000A86E: push        es
  1000A86F: adc         al,byte ptr [ecx]
  1000A871: dec         edx
  1000A872: pop         ds
  1000A873: adc         byte ptr [eax+49h],bl
  1000A876: push        ebx
  1000A877: sub         edx,edi
  1000A879: push        es
  1000A87A: sub         cl,ah
  1000A87C: add         esi,dword ptr [eax]
  1000A87E: push        es
  1000A87F: add         cl,dh
  1000A881: add         byte ptr [eax],al
  1000A883: add         byte ptr [ecx+02110001h],al
  1000A889: sbb         bl,byte ptr [eax+4Ah]
  1000A88C: or          al,byte ptr [esi]
  1000A88E: add         bl,byte ptr [esi]
  1000A890: pop         eax
  1000A891: dec         edx
  1000A892: popad
  1000A894: add         al,13h
  1000A896: or          dword ptr [ebx+eax],eax
  1000A899: aaa
  1000A89A: or          al,byte ptr [esi+eax]
  1000A89D: xor         al,6
  1000A89F: add         al,1Fh
  1000A8A1: adc         al,58h
  1000A8A3: adc         ecx,dword ptr [ecx]
  1000A8A5: push        es
  1000A8A6: adc         ecx,dword ptr [eax]
  1000A8A8: adc         dword ptr [eax],ecx
  1000A8AA: sub         al,0Ah
  1000A8AC: adc         dword ptr [eax],ecx
  1000A8AE: push        es
  1000A8AF: pop         ds
  1000A8B0: adc         al,59h
  1000A8B2: pop         ds
  1000A8B3: adc         al,0FEh
  1000A8B5: pop         ss
  1000A8B6: add         bl,byte ptr [edx]
  1000A8B8: pop         eax
  1000A8B9: dec         edx
  1000A8BA: or          al,byte ptr [esi]
  1000A8BC: adc         eax,dword ptr ds:[59141F06h]
  1000A8C2: or          al,8
  1000A8C4: add         ebp,dword ptr [esi]
  1000A8C6: pop         ss
  1000A8C7: or          byte ptr [edi],bl
  1000A8C9: adc         al,59h
  1000A8CB: or          al,11h
  1000A8CD: add         eax,1359141Fh
  1000A8D2: add         eax,1F080511h
  1000A8D7: adc         al,0FEh
  1000A8D9: pop         ss
  1000A8DA: or          byte ptr [ebx],al
  1000A8DC: xor         ebp,ecx
  1000A8DE: add         edx,dword ptr [ecx]
  1000A8E0: or          dword ptr [edi],ebx
  1000A8E2: adc         al,0FEh
  1000A8E4: pop         ss
  1000A8E5: add         bl,byte ptr [edx]
  1000A8E7: pop         eax
  1000A8E8: add         bl,byte ptr [edx]
  1000A8EA: pop         eax
  1000A8EB: dec         edx
  1000A8EC: pop         ds
  1000A8ED: adc         al,58h
  1000A8EF: push        esp
  1000A8F0: cmp         byte ptr [ebx+06000000h],al
  1000A8F6: add         cl,byte ptr [edx+59h]
  1000A8F9: pop         ds
  1000A8FA: adc         al,5Bh
  1000A8FC: adc         eax,dword ptr [edi]
  1000A8FE: adc         dword ptr [edi],eax
  1000A900: push        ss
  1000A901: or          byte ptr ss:[ecx],dl
  1000A904: pop         es
  1000A905: pop         ss
  1000A906: bound       edx,qword ptr [ebx]
  1000A908: add         al,2Bh
  1000A90A: add         eax,2B041317h
  1000A90F: add         al,11h
  1000A911: add         al,2Ch
  1000A913: push        ds
  1000A914: adc         dword ptr [edi+ebx],eax
  1000A917: adc         al,5Ah
  1000A919: jg          1000A91D
  1000A91B: add         byte ptr [eax],al
  1000A91D: add         al,16h
  1000A91F: push        ss
  1000A920: jg          1000A925
  1000A922: add         byte ptr [eax],al
  1000A924: add         al,20h
  1000A926: rol         dword ptr [eax],1
  1000A928: add         byte ptr [eax],al
  1000A92A: sub         byte ptr [edx+0D060000h],ah
  1000A930: sub         eax,dword ptr [edx]
  1000A932: push        ss
  1000A933: or          eax,9034A02h
  1000A938: sub         dl,bl
  1000A93A: add         byte ptr [eax],al
  1000A93C: push        es
  1000A93D: or          eax,dword ptr [edi]
  1000A93F: sub         al,6
  1000A941: pop         es
  1000A942: add         al,1Fh
  1000A944: adc         al,0FEh
  1000A946: pop         ss
  1000A947: add         eax,dword ptr [edx]
  1000A949: sbb         bl,byte ptr [eax+4Ah]
  1000A94C: pop         es
  1000A94D: pop         ds
  1000A94E: adc         al,58h
  1000A950: sub         dl,bl
  1000A952: add         byte ptr [eax],al
  1000A954: push        es
  1000A955: or          eax,dword ptr [edx]
  1000A957: dec         edx
  1000A958: adc         eax,dword ptr [esi]
  1000A95A: adc         dword ptr [esi],eax
  1000A95C: sub         al,7
  1000A95E: adc         dword ptr [esi],eax
  1000A960: sub         byte ptr [edi],bl
  1000A962: add         dword ptr [eax],eax
  1000A964: push        es
  1000A965: add         cl,byte ptr [ecx]
  1000A967: push        esp
  1000A968: add         bl,byte ptr [edx]
  1000A96A: pop         eax
  1000A96B: pop         es
  1000A96C: push        esp
  1000A96D: add         bl,byte ptr [esi]
  1000A96F: pop         eax
  1000A970: adc         dword ptr [edi+ebx],eax
  1000A973: adc         al,5Ah
  1000A975: or          dword ptr [eax+54h],ebx
  1000A978: sub         cl,ah
  1000A97A: int         3
  1000A97B: int         3
  1000A97C: add         esi,dword ptr [eax]
  1000A97E: add         eax,dword ptr [eax]
  1000A980: and         eax,82000000h
  1000A985: add         dword ptr [eax],eax
  1000A987: adc         dword ptr [edx],edx
  1000A989: add         al,byte ptr [edx]
  1000A98B: push        esp
  1000A98C: add         ecx,dword ptr [edx]
  1000A98E: or          byte ptr ds:[030B4904h],cl
  1000A994: push        ss
  1000A995: adc         eax,0A591706h
  1000A99B: adc         al,byte ptr [ebx]
  1000A99D: dec         edx
  1000A99E: pop         es
  1000A99F: push        ebx
  1000A9A0: adc         al,byte ptr [ebx]
  1000A9A2: adc         al,byte ptr [ebx]
  1000A9A4: dec         edx
  1000A9A5: sbb         byte ptr [eax+54h],bl
  1000A9A8: push        es
  1000A9A9: push        ss
  1000A9AA: xor         eax,0CCCC2AEBh
  1000A9AF: int         3
  1000A9B0: add         esi,dword ptr [eax]
  1000A9B2: add         eax,dword ptr [eax]
  1000A9B4: das
  1000A9B5: add         byte ptr [eax],al
  1000A9B7: add         byte ptr [ecx+eax],dh
  1000A9BB: adc         dword ptr [edx+ecx],eax
  1000A9BE: add         cl,byte ptr [ebx]
  1000A9C0: adc         al,byte ptr [ecx]
  1000A9C2: dec         edx
  1000A9C3: sidt        fword ptr [edx+33h]
  1000A9C7: add         edx,dword ptr [esi]
  1000A9C9: sub         eax,dword ptr [ecx]
  1000A9CB: pop         ss
  1000A9CC: shr         byte ptr [edx+ebx],cl
  1000A9CF: push        es
  1000A9D0: adc         al,byte ptr [ecx]
  1000A9D2: dec         edx
  1000A9D3: pop         ds
  1000A9D4: adc         byte ptr [eax+49h],bl
  1000A9D7: push        ebx
  1000A9D8: push        es
  1000A9D9: sbb         byte ptr [eax+0Ah],bl
  1000A9DC: adc         al,byte ptr [ecx]
  1000A9DE: adc         al,byte ptr [ecx]
  1000A9E0: dec         edx
  1000A9E1: sub         byte ptr [edx],ch
  1000A9E3: add         dword ptr [eax],eax
  1000A9E5: push        es
  1000A9E6: push        esp
  1000A9E7: sub         edx,edi
  1000A9E9: push        es
  1000A9EA: sub         cl,ah
  1000A9EC: add         esi,dword ptr [eax]
  1000A9EE: add         eax,dword ptr [eax]
  1000A9F0: sub         al,byte ptr [eax]
  1000A9F2: add         byte ptr [eax],al
  1000A9F4: dec         esp
  1000A9F5: add         byte ptr [eax],al
  1000A9F7: adc         dword ptr [edx],eax
  1000A9F9: sbb         bl,byte ptr [eax+4Ah]
  1000A9FC: or          al,byte ptr [esi]
  1000A9FE: add         bl,byte ptr [esi]
  1000AA00: pop         eax
  1000AA01: dec         edx
  1000AA02: xor         al,15h
  1000AA04: push        es
  1000AA05: or          eax,dword ptr [edx]
  1000AA07: sbb         bl,byte ptr [eax+6]
  1000AA0A: pop         ds
  1000AA0B: adc         al,58h
  1000AA0D: push        esp
  1000AA0E: pop         es
  1000AA0F: sub         al,10h
  1000AA11: pop         es
  1000AA12: add         ebx,dword ptr [edi]
  1000AA14: adc         al,0FEh
  1000AA16: pop         ss
  1000AA17: sub         ecx,dword ptr [eax]
  1000AA19: add         al,byte ptr [esi]
  1000AA1B: add         ebp,dword ptr [eax]
  1000AA1D: D6
  1000AA1E: add         byte ptr [eax],al
  1000AA20: push        es
  1000AA21: sub         cl,ah
  1000AA23: int         3
  1000AA24: add         esi,dword ptr [eax]
  1000AA26: add         al,0
  1000AA28: inc         ecx
  1000AA29: add         byte ptr [eax],al
  1000AA2B: add         byte ptr [ebx+02110001h],al
  1000AA31: sbb         bl,byte ptr [eax+4Ah]
  1000AA34: adc         eax,dword ptr ds:[020C0511h]
  1000AA3A: dec         edx
  1000AA3B: adc         eax,dword ptr [ecx+edx]
  1000AA3E: add         eax,0B04110Dh
  1000AA43: or          byte ptr [edx],cl
  1000AA45: or          byte ptr [ecx],cl
  1000AA47: adc         al,7
  1000AA4A: push        es
  1000AA4B: pop         ds
  1000AA4C: adc         al,0FEh
  1000AA4E: pop         ss
  1000AA4F: pop         es
  1000AA50: pop         ds
  1000AA51: adc         al,58h
  1000AA53: or          eax,dword ptr [esi]
  1000AA55: pop         ds
  1000AA56: adc         al,58h
  1000AA58: or          al,byte ptr [esi]
  1000AA5A: or          dword ptr [ebx],esi
  1000AA5C: in          al,dx
  1000AA5D: add         bl,byte ptr [edx]
  1000AA5F: pop         eax
  1000AA60: add         bl,byte ptr [edx]
  1000AA62: pop         eax
  1000AA63: dec         edx
  1000AA64: or          byte ptr [ecx],dl
  1000AA66: add         al,59h
  1000AA68: pop         ds
  1000AA69: in          al,dx
  1000AA6A: pop         ebx
  1000AA6B: pop         ds
  1000AA6C: adc         al,5Ah
  1000AA6E: pop         eax
  1000AA6F: push        esp
  1000AA70: sub         cl,ah
  1000AA72: int         3
  1000AA73: int         3
  1000AA74: add         esi,dword ptr [eax]
  1000AA76: push        es
  1000AA77: add         bl,ch
  1000AA79: add         dword ptr [eax],eax
  1000AA7B: add         byte ptr [ebp+02110001h],al
  1000AA81: sbb         bl,byte ptr [eax+4Ah]
  1000AA84: or          al,byte ptr [edx+eax]
  1000AA87: push        ds
  1000AA88: pop         eax
  1000AA89: dec         edx
  1000AA8A: push        es
  1000AA8B: pop         ecx
  1000AA8C: pop         ss
  1000AA8D: arpl        word ptr [edx-0Ah],ax
  1000AA90: add         byte ptr [eax],al
  1000AA92: add         byte ptr [esi+edx],al
  1000AA95: inc         ebx
  1000AA96: rol         byte ptr [ecx],1
  1000AA98: add         byte ptr [eax],al
  1000AA9A: add         eax,6131349h
  1000AA9F: add         ebx,dword ptr [ecx+17h]
  1000AAA2: arpl        word ptr [ebx],dx
  1000AAA4: or          al,byte ptr [edx]
  1000AAA6: sbb         bl,byte ptr [eax+4Ah]
  1000AAA9: or          al,byte ptr [esi]
  1000AAAB: adc         eax,dword ptr [esi]
  1000AAAD: add         al,11h
  1000AAAF: or          dh,byte ptr [ebx+esi*2]
  1000AAB2: adc         bl,byte ptr [esi]
  1000AAB4: push        es
  1000AAB5: push        esp
  1000AAB6: adc         bl,byte ptr ds:[04065406h]
  1000AABC: sbb         byte ptr [edx+59h],bl
  1000AABF: adc         edx,dword ptr [edx]
  1000AAC1: adc         bl,byte ptr [ecx+edx]
  1000AAC4: adc         dl,byte ptr [edx+edx+1Eh]
  1000AAC8: dec         edx
  1000AAC9: adc         bl,byte ptr [edx+ecx*2]
  1000AACC: adc         bl,byte ptr ds:[4A1C124Ah]
  1000AAD2: pop         ecx
  1000AAD3: sub         byte ptr [ecx],ah
  1000AAD5: add         dword ptr [eax],eax
  1000AAD7: push        es
  1000AAD8: add         bl,byte ptr es:[edx]
  1000AADB: pop         eax
  1000AADC: add         bl,byte ptr [edx]
  1000AADE: pop         eax
  1000AADF: dec         edx
  1000AAE0: add         al,18h
  1000AAE2: pop         edx
  1000AAE3: pop         eax
  1000AAE4: push        esp
  1000AAE5: adc         dword ptr [edx],edx
  1000AAE7: add         ebx,dword ptr [ecx+13h]
  1000AAEA: adc         dword ptr [ecx],edx
  1000AAEC: push        es
  1000AAED: adc         dword ptr [ecx],edx
  1000AAEF: pop         ss
  1000AAF0: arpl        word ptr [edi],dx
  1000AAF2: bound       ebx,qword ptr [ecx+3]
  1000AAF5: adc         dword ptr [ecx],edx
  1000AAF7: sub         byte ptr [ecx],ah
  1000AAF9: add         dword ptr [eax],eax
  1000AAFB: push        es
  1000AAFC: add         edx,dword ptr es:[ebx]
  1000AAFF: add         eax,35A1804h
  1000AB04: pop         eax
  1000AB05: adc         edx,dword ptr [eax]
  1000AB07: add         edx,dword ptr [ecx]
  1000AB09: adc         byte ptr [ebx],bh
  1000AB0B: pop         ebx
  1000AB0C: add         dword ptr [eax],eax
  1000AB0E: add         byte ptr [ecx],dl
  1000AB10: add         eax,11531311h
  1000AB15: add         eax,5135818h
  1000AB1A: adc         dword ptr ds:[EF331011h],eax
  1000AB20: cmp         byte ptr [ebp+1],al
  1000AB23: add         byte ptr [eax],al
  1000AB25: add         al,11h
  1000AB27: or          bl,byte ptr [ecx+13h]
  1000AB2A: clts
  1000AB2C: adc         dword ptr [edi],ecx
  1000AB2E: adc         dl,byte ptr [ebx]
  1000AB30: sub         ch,bl
  1000AB32: add         byte ptr [eax],al
  1000AB34: push        es
  1000AB35: add         bl,byte ptr [edx]
  1000AB37: pop         eax
  1000AB38: add         bl,byte ptr [edx]
  1000AB3A: pop         eax
  1000AB3B: dec         edx
  1000AB3C: adc         dword ptr [edi],ecx
  1000AB3E: pop         ss
  1000AB3F: bound       ebx,qword ptr [eax+54h]
  1000AB42: add         bl,byte ptr [edx]
  1000AB44: pop         eax
  1000AB45: dec         edx
  1000AB46: adc         edx,dword ptr [esi]
  1000AB48: adc         bl,byte ptr [ebx]
  1000AB4A: adc         dword ptr [esi],edx
  1000AB4C: push        esp
  1000AB4D: adc         bl,byte ptr [ebx]
  1000AB4F: dec         edx
  1000AB50: add         edx,dword ptr [ecx]
  1000AB52: push        es
  1000AB53: add         ebx,dword ptr [ecx+28h]
  1000AB56: and         dword ptr [ecx],eax
  1000AB58: add         byte ptr [esi],al
  1000AB5A: add         bl,byte ptr es:[edx]
  1000AB5D: pop         eax
  1000AB5E: add         bl,byte ptr [edx]
  1000AB60: pop         eax
  1000AB61: dec         edx
  1000AB62: adc         dword ptr [edx],ecx
  1000AB64: pop         ss
  1000AB65: bound       ebx,qword ptr [eax+54h]
  1000AB68: add         edx,dword ptr [ebx]
  1000AB6A: add         al,3
  1000AB6C: adc         dword ptr [esi],eax
  1000AB6E: cmp         esi,edi
  1000AB70: add         byte ptr [eax],al
  1000AB72: add         byte ptr [ecx],dl
  1000AB74: add         al,11h
  1000AB76: adc         edx,dword ptr [ebx+11h]
  1000AB79: add         al,18h
  1000AB7B: pop         eax
  1000AB7C: adc         eax,dword ptr [ecx+edx]
  1000AB7F: add         al,11h
  1000AB81: push        es
  1000AB82: xor         ebp,edi
  1000AB84: cmp         cl,ah
  1000AB86: add         byte ptr [eax],al
  1000AB88: add         byte ptr [esi],al
  1000AB8A: add         cl,byte ptr [edx+59h]
  1000AB8D: pop         ss
  1000AB8E: arpl        word ptr [ebx],dx
  1000AB90: or          dword ptr [ecx],edx
  1000AB92: or          dword ptr [esi],edx
  1000AB94: or          byte ptr ss:[ecx],dl
  1000AB97: or          dword ptr [edi],edx
  1000AB99: bound       edx,qword ptr [ebx]
  1000AB9B: or          byte ptr [ebx],ch
  1000AB9D: add         edx,dword ptr [edi]
  1000AB9F: adc         ecx,dword ptr [eax]
  1000ABA1: add         al,11h
  1000ABA3: or          dword ptr [eax+13h],ebx
  1000ABA6: push        cs
  1000ABA7: adc         dword ptr [eax],ecx
  1000ABA9: adc         dword ptr [esi],ecx
  1000ABAB: add         eax,2B0D0811h
  1000ABB1: add         edx,dword ptr [ecx]
  1000ABB3: push        cs
  1000ABB4: or          eax,91C2C09h
  1000ABB9: pop         ss
  1000ABBA: bound       edi,qword ptr [edi+2]
  1000ABBD: add         byte ptr [eax],al
  1000ABBF: add         al,16h
  1000ABC1: push        ss
  1000ABC2: jg          1000ABC7
  1000ABC4: add         byte ptr [eax],al
  1000ABC6: add         al,20h
  1000ABC8: rol         dword ptr [eax],1
  1000ABCA: add         byte ptr [eax],al
  1000ABCC: sub         byte ptr [edx+0C060000h],ah
  1000ABD2: sub         eax,dword ptr [edx]
  1000ABD4: push        ss
  1000ABD5: or          al,12h
  1000ABD7: sbb         al,byte ptr [edx]
  1000ABD9: dec         edx
  1000ABDA: push        esp
  1000ABDB: add         edx,dword ptr [edx]
  1000ABDD: sbb         cl,byte ptr [edx+59h]
  1000ABE0: adc         ecx,dword ptr ds:[63170D11h]
  1000ABE6: sbb         byte ptr [edx+8],bl
  1000ABE9: adc         bl,byte ptr [edx]
  1000ABEB: dec         edx
  1000ABEC: adc         dword ptr ds:[00012128h],ecx
  1000ABF2: push        es
  1000ABF3: pop         eax
  1000ABF4: or          edx,dword ptr [edx]
  1000ABF6: adc         eax,13045407h
  1000ABFB: pop         es
  1000ABFC: adc         dword ptr ds:[49051913h],edx
  1000AC02: adc         edx,dword ptr [esp+eax]
  1000AC05: push        ss
  1000AC06: sbb         dword ptr ss:[ecx],edx
  1000AC09: pop         es
  1000AC0A: pop         ss
  1000AC0B: pop         ecx
  1000AC0C: adc         eax,dword ptr [edi]
  1000AC0E: adc         bl,byte ptr [ecx]
  1000AC10: dec         edx
  1000AC11: adc         dword ptr [ebx+edx*2],edx
  1000AC14: adc         bl,byte ptr [ecx]
  1000AC16: adc         bl,byte ptr [ecx]
  1000AC18: dec         edx
  1000AC19: sbb         byte ptr [eax+54h],bl
  1000AC1C: adc         dword ptr [edi],eax
  1000AC1E: push        ss
  1000AC1F: xor         eax,41812E7h
  1000AC24: sbb         byte ptr [edx+7],bl
  1000AC27: pop         eax
  1000AC28: push        esp
  1000AC29: adc         dl,byte ptr [edi]
  1000AC2B: add         bl,byte ptr [edx]
  1000AC2D: pop         eax
  1000AC2E: dec         edx
  1000AC2F: push        esp
  1000AC30: adc         dl,byte ptr [edi]
  1000AC32: dec         edx
  1000AC33: add         ebx,dword ptr [ecx+13h]
  1000AC36: or          al,11h
  1000AC38: or          al,17h
  1000AC3A: arpl        word ptr [eax],bx
  1000AC3C: pop         edx
  1000AC3D: adc         bl,byte ptr [eax]
  1000AC3F: dec         edx
  1000AC40: add         edx,dword ptr [ecx]
  1000AC42: or          al,28h
  1000AC44: and         dword ptr [ecx],eax
  1000AC46: add         byte ptr [esi],al
  1000AC48: pop         eax
  1000AC49: or          eax,dword ptr [edx]
  1000AC4B: dec         edx
  1000AC4C: adc         ecx,dword ptr [ebx]
  1000AC4E: adc         dword ptr [ebx],ecx
  1000AC50: sub         al,7
  1000AC52: adc         dword ptr [ebx],ecx
  1000AC54: sub         byte ptr [edi],bl
  1000AC56: add         dword ptr [eax],eax
  1000AC58: push        es
  1000AC59: add         cl,byte ptr [eax]
  1000AC5B: push        esp
  1000AC5C: add         bl,byte ptr [edx]
  1000AC5E: pop         eax
  1000AC5F: pop         es
  1000AC60: push        esp
  1000AC61: add         bl,byte ptr [esi]
  1000AC63: pop         eax
  1000AC64: or          dword ptr [eax],ebx
  1000AC66: pop         edx
  1000AC67: or          byte ptr [eax+54h],bl
  1000AC6A: sub         cl,ah
  1000AC6C: add         esi,dword ptr [eax]
  1000AC6E: push        es
  1000AC6F: add         dl,dh
  1000AC71: add         dword ptr [eax],eax
  1000AC73: add         byte ptr [edi+0F110001h],al
  1000AC79: add         cl,byte ptr [edx+0Fh]
  1000AC7C: add         ecx,dword ptr [edx+33h]
  1000AC7F: add         edx,dword ptr [esi]
  1000AC81: sub         eax,dword ptr [ecx]
  1000AC83: pop         ss
  1000AC84: sar         byte ptr [ecx],cl
  1000AC86: fild        word ptr [ecx]
  1000AC88: add         byte ptr [eax],al
  1000AC8A: add         al,13h
  1000AC8C: sbb         eax,1D120A16h
  1000AC91: dec         edx
  1000AC92: lsl         ecx,word ptr [edx+33h]
  1000AC96: add         edx,dword ptr [esi]
  1000AC98: sub         eax,dword ptr [ecx]
  1000AC9A: pop         ss
  1000AC9B: shr         byte ptr [ecx+edx],cl
  1000AC9E: adc         bl,byte ptr ds:[284A1D12h]
  1000ACA4: sub         al,byte ptr [ecx]
  1000ACA6: add         byte ptr [esi],al
  1000ACA8: push        esp
  1000ACA9: push        es
  1000ACAA: pop         ss
  1000ACAB: pop         eax
  1000ACAC: or          ch,byte ptr [ebx]
  1000ACAE: loopne      1000ACB2
  1000ACB0: sbb         bl,byte ptr [eax+4Ah]
  1000ACB3: adc         ecx,dword ptr [eax]
  1000ACB5: push        es
  1000ACB6: add         bl,byte ptr [esi]
  1000ACB8: pop         eax
  1000ACB9: dec         edx
  1000ACBA: adc         dword ptr [eax],ecx
  1000ACBC: pop         ecx
  1000ACBD: pop         ss
  1000ACBE: arpl        word ptr [edx-18h],ax
  1000ACC1: add         byte ptr [eax],al
  1000ACC3: add         byte ptr [ecx],dl
  1000ACC5: or          byte ptr [ebx],al
  1000ACC7: pop         ecx
  1000ACC8: pop         ss
  1000ACC9: arpl        word ptr [ebx],cx
  1000ACCB: add         bl,byte ptr [edx]
  1000ACCD: pop         eax
  1000ACCE: dec         edx
  1000ACCF: adc         eax,dword ptr [ecx+edx]
  1000ACD2: add         al,13h
  1000ACD4: adc         al,byte ptr [esi]
  1000ACD6: pop         es
  1000ACD7: xor         al,5Fh
  1000ACD9: adc         bl,byte ptr [ecx+edx]
  1000ACDC: add         al,54h
  1000ACDE: adc         bl,byte ptr [ebx]
  1000ACE0: adc         dword ptr [esp+edx*2],eax
  1000ACE3: push        es
  1000ACE4: sbb         byte ptr [edx+13h],bl
  1000ACE7: adc         dword ptr [ecx],edx
  1000ACE9: add         al,11h
  1000ACEB: adc         dword ptr [ecx+13h],ebx
  1000ACEE: adc         byte ptr [edx],dl
  1000ACF0: sbb         dl,byte ptr [ecx]
  1000ACF2: adc         byte ptr [edx+edx+1Ch],dl
  1000ACF6: dec         edx
  1000ACF7: adc         bl,byte ptr [edx]
  1000ACF9: dec         edx
  1000ACFA: adc         bl,byte ptr [ebx]
  1000ACFC: dec         edx
  1000ACFD: adc         bl,byte ptr [edx]
  1000ACFF: dec         edx
  1000AD00: pop         ecx
  1000AD01: sub         byte ptr [ecx],ah
  1000AD03: add         dword ptr [eax],eax
  1000AD05: push        es
  1000AD06: add         bl,byte ptr es:[edx]
  1000AD09: pop         eax
  1000AD0A: add         bl,byte ptr [edx]
  1000AD0C: pop         eax
  1000AD0D: dec         edx
  1000AD0E: adc         dword ptr [ecx],edx
  1000AD10: pop         eax
  1000AD11: push        esp
  1000AD12: adc         dword ptr [eax],edx
  1000AD14: add         ebx,dword ptr [ecx+13h]
  1000AD17: movups      xmmword ptr [edx],xmm2
  1000AD1A: adc         dword ptr [edi],ecx
  1000AD1C: pop         ss
  1000AD1D: arpl        word ptr [edi],dx
  1000AD1F: bound       ebx,qword ptr [ecx+3]
  1000AD22: adc         dword ptr [edi],ecx
  1000AD24: sub         byte ptr [ecx],ah
  1000AD26: add         dword ptr [eax],eax
  1000AD28: push        es
  1000AD29: add         al,5
  1000AD2C: add         ebp,dword ptr [eax]
  1000AD2E: fild        word ptr [eax]
  1000AD30: add         byte ptr [esi],al
  1000AD32: cmp         byte ptr es:[ecx],dh
  1000AD35: add         dword ptr [eax],eax
  1000AD37: add         byte ptr [ebx+edx],al
  1000AD3A: push        cs
  1000AD3B: pop         es
  1000AD3C: adc         eax,dword ptr [edi]
  1000AD3E: pop         es
  1000AD3F: sub         al,15h
  1000AD41: adc         dword ptr [edi],eax
  1000AD43: pop         ss
  1000AD44: pop         ecx
  1000AD45: adc         eax,dword ptr [edi]
  1000AD47: adc         cl,byte ptr [esi]
  1000AD49: adc         cl,byte ptr [esi]
  1000AD4B: dec         edx
  1000AD4C: sub         byte ptr [edx],ch
  1000AD4E: add         dword ptr [eax],eax
  1000AD50: push        es
  1000AD51: push        esp
  1000AD52: adc         dword ptr [edi],eax
  1000AD54: sub         eax,50E11EBh
  1000AD59: add         bl,byte ptr [edx]
  1000AD5B: pop         eax
  1000AD5C: dec         edx
  1000AD5D: sub         al,ah
  1000AD5F: add         byte ptr [eax],al
  1000AD61: push        es
  1000AD62: add         bl,byte ptr es:[edx]
  1000AD65: pop         eax
  1000AD66: add         bl,byte ptr [edx]
  1000AD68: pop         eax
  1000AD69: dec         edx
  1000AD6A: push        es
  1000AD6B: pop         es
  1000AD6C: pop         ecx
  1000AD6D: pop         ss
  1000AD6E: bound       ebx,qword ptr [eax+54h]
  1000AD71: add         bl,byte ptr [edx]
  1000AD73: pop         eax
  1000AD74: dec         edx
  1000AD75: adc         edx,dword ptr ds:[15111912h]
  1000AD7B: push        esp
  1000AD7C: adc         bl,byte ptr [ecx]
  1000AD7E: dec         edx
  1000AD7F: add         edx,dword ptr [ecx]
  1000AD81: adc         al,byte ptr [ebx]
  1000AD83: pop         ecx
  1000AD84: sub         byte ptr [ecx],ah
  1000AD86: add         dword ptr [eax],eax
  1000AD88: push        es
  1000AD89: pop         es
  1000AD8B: sbb         byte ptr [edx+13h],bl
  1000AD8E: or          eax,2581A02h
  1000AD93: sbb         bl,byte ptr [eax+4Ah]
  1000AD96: adc         dword ptr ds:[11045458h],ecx
  1000AD9C: push        cs
  1000AD9D: adc         dword ptr ds:[E1285803h],ecx
  1000ADA3: add         byte ptr [eax],al
  1000ADA5: push        es
  1000ADA6: cmp         byte ptr es:[ebp+11000000h],bh
  1000ADAD: or          byte ptr [edx],al
  1000ADAF: dec         edx
  1000ADB0: pop         ecx
  1000ADB1: pop         ss
  1000ADB2: arpl        word ptr [ebx],dx
  1000ADB4: push        es
  1000ADB5: adc         dword ptr [esi],eax
  1000ADB7: push        ss
  1000ADB8: or          byte ptr ss:[ecx],dl
  1000ADBB: push        es
  1000ADBC: pop         ss
  1000ADBD: bound       edx,qword ptr [ebx]
  1000ADBF: add         eax,1317032Bh
  1000ADC4: add         eax,58060611h
  1000ADC9: adc         ecx,dword ptr [ecx+edx]
  1000ADCC: add         eax,5360C11h
  1000ADD1: adc         dword ptr ds:[11032B0Dh],eax
  1000ADD7: or          al,0Dh
  1000ADD9: or          dword ptr [esp+ebx],ebp
  1000ADDC: or          dword ptr [edi],edx
  1000ADDE: bound       edi,qword ptr [edi+2]
  1000ADE1: add         byte ptr [eax],al
  1000ADE3: add         al,16h
  1000ADE5: push        ss
  1000ADE6: jg          1000ADEB
  1000ADE8: add         byte ptr [eax],al
  1000ADEA: add         al,20h
  1000ADEC: rol         dword ptr [eax],1
  1000ADEE: add         byte ptr [eax],al
  1000ADF0: sub         byte ptr [edx+0C060000h],ah
  1000ADF6: sub         eax,dword ptr [edx]
  1000ADF8: push        ss
  1000ADF9: or          al,12h
  1000ADFB: sbb         byte ptr [edx],al
  1000ADFD: dec         edx
  1000ADFE: push        esp
  1000ADFF: add         edx,dword ptr [edx]
  1000AE01: sbb         byte ptr [edx+59h],cl
  1000AE04: adc         ecx,dword ptr [ebx]
  1000AE06: adc         dword ptr [ebx],ecx
  1000AE08: pop         ss
  1000AE09: arpl        word ptr [eax],bx
  1000AE0B: pop         edx
  1000AE0C: or          byte ptr [edx],dl
  1000AE0E: sbb         byte ptr [edx+11h],cl
  1000AE11: or          ebp,dword ptr [eax]
  1000AE13: and         dword ptr [ecx],eax
  1000AE15: add         byte ptr [esi],al
  1000AE17: pop         eax
  1000AE18: adc         edx,dword ptr [edx+edx]
  1000AE1B: pop         ss
  1000AE1C: add         al,5
  1000AE1E: adc         dword ptr [eax+ebp],edx
  1000AE21: loopne      1000AE23
  1000AE23: add         byte ptr [esi],al
  1000AE25: push        esp
  1000AE26: adc         dl,byte ptr [esi]
  1000AE28: add         bl,byte ptr [edx]
  1000AE2A: pop         eax
  1000AE2B: dec         edx
  1000AE2C: push        esp
  1000AE2D: adc         dl,byte ptr [esi]
  1000AE2F: dec         edx
  1000AE30: add         ebx,dword ptr [ecx+13h]
  1000AE33: or          dl,byte ptr [ecx]
  1000AE35: or          dl,byte ptr [edi]
  1000AE37: arpl        word ptr [eax],bx
  1000AE39: pop         edx
  1000AE3A: adc         dl,byte ptr [edi]
  1000AE3C: dec         edx
  1000AE3D: add         edx,dword ptr [ecx]
  1000AE3F: or          ch,byte ptr [eax]
  1000AE41: and         dword ptr [ecx],eax
  1000AE43: add         byte ptr [esi],al
  1000AE45: pop         eax
  1000AE46: adc         edx,dword ptr [ebx]
  1000AE48: add         cl,byte ptr [edx+13h]
  1000AE4B: or          dword ptr [ecx],edx
  1000AE4D: or          dword ptr [edi+eax],ebp
  1000AE50: adc         dword ptr [ecx],ecx
  1000AE52: sub         byte ptr [edi],bl
  1000AE54: add         dword ptr [eax],eax
  1000AE56: push        es
  1000AE57: add         cl,byte ptr [eax]
  1000AE59: push        esp
  1000AE5A: add         bl,byte ptr [edx]
  1000AE5C: pop         eax
  1000AE5D: adc         dword ptr [ebx],edx
  1000AE5F: push        esp
  1000AE60: add         bl,byte ptr [esi]
  1000AE62: pop         eax
  1000AE63: or          dword ptr [eax],ebx
  1000AE65: pop         edx
  1000AE66: or          byte ptr [eax+54h],bl
  1000AE69: sub         cl,ah
  1000AE6B: int         3
  1000AE6C: add         esi,dword ptr [eax]
  1000AE6E: add         eax,dword ptr [eax]
  1000AE70: test        al,3
  1000AE72: add         byte ptr [eax],al
  1000AE74: mov         dword ptr [ecx],eax
  1000AE76: add         byte ptr [ecx],dl
  1000AE78: add         ebp,dword ptr [eax]
  1000AE7A: aadb        0
  1000AE7C: add         byte ptr [esi],al
  1000AE7E: push        ss
  1000AE7F: adc         ecx,dword ptr [eax]
  1000AE81: push        ss
  1000AE82: add         cl,byte ptr [edx+2Fh]
  1000AE85: jb          1000AE89
  1000AE87: sbb         bl,byte ptr [eax+13h]
  1000AE8A: sbb         eax,13581E03h
  1000AE8F: sbb         al,12h
  1000AE91: push        ss
  1000AE93: push        esp
  1000AE94: adc         ah,byte ptr [esi]
  1000AE96: sbb         bl,byte ptr [eax+11h]
  1000AE99: or          byte ptr [edx+edx+26h],dl
  1000AE9D: push        ds
  1000AE9E: pop         eax
  1000AE9F: adc         dword ptr [eax],ecx
  1000AEA1: push        ds
  1000AEA2: pop         edx
  1000AEA3: adc         dword ptr ds:[581A584Ah],ebx
  1000AEA9: dec         edx
  1000AEAA: push        esp
  1000AEAB: adc         ah,byte ptr [esi]
  1000AEAD: pop         ds
  1000AEAE: or          al,58h
  1000AEB0: pop         ds
  1000AEB1: or          al,54h
  1000AEB3: adc         ah,byte ptr [esi]
  1000AEB5: pop         ds
  1000AEB6: adc         byte ptr [eax+16h],bl
  1000AEB9: push        esp
  1000AEBA: add         ebx,dword ptr [edx]
  1000AEBC: pop         eax
  1000AEBD: dec         edx
  1000AEBE: adc         ecx,dword ptr [ebx]
  1000AEC0: adc         dword ptr [ebx],ecx
  1000AEC2: adc         dword ptr [edx+ecx*2],ebx
  1000AEC5: xor         al,1Bh
  1000AEC7: adc         dword ptr [ebx],ecx
  1000AEC9: adc         edx,dword ptr [esi]
  1000AECB: add         ebx,dword ptr [edx]
  1000AECD: pop         eax
  1000AECE: adc         dword ptr [ebx],ecx
  1000AED0: pop         ds
  1000AED1: adc         al,58h
  1000AED3: push        esp
  1000AED4: adc         dword ptr [esi],edx
  1000AED6: sub         al,14h
  1000AED8: adc         dword ptr [esi],edx
  1000AEDA: adc         ah,byte ptr [esi]
  1000AEDC: pop         ds
  1000AEDD: adc         al,0FEh
  1000AEDF: pop         ss
  1000AEE0: sub         ecx,dword ptr [edx]
  1000AEE2: add         edx,dword ptr [ecx]
  1000AEE4: or          edx,dword ptr [edx]
  1000AEE6: sub         dh,dl
  1000AEE9: add         byte ptr [eax],al
  1000AEEB: push        es
  1000AEEC: adc         dword ptr [eax],ecx
  1000AEEE: pop         ss
  1000AEEF: pop         eax
  1000AEF0: adc         ecx,dword ptr [eax]
  1000AEF2: adc         dword ptr [eax],ecx
  1000AEF4: add         cl,byte ptr [edx+32h]
  1000AEF7: cwde
  1000AEF8: push        ss
  1000AEF9: adc         eax,dword ptr [edi]
  1000AEFB: push        ss
  1000AEFC: add         bl,byte ptr [esi]
  1000AEFE: pop         eax
  1000AEFF: dec         edx
  1000AF00: cmp         al,75h
  1000AF02: add         byte ptr [eax],al
  1000AF04: add         byte ptr [edx],al
  1000AF06: pop         ds
  1000AF07: or          al,58h
  1000AF09: adc         ebx,dword ptr [ebx]
  1000AF0B: add         ebx,dword ptr [esi]
  1000AF0D: pop         eax
  1000AF0E: adc         ebx,dword ptr [edx]
  1000AF10: adc         ah,byte ptr ds:[25125417h]
  1000AF16: sbb         bl,byte ptr [eax+11h]
  1000AF19: pop         es
  1000AF1A: push        esp
  1000AF1B: adc         ah,byte ptr ds:[0711581Eh]
  1000AF21: push        ds
  1000AF22: pop         edx
  1000AF23: adc         dword ptr [ebx],ebx
  1000AF25: dec         edx
  1000AF26: pop         eax
  1000AF27: sbb         bl,byte ptr [eax+4Ah]
  1000AF2A: push        esp
  1000AF2B: adc         ah,byte ptr ds:[1F580C1Fh]
  1000AF31: or          al,54h
  1000AF33: adc         ah,byte ptr ds:[1658101Fh]
  1000AF39: push        esp
  1000AF3A: add         ebx,dword ptr [edx]
  1000AF3C: pop         eax
  1000AF3D: dec         edx
  1000AF3E: adc         ecx,dword ptr [edx]
  1000AF40: adc         dword ptr [edx],ecx
  1000AF42: adc         dword ptr [edx],ebx
  1000AF44: dec         edx
  1000AF45: xor         al,1Bh
  1000AF47: adc         dword ptr [edx],ecx
  1000AF49: adc         edx,dword ptr ds:[11581A03h]
  1000AF4F: or          bl,byte ptr [edi]
  1000AF51: adc         al,58h
  1000AF53: push        esp
  1000AF54: adc         dword ptr ds:[1511142Ch],edx
  1000AF5A: adc         ah,byte ptr ds:[17FE141Fh]
  1000AF60: sub         ecx,dword ptr [edx]
  1000AF62: add         edx,dword ptr [ecx]
  1000AF64: or          dl,byte ptr [edx]
  1000AF66: and         eax,0D628h
  1000AF6B: push        es
  1000AF6C: adc         dword ptr [edi],eax
  1000AF6E: pop         ss
  1000AF6F: pop         eax
  1000AF70: adc         eax,dword ptr [edi]
  1000AF72: adc         dword ptr [edi],eax
  1000AF74: add         bl,byte ptr [esi]
  1000AF76: pop         eax
  1000AF77: dec         edx
  1000AF78: xor         dl,byte ptr [esi+58181F02h]
  1000AF7E: dec         edx
  1000AF7F: adc         edx,dword ptr [ecx+edx]
  1000AF82: adc         al,2Ch
  1000AF84: push        ebp
  1000AF85: adc         ah,byte ptr [ebx+ebx]
  1000AF88: push        esp
  1000AF89: adc         ah,byte ptr [edx+ebx]
  1000AF8C: pop         eax
  1000AF8D: push        ss
  1000AF8E: push        esp
  1000AF8F: adc         ah,byte ptr [esi+ebx]
  1000AF92: pop         eax
  1000AF93: adc         dword ptr [edx+ebx],edx
  1000AF96: pop         eax
  1000AF97: dec         edx
  1000AF98: push        esp
  1000AF99: adc         ah,byte ptr [edi+ebx]
  1000AF9C: or          al,58h
  1000AF9E: pop         ds
  1000AF9F: adc         byte ptr [edx+edx+24h],dl
  1000AFA3: pop         ds
  1000AFA4: adc         byte ptr [eax+16h],bl
  1000AFA7: push        esp
  1000AFA8: add         ebx,dword ptr [esi]
  1000AFAA: pop         eax
  1000AFAB: or          al,3
  1000AFAD: sbb         bl,byte ptr [eax+0Bh]
  1000AFB0: pop         es
  1000AFB1: dec         edx
  1000AFB2: or          al,byte ptr [esi]
  1000AFB4: or          byte ptr [edx+34h],cl
  1000AFB7: pop         ss
  1000AFB8: push        es
  1000AFB9: adc         edx,dword ptr [ebx]
  1000AFBB: pop         es
  1000AFBC: push        es
  1000AFBD: pop         ds
  1000AFBE: adc         al,58h
  1000AFC0: push        esp
  1000AFC1: adc         dword ptr [ebx],edx
  1000AFC3: sub         al,67h
  1000AFC5: adc         dword ptr [ebx],edx
  1000AFC7: adc         ah,byte ptr [edi+ebx]
  1000AFCA: adc         al,0FEh
  1000AFCC: pop         ss
  1000AFCD: sub         ebx,dword ptr [ebp+3]
  1000AFD0: push        es
  1000AFD1: adc         ah,byte ptr [eax+ebp]
  1000AFD4: D6
  1000AFD5: add         byte ptr [eax],al
  1000AFD7: push        es
  1000AFD8: sub         edx,dword ptr [edx+12h]
  1000AFDB: and         ebx,dword ptr [ebx]
  1000AFDD: push        esp
  1000AFDE: adc         ah,byte ptr [ebx]
  1000AFE0: sbb         bl,byte ptr [eax+16h]
  1000AFE3: push        esp
  1000AFE4: adc         ah,byte ptr [ebx]
  1000AFE6: push        ds
  1000AFE7: pop         eax
  1000AFE8: jg          1000AFF0
  1000AFEA: add         dword ptr [eax],eax
  1000AFEC: add         al,54h
  1000AFEE: adc         ah,byte ptr [ebx]
  1000AFF0: pop         ds
  1000AFF1: or          al,58h
  1000AFF3: push        ss
  1000AFF4: push        esp
  1000AFF5: adc         ah,byte ptr [ebx]
  1000AFF7: pop         ds
  1000AFF8: adc         byte ptr [eax+16h],bl
  1000AFFB: push        esp
  1000AFFC: add         ebx,dword ptr [esi]
  1000AFFE: pop         eax
  1000AFFF: or          al,3
  1000B001: sbb         bl,byte ptr [eax+0Bh]
  1000B004: pop         es
  1000B005: dec         edx
  1000B006: or          al,byte ptr [esi]
  1000B008: or          byte ptr [edx+34h],cl
  1000B00B: pop         ss
  1000B00C: push        es
  1000B00D: adc         edx,dword ptr [edx]
  1000B00F: pop         es
  1000B010: push        es
  1000B011: pop         ds
  1000B012: adc         al,58h
  1000B014: push        esp
  1000B015: adc         dword ptr [edx],edx
  1000B017: sub         al,13h
  1000B019: adc         dword ptr [edx],edx
  1000B01B: adc         ah,byte ptr [ebx]
  1000B01D: pop         ds
  1000B01E: adc         al,0FEh
  1000B020: pop         ss
  1000B021: sub         ecx,dword ptr [ecx]
  1000B023: add         eax,dword ptr [esi]
  1000B025: adc         ah,byte ptr [ebx]
  1000B027: sub         dh,dl
  1000B029: add         byte ptr [eax],al
  1000B02B: push        es
  1000B02C: add         bl,byte ptr [edi]
  1000B02E: adc         byte ptr [eax+4Ah],bl
  1000B031: adc         edx,dword ptr [ecx]
  1000B033: adc         dword ptr [ecx],edx
  1000B035: cmp         dword ptr [eax+02000000h],ebp
  1000B03B: pop         ds
  1000B03C: adc         al,58h
  1000B03E: dec         edx
  1000B03F: cmp         dword ptr [esi+12000000h],ebx
  1000B045: and         bl,byte ptr [eax]
  1000B047: push        esp
  1000B048: adc         ah,byte ptr [edx]
  1000B04A: sbb         bl,byte ptr [eax+16h]
  1000B04D: push        esp
  1000B04E: adc         ah,byte ptr [edx]
  1000B050: push        ds
  1000B051: pop         eax
  1000B052: adc         dword ptr [ecx],edx
  1000B054: sbb         bl,byte ptr [eax+4Ah]
  1000B057: push        esp
  1000B058: adc         ah,byte ptr [edx]
  1000B05A: pop         ds
  1000B05B: or          al,58h
  1000B05D: pop         ds
  1000B05E: or          al,54h
  1000B060: adc         ah,byte ptr [edx]
  1000B062: pop         ds
  1000B063: adc         byte ptr [eax+16h],bl
  1000B066: push        esp
  1000B067: pop         es
  1000B068: dec         edx
  1000B069: adc         ecx,dword ptr [ecx]
  1000B06B: adc         dword ptr [ecx],ecx
  1000B06D: or          byte ptr [edx+34h],cl
  1000B070: sbb         dword ptr [ecx],edx
  1000B072: or          dword ptr [ebx],edx
  1000B074: adc         byte ptr [edi],al
  1000B076: adc         dword ptr [ecx],ecx
  1000B078: pop         ds
  1000B079: adc         al,58h
  1000B07B: push        esp
  1000B07C: adc         dword ptr [eax],edx
  1000B07E: sub         al,14h
  1000B080: adc         dword ptr [eax],edx
  1000B082: adc         ah,byte ptr [edx]
  1000B084: pop         ds
  1000B085: adc         al,0FEh
  1000B087: pop         ss
  1000B088: sub         ecx,dword ptr [edx]
  1000B08A: add         edx,dword ptr [ecx]
  1000B08C: or          dword ptr [edx],edx
  1000B08E: and         ch,byte ptr [eax]
  1000B090: D6
  1000B091: add         byte ptr [eax],al
  1000B093: push        es
  1000B094: adc         ah,byte ptr [ecx]
  1000B096: sbb         dword ptr [edx+edx+21h],edx
  1000B09A: sbb         bl,byte ptr [eax+16h]
  1000B09D: push        esp
  1000B09E: adc         ah,byte ptr [ecx]
  1000B0A0: push        ds
  1000B0A1: pop         eax
  1000B0A2: add         bl,byte ptr [edi]
  1000B0A4: adc         al,58h
  1000B0A6: dec         edx
  1000B0A7: sbb         bl,byte ptr [eax+4Ah]
  1000B0AA: push        esp
  1000B0AB: adc         ah,byte ptr [ecx]
  1000B0AD: pop         ds
  1000B0AE: or          al,58h
  1000B0B0: pop         ds
  1000B0B1: or          al,54h
  1000B0B3: adc         ah,byte ptr [ecx]
  1000B0B5: pop         ds
  1000B0B6: adc         byte ptr [eax+16h],bl
  1000B0B9: push        esp
  1000B0BA: pop         es
  1000B0BB: dec         edx
  1000B0BC: or          al,byte ptr [esi]
  1000B0BE: or          byte ptr [edx+34h],cl
  1000B0C1: pop         ss
  1000B0C2: push        es
  1000B0C3: adc         ecx,dword ptr [edi]
  1000B0C5: pop         es
  1000B0C6: push        es
  1000B0C7: pop         ds
  1000B0C8: adc         al,58h
  1000B0CA: push        esp
  1000B0CB: adc         dword ptr [edi],ecx
  1000B0CD: sub         al,13h
  1000B0CF: adc         dword ptr [edi],ecx
  1000B0D1: adc         ah,byte ptr [ecx]
  1000B0D3: pop         ds
  1000B0D4: adc         al,0FEh
  1000B0D6: pop         ss
  1000B0D7: sub         ecx,dword ptr [ecx]
  1000B0D9: add         eax,dword ptr [esi]
  1000B0DB: adc         ah,byte ptr [ecx]
  1000B0DD: sub         dh,dl
  1000B0DF: add         byte ptr [eax],al
  1000B0E1: push        es
  1000B0E2: push        ss
  1000B0E3: adc         eax,dword ptr [esi]
  1000B0E5: push        ss
  1000B0E6: add         bl,byte ptr [edi]
  1000B0E8: sbb         al,58h
  1000B0EA: dec         edx
  1000B0EB: xor         al,46h
  1000B0ED: add         bl,byte ptr [edi]
  1000B0EF: and         byte ptr [eax+13h],bl
  1000B0F2: sbb         dword ptr [edx],edx
  1000B0F4: and         byte ptr [edx],bl
  1000B0F6: push        esp
  1000B0F7: adc         ah,byte ptr [eax]
  1000B0F9: sbb         bl,byte ptr [eax+11h]
  1000B0FC: push        es
  1000B0FD: push        esp
  1000B0FE: adc         ah,byte ptr [eax]
  1000B100: push        ds
  1000B101: pop         eax
  1000B102: adc         dword ptr [esi],eax
  1000B104: push        ds
  1000B105: pop         edx
  1000B106: adc         dword ptr [ecx],ebx
  1000B108: dec         edx
  1000B109: pop         eax
  1000B10A: sbb         bl,byte ptr [eax+4Ah]
  1000B10D: push        esp
  1000B10E: adc         ah,byte ptr [eax]
  1000B110: pop         ds
  1000B111: or          al,58h
  1000B113: push        ds
  1000B114: push        esp
  1000B115: adc         ah,byte ptr [eax]
  1000B117: pop         ds
  1000B118: adc         byte ptr [eax+16h],bl
  1000B11B: push        esp
  1000B11C: add         edx,dword ptr [edx]
  1000B11E: and         byte ptr [eax],ch
  1000B120: aamb        0
  1000B122: add         byte ptr [esi],al
  1000B124: adc         dword ptr [esi],eax
  1000B126: pop         ss
  1000B127: pop         eax
  1000B128: adc         eax,dword ptr [esi]
  1000B12A: adc         dword ptr [esi],eax
  1000B12C: add         bl,byte ptr [edi]
  1000B12E: sbb         al,58h
  1000B130: dec         edx
  1000B131: aaa
  1000B132: rol         byte ptr [edx],1Fh
  1000B135: and         al,58h
  1000B137: adc         ecx,dword ptr [esi]
  1000B139: adc         dword ptr [esi],ecx
  1000B13B: dec         edx
  1000B13C: add         cl,byte ptr [edx+34h]
  1000B13F: add         al,11h
  1000B141: push        cs
  1000B142: sub         eax,dword ptr [ecx]
  1000B144: add         cl,byte ptr [edx+13h]
  1000B147: add         eax,16041316h
  1000B14C: adc         dword ptr ds:[1F02652Fh],eax
  1000B152: sub         byte ptr [eax+13h],bl
  1000B155: sbb         byte ptr [edx],dl
  1000B157: pop         ds
  1000B158: sbb         eax,1A1F1254h
  1000B15D: pop         eax
  1000B15E: adc         dword ptr [esp+edx*2],eax
  1000B161: adc         bl,byte ptr [edi]
  1000B163: push        ds
  1000B164: pop         eax
  1000B165: adc         dword ptr [esi+ebx],eax
  1000B168: pop         edx
  1000B169: adc         dword ptr [eax],ebx
  1000B16B: dec         edx
  1000B16C: pop         eax
  1000B16D: sbb         bl,byte ptr [eax+4Ah]
  1000B170: sbb         bl,byte ptr [eax+54h]
  1000B173: adc         bl,byte ptr [edi]
  1000B175: pop         ds
  1000B176: or          al,58h
  1000B178: push        ds
  1000B179: push        esp
  1000B17A: adc         bl,byte ptr [edi]
  1000B17C: pop         ds
  1000B17D: adc         byte ptr [eax+16h],bl
  1000B180: push        esp
  1000B181: pop         es
  1000B182: dec         edx
  1000B183: or          al,byte ptr [esi]
  1000B185: or          byte ptr [edx+34h],cl
  1000B188: pop         ss
  1000B189: push        es
  1000B18A: adc         ecx,dword ptr ds:[141F0607h]
  1000B190: pop         eax
  1000B191: push        esp
  1000B192: adc         dword ptr ds:[0D11132Ch],ecx
  1000B198: adc         bl,byte ptr [edi]
  1000B19A: pop         ds
  1000B19B: adc         al,0FEh
  1000B19D: pop         ss
  1000B19E: sub         ecx,dword ptr [ecx]
  1000B1A0: add         eax,dword ptr [esi]
  1000B1A2: adc         bl,byte ptr [edi]
  1000B1A4: sub         dh,dl
  1000B1A6: add         byte ptr [eax],al
  1000B1A8: push        es
  1000B1A9: adc         dword ptr [edi+edx],eax
  1000B1AC: pop         eax
  1000B1AD: adc         eax,dword ptr [ecx+edx]
  1000B1B0: add         al,11h
  1000B1B2: add         eax,511A132h
  1000B1B7: pop         ss
  1000B1B8: xor         dword ptr [ebp+16h],esp
  1000B1BB: or          eax,2F051116h
  1000B1C0: pop         esi
  1000B1C1: add         bl,byte ptr [edi]
  1000B1C3: sub         byte ptr [eax+13h],bl
  1000B1C6: pop         ss
  1000B1C7: adc         bl,byte ptr [esi]
  1000B1C9: sbb         al,54h
  1000B1CB: adc         bl,byte ptr [esi]
  1000B1CD: sbb         bl,byte ptr [eax+9]
  1000B1D0: push        esp
  1000B1D1: adc         bl,byte ptr [esi]
  1000B1D3: push        ds
  1000B1D4: pop         eax
  1000B1D5: or          dword ptr [esi],ebx
  1000B1D7: pop         edx
  1000B1D8: adc         dword ptr [edi],edx
  1000B1DA: dec         edx
  1000B1DB: pop         eax
  1000B1DC: sbb         bl,byte ptr [eax+4Ah]
  1000B1DF: push        esp
  1000B1E0: adc         bl,byte ptr [esi]
  1000B1E2: pop         ds
  1000B1E3: or          al,58h
  1000B1E5: push        ds
  1000B1E6: push        esp
  1000B1E7: adc         bl,byte ptr [esi]
  1000B1E9: pop         ds
  1000B1EA: adc         byte ptr [eax+16h],bl
  1000B1ED: push        esp
  1000B1EE: pop         es
  1000B1EF: dec         edx
  1000B1F0: or          al,byte ptr [esi]
  1000B1F2: or          byte ptr [edx+34h],cl
  1000B1F5: pop         ss
  1000B1F6: push        es
  1000B1F7: adc         ecx,dword ptr [edi+eax]
  1000B1FA: push        es
  1000B1FB: pop         ds
  1000B1FC: adc         al,58h
  1000B1FE: push        esp
  1000B1FF: adc         dword ptr [esp+ebp],ecx
  1000B202: adc         edx,dword ptr [ecx]
  1000B204: or          al,12h
  1000B206: push        ds
  1000B207: pop         ds
  1000B208: adc         al,0FEh
  1000B20A: pop         ss
  1000B20B: sub         ecx,dword ptr [ecx]
  1000B20D: add         eax,dword ptr [esi]
  1000B20F: adc         bl,byte ptr [esi]
  1000B211: sub         dh,dl
  1000B213: add         byte ptr [eax],al
  1000B215: push        es
  1000B216: or          dword ptr [edi],edx
  1000B218: pop         eax
  1000B219: or          eax,32051109h
  1000B21E: test        al,2Ah
  1000B220: add         esi,dword ptr [eax]
  1000B222: add         al,0
  1000B224: dec         ebx
  1000B225: add         byte ptr [eax],al
  1000B227: add         byte ptr [edx+02110001h],cl
  1000B22D: sbb         bl,byte ptr [eax+4Ah]
  1000B230: or          al,byte ptr [edx]
  1000B232: dec         edx
  1000B233: adc         eax,dword ptr [esi+eax]
  1000B236: adc         dword ptr [ecx+ebx*2],eax
  1000B239: pop         ss
  1000B23A: arpl        word ptr ds:[0D360903h],cx
  1000B240: add         al,byte ptr [esi]
  1000B242: add         ecx,dword ptr [ecx]
  1000B244: pop         ecx
  1000B245: add         al,28h
  1000B247: fld         dword ptr [eax]
  1000B249: add         byte ptr [esi],al
  1000B24B: sub         ebp,dword ptr [ecx]
  1000B24D: push        es
  1000B24E: or          eax,dword ptr [ebx]
  1000B250: sbb         byte ptr [edx+11h],bl
  1000B253: add         al,58h
  1000B255: or          al,6
  1000B257: adc         eax,dword ptr ds:[05110708h]
  1000B25D: pop         es
  1000B25E: pop         ecx
  1000B25F: sub         byte ptr [ecx],ah
  1000B261: add         dword ptr [eax],eax
  1000B263: push        es
  1000B264: add         bl,byte ptr es:[edx]
  1000B267: pop         eax
  1000B268: add         bl,byte ptr [edx]
  1000B26A: pop         eax
  1000B26B: dec         edx
  1000B26C: pop         es
  1000B26D: or          byte ptr [ecx+17h],bl
  1000B270: arpl        word ptr [edi],bx
  1000B272: FE
  1000B273: pop         edx
  1000B274: pop         eax
  1000B275: push        esp
  1000B276: sub         cl,ah
  1000B278: or          esi,dword ptr [eax]
  1000B27A: add         eax,21B00h
  1000B27F: add         byte ptr [esi+03110001h],cl
  1000B285: sbb         bl,byte ptr [eax+4Ah]
  1000B288: or          al,byte ptr [esi]
  1000B28A: adc         ecx,dword ptr [eax]
  1000B28C: add         ecx,dword ptr [edx+13h]
  1000B28F: clts
  1000B291: adc         ebx,dword ptr [ebx]
  1000B293: adc         dword ptr [edi],ecx
  1000B295: adc         dword ptr [eax],ecx
  1000B297: adc         dword ptr [ebx],ebx
  1000B299: adc         dword ptr [eax],ecx
  1000B29B: pop         ecx
  1000B29C: sub         byte ptr [ecx],ah
  1000B29E: add         dword ptr [eax],eax
  1000B2A0: push        es
  1000B2A1: add         ebx,dword ptr es:[edx]
  1000B2A4: pop         eax
  1000B2A5: add         ebx,dword ptr [edx]
  1000B2A7: pop         eax
  1000B2A8: dec         edx
  1000B2A9: adc         dword ptr [eax],ecx
  1000B2AB: adc         dword ptr [edi],ecx
  1000B2AD: pop         ecx
  1000B2AE: pop         ss
  1000B2AF: arpl        word ptr [edi],bx
  1000B2B1: FE
  1000B2B2: pop         edx
  1000B2B3: pop         eax
  1000B2B4: push        esp
  1000B2B5: add         al,1Ah
  1000B2B7: pop         eax
  1000B2B8: dec         edx
  1000B2B9: adc         ecx,dword ptr [esi]
  1000B2BB: adc         dword ptr [esi],ecx
  1000B2BD: adc         eax,dword ptr [edi]
  1000B2BF: add         al,4Ah
  1000B2C1: adc         ecx,dword ptr ds:[1A130E11h]
  1000B2C7: adc         dword ptr ds:[1A110711h],ecx
  1000B2CD: adc         dword ptr [edi],eax
  1000B2CF: pop         ecx
  1000B2D0: sub         byte ptr [ecx],ah
  1000B2D2: add         dword ptr [eax],eax
  1000B2D4: push        es
  1000B2D5: add         al,1Ah
  1000B2D8: pop         eax
  1000B2D9: add         al,1Ah
  1000B2DB: pop         eax
  1000B2DC: dec         edx
  1000B2DD: adc         dword ptr [edi],eax
  1000B2DF: adc         dword ptr ds:[1F631759h],ecx
  1000B2E5: FE
  1000B2E6: pop         edx
  1000B2E7: pop         eax
  1000B2E8: push        esp
  1000B2E9: adc         ah,byte ptr [edx]
  1000B2EB: sbb         bl,byte ptr [eax+16h]
  1000B2EE: pop         ds
  1000B2EF: adc         dh,bh
  1000B2F1: sbb         byte ptr [edx],dl
  1000B2F3: and         bl,byte ptr [edx]
  1000B2F5: pop         eax
  1000B2F6: adc         ah,byte ptr [edx]
  1000B2F8: sbb         bl,byte ptr [eax+54h]
  1000B2FB: adc         ah,byte ptr [edx]
  1000B2FD: push        ds
  1000B2FE: pop         eax
  1000B2FF: adc         ah,byte ptr [edx]
  1000B301: sbb         bl,byte ptr [eax+54h]
  1000B304: adc         ah,byte ptr [edx]
  1000B306: pop         ds
  1000B307: or          al,58h
  1000B309: push        ss
  1000B30A: push        esp
  1000B30B: adc         ah,byte ptr [edx]
  1000B30D: pop         ds
  1000B30E: adc         byte ptr [eax+16h],bl
  1000B311: push        edx
  1000B312: adc         ah,byte ptr [edx]
  1000B314: pop         ds
  1000B315: adc         al,58h
  1000B317: push        ss
  1000B318: push        esp
  1000B319: push        ss
  1000B31A: or          eax,241F0216h
  1000B31F: pop         eax
  1000B320: dec         edx
  1000B321: das
  1000B322: push        edx
  1000B323: add         bl,byte ptr [edi]
  1000B325: sub         byte ptr [eax+13h],bl
  1000B328: sbb         dword ptr [ecx],ecx
  1000B32A: push        ds
  1000B32B: pop         edx
  1000B32C: adc         dword ptr [ecx],ebx
  1000B32E: dec         edx
  1000B32F: pop         eax
  1000B330: adc         eax,dword ptr [esi]
  1000B332: push        ss
  1000B333: or          al,16h
  1000B335: adc         dword ptr [esi],eax
  1000B337: dec         edx
  1000B338: das
  1000B339: das
  1000B33A: adc         dword ptr [esi],eax
  1000B33C: sbb         bl,byte ptr [eax+13h]
  1000B33F: sbb         byte ptr [eax],cl
  1000B341: push        ds
  1000B342: pop         edx
  1000B343: adc         dword ptr [eax],ebx
  1000B345: dec         edx
  1000B346: pop         eax
  1000B347: sbb         bl,byte ptr [eax+13h]
  1000B34A: pop         ss
  1000B34B: adc         dl,byte ptr [esi]
  1000B34D: push        ss
  1000B34E: pop         ss
  1000B34F: FE
  1000B350: sbb         byte ptr [edx],dl
  1000B352: and         dl,byte ptr [edx]
  1000B354: and         dword ptr [ecx],edx
  1000B356: pop         ss
  1000B357: adc         dword ptr [esi],edx
  1000B359: sub         al,bl
  1000B35B: add         byte ptr [eax],al
  1000B35D: push        es
  1000B35E: or          byte ptr es:[edi],dl
  1000B361: pop         eax
  1000B362: or          al,8
  1000B364: adc         dword ptr [esi],eax
  1000B366: dec         edx
  1000B367: xor         dl,bh
  1000B369: or          dword ptr [edi],edx
  1000B36B: pop         eax
  1000B36C: or          eax,241F0209h
  1000B371: pop         eax
  1000B372: dec         edx
  1000B373: xor         dh,byte ptr [edx+edx+58141F22h]
  1000B37A: dec         edx
  1000B37B: push        ss
  1000B37C: inc         byte ptr [ecx]
  1000B37E: sar         byte ptr [edx],cl
  1000B380: fild        word ptr [eax]
  1000B382: add         byte ptr [eax],al
  1000B384: add         ebx,dword ptr [edx]
  1000B386: pop         eax
  1000B387: dec         edx
  1000B388: or          al,byte ptr [esi]
  1000B38A: adc         eax,dword ptr ds:[0C134A03h]
  1000B390: push        es
  1000B391: adc         edx,dword ptr ds:[05110C11h]
  1000B397: adc         dword ptr ds:[28590511h],edx
  1000B39D: and         dword ptr [ecx],eax
  1000B39F: add         byte ptr [esi],al
  1000B3A1: add         ebx,dword ptr es:[edx]
  1000B3A4: pop         eax
  1000B3A5: add         ebx,dword ptr [edx]
  1000B3A7: pop         eax
  1000B3A8: dec         edx
  1000B3A9: adc         dword ptr ds:[17590C11h],eax
  1000B3AF: arpl        word ptr [edi],bx
  1000B3B1: FE
  1000B3B2: pop         edx
  1000B3B3: pop         eax
  1000B3B4: push        esp
  1000B3B5: adc         dl,byte ptr [edx+edx]
  1000B3B8: and         bl,byte ptr [edx]
  1000B3BA: pop         eax
  1000B3BB: push        esp
  1000B3BC: adc         dl,byte ptr [ebx]
  1000B3BE: adc         ah,byte ptr [edx]
  1000B3C0: push        ds
  1000B3C1: pop         eax
  1000B3C2: dec         edx
  1000B3C3: push        esp
  1000B3C4: add         ecx,dword ptr [edx+13h]
  1000B3C7: adc         dl,byte ptr [ecx]
  1000B3C9: adc         al,13h
  1000B3CB: adc         dword ptr [ecx],edx
  1000B3CD: adc         edx,dword ptr [ebx]
  1000B3CF: adc         byte ptr [ebx],al
  1000B3D1: adc         dword ptr [edx],edx
  1000B3D3: adc         dword ptr [eax],edx
  1000B3D5: adc         dword ptr [ecx],edx
  1000B3D7: adc         dword ptr [eax],esp
  1000B3D9: sub         ah,bl
  1000B3DB: add         byte ptr [eax],al
  1000B3DD: push        es
  1000B3DE: push        ss
  1000B3DF: adc         ebx,dword ptr [edi]
  1000B3E1: adc         bl,byte ptr [esi]
  1000B3E3: adc         ah,byte ptr [edx]
  1000B3E5: sbb         bl,byte ptr [eax+28h]
  1000B3E8: sub         eax,dword ptr [ecx]
  1000B3EA: add         byte ptr [esi],al
  1000B3EC: push        esp
  1000B3ED: add         al,12h
  1000B3EF: push        ds
  1000B3F0: dec         edx
  1000B3F1: pop         ds
  1000B3F2: adc         byte ptr [eax+49h],bl
  1000B3F5: pop         ss
  1000B3F6: pop         eax
  1000B3F7: adc         bl,byte ptr [edi]
  1000B3F9: sub         cl,dl
  1000B3FB: add         byte ptr [eax],al
  1000B3FD: push        es
  1000B3FE: push        ss
  1000B3FF: adc         eax,dword ptr [edx+edx]
  1000B402: sbb         eax,581E2212h
  1000B407: dec         edx
  1000B408: push        esp
  1000B409: adc         bl,byte ptr ds:[1A22124Ah]
  1000B40F: pop         eax
  1000B410: xor         eax,dword ptr [ebx]
  1000B412: push        ss
  1000B413: sub         eax,dword ptr [ecx]
  1000B415: pop         ss
  1000B416: shr         byte ptr [edx+ecx*2],cl
  1000B419: add         al,4Ah
  1000B41B: adc         ecx,dword ptr [ebx]
  1000B41D: adc         bl,byte ptr ds:[58101F4Ah]
  1000B423: dec         ecx
  1000B424: adc         ecx,dword ptr [edx]
  1000B426: adc         dword ptr [edx],ecx
  1000B428: add         al,1Ah
  1000B42A: pop         eax
  1000B42B: dec         edx
  1000B42C: adc         dword ptr [ebx],ecx
  1000B42E: pop         ecx
  1000B42F: pop         ss
  1000B430: arpl        word ptr [edi],bp
  1000B432: sbb         eax,5A180A11h
  1000B437: adc         dword ptr [ebx],ecx
  1000B439: pop         eax
  1000B43A: adc         dword ptr [ebx+edx*2],eax
  1000B43D: adc         bl,byte ptr ds:[284A1D12h]
  1000B443: sub         al,byte ptr [ecx]
  1000B445: add         byte ptr [esi],al
  1000B447: push        esp
  1000B448: adc         dword ptr [edi+edx],eax
  1000B44B: pop         eax
  1000B44C: adc         eax,dword ptr [ebx+ebp]
  1000B44F: mov         ecx,1017Fh
  1000B454: add         al,13h
  1000B456: sbb         al,12h
  1000B458: sbb         al,7Fh
  1000B45A: or          dword ptr [ecx],eax
  1000B45C: add         byte ptr [eax+ebp],al
  1000B45F: sub         eax,0DE060001h
  1000B464: push        cs
  1000B465: inc         byte ptr [esi]
  1000B467: int         3
  1000B468: add         byte ptr [eax],al
  1000B46A: push        es
  1000B46B: adc         ah,byte ptr [edx]
  1000B46D: sub         byte ptr [ebx],al
  1000B46F: add         dword ptr [eax],eax
  1000B471: push        es
  1000B472: fcom        qword ptr [edx]
  1000B474: and         bl,byte ptr [edi]
  1000B476: or          al,58h
  1000B478: dec         edx
  1000B479: or          edx,dword ptr [edx]
  1000B47B: and         bl,byte ptr [edi]
  1000B47D: or          al,58h
  1000B47F: dec         edx
  1000B480: sub         al,1Ch
  1000B482: adc         ah,byte ptr [edx]
  1000B484: pop         es
  1000B485: dec         edx
  1000B486: sub         bh,dl
  1000B488: add         byte ptr [eax],al
  1000B48A: push        es
  1000B48B: pop         es
  1000B48C: sbb         bl,byte ptr [eax+4Ah]
  1000B48F: adc         ecx,dword ptr [ecx]
  1000B491: pop         es
  1000B492: sub         byte ptr [edi],bl
  1000B494: add         dword ptr [eax],eax
  1000B496: push        es
  1000B497: adc         dword ptr [ecx],ecx
  1000B499: or          edx,dword ptr [ecx]
  1000B49B: or          dword ptr ds:[41002AE4h],ebp
  1000B4A1: sbb         al,0
  1000B4A3: add         byte ptr [eax+eax],al
  1000B4A6: add         byte ptr [eax],al
  1000B4A8: xchg        eax,ebp
  1000B4A9: add         byte ptr [eax],al
  1000B4AB: add         byte ptr [ecx+eax],cl
  1000B4AF: add         cl,ah
  1000B4B1: add         dword ptr [eax],eax
  1000B4B3: add         byte ptr [esi],cl
  1000B4B5: add         byte ptr [eax],al
  1000B4B7: add         byte ptr [edx],ah
  1000B4B9: add         byte ptr [eax],al
  1000B4BB: add         dword ptr [ebx],eax
  1000B4BD: xor         byte ptr [edi],al
  1000B4BF: add         byte ptr [edx],dh
  1000B4C1: add         dword ptr [eax],eax
  1000B4C3: add         byte ptr [ecx+12110001h],dl
  1000B4C9: adc         dword ptr [ebx],ecx
  1000B4CB: add         cl,byte ptr [edx+0Ah]
  1000B4CE: push        es
  1000B4CF: add         bl,byte ptr [edx]
  1000B4D1: pop         eax
  1000B4D2: dec         edx
  1000B4D3: cmp         edi,dword ptr [esi+06000000h]
  1000B4D9: add         cl,byte ptr [edx+2Eh]
  1000B4DC: or          byte ptr [edi],al
  1000B4DE: pop         ds
  1000B4DF: and         byte ptr [edx+7],dl
  1000B4E2: pop         ss
  1000B4E3: pop         eax
  1000B4E4: or          eax,dword ptr [esi]
  1000B4E6: dec         edx
  1000B4E7: adc         ecx,dword ptr [ecx+edx]
  1000B4EA: or          al,13h
  1000B4EC: pop         es
  1000B4ED: push        es
  1000B4EE: sbb         bl,byte ptr [eax+4Ah]
  1000B4F1: adc         ecx,dword ptr [edi]
  1000B4F3: push        es
  1000B4F4: pop         ds
  1000B4F5: adc         byte ptr [eax+4Ah],bl
  1000B4F8: adc         eax,dword ptr [esi]
  1000B4FA: adc         dword ptr [edi],eax
  1000B4FC: sbb         eax,711052Eh
  1000B501: sbb         al,33h
  1000B503: cmp         byte ptr [esi],al
  1000B505: or          al,2
  1000B507: sbb         bl,byte ptr [eax+4Ah]
  1000B50A: adc         ecx,dword ptr [ebx]
  1000B50C: push        es
  1000B50D: adc         dword ptr [ebx],ecx
  1000B50F: adc         byte ptr cs:[eax],cl
  1000B512: dec         edx
  1000B513: adc         dword ptr [ebx+esi],ecx
  1000B516: or          cl,byte ptr [eax]
  1000B518: pop         ds
  1000B519: adc         al,58h
  1000B51B: or          al,8
  1000B51D: adc         dword ptr [ebx],ecx
  1000B51F: xor         esi,eax
  1000B521: or          byte ptr [esi],al
  1000B523: pop         ecx
  1000B524: pop         ds
  1000B525: adc         al,5Bh
  1000B527: sbb         dh,byte ptr [eax]
  1000B529: pop         ecx
  1000B52A: push        cs
  1000B52B: add         al,17h
  1000B52D: xor         ecx,dword ptr [eax]
  1000B52F: adc         dword ptr [esi],eax
  1000B531: and         eax,13595D1Ah
  1000B536: push        es
  1000B537: or          byte ptr [edi],bl
  1000B539: adc         al,59h
  1000B53B: or          bl,byte ptr [edi]
  1000B53D: aas
  1000B53E: adc         ecx,dword ptr [esi]
  1000B540: add         al,11h
  1000B542: pop         es
  1000B543: pop         ds
  1000B544: adc         byte ptr [edx+58h],bl
  1000B547: adc         ecx,dword ptr [edx]
  1000B549: adc         dword ptr [edx],ecx
  1000B54B: dec         edx
  1000B54C: adc         cl,byte ptr [esi]
  1000B54E: sub         bl,ah
  1000B550: add         byte ptr [eax],al
  1000B552: push        es
  1000B553: pop         es
  1000B555: jg          1000B55A
  1000B557: add         dword ptr [eax],eax
  1000B559: add         al,11h
  1000B55B: push        cs
  1000B55C: adc         dword ptr [edi],ecx
  1000B55E: adc         dword ptr [esi],eax
  1000B560: adc         dword ptr [edx],ecx
  1000B562: sbb         bl,byte ptr [eax+4Ah]
  1000B565: sub         dl,ah
  1000B567: add         byte ptr [eax],al
  1000B569: push        es
  1000B56A: sub         byte ptr [edx],cl
  1000B56D: add         byte ptr [edx],cl
  1000B56F: pop         es
  1000B570: pop         eax
  1000B571: or          eax,dword ptr [esi]
  1000B573: pop         ds
  1000B574: adc         al,58h
  1000B576: or          al,byte ptr [esi]
  1000B578: add         bl,byte ptr [edx]
  1000B57A: pop         eax
  1000B57B: dec         edx
  1000B57C: inc         eax
  1000B57D: push        edi
  1000B57E: FF
  1000B57F: FF
  1000B580: jmp         fword ptr [ebx]
  1000B582: adc         edi,dword ptr [edi+2]
  1000B585: add         dword ptr [eax],eax
  1000B587: add         al,13h
  1000B589: adc         byte ptr [edx],dl
  1000B58B: adc         byte ptr [edi+9],bh
  1000B58E: add         dword ptr [eax],eax
  1000B590: add         al,28h
  1000B592: sub         eax,7060001h
  1000B597: push        ss
  1000B598: push        edx
  1000B599: adc         dl,byte ptr [ecx]
  1000B59B: adc         eax,dword ptr ds:[04131112h]
  1000B5A1: adc         dl,byte ptr [ecx]
  1000B5A3: inc         esi
  1000B5A4: sub         al,0Bh
  1000B5A6: adc         dword ptr [edi+edx],eax
  1000B5A9: pop         eax
  1000B5AA: adc         eax,dword ptr [ecx+edx]
  1000B5AD: add         al,46h
  1000B5AF: sub         eax,120411F5h
  1000B5B4: adc         dword ptr [ecx+13h],ebx
  1000B5B7: or          dword ptr [ebx],eax
  1000B5B9: adc         dword ptr [ecx],ecx
  1000B5BB: push        esp
  1000B5BC: add         ebx,dword ptr [edx]
  1000B5BE: pop         eax
  1000B5BF: adc         ecx,dword ptr [eax]
  1000B5C1: add         eax,11170811h
  1000B5C6: or          dword ptr [edi],edx
  1000B5C8: pop         eax
  1000B5C9: sub         byte ptr [esi],al
  1000B5CB: add         byte ptr [eax],al
  1000B5CD: push        es
  1000B5CE: adc         dword ptr es:[eax],ecx
  1000B5D1: dec         edx
  1000B5D2: or          eax,46051109h
  1000B5D7: push        edx
  1000B5D8: adc         dword ptr ds:[05135817h],eax
  1000B5DE: or          dword ptr [esi+13h],eax
  1000B5E1: or          eax,0D581709h
  1000B5E6: adc         dword ptr ds:[1A05E92Dh],ecx
  1000B5EC: pop         eax
  1000B5ED: sbb         bl,byte ptr [eax+5]
  1000B5F0: sbb         bl,byte ptr [eax+1Ah]
  1000B5F3: pop         eax
  1000B5F4: dec         edx
  1000B5F5: pop         ds
  1000B5F6: cld
  1000B5F7: pop         eax
  1000B5F8: push        esp
  1000B5F9: sub         cl,ah
  1000B5FB: int         3
  1000B5FC: or          esi,dword ptr [eax]
  1000B5FE: or          dword ptr [eax],eax
  1000B600: add         eax,dword ptr ds:[eax]
  1000B603: add         byte ptr [esi+16110001h],dl
  1000B609: or          al,0Eh
  1000B60B: add         al,2Dh
  1000B60D: or          byte ptr [edi+0Ch],bh
  1000B610: add         dword ptr [eax],eax
  1000B612: add         al,0Ch
  1000B614: sub         ebx,dword ptr [eax]
  1000B616: push        cs
  1000B617: add         al,17h
  1000B619: xor         ecx,dword ptr [eax]
  1000B61B: jg          1000B627
  1000B61D: add         dword ptr [eax],eax
  1000B61F: add         al,0Ch
  1000B621: sub         ecx,dword ptr [ebx]
  1000B623: push        cs
  1000B624: add         al,18h
  1000B626: xor         eax,dword ptr [esi]
  1000B628: jg          1000B635
  1000B62A: add         dword ptr [eax],eax
  1000B62C: add         al,0Ch
  1000B62E: adc         bl,byte ptr ds:[1D125416h]
  1000B634: sbb         bl,byte ptr [eax+16h]
  1000B637: push        esp
  1000B638: adc         bl,byte ptr ds:[5416581Eh]
  1000B63E: add         dl,byte ptr [edx]
  1000B640: sbb         eax,0C928h
  1000B645: push        es
  1000B646: adc         bl,byte ptr ds:[0E050408h]
  1000B64C: add         al,28h
  1000B64E: retf        0
  1000B651: push        es
  1000B652: adc         eax,dword ptr [esi]
  1000B654: add         bl,byte ptr [edx]
  1000B656: pop         eax
  1000B657: dec         edx
  1000B658: dec         edx
  1000B659: adc         eax,dword ptr ds:[54161C12h]
  1000B65F: adc         bl,byte ptr [edx+ebx]
  1000B662: pop         eax
  1000B663: push        ss
  1000B664: push        esp
  1000B665: adc         bl,byte ptr [esi+ebx]
  1000B668: pop         eax
  1000B669: push        ss
  1000B66A: push        esp
  1000B66B: adc         bl,byte ptr [edi+ebx]
  1000B66E: adc         byte ptr [eax+4],bl
  1000B671: push        esp
  1000B672: adc         bl,byte ptr [edi+ebx]
  1000B675: adc         al,58h
  1000B677: add         eax,0FE0EDE54h
  1000B67C: push        es
  1000B67D: rol         byte ptr [eax],1
  1000B67F: add         byte ptr [esi],al
  1000B681: adc         bl,byte ptr [eax+ebp]
  1000B684: add         eax,dword ptr [ecx]
  1000B686: add         byte ptr [esi],al
  1000B688: fadd        qword ptr [eax]
  1000B68A: adc         bl,byte ptr [ebx]
  1000B68C: push        ss
  1000B68D: push        esp
  1000B68E: adc         bl,byte ptr [ebx]
  1000B690: sbb         bl,byte ptr [eax+16h]
  1000B693: push        esp
  1000B694: adc         bl,byte ptr [ebx]
  1000B696: push        ds
  1000B697: pop         eax
  1000B698: push        ss
  1000B699: push        esp
  1000B69A: add         dl,byte ptr [edx]
  1000B69C: sbb         edx,dword ptr [edx]
  1000B69E: sbb         al,28h
  1000B6A0: retf
  1000B6A1: add         byte ptr [eax],al
  1000B6A3: push        es
  1000B6A4: adc         dword ptr ds:[47051313h],eax
  1000B6AA: sub         al,28h
  1000B6AC: adc         bl,byte ptr [ecx]
  1000B6AE: adc         al,byte ptr ds:[52475819h]
  1000B6B4: adc         bl,byte ptr [ecx]
  1000B6B6: pop         ss
  1000B6B7: pop         eax
  1000B6B8: adc         al,byte ptr ds:[52475818h]
  1000B6BE: adc         bl,byte ptr [ecx]
  1000B6C0: sbb         byte ptr [eax+12h],bl
  1000B6C3: add         eax,52475817h
  1000B6C8: adc         bl,byte ptr [ecx]
  1000B6CA: sbb         dword ptr [eax+12h],ebx
  1000B6CD: add         eax,19115247h
  1000B6D2: adc         edx,dword ptr [ebx]
  1000B6D4: add         edx,dword ptr [ecx]
  1000B6D6: adc         edx,dword ptr [ecx+edx+6]
  1000B6DA: adc         edx,dword ptr [edx]
  1000B6DC: add         eax,12282C47h
  1000B6E1: sbb         byte ptr [edx],dl
  1000B6E3: push        es
  1000B6E4: sbb         dword ptr [eax+47h],ebx
  1000B6E7: push        edx
  1000B6E8: adc         bl,byte ptr [eax]
  1000B6EA: pop         ss
  1000B6EB: pop         eax
  1000B6EC: adc         al,byte ptr [esi]
  1000B6EE: sbb         byte ptr [eax+47h],bl
  1000B6F1: push        edx
  1000B6F2: adc         bl,byte ptr [eax]
  1000B6F4: sbb         byte ptr [eax+12h],bl
  1000B6F7: push        es
  1000B6F8: pop         ss
  1000B6F9: pop         eax
  1000B6FA: inc         edi
  1000B6FB: push        edx
  1000B6FC: adc         bl,byte ptr [eax]
  1000B6FE: sbb         dword ptr [eax+12h],ebx
  1000B701: push        es
  1000B702: inc         edi
  1000B703: push        edx
  1000B704: adc         dword ptr [eax],ebx
  1000B706: adc         edx,dword ptr [edx]
  1000B708: add         ebx,dword ptr [edx]
  1000B70A: pop         eax
  1000B70B: adc         dword ptr [edx],edx
  1000B70D: push        esp
  1000B70E: adc         dword ptr ds:[135A0611h],eax
  1000B714: adc         dword ptr [ebx+eax],eax
  1000B717: push        ds
  1000B718: pop         eax
  1000B719: pop         ss
  1000B71A: adc         dword ptr [ecx],edx
  1000B71C: sub         byte ptr [esi],al
  1000B71E: add         byte ptr [eax],al
  1000B720: push        es
  1000B721: add         ebx,dword ptr es:[esi]
  1000B724: pop         eax
  1000B725: dec         edx
  1000B726: push        ss
  1000B727: adc         dword ptr [ecx],edx
  1000B729: FE
  1000B72A: sbb         byte ptr [edx],dl
  1000B72C: sbb         eax,1A1D124Ah
  1000B731: pop         eax
  1000B732: dec         edx
  1000B733: aas
  1000B735: adc         bl,byte ptr ds:[580C1F4Ah]
  1000B73B: or          edx,dword ptr [ecx]
  1000B73D: add         eax,4A591A07h
  1000B742: pop         es
  1000B743: dec         edx
  1000B744: pop         es
  1000B745: sbb         bl,byte ptr [eax+4Ah]
  1000B748: add         ebx,dword ptr [esi]
  1000B74A: pop         eax
  1000B74B: dec         edx
  1000B74C: pop         eax
  1000B74D: adc         dword ptr [esi],eax
  1000B74F: adc         bl,byte ptr [eax+ecx]
  1000B752: pop         es
  1000B753: pop         ds
  1000B754: or          al,59h
  1000B756: dec         edx
  1000B757: pop         ds
  1000B758: adc         byte ptr [edx+58h],bl
  1000B75B: pop         ds
  1000B75C: or          al,58h
  1000B75E: dec         edx
  1000B75F: sub         dword ptr [ebp+1],ebx
  1000B762: add         byte ptr [ecx],dl
  1000B764: pop         es
  1000B765: pop         ds
  1000B766: adc         al,58h
  1000B768: or          eax,dword ptr [edi]
  1000B76A: pop         ds
  1000B76B: or          al,59h
  1000B76D: adc         bl,byte ptr ds:[334A581Ah]
  1000B773: enter       1D12h,4Ah
  1000B777: or          dl,byte ptr [edx]
  1000B779: sbb         eax,1A1D124Ah
  1000B77E: pop         eax
  1000B77F: dec         edx
  1000B780: cmp         esp,dword ptr [eax+06000000h]
  1000B786: dec         edx
  1000B787: sbb         al,2Eh
  1000B789: adc         al,byte ptr [esi]
  1000B78B: pop         ds
  1000B78C: adc         al,58h
  1000B78E: or          al,byte ptr [esi]
  1000B790: adc         bl,byte ptr ds:[334A581Ah]
  1000B796: out         dx,al
  1000B797: cmp         byte ptr [ecx+06000000h],cl
  1000B79D: adc         eax,dword ptr [esi+eax]
  1000B7A0: adc         bl,byte ptr ds:[2E4A581Ah]
  1000B7A6: sbb         eax,dword ptr [esi]
  1000B7A8: dec         edx
  1000B7A9: adc         edx,dword ptr [edi]
  1000B7AB: adc         dword ptr [edx+ecx*2],eax
  1000B7AE: adc         dword ptr [edi],edx
  1000B7B0: xor         edx,dword ptr [eax]
  1000B7B2: adc         dword ptr [edi+ebx],eax
  1000B7B5: adc         al,58h
  1000B7B7: adc         eax,dword ptr [ecx+edx]
  1000B7BA: add         al,12h
  1000B7BC: sbb         eax,334A581Ah
  1000B7C1: jmp         6906BBD7
  1000B7C6: pop         ds
  1000B7C7: adc         al,5Bh
  1000B7C9: sbb         byte ptr [esi],ch
  1000B7CB: adc         edi,dword ptr [edi+4]
  1000B7CE: add         dword ptr [eax],eax
  1000B7D0: add         al,13h
  1000B7D2: sbb         dl,byte ptr [edx]
  1000B7D4: sbb         bh,byte ptr [edi+9]
  1000B7D7: add         dword ptr [eax],eax
  1000B7D9: add         al,28h
  1000B7DB: sub         eax,3060001h
  1000B7E0: push        ds
  1000B7E1: pop         eax
  1000B7E2: dec         edx
  1000B7E3: adc         edx,dword ptr [eax]
  1000B7E5: push        es
  1000B7E6: pop         ds
  1000B7E7: and         al,58h
  1000B7E9: dec         edx
  1000B7EA: adc         dword ptr [eax],edx
  1000B7EC: pop         eax
  1000B7ED: adc         ecx,dword ptr [edx]
  1000B7EF: push        es
  1000B7F0: pop         ds
  1000B7F1: adc         byte ptr [eax+4Ah],bl
  1000B7F4: adc         dword ptr [eax],edx
  1000B7F6: pop         eax
  1000B7F7: adc         ecx,dword ptr [ecx]
  1000B7F9: adc         dword ptr ds:[05110813h],eax
  1000B7FF: sub         al,24h
  1000B801: adc         dword ptr [edx],ecx
  1000B803: and         bh,bh
  1000B805: add         byte ptr [eax],al
  1000B807: add         byte ptr [ecx],dl
  1000B809: or          dword ptr [edi+59h],eax
  1000B80C: push        edx
  1000B80D: adc         dword ptr [esi],eax
  1000B80F: adc         dword ptr [ecx],ecx
  1000B811: pop         eax
  1000B812: adc         ecx,dword ptr [ecx]
  1000B814: adc         dword ptr [esi],eax
  1000B816: adc         dword ptr [edx],ecx
  1000B818: pop         eax
  1000B819: adc         ecx,dword ptr [edx]
  1000B81B: adc         dword ptr [eax],ecx
  1000B81D: pop         ss
  1000B81E: pop         ecx
  1000B81F: adc         ecx,dword ptr [eax]
  1000B821: adc         dword ptr [eax],ecx
  1000B823: sub         eax,581A04DCh
  1000B828: adc         ecx,dword ptr [edi]
  1000B82A: adc         dword ptr [edi],ecx
  1000B82C: sbb         bl,byte ptr [eax+11h]
  1000B82F: bndldx      bnd3,dword ptr [eax+4Ah]
  1000B833: pop         ds
  1000B834: cld
  1000B835: pop         eax
  1000B836: push        esp
  1000B837: adc         bl,byte ptr ds:[580C1F03h]
  1000B83D: or          byte ptr [esi+ecx],al
  1000B840: add         al,28h
  1000B842: int         0
  1000B844: add         byte ptr [esi],al
  1000B846: adc         bl,byte ptr [ebx]
  1000B848: sbb         bl,byte ptr [eax+4Ah]
  1000B84B: adc         bl,byte ptr [ebx]
  1000B84D: dec         edx
  1000B84E: pop         ecx
  1000B84F: pop         ss
  1000B850: arpl        word ptr [ebx],dx
  1000B852: pop         es
  1000B853: adc         dword ptr [edi],eax
  1000B855: adc         ecx,dword ptr [esi]
  1000B857: add         eax,12282C47h
  1000B85C: push        ss
  1000B85D: adc         cl,byte ptr [esi]
  1000B85F: sbb         dword ptr [eax+47h],ebx
  1000B862: push        edx
  1000B863: adc         dl,byte ptr [esi]
  1000B865: pop         ss
  1000B866: pop         eax
  1000B867: adc         cl,byte ptr [esi]
  1000B869: sbb         byte ptr [eax+47h],bl
  1000B86C: push        edx
  1000B86D: adc         dl,byte ptr [esi]
  1000B86F: sbb         byte ptr [eax+12h],bl
  1000B872: push        cs
  1000B873: pop         ss
  1000B874: pop         eax
  1000B875: inc         edi
  1000B876: push        edx
  1000B877: adc         dl,byte ptr [esi]
  1000B879: sbb         dword ptr [eax+12h],ebx
  1000B87C: push        cs
  1000B87D: inc         edi
  1000B87E: push        edx
  1000B87F: adc         dword ptr [esi],edx
  1000B881: adc         ecx,dword ptr [esi]
  1000B883: add         ebx,dword ptr [edi]
  1000B885: adc         al,58h
  1000B887: adc         dword ptr [esi],ecx
  1000B889: push        esp
  1000B88A: adc         dword ptr [edi],eax
  1000B88C: adc         edx,dword ptr ds:[58181F03h]
  1000B892: adc         ecx,dword ptr ds:[180D1104h]
  1000B898: adc         dword ptr ds:[00000628h],edx
  1000B89E: push        es
  1000B89F: push        ss
  1000B8A1: or          eax,34071116h
  1000B8A6: xor         eax,125A1809h
  1000B8AB: sbb         ecx,dword ptr [edx+58h]
  1000B8AE: dec         ecx
  1000B8AF: adc         ecx,dword ptr [eax+12142C47h]
  1000B8B6: adc         al,12h
  1000B8B8: or          al,17h
  1000B8BA: pop         eax
  1000B8BB: inc         edi
  1000B8BC: push        edx
  1000B8BD: adc         dl,byte ptr [edi+edx]
  1000B8C0: pop         eax
  1000B8C1: adc         cl,byte ptr [edi+eax*2]
  1000B8C4: push        edx
  1000B8C5: adc         dword ptr [ebx+edx],edx
  1000B8C8: or          al,9
  1000B8CA: sbb         byte ptr [edx+11h],bl
  1000B8CD: or          eax,0C11584Ah
  1000B8D2: push        ebx
  1000B8D3: or          dword ptr [edi],edx
  1000B8D5: pop         eax
  1000B8D6: or          eax,37071109h
  1000B8DB: retf
  1000B8DC: add         al,1Ah
  1000B8DE: pop         eax
  1000B8DF: adc         ecx,dword ptr [ebx]
  1000B8E1: adc         dword ptr [ebx],ecx
  1000B8E3: sbb         bl,byte ptr [eax+11h]
  1000B8E6: or          ebx,dword ptr [edx]
  1000B8E8: pop         eax
  1000B8E9: dec         edx
  1000B8EA: pop         ds
  1000B8EB: cld
  1000B8EC: pop         eax
  1000B8ED: push        esp
  1000B8EE: fimul       word ptr [esi]
  1000B8F0: inc         byte ptr [esi]
  1000B8F2: rol         byte ptr [eax],1
  1000B8F4: add         byte ptr [esi],al
  1000B8F6: adc         bl,byte ptr [ebx]
  1000B8F8: sub         byte ptr [ebx],al
  1000B8FA: add         dword ptr [eax],eax
  1000B8FC: push        es
  1000B8FD: fcom        qword ptr [edx]
  1000B8FF: sbb         ecx,dword ptr [edx+2Ch]
  1000B902: or          byte ptr [edx],dl
  1000B904: sbb         ecx,dword ptr [edx+28h]
  1000B907: pop         ds
  1000B908: add         dword ptr [eax],eax
  1000B90A: push        es
  1000B90B: fimul       word ptr [esi]
  1000B90D: inc         byte ptr [esi]
  1000B90F: iretd
  1000B910: add         byte ptr [eax],al
  1000B912: push        es
  1000B913: adc         bl,byte ptr [eax+ebp]
  1000B916: add         eax,dword ptr [ecx]
  1000B918: add         byte ptr [esi],al
  1000B91A: fcom        qword ptr [edx]
  1000B91C: sbb         al,4Ah
  1000B91E: sub         al,8
  1000B920: adc         bl,byte ptr [edx+ecx*2]
  1000B923: sub         byte ptr [edi],bl
  1000B925: add         dword ptr [eax],eax
  1000B927: push        es
  1000B928: fimul       word ptr [esi]
  1000B92A: inc         byte ptr [esi]
  1000B92C: rol         dword ptr [eax],cl
  1000B92E: add         byte ptr [esi],al
  1000B930: adc         bl,byte ptr ds:[00010328h]
  1000B936: push        es
  1000B937: fcom        qword ptr [edx]
  1000B939: sbb         eax,12082C4Ah
  1000B93E: sbb         eax,11F284Ah
  1000B943: add         byte ptr [esi],al
  1000B945: sub         al,byte ptr [eax]
  1000B947: add         byte ptr [ecx+64h],al
  1000B94A: add         byte ptr [eax],al
  1000B94C: add         al,0
  1000B94E: add         byte ptr [eax],al
  1000B950: arpl        word ptr [eax],ax
  1000B952: add         byte ptr [eax],al
  1000B954: adc         byte ptr [eax],al
  1000B956: add         byte ptr [eax],al
  1000B958: jae         1000B95A
  1000B95A: add         byte ptr [eax],al
  1000B95C: push        cs
  1000B95D: add         byte ptr [eax],al
  1000B95F: add         byte ptr [edx],ah
  1000B961: add         byte ptr [eax],al
  1000B963: add         dword ptr [eax+eax],eax
  1000B966: add         byte ptr [eax],al
  1000B968: xchg        eax,edx
  1000B969: add         byte ptr [eax],al
  1000B96B: add         byte ptr [esi+2],dl
  1000B96E: add         byte ptr [eax],al
  1000B970: call        1E00B977
  1000B975: add         byte ptr [eax],al
  1000B977: add         byte ptr [edx],ah
  1000B979: add         byte ptr [eax],al
  1000B97B: add         dword ptr [eax+eax],eax
  1000B97E: add         byte ptr [eax],al
  1000B980: add         byte ptr [eax],0
  1000B983: add         byte ptr [ebx+05000002h],al
  1000B989: add         eax,dword ptr [eax]
  1000B98B: add         byte ptr [esi],cl
  1000B98D: add         byte ptr [eax],al
  1000B98F: add         byte ptr [edx],ah
  1000B991: add         byte ptr [eax],al
  1000B993: add         dword ptr [eax+eax],eax
  1000B996: add         byte ptr [eax],al
  1000B998: add         byte ptr ss:[eax],al
  1000B99B: add         ah,ch
  1000B99D: add         al,byte ptr [eax]
  1000B99F: add         byte ptr [edx],ah
  1000B9A1: add         eax,dword ptr [eax]
  1000B9A3: add         byte ptr [esi],cl
  1000B9A5: add         byte ptr [eax],al
  1000B9A7: add         byte ptr [edx],ah
  1000B9A9: add         byte ptr [eax],al
  1000B9AB: add         dword ptr [ebx],eax
  1000B9AD: xor         byte ptr [edx],al
  1000B9AF: add         byte ptr [eax+eax],cl
  1000B9B2: add         byte ptr [eax],al
  1000B9B4: add         byte ptr [eax],al
  1000B9B6: add         byte ptr [eax],al
  1000B9B8: add         bl,byte ptr [edi]
  1000B9BA: or          al,5Ah
  1000B9BC: jg          1000B9EC
  1000B9BE: add         dword ptr [eax],eax
  1000B9C0: add         al,58h
  1000B9C2: dec         edx
  1000B9C3: sub         al,byte ptr [ebx]
  1000B9C5: xor         byte ptr [edx],al
  1000B9C7: add         byte ptr [edi],bl
  1000B9CA: add         byte ptr [eax],al
  1000B9CC: add         byte ptr [eax],al
  1000B9CE: add         byte ptr [eax],al
  1000B9D0: add         dl,byte ptr [edi]
  1000B9D2: pop         ecx
  1000B9D3: inc         ebp
  1000B9D4: or          byte ptr [eax],al
  1000B9D6: add         byte ptr [eax],al
  1000B9D8: add         al,byte ptr [eax]
  1000B9DA: add         byte ptr [eax],al
  1000B9DC: push        cs
  1000B9DD: add         byte ptr [eax],al
  1000B9DF: add         byte ptr [eax+eax],dl
  1000B9E2: add         byte ptr [eax],al
  1000B9E4: or          byte ptr [eax],al
  1000B9E6: add         byte ptr [eax],al
  1000B9E8: sbb         al,byte ptr [eax]
  1000B9EA: add         byte ptr [eax],al
  1000B9EC: and         byte ptr [eax],al
  1000B9EE: add         byte ptr [eax],al
  1000B9F0: add         byte ptr es:[eax],al
  1000B9F3: add         byte ptr [eax+eax],ch
  1000B9F6: add         byte ptr [eax],al
  1000B9F8: sub         esi,dword ptr [eax]
  1000B9FA: add         ebx,dword ptr [edi]
  1000B9FC: jo          1000BA50
  1000B9FE: sub         ebp,dword ptr [eax]
  1000BA00: add         ebx,dword ptr [edi]
  1000BA02: outs        dx,byte ptr [esi]
  1000BA03: push        edx
  1000BA04: sub         esp,dword ptr [edx]
  1000BA06: add         ebx,dword ptr [edi]
  1000BA08: arpl        word ptr [edx+2Bh],dx
  1000BA0B: sbb         al,3
  1000BA0D: pop         ds
  1000BA0E: je          1000BA62
  1000BA10: sub         edx,dword ptr [esi]
  1000BA12: add         ebx,dword ptr [edi]
  1000BA14: bound       edx,qword ptr [edx+2Bh]
  1000BA17: adc         byte ptr [ebx],al
  1000BA19: pop         ds
  1000BA1A: push        edx
  1000BA1C: sub         ecx,dword ptr [edx]
  1000BA1E: add         ebx,dword ptr [edi]
  1000BA20: ja          1000BA74
  1000BA22: sub         eax,dword ptr [ebx+eax]
  1000BA25: pop         ds
  1000BA26: imul        edx,dword ptr [edx+17h],5216032Ah
  1000BA2D: push        ss
  1000BA2E: sub         cl,ah
  1000BA30: push        ebx
  1000BA31: mov         bl,byte ptr [esp+8]
  1000BA35: test        bl,2
  1000BA38: push        esi
  1000BA39: mov         esi,ecx
  1000BA3B: je          1000BA61
  1000BA3D: push        edi
  1000BA3E: push        1000C24Ah
  1000BA43: lea         edi,[esi-4]
  1000BA46: push        dword ptr [edi]
  1000BA48: push        0Ch
  1000BA4A: push        esi
  1000BA4B: call        1000BE2C
  1000BA50: test        bl,1
  1000BA53: je          1000BA5C
  1000BA55: push        edi
  1000BA56: call        1000BDC8
  1000BA5B: pop         ecx
  1000BA5C: mov         eax,edi
  1000BA5E: pop         edi
  1000BA5F: jmp         1000BA74
  1000BA61: call        1000C24A
  1000BA66: test        bl,1
  1000BA69: je          1000BA72
  1000BA6B: push        esi
  1000BA6C: call        1000BDC8
  1000BA71: pop         ecx
  1000BA72: mov         eax,esi
  1000BA74: pop         esi
  1000BA75: pop         ebx
  1000BA76: ret         4
  1000BA79: int         3
  1000BA7A: jmp         dword ptr ds:[1000E088h]
  1000BA80: push        esi
  1000BA81: push        80h
  1000BA86: call        dword ptr ds:[1000E07Ch]
  1000BA8C: mov         esi,eax
  1000BA8E: push        esi
  1000BA8F: call        dword ptr ds:[1000E080h]
  1000BA95: test        esi,esi
  1000BA97: pop         ecx
  1000BA98: pop         ecx
  1000BA99: mov         dword ptr ds:[10025F14h],eax
  1000BA9E: mov         dword ptr ds:[10025F10h],eax
  1000BAA3: jne         1000BAAA
  1000BAA5: xor         eax,eax
  1000BAA7: inc         eax
  1000BAA8: pop         esi
  1000BAA9: ret
  1000BAAA: and         dword ptr [esi],0
  1000BAAD: call        1000BF52
  1000BAB2: push        1000BF76h
  1000BAB7: call        1000BF40
  1000BABC: mov         dword ptr [esp],1000BE8Fh
  1000BAC3: call        1000BF40
  1000BAC8: pop         ecx
  1000BAC9: xor         eax,eax
  1000BACB: pop         esi
  1000BACC: ret
  1000BACD: mov         eax,dword ptr [esp+8]
  1000BAD1: push        ebp
  1000BAD2: xor         ebp,ebp
  1000BAD4: cmp         eax,ebp
  1000BAD6: jne         1000BAE6
  1000BAD8: cmp         dword ptr ds:[100259CCh],ebp
  1000BADE: jle         1000BB1A
  1000BAE0: dec         dword ptr ds:[100259CCh]
  1000BAE6: cmp         eax,1
  1000BAE9: mov         ecx,dword ptr ds:[1000E060h]
  1000BAEF: mov         ecx,dword ptr [ecx]
  1000BAF1: push        ebx
  1000BAF2: push        esi
  1000BAF3: push        edi
  1000BAF4: mov         dword ptr ds:[10025F04h],ecx
  1000BAFA: jne         1000BBD4
  1000BB00: mov         eax,dword ptr fs:[00000018h]
  1000BB06: mov         esi,dword ptr [eax+4]
  1000BB09: mov         ebx,dword ptr ds:[1000E02Ch]
  1000BB0F: mov         dword ptr [esp+18h],ebp
  1000BB13: mov         edi,10025F0Ch
  1000BB18: jmp         1000BB30
  1000BB1A: xor         eax,eax
  1000BB1C: jmp         1000BC8C
  1000BB21: cmp         eax,esi
  1000BB23: je          1000BB3B
  1000BB25: push        3E8h
  1000BB2A: call        dword ptr ds:[1000E030h]
  1000BB30: push        ebp
  1000BB31: push        esi
  1000BB32: push        edi
  1000BB33: call        ebx
  1000BB35: cmp         eax,ebp
  1000BB37: jne         1000BB21
  1000BB39: jmp         1000BB43
  1000BB3B: mov         dword ptr [esp+18h],1
  1000BB43: mov         eax,dword ptr ds:[10025F08h]
  1000BB48: test        eax,eax
  1000BB4A: push        2
  1000BB4C: pop         esi
  1000BB4D: je          1000BB58
  1000BB4F: push        1Fh
  1000BB51: call        1000C108
  1000BB56: jmp         1000BB94
  1000BB58: push        1000E100h
  1000BB5D: push        1000E0F8h
  1000BB62: mov         dword ptr ds:[10025F08h],1
  1000BB6C: call        1000C102
  1000BB71: test        eax,eax
  1000BB73: pop         ecx
  1000BB74: pop         ecx
  1000BB75: je          1000BB7E
  1000BB77: xor         eax,eax
  1000BB79: jmp         1000BC89
  1000BB7E: push        1000E0F4h
  1000BB83: push        1000E0F0h
  1000BB88: call        1000C0FC
  1000BB8D: pop         ecx
  1000BB8E: mov         dword ptr ds:[10025F08h],esi
  1000BB94: cmp         dword ptr [esp+1Ch],ebp
  1000BB98: pop         ecx
  1000BB99: jne         1000BBA3
  1000BB9B: push        ebp
  1000BB9C: push        edi
  1000BB9D: call        dword ptr ds:[1000E034h]
  1000BBA3: cmp         dword ptr ds:[10025F18h],ebp
  1000BBA9: je          1000BBC9
  1000BBAB: push        10025F18h
  1000BBB0: call        1000C040
  1000BBB5: test        eax,eax
  1000BBB7: pop         ecx
  1000BBB8: je          1000BBC9
  1000BBBA: push        dword ptr [esp+1Ch]
  1000BBBE: push        esi
  1000BBBF: push        dword ptr [esp+1Ch]
  1000BBC3: call        dword ptr ds:[10025F18h]
  1000BBC9: inc         dword ptr ds:[100259CCh]
  1000BBCF: jmp         1000BC86
  1000BBD4: cmp         eax,ebp
  1000BBD6: jne         1000BC86
  1000BBDC: mov         esi,dword ptr ds:[1000E02Ch]
  1000BBE2: mov         edi,10025F0Ch
  1000BBE7: jmp         1000BBF4
  1000BBE9: push        3E8h
  1000BBEE: call        dword ptr ds:[1000E030h]
  1000BBF4: push        ebp
  1000BBF5: push        1
  1000BBF7: push        edi
  1000BBF8: call        esi
  1000BBFA: test        eax,eax
  1000BBFC: jne         1000BBE9
  1000BBFE: mov         eax,dword ptr ds:[10025F08h]
  1000BC03: cmp         eax,2
  1000BC06: je          1000BC12
  1000BC08: push        1Fh
  1000BC0A: call        1000C108
  1000BC0F: pop         ecx
  1000BC10: jmp         1000BC86
  1000BC12: push        dword ptr ds:[10025F14h]
  1000BC18: mov         ebx,dword ptr ds:[1000E070h]
  1000BC1E: call        ebx
  1000BC20: mov         ebp,eax
  1000BC22: test        ebp,ebp
  1000BC24: pop         ecx
  1000BC25: je          1000BC73
  1000BC27: push        dword ptr ds:[10025F10h]
  1000BC2D: call        ebx
  1000BC2F: pop         ecx
  1000BC30: mov         esi,eax
  1000BC32: jmp         1000BC54
  1000BC34: cmp         dword ptr [esi],0
  1000BC37: je          1000BC54
  1000BC39: mov         eax,dword ptr [esi]
  1000BC3B: mov         dword ptr [esp+18h],eax
  1000BC3F: call        dword ptr ds:[1000E074h]
  1000BC45: cmp         dword ptr [esp+18h],eax
  1000BC49: je          1000BC54
  1000BC4B: push        dword ptr [esp+18h]
  1000BC4F: call        ebx
  1000BC51: pop         ecx
  1000BC52: call        eax
  1000BC54: sub         esi,4
  1000BC57: cmp         esi,ebp
  1000BC59: jae         1000BC34
  1000BC5B: push        ebp
  1000BC5C: call        dword ptr ds:[1000E078h]
  1000BC62: pop         ecx
  1000BC63: call        dword ptr ds:[1000E074h]
  1000BC69: mov         dword ptr ds:[10025F10h],eax
  1000BC6E: mov         dword ptr ds:[10025F14h],eax
  1000BC73: push        0
  1000BC75: push        edi
  1000BC76: mov         dword ptr ds:[10025F08h],0
  1000BC80: call        dword ptr ds:[1000E034h]
  1000BC86: xor         eax,eax
  1000BC88: inc         eax
  1000BC89: pop         edi
  1000BC8A: pop         esi
  1000BC8B: pop         ebx
  1000BC8C: pop         ebp
  1000BC8D: ret         0Ch
  1000BC90: push        10h
  1000BC92: push        10022940h
  1000BC97: call        1000C134
  1000BC9C: mov         edi,ecx
  1000BC9E: mov         esi,edx
  1000BCA0: mov         ebx,dword ptr [ebp+8]
  1000BCA3: xor         eax,eax
  1000BCA5: inc         eax
  1000BCA6: mov         dword ptr [ebp-1Ch],eax
  1000BCA9: xor         ecx,ecx
  1000BCAB: mov         dword ptr [ebp-4],ecx
  1000BCAE: mov         dword ptr ds:[10024698h],esi
  1000BCB4: mov         dword ptr [ebp-4],eax
  1000BCB7: cmp         esi,ecx
  1000BCB9: jne         1000BCCB
  1000BCBB: cmp         dword ptr ds:[100259CCh],ecx
  1000BCC1: jne         1000BCCB
  1000BCC3: mov         dword ptr [ebp-1Ch],ecx
  1000BCC6: jmp         1000BD82
  1000BCCB: cmp         esi,eax
  1000BCCD: je          1000BCD4
  1000BCCF: cmp         esi,2
  1000BCD2: jne         1000BD02
  1000BCD4: mov         eax,dword ptr ds:[1000F3C8h]
  1000BCD9: cmp         eax,ecx
  1000BCDB: je          1000BCE5
  1000BCDD: push        edi
  1000BCDE: push        esi
  1000BCDF: push        ebx
  1000BCE0: call        eax
  1000BCE2: mov         dword ptr [ebp-1Ch],eax
  1000BCE5: cmp         dword ptr [ebp-1Ch],0
  1000BCE9: je          1000BD82
  1000BCEF: push        edi
  1000BCF0: push        esi
  1000BCF1: push        ebx
  1000BCF2: call        1000BACD
  1000BCF7: mov         dword ptr [ebp-1Ch],eax
  1000BCFA: test        eax,eax
  1000BCFC: je          1000BD82
  1000BD02: push        edi
  1000BD03: push        esi
  1000BD04: push        ebx
  1000BD05: call        1000C114
  1000BD0A: mov         dword ptr [ebp-1Ch],eax
  1000BD0D: cmp         esi,1
  1000BD10: jne         1000BD36
  1000BD12: test        eax,eax
  1000BD14: jne         1000BD36
  1000BD16: push        edi
  1000BD17: push        eax
  1000BD18: push        ebx
  1000BD19: call        1000C114
  1000BD1E: push        edi
  1000BD1F: push        0
  1000BD21: push        ebx
  1000BD22: call        1000BACD
  1000BD27: mov         eax,dword ptr ds:[1000F3C8h]
  1000BD2C: test        eax,eax
  1000BD2E: je          1000BD36
  1000BD30: push        edi
  1000BD31: push        0
  1000BD33: push        ebx
  1000BD34: call        eax
  1000BD36: test        esi,esi
  1000BD38: je          1000BD3F
  1000BD3A: cmp         esi,3
  1000BD3D: jne         1000BD82
  1000BD3F: push        edi
  1000BD40: push        esi
  1000BD41: push        ebx
  1000BD42: call        1000BACD
  1000BD47: test        eax,eax
  1000BD49: jne         1000BD4E
  1000BD4B: and         dword ptr [ebp-1Ch],eax
  1000BD4E: cmp         dword ptr [ebp-1Ch],0
  1000BD52: je          1000BD82
  1000BD54: mov         eax,dword ptr ds:[1000F3C8h]
  1000BD59: test        eax,eax
  1000BD5B: je          1000BD82
  1000BD5D: push        edi
  1000BD5E: push        esi
  1000BD5F: push        ebx
  1000BD60: call        eax
  1000BD62: mov         dword ptr [ebp-1Ch],eax
  1000BD65: jmp         1000BD82
  1000BD67: mov         eax,dword ptr [ebp-14h]
  1000BD6A: mov         ecx,dword ptr [eax]
  1000BD6C: mov         ecx,dword ptr [ecx]
  1000BD6E: mov         dword ptr [ebp-20h],ecx
  1000BD71: push        eax
  1000BD72: push        ecx
  1000BD73: call        1000C10E
  1000BD78: pop         ecx
  1000BD79: pop         ecx
  1000BD7A: ret
  1000BD7B: mov         esp,dword ptr [ebp-18h]
  1000BD7E: and         dword ptr [ebp-1Ch],0
  1000BD82: and         dword ptr [ebp-4],0
  1000BD86: mov         dword ptr [ebp-4],0FFFFFFFEh
  1000BD8D: call        1000BD9B
  1000BD92: mov         eax,dword ptr [ebp-1Ch]
  1000BD95: call        1000C179
  1000BD9A: ret
  1000BD9B: mov         dword ptr ds:[10024698h],0FFFFFFFFh
  1000BDA5: ret
  1000BDA6: cmp         dword ptr [esp+8],1
  1000BDAB: jne         1000BDB2
  1000BDAD: call        1000C1B0
  1000BDB2: push        dword ptr [esp+4]
  1000BDB6: mov         ecx,dword ptr [esp+10h]
  1000BDBA: mov         edx,dword ptr [esp+0Ch]
  1000BDBE: call        1000BC90
  1000BDC3: pop         ecx
  1000BDC4: ret         0Ch
  1000BDC7: int         3
  1000BDC8: jmp         dword ptr ds:[1000E084h]
  1000BDCE: push        14h
  1000BDD0: push        10022968h
  1000BDD5: call        1000C134
  1000BDDA: and         dword ptr [ebp-4],0
  1000BDDE: dec         dword ptr [ebp+10h]
  1000BDE1: js          1000BE1D
  1000BDE3: mov         ecx,dword ptr [ebp+8]
  1000BDE6: sub         ecx,dword ptr [ebp+0Ch]
  1000BDE9: mov         dword ptr [ebp+8],ecx
  1000BDEC: call        dword ptr [ebp+14h]
  1000BDEF: jmp         1000BDDE
  1000BDF1: mov         eax,dword ptr [ebp-14h]
  1000BDF4: mov         dword ptr [ebp-1Ch],eax
  1000BDF7: mov         eax,dword ptr [ebp-1Ch]
  1000BDFA: mov         eax,dword ptr [eax]
  1000BDFC: mov         dword ptr [ebp-20h],eax
  1000BDFF: mov         eax,dword ptr [ebp-20h]
  1000BE02: cmp         dword ptr [eax],0E06D7363h
  1000BE08: je          1000BE15
  1000BE0A: mov         dword ptr [ebp-24h],0
  1000BE11: mov         eax,dword ptr [ebp-24h]
  1000BE14: ret
  1000BE15: call        1000C244
  1000BE1A: mov         esp,dword ptr [ebp-18h]
  1000BE1D: mov         dword ptr [ebp-4],0FFFFFFFEh
  1000BE24: call        1000C179
  1000BE29: ret         10h
  1000BE2C: push        0Ch
  1000BE2E: push        10022988h
  1000BE33: call        1000C134
  1000BE38: and         dword ptr [ebp-1Ch],0
  1000BE3C: mov         esi,dword ptr [ebp+0Ch]
  1000BE3F: mov         eax,esi
  1000BE41: imul        eax,dword ptr [ebp+10h]
  1000BE45: add         dword ptr [ebp+8],eax
  1000BE48: and         dword ptr [ebp-4],0
  1000BE4C: dec         dword ptr [ebp+10h]
  1000BE4F: js          1000BE5C
  1000BE51: sub         dword ptr [ebp+8],esi
  1000BE54: mov         ecx,dword ptr [ebp+8]
  1000BE57: call        dword ptr [ebp+14h]
  1000BE5A: jmp         1000BE4C
  1000BE5C: mov         dword ptr [ebp-1Ch],1
  1000BE63: mov         dword ptr [ebp-4],0FFFFFFFEh
  1000BE6A: call        1000BE77
  1000BE6F: call        1000C179
  1000BE74: ret         10h
  1000BE77: cmp         dword ptr [ebp-1Ch],0
  1000BE7B: jne         1000BE8E
  1000BE7D: push        dword ptr [ebp+14h]
  1000BE80: push        dword ptr [ebp+10h]
  1000BE83: push        dword ptr [ebp+0Ch]
  1000BE86: push        dword ptr [ebp+8]
  1000BE89: call        1000BDCE
  1000BE8E: ret
  1000BE8F: push        100259D4h
  1000BE94: call        1000C250
  1000BE99: pop         ecx
  1000BE9A: ret
  1000BE9B: push        14h
  1000BE9D: push        100229A8h
  1000BEA2: call        1000C134
  1000BEA7: push        dword ptr ds:[10025F14h]
  1000BEAD: mov         esi,dword ptr ds:[1000E070h]
  1000BEB3: call        esi
  1000BEB5: pop         ecx
  1000BEB6: mov         dword ptr [ebp-1Ch],eax
  1000BEB9: cmp         eax,0FFFFFFFFh
  1000BEBC: jne         1000BECA
  1000BEBE: push        dword ptr [ebp+8]
  1000BEC1: call        dword ptr ds:[1000E04Ch]
  1000BEC7: pop         ecx
  1000BEC8: jmp         1000BF31
  1000BECA: push        8
  1000BECC: call        1000C262
  1000BED1: pop         ecx
  1000BED2: and         dword ptr [ebp-4],0
  1000BED6: push        dword ptr ds:[10025F14h]
  1000BEDC: call        esi
  1000BEDE: mov         dword ptr [ebp-1Ch],eax
  1000BEE1: push        dword ptr ds:[10025F10h]
  1000BEE7: call        esi
  1000BEE9: pop         ecx
  1000BEEA: pop         ecx
  1000BEEB: mov         dword ptr [ebp-20h],eax
  1000BEEE: lea         eax,[ebp-20h]
  1000BEF1: push        eax
  1000BEF2: lea         eax,[ebp-1Ch]
  1000BEF5: push        eax
  1000BEF6: push        dword ptr [ebp+8]
  1000BEF9: mov         esi,dword ptr ds:[1000E080h]
  1000BEFF: call        esi
  1000BF01: pop         ecx
  1000BF02: push        eax
  1000BF03: call        1000C25C
  1000BF08: mov         dword ptr [ebp-24h],eax
  1000BF0B: push        dword ptr [ebp-1Ch]
  1000BF0E: call        esi
  1000BF10: mov         dword ptr ds:[10025F14h],eax
  1000BF15: push        dword ptr [ebp-20h]
  1000BF18: call        esi
  1000BF1A: add         esp,14h
  1000BF1D: mov         dword ptr ds:[10025F10h],eax
  1000BF22: mov         dword ptr [ebp-4],0FFFFFFFEh
  1000BF29: call        1000BF37
  1000BF2E: mov         eax,dword ptr [ebp-24h]
  1000BF31: call        1000C179
  1000BF36: ret
  1000BF37: push        8
  1000BF39: call        1000C256
  1000BF3E: pop         ecx
  1000BF3F: ret
  1000BF40: push        dword ptr [esp+4]
  1000BF44: call        1000BE9B
  1000BF49: neg         eax
  1000BF4B: sbb         eax,eax
  1000BF4D: neg         eax
  1000BF4F: pop         ecx
  1000BF50: dec         eax
  1000BF51: ret
  1000BF52: push        esi
  1000BF53: push        edi
  1000BF54: mov         eax,100228D8h
  1000BF59: mov         edi,100228D8h
  1000BF5E: cmp         eax,edi
  1000BF60: mov         esi,eax
  1000BF62: jae         1000BF73
  1000BF64: mov         eax,dword ptr [esi]
  1000BF66: test        eax,eax
  1000BF68: je          1000BF6C
  1000BF6A: call        eax
  1000BF6C: add         esi,4
  1000BF6F: cmp         esi,edi
  1000BF71: jb          1000BF64
  1000BF73: pop         edi
  1000BF74: pop         esi
  1000BF75: ret
  1000BF76: push        esi
  1000BF77: push        edi
  1000BF78: mov         eax,100228E0h
  1000BF7D: mov         edi,100228E0h
  1000BF82: cmp         eax,edi
  1000BF84: mov         esi,eax
  1000BF86: jae         1000BF97
  1000BF88: mov         eax,dword ptr [esi]
  1000BF8A: test        eax,eax
  1000BF8C: je          1000BF90
  1000BF8E: call        eax
  1000BF90: add         esi,4
  1000BF93: cmp         esi,edi
  1000BF95: jb          1000BF88
  1000BF97: pop         edi
  1000BF98: pop         esi
  1000BF99: ret
  1000BF9A: jmp         dword ptr ds:[1000E080h]
  1000BFA0: jmp         dword ptr ds:[1000E078h]
  1000BFA6: jmp         dword ptr ds:[1000E074h]
  1000BFAC: jmp         dword ptr ds:[1000E070h]
  1000BFB2: int         3
  1000BFB3: int         3
  1000BFB4: int         3
  1000BFB5: int         3
  1000BFB6: int         3
  1000BFB7: int         3
  1000BFB8: int         3
  1000BFB9: int         3
  1000BFBA: int         3
  1000BFBB: int         3
  1000BFBC: int         3
  1000BFBD: int         3
  1000BFBE: int         3
  1000BFBF: int         3
  1000BFC0: mov         ecx,dword ptr [esp+4]
  1000BFC4: cmp         word ptr [ecx],5A4Dh
  1000BFC9: je          1000BFCE
  1000BFCB: xor         eax,eax
  1000BFCD: ret
  1000BFCE: mov         eax,dword ptr [ecx+3Ch]
  1000BFD1: add         eax,ecx
  1000BFD3: cmp         dword ptr [eax],4550h
  1000BFD9: jne         1000BFCB
  1000BFDB: xor         ecx,ecx
  1000BFDD: cmp         word ptr [eax+18h],10Bh
  1000BFE3: sete        cl
  1000BFE6: mov         eax,ecx
  1000BFE8: ret
  1000BFE9: int         3
  1000BFEA: int         3
  1000BFEB: int         3
  1000BFEC: int         3
  1000BFED: int         3
  1000BFEE: int         3
  1000BFEF: int         3
  1000BFF0: mov         eax,dword ptr [esp+4]
  1000BFF4: mov         ecx,dword ptr [eax+3Ch]
  1000BFF7: add         ecx,eax
  1000BFF9: movzx       eax,word ptr [ecx+14h]
  1000BFFD: push        ebx
  1000BFFE: push        esi
  1000BFFF: movzx       esi,word ptr [ecx+6]
  1000C003: xor         edx,edx
  1000C005: test        esi,esi
  1000C007: push        edi
  1000C008: lea         eax,[eax+ecx+18h]
  1000C00C: jbe         1000C02C
  1000C00E: mov         edi,dword ptr [esp+14h]
  1000C012: mov         ecx,dword ptr [eax+0Ch]
  1000C015: cmp         edi,ecx
  1000C017: jb          1000C022
  1000C019: mov         ebx,dword ptr [eax+8]
  1000C01C: add         ebx,ecx
  1000C01E: cmp         edi,ebx
  1000C020: jb          1000C02E
  1000C022: add         edx,1
  1000C025: add         eax,28h
  1000C028: cmp         edx,esi
  1000C02A: jb          1000C012
  1000C02C: xor         eax,eax
  1000C02E: pop         edi
  1000C02F: pop         esi
  1000C030: pop         ebx
  1000C031: ret
  1000C032: int         3
  1000C033: int         3
  1000C034: int         3
  1000C035: int         3
  1000C036: int         3
  1000C037: int         3
  1000C038: int         3
  1000C039: int         3
  1000C03A: int         3
  1000C03B: int         3
  1000C03C: int         3
  1000C03D: int         3
  1000C03E: int         3
  1000C03F: int         3
  1000C040: push        ebp
  1000C041: mov         ebp,esp
  1000C043: push        0FFFFFFFEh
  1000C045: push        100229C8h
  1000C04A: push        1000C18Dh
  1000C04F: mov         eax,dword ptr fs:[00000000h]
  1000C055: push        eax
  1000C056: sub         esp,8
  1000C059: push        ebx
  1000C05A: push        esi
  1000C05B: push        edi
  1000C05C: mov         eax,dword ptr ds:[100246A0h]
  1000C061: xor         dword ptr [ebp-8],eax
  1000C064: xor         eax,ebp
  1000C066: push        eax
  1000C067: lea         eax,[ebp-10h]
  1000C06A: mov         dword ptr fs:[00000000h],eax
  1000C070: mov         dword ptr [ebp-18h],esp
  1000C073: mov         dword ptr [ebp-4],0
  1000C07A: push        10000000h
  1000C07F: call        1000BFC0
  1000C084: add         esp,4
  1000C087: test        eax,eax
  1000C089: je          1000C0E0
  1000C08B: mov         eax,dword ptr [ebp+8]
  1000C08E: sub         eax,10000000h
  1000C093: push        eax
  1000C094: push        10000000h
  1000C099: call        1000BFF0
  1000C09E: add         esp,8
  1000C0A1: test        eax,eax
  1000C0A3: je          1000C0E0
  1000C0A5: mov         eax,dword ptr [eax+24h]
  1000C0A8: shr         eax,1Fh
  1000C0AB: not         eax
  1000C0AD: and         eax,1
  1000C0B0: mov         dword ptr [ebp-4],0FFFFFFFEh
  1000C0B7: mov         ecx,dword ptr [ebp-10h]
  1000C0BA: mov         dword ptr fs:[00000000h],ecx
  1000C0C1: pop         ecx
  1000C0C2: pop         edi
  1000C0C3: pop         esi
  1000C0C4: pop         ebx
  1000C0C5: mov         esp,ebp
  1000C0C7: pop         ebp
  1000C0C8: ret
  1000C0C9: mov         eax,dword ptr [ebp-14h]
  1000C0CC: mov         ecx,dword ptr [eax]
  1000C0CE: mov         eax,dword ptr [ecx]
  1000C0D0: xor         edx,edx
  1000C0D2: cmp         eax,0C0000005h
  1000C0D7: sete        dl
  1000C0DA: mov         eax,edx
  1000C0DC: ret
  1000C0DD: mov         esp,dword ptr [ebp-18h]
  1000C0E0: mov         dword ptr [ebp-4],0FFFFFFFEh
  1000C0E7: xor         eax,eax
  1000C0E9: mov         ecx,dword ptr [ebp-10h]
  1000C0EC: mov         dword ptr fs:[00000000h],ecx
  1000C0F3: pop         ecx
  1000C0F4: pop         edi
  1000C0F5: pop         esi
  1000C0F6: pop         ebx
  1000C0F7: mov         esp,ebp
  1000C0F9: pop         ebp
  1000C0FA: ret
  1000C0FB: int         3
  1000C0FC: jmp         dword ptr ds:[1000E06Ch]
  1000C102: jmp         dword ptr ds:[1000E068h]
  1000C108: jmp         dword ptr ds:[1000E064h]
  1000C10E: jmp         dword ptr ds:[1000E05Ch]
  1000C114: cmp         dword ptr [esp+8],1
  1000C119: jne         1000C12E
  1000C11B: cmp         dword ptr ds:[1000F3C8h],0
  1000C122: jne         1000C12E
  1000C124: push        dword ptr [esp+4]
  1000C128: call        dword ptr ds:[1000E028h]
  1000C12E: xor         eax,eax
  1000C130: inc         eax
  1000C131: ret         0Ch
  1000C134: push        1000C18Dh
  1000C139: push        dword ptr fs:[00000000h]
  1000C140: mov         eax,dword ptr [esp+10h]
  1000C144: mov         dword ptr [esp+10h],ebp
  1000C148: lea         ebp,[esp+10h]
  1000C14C: sub         esp,eax
  1000C14E: push        ebx
  1000C14F: push        esi
  1000C150: push        edi
  1000C151: mov         eax,dword ptr ds:[100246A0h]
  1000C156: xor         dword ptr [ebp-4],eax
  1000C159: xor         eax,ebp
  1000C15B: push        eax
  1000C15C: mov         dword ptr [ebp-18h],esp
  1000C15F: push        dword ptr [ebp-8]
  1000C162: mov         eax,dword ptr [ebp-4]
  1000C165: mov         dword ptr [ebp-4],0FFFFFFFEh
  1000C16C: mov         dword ptr [ebp-8],eax
  1000C16F: lea         eax,[ebp-10h]
  1000C172: mov         dword ptr fs:[00000000h],eax
  1000C178: ret
  1000C179: mov         ecx,dword ptr [ebp-10h]
  1000C17C: mov         dword ptr fs:[00000000h],ecx
  1000C183: pop         ecx
  1000C184: pop         edi
  1000C185: pop         edi
  1000C186: pop         esi
  1000C187: pop         ebx
  1000C188: mov         esp,ebp
  1000C18A: pop         ebp
  1000C18B: push        ecx
  1000C18C: ret
  1000C18D: push        dword ptr [esp+10h]
  1000C191: push        dword ptr [esp+10h]
  1000C195: push        dword ptr [esp+10h]
  1000C199: push        dword ptr [esp+10h]
  1000C19D: push        1000C268h
  1000C1A2: push        100246A0h
  1000C1A7: call        1000C278
  1000C1AC: add         esp,18h
  1000C1AF: ret
  1000C1B0: push        ebp
  1000C1B1: mov         ebp,esp
  1000C1B3: sub         esp,10h
  1000C1B6: mov         eax,dword ptr ds:[100246A0h]
  1000C1BB: and         dword ptr [ebp-8],0
  1000C1BF: and         dword ptr [ebp-4],0
  1000C1C3: push        ebx
  1000C1C4: push        edi
  1000C1C5: mov         edi,0BB40E64Eh
  1000C1CA: cmp         eax,edi
  1000C1CC: mov         ebx,0FFFF0000h
  1000C1D1: je          1000C1E0
  1000C1D3: test        ebx,eax
  1000C1D5: je          1000C1E0
  1000C1D7: not         eax
  1000C1D9: mov         dword ptr ds:[100246A4h],eax
  1000C1DE: jmp         1000C240
  1000C1E0: push        esi
  1000C1E1: lea         eax,[ebp-8]
  1000C1E4: push        eax
  1000C1E5: call        dword ptr ds:[1000E014h]
  1000C1EB: mov         esi,dword ptr [ebp-4]
  1000C1EE: xor         esi,dword ptr [ebp-8]
  1000C1F1: call        dword ptr ds:[1000E018h]
  1000C1F7: xor         esi,eax
  1000C1F9: call        dword ptr ds:[1000E01Ch]
  1000C1FF: xor         esi,eax
  1000C201: call        dword ptr ds:[1000E020h]
  1000C207: xor         esi,eax
  1000C209: lea         eax,[ebp-10h]
  1000C20C: push        eax
  1000C20D: call        dword ptr ds:[1000E024h]
  1000C213: mov         eax,dword ptr [ebp-0Ch]
  1000C216: xor         eax,dword ptr [ebp-10h]
  1000C219: xor         esi,eax
  1000C21B: cmp         esi,edi
  1000C21D: jne         1000C226
  1000C21F: mov         esi,0BB40E64Fh
  1000C224: jmp         1000C231
  1000C226: test        ebx,esi
  1000C228: jne         1000C231
  1000C22A: mov         eax,esi
  1000C22C: shl         eax,10h
  1000C22F: or          esi,eax
  1000C231: mov         dword ptr ds:[100246A0h],esi
  1000C237: not         esi
  1000C239: mov         dword ptr ds:[100246A4h],esi
  1000C23F: pop         esi
  1000C240: pop         edi
  1000C241: pop         ebx
  1000C242: leave
  1000C243: ret
  1000C244: jmp         dword ptr ds:[1000E058h]
  1000C24A: jmp         dword ptr ds:[1000E048h]
  1000C250: jmp         dword ptr ds:[1000E03Ch]
  1000C256: jmp         dword ptr ds:[1000E040h]
  1000C25C: jmp         dword ptr ds:[1000E044h]
  1000C262: jmp         dword ptr ds:[1000E08Ch]
  1000C268: cmp         ecx,dword ptr ds:[100246A0h]
  1000C26E: jne         1000C272
  1000C270: rep ret
  1000C272: jmp         1000C27E
  1000C277: int         3
  1000C278: jmp         dword ptr ds:[1000E050h]
  1000C27E: push        ebp
  1000C27F: mov         ebp,esp
  1000C281: sub         esp,328h
  1000C287: mov         dword ptr ds:[10025AE8h],eax
  1000C28C: mov         dword ptr ds:[10025AE4h],ecx
  1000C292: mov         dword ptr ds:[10025AE0h],edx
  1000C298: mov         dword ptr ds:[10025ADCh],ebx
  1000C29E: mov         dword ptr ds:[10025AD8h],esi
  1000C2A4: mov         dword ptr ds:[10025AD4h],edi
  1000C2AA: mov         word ptr ds:[10025B00h],ss
  1000C2B1: mov         word ptr ds:[10025AF4h],cs
  1000C2B8: mov         word ptr ds:[10025AD0h],ds
  1000C2BF: mov         word ptr ds:[10025ACCh],es
  1000C2C6: mov         word ptr ds:[10025AC8h],fs
  1000C2CD: mov         word ptr ds:[10025AC4h],gs
  1000C2D4: pushfd
  1000C2D5: pop         dword ptr ds:[10025AF8h]
  1000C2DB: mov         eax,dword ptr [ebp]
  1000C2DE: mov         dword ptr ds:[10025AECh],eax
  1000C2E3: mov         eax,dword ptr [ebp+4]
  1000C2E6: mov         dword ptr ds:[10025AF0h],eax
  1000C2EB: lea         eax,[ebp+8]
  1000C2EE: mov         dword ptr ds:[10025AFCh],eax
  1000C2F3: mov         eax,dword ptr [ebp+FFFFFCE0h]
  1000C2F9: mov         dword ptr ds:[10025A38h],10001h
  1000C303: mov         eax,dword ptr ds:[10025AF0h]
  1000C308: mov         dword ptr ds:[100259ECh],eax
  1000C30D: mov         dword ptr ds:[100259E0h],0C0000409h
  1000C317: mov         dword ptr ds:[100259E4h],1
  1000C321: mov         eax,dword ptr ds:[100246A0h]
  1000C326: mov         dword ptr [ebp+FFFFFCD8h],eax
  1000C32C: mov         eax,dword ptr ds:[100246A4h]
  1000C331: mov         dword ptr [ebp+FFFFFCDCh],eax
  1000C337: call        dword ptr ds:[1000E000h]
  1000C33D: mov         dword ptr ds:[10025A30h],eax
  1000C342: push        1
  1000C344: call        1000C382
  1000C349: pop         ecx
  1000C34A: push        0
  1000C34C: call        dword ptr ds:[1000E004h]
  1000C352: push        1000F3CCh
  1000C357: call        dword ptr ds:[1000E008h]
  1000C35D: cmp         dword ptr ds:[10025A30h],0
  1000C364: jne         1000C36E
  1000C366: push        1
  1000C368: call        1000C382
  1000C36D: pop         ecx
  1000C36E: push        0C0000409h
  1000C373: call        dword ptr ds:[1000E00Ch]
  1000C379: push        eax
  1000C37A: call        dword ptr ds:[1000E010h]
  1000C380: leave
  1000C381: ret
  1000C382: jmp         dword ptr ds:[1000E054h]
  1000C388: add         esi,dword ptr [eax]
  1000C38A: add         al,byte ptr [eax]
  1000C38C: dec         ecx
  1000C38D: add         byte ptr [eax],al
  1000C38F: add         byte ptr [eax],dl
  1000C391: add         byte ptr [eax],al
  1000C393: adc         esi,edi
  1000C395: adc         edi,dword ptr [esi+5Dh]
  1000C398: add         dword ptr [eax],eax
  1000C39A: add         al,15h
  1000C39C: xor         eax,dword ptr [ebx]
  1000C39E: push        ss
  1000C39F: sub         eax,dword ptr [ecx]
  1000C3A1: pop         ss
  1000C3A2: shr         byte ptr ds:[FE2A1702h],cl
  1000C3A8: adc         edi,dword ptr [esi+57h]
  1000C3AB: add         dword ptr [eax],eax
  1000C3AD: add         al,15h
  1000C3AF: xor         eax,dword ptr [ebx]
  1000C3B1: push        ss
  1000C3B2: sub         eax,dword ptr [ecx]
  1000C3B4: pop         ss
  1000C3B5: shr         byte ptr [edx+eax],cl
  1000C3B8: pop         ss
  1000C3B9: sub         bh,dh
  1000C3BB: adc         edi,dword ptr [esi+5Dh]
  1000C3BE: add         dword ptr [eax],eax
  1000C3C0: add         al,17h
  1000C3C2: inc         byte ptr [ecx]
  1000C3C4: shr         byte ptr ds:[7E13FE11h],cl
  1000C3CA: pop         ebp
  1000C3CB: add         dword ptr [eax],eax
  1000C3CD: add         al,16h
  1000C3CF: inc         byte ptr [ecx]
  1000C3D1: shr         byte ptr ds:[2B0A1704h],cl
  1000C3D7: add         dl,byte ptr [esi]
  1000C3D9: or          al,byte ptr [esi]
  1000C3DB: shr         byte ptr [edx],cl
  1000C3DD: mov         eax,dword ptr fs:[00000018h]
  1000C3E3: mov         eax,dword ptr [eax+4]
  1000C3E6: ret
  1000C3E7: int         3
  1000C3E8: add         esi,dword ptr [eax]
  1000C3EA: add         dword ptr [eax],eax
  1000C3EC: adc         dword ptr [eax],eax
  1000C3EE: add         byte ptr [eax],al
  1000C3F0: add         byte ptr [eax],al
  1000C3F2: add         byte ptr [eax],al
  1000C3F4: and         bh,bh
  1000C3F6: FF
  1000C3F7: FF
  1000C3F8: jg          1000C386
  1000C3FA: and         eax,28010000h
  1000C3FF: push        ecx
  1000C400: add         byte ptr [eax],al
  1000C402: or          dl,byte ptr [esi]
  1000C404: sub         bh,bh
  1000C406: and         eax,100246B0h
  1000C40B: int         3
  1000C40C: add         esi,dword ptr [eax]
  1000C40E: add         al,byte ptr [eax]
  1000C410: inc         esi
  1000C411: add         byte ptr [eax],al
  1000C413: add         byte ptr [ecx+7E110001h],bl
  1000C419: inc         edi
  1000C41A: add         dword ptr [eax],eax
  1000C41C: add         al,18h
  1000C41E: xor         esi,dword ptr [edi+edi*2]
  1000C421: dec         ecx
  1000C422: add         dword ptr [eax],eax
  1000C424: add         al,0Ah
  1000C426: jg          1000C471
  1000C428: add         dword ptr [eax],eax
  1000C42A: add         al,7Fh
  1000C42C: das
  1000C42D: add         dword ptr [eax],eax
  1000C42F: add         al,34h
  1000C431: sbb         al,byte ptr [esi]
  1000C433: dec         edx
  1000C434: sub         eax,581A060Eh
  1000C439: or          al,byte ptr [esi]
  1000C43B: jg          1000C46C
  1000C43D: add         dword ptr [eax],eax
  1000C43F: add         al,37h
  1000C441: lock sub    ecx,dword ptr [eax]
  1000C444: adc         eax,14780h
  1000C449: add         al,17h
  1000C44B: sub         dl,byte ptr [esi]
  1000C44D: add         byte ptr [edi+1],0
  1000C451: add         al,16h
  1000C453: sub         bh,byte ptr [esi+47h]
  1000C456: add         dword ptr [eax],eax
  1000C458: add         al,15h
  1000C45A: inc         byte ptr [ecx]
  1000C45C: shr         byte ptr [edx],cl
  1000C45E: int         3
  1000C45F: int         3
  1000C460: add         esi,dword ptr [eax]
  1000C462: add         al,byte ptr [eax]
  1000C464: jb          1000C466
  1000C466: add         byte ptr [eax],al
  1000C468: call        0146:7E110001
  1000C46F: add         byte ptr [eax+ebx],al
  1000C472: xor         esp,dword ptr [eax+7Fh]
  1000C475: pop         ecx
  1000C476: add         dword ptr [eax],eax
  1000C478: add         al,0Bh
  1000C47A: jg          1000C4D5
  1000C47C: add         dword ptr [eax],eax
  1000C47E: add         al,7Fh
  1000C480: pop         ebx
  1000C481: add         dword ptr [eax],eax
  1000C483: add         al,34h
  1000C485: sbb         al,byte ptr [edi]
  1000C487: dec         edx
  1000C488: sub         eax,581A070Eh
  1000C48D: or          eax,dword ptr [edi]
  1000C48F: jg          1000C4EC
  1000C491: add         dword ptr [eax],eax
  1000C493: add         al,37h
  1000C495: lock sub    ecx,dword ptr [eax]
  1000C498: adc         eax,14680h
  1000C49D: add         al,17h
  1000C49F: sub         bh,byte ptr [edi+58h]
  1000C4A2: add         dword ptr [eax],eax
  1000C4A4: add         al,0Ah
  1000C4A6: jg          1000C500
  1000C4A8: add         dword ptr [eax],eax
  1000C4AA: add         al,7Fh
  1000C4AC: push        esi
  1000C4AD: add         dword ptr [eax],eax
  1000C4AF: add         al,34h
  1000C4B1: sbb         al,byte ptr [esi]
  1000C4B3: dec         edx
  1000C4B4: sub         eax,581A060Eh
  1000C4B9: or          al,byte ptr [esi]
  1000C4BB: jg          1000C513
  1000C4BD: add         dword ptr [eax],eax
  1000C4BF: add         al,37h
  1000C4C1: lock sub    ecx,dword ptr [eax]
  1000C4C4: adc         eax,14680h
  1000C4C9: add         al,17h
  1000C4CB: sub         dl,byte ptr [esi]
  1000C4CD: add         byte ptr [esi+1],0
  1000C4D1: add         al,16h
  1000C4D3: sub         bh,byte ptr [esi+46h]
  1000C4D6: add         dword ptr [eax],eax
  1000C4D8: add         al,15h
  1000C4DA: inc         byte ptr [ecx]
  1000C4DC: shr         byte ptr [edx],cl
  1000C4DE: int         3
  1000C4DF: int         3
  1000C4E0: add         esi,dword ptr [eax]
  1000C4E2: add         dword ptr [eax],eax
  1000C4E4: add         byte ptr cs:[eax],al
  1000C4E7: add         byte ptr [eax],dl
  1000C4E9: add         byte ptr [eax],al
  1000C4EB: adc         dword ptr [eax],ebp
  1000C4ED: out         0,al
  1000C4EF: add         byte ptr [esi],al
  1000C4F1: sub         al,7
  1000C4F3: jle         1000C537
  1000C4F5: add         dword ptr [eax],eax
  1000C4F7: add         al,2Ch
  1000C4F9: pop         ss
  1000C4FA: sub         bh,ah
  1000C4FC: add         byte ptr [eax],al
  1000C4FE: push        es
  1000C4FF: sub         al,14h
  1000C501: jle         1000C547
  1000C503: add         dword ptr [eax],eax
  1000C505: add         al,2Dh
  1000C507: or          eax,5A7E13FEh
  1000C50C: add         dword ptr [eax],eax
  1000C50E: add         al,2Dh
  1000C510: add         al,17h
  1000C512: or          ch,byte ptr [ebx]
  1000C514: add         dl,byte ptr [esi]
  1000C516: or          al,byte ptr [esi]
  1000C518: shr         byte ptr [edx],cl
  1000C51A: int         3
  1000C51B: int         3
  1000C51C: add         esi,dword ptr [eax]
  1000C51E: add         al,byte ptr [eax]
  1000C520: or          al,0
  1000C522: add         byte ptr [eax],al
  1000C524: add         byte ptr [eax],al
  1000C526: add         byte ptr [eax],al
  1000C528: jle         1000C574
  1000C52A: add         dword ptr [eax],eax
  1000C52C: add         al,16h
  1000C52E: sub         byte ptr [eax],bh
  1000C530: add         dword ptr [eax],eax
  1000C532: push        es
  1000C533: sub         al,byte ptr [ebx]
  1000C535: xor         byte ptr [eax],al
  1000C537: add         byte ptr [esi],al
  1000C539: add         byte ptr [eax],al
  1000C53B: add         byte ptr [eax],al
  1000C53D: add         byte ptr [eax],al
  1000C53F: add         byte ptr [eax],ch
  1000C541: adc         al,byte ptr [ecx]
  1000C543: add         byte ptr [esi],al
  1000C545: sub         cl,ah
  1000C547: int         3
  1000C548: add         esi,dword ptr [eax]
  1000C54A: add         dword ptr [eax],eax
  1000C54C: sub         eax,0
  1000C551: add         byte ptr [eax],al
  1000C553: add         byte ptr [eax],ch
  1000C555: sgdt        fword ptr [eax]
  1000C558: push        es
  1000C559: push        ss
  1000C55A: add         byte ptr [edx+1],0
  1000C55E: add         al,7Eh
  1000C560: dec         eax
  1000C561: add         dword ptr [eax],eax
  1000C563: add         al,2Ch
  1000C565: adc         ebp,dword ptr [eax]
  1000C567: cmp         dword ptr [ecx],eax
  1000C569: add         byte ptr [esi],al
  1000C56B: push        ss
  1000C56C: FE
  1000C56D: adc         eax,dword ptr [eax+0400015Ah]
  1000C573: push        ss
  1000C574: or          byte ptr [eax+1],0
  1000C578: add         al,16h
  1000C57A: add         byte ptr [ecx+eax],4
  1000C57F: push        ss
  1000C580: sub         bh,bh
  1000C582: and         eax,100246B4h
  1000C587: int         3
  1000C588: add         esi,dword ptr [eax]
  1000C58A: add         al,byte ptr [eax]
  1000C58C: sub         byte ptr [eax],al
  1000C58E: add         byte ptr [eax],al
  1000C590: add         byte ptr [eax],al
  1000C592: add         byte ptr [eax],al
  1000C594: jle         1000C5D9
  1000C596: add         dword ptr [eax],eax
  1000C598: add         al,2Ch
  1000C59A: and         byte ptr [eax],ch
  1000C59C: push        ebx
  1000C59D: add         byte ptr [eax],al
  1000C59F: or          ch,byte ptr [eax]
  1000C5A1: push        edx
  1000C5A2: add         byte ptr [eax],al
  1000C5A4: or          ch,byte ptr [ecx+ecx]
  1000C5A7: push        ss
  1000C5A8: sub         cl,bh
  1000C5AA: add         byte ptr [eax],al
  1000C5AC: push        es
  1000C5AD: sub         ecx,dword ptr es:[ebx]
  1000C5B0: jle         1000C5FD
  1000C5B2: add         dword ptr [eax],eax
  1000C5B4: add         al,16h
  1000C5B6: sub         byte ptr [eax],bh
  1000C5B8: add         dword ptr [eax],eax
  1000C5BA: push        es
  1000C5BB: sub         al,byte ptr [ebx]
  1000C5BD: xor         byte ptr [edx],al
  1000C5BF: add         byte ptr [edi],ch
  1000C5C1: add         byte ptr [eax],al
  1000C5C3: add         byte ptr [eax],al
  1000C5C5: add         byte ptr [eax],al
  1000C5C7: add         byte ptr [esi+3Ah],bh
  1000C5CA: add         dword ptr [eax],eax
  1000C5CC: add         al,2Ch
  1000C5CE: daa
  1000C5CF: jg          1000C601
  1000C5D1: add         dword ptr [eax],eax
  1000C5D3: add         al,17h
  1000C5D5: sub         byte ptr [ecx],bl
  1000C5D8: add         byte ptr [edx],cl
  1000C5DA: sub         eax,1457F1Ah
  1000C5DF: add         byte ptr [eax+ebp],al
  1000C5E2: push        edi
  1000C5E3: add         byte ptr [eax],al
  1000C5E5: or          dl,byte ptr [esi]
  1000C5E7: inc         byte ptr [ecx]
  1000C5E9: sub         byte ptr [edx],dl
  1000C5EB: add         dword ptr [eax],eax
  1000C5ED: push        es
  1000C5EE: shr         byte ptr [eax+0000FA28h],cl
  1000C5F5: push        es
  1000C5F6: sub         cl,ah
  1000C5F8: or          esi,dword ptr [eax]
  1000C5FA: add         al,0
  1000C5FC: xor         eax,dword ptr [eax]
  1000C5FE: add         byte ptr [eax],al
  1000C600: sahf
  1000C601: add         dword ptr [eax],eax
  1000C603: adc         dword ptr [edi+45h],edi
  1000C606: add         dword ptr [eax],eax
  1000C608: add         al,28h
  1000C60A: push        edi
  1000C60B: add         byte ptr [eax],al
  1000C60D: or          dl,byte ptr [esi]
  1000C60F: inc         byte ptr [ecx]
  1000C611: ror         byte ptr [ebx],cl
  1000C613: sub         al,bh
  1000C615: add         byte ptr [eax],al
  1000C617: push        es
  1000C618: pop         es
  1000C619: sub         al,5
  1000C61B: sub         dl,bh
  1000C61D: add         byte ptr [eax],al
  1000C61F: push        es
  1000C620: ficom       word ptr [edx+ecx]
  1000C623: add         eax,dword ptr [esi]
  1000C625: sub         byte ptr [esi],dh
  1000C627: add         dword ptr [eax],eax
  1000C629: push        es
  1000C62A: fimul       word ptr [edx]
  1000C62C: or          al,3
  1000C62E: adc         al,28h
  1000C630: add         dword ptr ss:[eax],eax
  1000C633: push        es
  1000C634: fiadd       word ptr [eax]
  1000C636: sub         al,byte ptr [eax]
  1000C638: inc         ecx
  1000C639: xor         al,0
  1000C63B: add         byte ptr [eax],al
  1000C63D: add         byte ptr [eax],al
  1000C63F: add         byte ptr [eax],al
  1000C641: add         byte ptr [eax],al
  1000C643: add         byte ptr [esi],bl
  1000C645: add         byte ptr [eax],al
  1000C647: add         byte ptr [esi],bl
  1000C649: add         byte ptr [eax],al
  1000C64B: add         byte ptr [edx],cl
  1000C64D: add         byte ptr [eax],al
  1000C64F: add         byte ptr [ecx],al
  1000C652: add         byte ptr [ecx],al
  1000C654: add         byte ptr [eax],al
  1000C656: add         byte ptr [eax],al
  1000C658: add         byte ptr [eax],al
  1000C65A: add         byte ptr [eax],al
  1000C65C: push        ds
  1000C65D: add         byte ptr [eax],al
  1000C65F: add         byte ptr [eax],ch
  1000C661: add         byte ptr [eax],al
  1000C663: add         byte ptr [edx],cl
  1000C665: add         byte ptr [eax],al
  1000C667: add         byte ptr ds:[03010000h],bl
  1000C66D: xor         byte ptr [edx],al
  1000C66F: add         byte ptr [edi],dl
  1000C671: add         byte ptr [eax],al
  1000C673: add         byte ptr [edi+14110000h],bl
  1000C679: sub         byte ptr [eax],dh
  1000C67B: add         byte ptr [eax],al
  1000C67D: or          ch,byte ptr [eax]
  1000C67F: xor         eax,dword ptr [eax]
  1000C681: add         byte ptr [edx],cl
  1000C683: or          al,byte ptr [edx]
  1000C685: adc         al,byte ptr [eax]
  1000C687: sub         byte ptr [ebx],ch
  1000C689: add         byte ptr [eax],al
  1000C68B: or          dl,byte ptr [edx+eax+2Ah]
  1000C68F: int         3
  1000C690: add         esi,dword ptr [eax]
  1000C692: add         al,byte ptr [eax]
  1000C694: sbb         al,byte ptr [eax]
  1000C696: add         byte ptr [eax],al
  1000C698: mov         byte ptr ds:[12110000h],al
  1000C69D: add         byte ptr [edx],al
  1000C69F: dec         edx
  1000C6A0: sub         byte ptr [edx],ch
  1000C6A2: add         byte ptr [eax],al
  1000C6A4: or          al,byte ptr [esi]
  1000C6A6: sub         byte ptr [edx],dh
  1000C6A8: add         byte ptr [eax],al
  1000C6AA: or          cl,byte ptr [ebx]
  1000C6AC: adc         al,byte ptr [ecx]
  1000C6AE: add         ebp,dword ptr [eax]
  1000C6B0: cmp         al,byte ptr [eax]
  1000C6B2: add         byte ptr [edx],cl
  1000C6B4: add         ch,byte ptr [edx]
  1000C6B6: int         3
  1000C6B7: int         3
  1000C6B8: add         esi,dword ptr [eax]
  1000C6BA: add         al,byte ptr [eax]
  1000C6BC: sub         byte ptr [eax],al
  1000C6BE: add         byte ptr [eax],al
  1000C6C0: add         byte ptr [eax],al
  1000C6C2: add         byte ptr [eax],al
  1000C6C4: add         dh,byte ptr [edx-3Bh]
  1000C6C7: add         dword ptr [eax],eax
  1000C6C9: jo          1000C6F3
  1000C6CB: add         al,byte ptr [ecx]
  1000C6CD: add         byte ptr [esi],al
  1000C6CF: pop         ss
  1000C6D1: cmp         byte ptr ds:[7F040001h],32h
  1000C6D8: add         dword ptr [eax],eax
  1000C6DA: add         al,7Fh
  1000C6DC: aas
  1000C6DD: add         dword ptr [eax],eax
  1000C6DF: add         al,28h
  1000C6E1: sbb         eax,dword ptr [ecx]
  1000C6E3: add         byte ptr [esi],al
  1000C6E5: sbb         byte ptr [eax+0400013Dh],al
  1000C6EB: sub         al,byte ptr [ebx]
  1000C6ED: xor         byte ptr [edx],al
  1000C6EF: add         byte ptr [edx],dl
  1000C6F1: add         byte ptr [eax],al
  1000C6F3: add         byte ptr [eax],al
  1000C6F5: add         byte ptr [eax],al
  1000C6F7: add         byte ptr [edx],al
  1000C6F9: jb          1000C73A
  1000C6FB: add         al,byte ptr [eax]
  1000C6FD: jo          1000C727
  1000C6FF: add         al,byte ptr [ecx]
  1000C701: add         byte ptr [esi],al
  1000C703: sub         cl,ch
  1000C706: add         byte ptr [eax],al
  1000C708: push        es
  1000C709: sub         cl,ah
  1000C70B: int         3
  1000C70C: add         esi,dword ptr [eax]
  1000C70E: add         al,byte ptr [eax]
  1000C710: pop         dword ptr [eax]
  1000C712: add         byte ptr [eax],al
  1000C714: add         byte ptr [eax],al
  1000C716: add         byte ptr [eax],al
  1000C718: add         dh,byte ptr [edx-16h]
  1000C71B: add         al,byte ptr [eax]
  1000C71D: jo          1000C747
  1000C71F: add         al,byte ptr [ecx]
  1000C721: add         byte ptr [esi],al
  1000C723: sub         byte ptr es:[ecx],dh
  1000C726: add         dword ptr [eax],eax
  1000C728: push        es
  1000C729: pop         ss
  1000C72A: add         byte ptr [ecx+eax],4
  1000C72F: sub         ah,ah
  1000C731: add         byte ptr [eax],al
  1000C733: push        es
  1000C734: sub         eax,28211F07h
  1000C739: xor         byte ptr [ecx],al
  1000C73B: add         byte ptr [esi],al
  1000C73D: FE
  1000C73E: adc         edi,dword ptr [esi+5Ah]
  1000C741: add         dword ptr [eax],eax
  1000C743: add         al,17h
  1000C745: xor         ecx,dword ptr [ecx]
  1000C747: pop         ds
  1000C748: and         dword ptr [eax],ebp
  1000C74A: xor         byte ptr [ecx],al
  1000C74C: add         byte ptr [esi],al
  1000C74E: sub         edx,dword ptr [esi-2]
  1000C751: adc         edi,dword ptr [esi+5Ah]
  1000C754: add         dword ptr [eax],eax
  1000C756: add         al,2Dh
  1000C758: dec         ebp
  1000C759: pop         ss
  1000C75A: cmp         byte ptr [eax],1
  1000C75D: add         byte ptr [edi+edx],al
  1000C760: FE
  1000C761: adc         eax,dword ptr [eax+0400015Ah]
  1000C767: jg          1000C7C2
  1000C769: add         dword ptr [eax],eax
  1000C76B: add         al,7Fh
  1000C76D: pop         ebx
  1000C76E: add         dword ptr [eax],eax
  1000C770: add         al,28h
  1000C772: sbb         byte ptr [ecx],al
  1000C774: add         byte ptr [esi],al
  1000C776: sub         al,0Bh
  1000C778: add         ch,byte ptr [eax]
  1000C77A: rol         byte ptr [eax],0
  1000C77D: push        es
  1000C77E: sub         byte ptr [ecx+eax],dh
  1000C781: add         byte ptr [esi],al
  1000C783: jg          1000C7DD
  1000C785: add         dword ptr [eax],eax
  1000C787: add         al,7Fh
  1000C789: push        esi
  1000C78A: add         dword ptr [eax],eax
  1000C78C: add         al,28h
  1000C78E: sbb         dword ptr [ecx],eax
  1000C790: add         byte ptr [esi],al
  1000C792: sbb         dh,bh
  1000C794: adc         eax,dword ptr [eax+0400015Ah]
  1000C79A: pop         ss
  1000C79B: or          byte ptr [eax+1],0
  1000C79F: add         al,18h
  1000C7A1: cmp         byte ptr [eax],1
  1000C7A4: add         byte ptr [edx+ebp],al
  1000C7A7: int         3
  1000C7A8: add         esi,dword ptr [eax]
  1000C7AA: add         al,byte ptr [eax]
  1000C7AC: xor         al,0
  1000C7AE: add         byte ptr [eax],al
  1000C7B0: add         byte ptr [eax],al
  1000C7B2: add         byte ptr [eax],al
  1000C7B4: add         dh,byte ptr [edx+64h]
  1000C7B7: add         eax,dword ptr [eax]
  1000C7B9: jo          1000C7E3
  1000C7BB: add         al,byte ptr [ecx]
  1000C7BD: add         byte ptr [esi],al
  1000C7BF: pop         ss
  1000C7C1: add         byte ptr [eax+1],0
  1000C7C5: add         al,28h
  1000C7C7: adc         byte ptr [ecx],al
  1000C7C9: add         byte ptr [esi],al
  1000C7CB: jg          1000C817
  1000C7CE: add         dword ptr [eax],eax
  1000C7D0: add         al,7Fh
  1000C7D2: das
  1000C7D3: add         dword ptr [eax],eax
  1000C7D5: add         al,28h
  1000C7D7: sbb         eax,dword ptr [ecx]
  1000C7D9: add         byte ptr [esi],al
  1000C7DB: sbb         byte ptr [eax+04000140h],al
  1000C7E1: pop         ss
  1000C7E2: add         byte ptr [edx+1],0
  1000C7E6: add         al,2Ah
  1000C7E8: add         esi,dword ptr [eax]
  1000C7EA: add         al,byte ptr [eax]
  1000C7EC: add         byte ptr cs:[eax],al
  1000C7EF: add         byte ptr [eax],al
  1000C7F1: add         byte ptr [eax],al
  1000C7F3: add         byte ptr [edx],al
  1000C7F5: jb          1000C7D7
  1000C7F7: add         eax,dword ptr [eax]
  1000C7F9: jo          1000C823
  1000C7FB: add         al,byte ptr [ecx]
  1000C7FD: add         byte ptr [esi],al
  1000C7FF: pop         ss
  1000C801: xor         byte ptr [ebx],1
  1000C804: add         byte ptr [eax+ebp],al
  1000C807: adc         dword ptr [ecx],eax
  1000C809: add         byte ptr [esi],al
  1000C80B: jg          1000C845
  1000C80E: add         dword ptr [eax],eax
  1000C810: add         al,7Fh
  1000C812: cmp         al,1
  1000C814: add         byte ptr [eax+ebp],al
  1000C817: sbb         eax,dword ptr [ecx]
  1000C819: add         byte ptr [esi],al
  1000C81B: sbb         byte ptr [eax+04000133h],al
  1000C821: sub         cl,ah
  1000C823: int         3
  1000C824: add         esi,dword ptr [eax]
  1000C826: add         al,byte ptr [eax]
  1000C828: push        ds
  1000C829: add         byte ptr [eax],al
  1000C82B: add         byte ptr [eax],al
  1000C82D: add         byte ptr [eax],al
  1000C82F: add         byte ptr [edx],al
  1000C831: jb          1000C893
  1000C833: add         al,0
  1000C835: jo          1000C85F
  1000C837: add         al,byte ptr [ecx]
  1000C839: add         byte ptr [esi],al
  1000C83B: adc         al,0FEh
  1000C83E: push        es
  1000C83F: sti
  1000C840: add         byte ptr [eax],al
  1000C842: push        es
  1000C843: jae         1000C899
  1000C845: add         byte ptr [eax],al
  1000C847: or          ch,byte ptr [eax]
  1000C849: aaa
  1000C84A: add         dword ptr [eax],eax
  1000C84C: push        es
  1000C84D: sub         cl,ah
  1000C84F: int         3
  1000C850: or          esi,dword ptr [eax]
  1000C852: add         al,0
  1000C854: rol         dword ptr [eax],cl
  1000C856: add         byte ptr [eax],al
  1000C858: lahf
  1000C859: add         dword ptr [eax],eax
  1000C85B: adc         dword ptr [eax],ebp
  1000C85D: push        ebx
  1000C85E: add         byte ptr [eax],al
  1000C860: or          ch,byte ptr [eax]
  1000C862: push        edx
  1000C863: add         byte ptr [eax],al
  1000C865: or          al,byte ptr [eax+04000135h]
  1000C86B: jle         1000C8A2
  1000C86D: add         dword ptr [eax],eax
  1000C86F: add         al,2Ch
  1000C871: push        es
  1000C872: pop         ss
  1000C873: add         byte ptr [ebx+1],0
  1000C877: add         al,28h
  1000C879: xor         eax,28060001h
  1000C87E: das
  1000C87F: add         dword ptr [eax],eax
  1000C881: push        es
  1000C882: or          eax,0A160C16h
  1000C887: sub         byte ptr [ebp],dl
  1000C88A: add         byte ptr [edx],cl
  1000C88C: push        es
  1000C88D: sub         eax,1634DE45h
  1000C892: sub         byte ptr [edi],cl
  1000C895: add         byte ptr [edx],cl
  1000C897: adc         eax,dword ptr [esi]
  1000C899: or          dword ptr [eax],ebp
  1000C89B: cmp         byte ptr [eax],al
  1000C89D: add         byte ptr [edx],cl
  1000C89F: adc         eax,dword ptr ds:[00015C7Fh]
  1000C8A5: add         al,11h
  1000C8A7: add         eax,5A280611h
  1000C8AC: add         byte ptr [eax],al
  1000C8AE: or          ch,byte ptr [eax]
  1000C8B0: push        eax
  1000C8B1: add         byte ptr [eax],al
  1000C8B3: or          cl,byte ptr [ebx]
  1000C8B5: pop         es
  1000C8B6: sub         eax,2B0A1704h
  1000C8BB: or          byte ptr [edi],al
  1000C8BD: or          dword ptr [ebx],esi
  1000C8BF: add         al,17h
  1000C8C1: or          al,17h
  1000C8C3: or          bl,ah
  1000C8C5: push        es
  1000C8C6: sub         eax,3E8200Ah
  1000C8CB: add         byte ptr [eax],al
  1000C8CD: sub         byte ptr [edx],dh
  1000C8CF: add         dword ptr [eax],eax
  1000C8D1: push        es
  1000C8D2: sub         edi,dword ptr [eax+0001357Eh]
  1000C8D8: add         al,2Dh
  1000C8DA: or          eax,0E828h
  1000C8DF: push        es
  1000C8E0: sub         al,6
  1000C8E2: add         ch,byte ptr [eax]
  1000C8E4: xacquire add byte ptr [eax],al
  1000C8E7: push        es
  1000C8E8: ficomp      word ptr [ecx]
  1000C8EA: or          byte ptr ds:[4F281615h],ch
  1000C8F0: add         byte ptr [eax],al
  1000C8F2: or          dl,byte ptr [ebx]
  1000C8F4: add         al,7Fh
  1000C8F6: pop         esp
  1000C8F7: add         dword ptr [eax],eax
  1000C8F9: add         al,11h
  1000C8FB: add         al,28h
  1000C8FD: pop         eax
  1000C8FE: add         byte ptr [eax],al
  1000C900: or          ah,byte ptr [esi]
  1000C902: fadd        qword ptr [edx]
  1000C904: sub         cl,dh
  1000C906: add         byte ptr [eax],al
  1000C908: push        es
  1000C909: jle         1000C940
  1000C90B: add         dword ptr [eax],eax
  1000C90D: add         al,2Ch
  1000C90F: or          al,2
  1000C911: sub         bl,dh
  1000C913: add         byte ptr [eax],al
  1000C915: push        es
  1000C916: add         ch,byte ptr [eax]
  1000C918: hlt
  1000C919: add         byte ptr [eax],al
  1000C91B: push        es
  1000C91C: add         ch,byte ptr [eax]
  1000C91E: cmc
  1000C91F: add         byte ptr [eax],al
  1000C921: push        es
  1000C922: pop         ss
  1000C923: cmp         byte ptr [edx],1
  1000C926: add         byte ptr [edx+eax],al
  1000C929: sub         dh,dh
  1000C92B: add         byte ptr [eax],al
  1000C92D: push        es
  1000C92E: sub         al,byte ptr [eax]
  1000C930: inc         ecx
  1000C931: xor         al,0
  1000C933: add         byte ptr [edx],al
  1000C935: add         byte ptr [eax],al
  1000C937: add         byte ptr [ebx],dh
  1000C939: add         byte ptr [eax],al
  1000C93B: add         byte ptr [edx],al
  1000C93D: add         byte ptr [eax],al
  1000C93F: add         byte ptr ds:[34000000h],dh
  1000C945: add         byte ptr [eax],al
  1000C947: add         byte ptr [ecx],dh
  1000C949: add         byte ptr [eax],al
  1000C94B: add         dword ptr [edx],eax
  1000C94D: add         byte ptr [eax],al
  1000C94F: add         byte ptr [eax],dh
  1000C951: add         byte ptr [eax],al
  1000C953: add         byte ptr [esi],bl
  1000C956: add         byte ptr [eax],al
  1000C958: mov         es,word ptr [eax]
  1000C95A: add         byte ptr [eax],al
  1000C95C: sbb         dword ptr [eax],eax
  1000C95E: add         byte ptr [eax],al
  1000C960: xor         dword ptr [eax],eax
  1000C962: add         byte ptr [ecx],al
  1000C964: or          esi,dword ptr [eax]
  1000C966: add         al,0
  1000C968: arpl        word ptr [eax],ax
  1000C96A: add         byte ptr [eax],al
  1000C96C: mov         al,byte ptr ds:[16110001h]
  1000C971: or          ch,byte ptr [eax]
  1000C973: push        ebp
  1000C974: add         byte ptr [eax],al
  1000C976: or          al,byte ptr [edx]
  1000C978: jb          1000C96F
  1000C97A: add         al,0
  1000C97C: jo          1000C9A6
  1000C97E: add         al,byte ptr [ecx]
  1000C980: add         byte ptr [esi],al
  1000C982: sub         byte ptr es:[ebp],dl
  1000C986: add         byte ptr [edx],cl
  1000C988: fimul       word ptr [esi]
  1000C98A: jg          1000C9D1
  1000C98C: add         dword ptr [eax],eax
  1000C98E: add         al,28h
  1000C990: push        esi
  1000C991: add         byte ptr [eax],al
  1000C993: or          ah,byte ptr [esi]
  1000C995: pop         ss
  1000C996: or          bl,ah
  1000C998: add         ch,byte ptr [eax]
  1000C99A: test        dword ptr [eax],32DE0600h
  1000C9A0: or          eax,dword ptr [esi]
  1000C9A2: sub         al,7
  1000C9A4: add         al,byte ptr [edi]
  1000C9A6: sub         ah,bh
  1000C9A8: add         byte ptr [eax],al
  1000C9AA: push        es
  1000C9AB: add         ch,byte ptr [eax]
  1000C9AD: rol         byte ptr [eax],0
  1000C9B0: push        es
  1000C9B1: pop         es
  1000C9B2: sub         byte ptr [ebx],dh
  1000C9B4: add         dword ptr [eax],eax
  1000C9B6: push        es
  1000C9B7: ficomp      word ptr [ecx]
  1000C9B9: or          al,6
  1000C9BB: sub         al,7
  1000C9BD: add         dl,byte ptr [eax+ebp]
  1000C9C0: cld
  1000C9C1: add         byte ptr [eax],al
  1000C9C3: push        es
  1000C9C4: add         ch,byte ptr [eax]
  1000C9C6: rol         byte ptr [eax],0
  1000C9C9: push        es
  1000C9CA: adc         al,28h
  1000C9CC: xor         eax,dword ptr [ecx]
  1000C9CE: add         byte ptr [esi],al
  1000C9D0: fiadd       word ptr [eax]
  1000C9D2: sub         al,byte ptr [eax]
  1000C9D4: inc         ecx
  1000C9D5: dec         esp
  1000C9D6: add         byte ptr [eax],al
  1000C9D8: add         al,byte ptr [eax]
  1000C9DA: add         byte ptr [eax],al
  1000C9DC: sbb         byte ptr [eax],al
  1000C9DE: add         byte ptr [eax],al
  1000C9E0: add         al,byte ptr [eax]
  1000C9E2: add         byte ptr [eax],al
  1000C9E4: sbb         al,byte ptr [eax]
  1000C9E6: add         byte ptr [eax],al
  1000C9E8: push        cs
  1000C9E9: add         byte ptr [eax],al
  1000C9EB: add         byte ptr [ecx],dh
  1000C9ED: add         byte ptr [eax],al
  1000C9EF: add         dword ptr [eax],eax
  1000C9F1: add         byte ptr [eax],al
  1000C9F3: add         byte ptr [edi],al
  1000C9F5: add         byte ptr [eax],al
  1000C9F7: add         byte ptr [ecx],ch
  1000C9F9: add         byte ptr [eax],al
  1000C9FB: add         byte ptr [eax],dh
  1000C9FD: add         byte ptr [eax],al
  1000C9FF: add         byte ptr [ecx],bl
  1000CA01: add         byte ptr [eax],al
  1000CA03: add         byte ptr [ecx],al
  1000CA06: add         byte ptr [ecx],al
  1000CA08: add         byte ptr [eax],al
  1000CA0A: add         byte ptr [eax],al
  1000CA0C: pop         es
  1000CA0D: add         byte ptr [eax],al
  1000CA0F: add         byte ptr [ecx],ch
  1000CA11: add         byte ptr [eax],al
  1000CA13: add         byte ptr [ecx],cl
  1000CA16: add         byte ptr [eax],al
  1000CA18: sbb         dword ptr [eax],eax
  1000CA1A: add         byte ptr [eax],al
  1000CA1C: sbb         eax,3010000h
  1000CA21: xor         byte ptr [ecx],al
  1000CA23: add         byte ptr [ecx],cl
  1000CA25: add         byte ptr [eax],al
  1000CA27: add         byte ptr [eax],al
  1000CA29: add         byte ptr [eax],al
  1000CA2B: add         byte ptr [edx],al
  1000CA2D: sub         byte ptr [ecx],al
  1000CA2F: add         dword ptr [eax],eax
  1000CA31: push        es
  1000CA32: add         ch,byte ptr es:[edx]
  1000CA35: add         byte ptr [eax],al
  1000CA37: add         byte ptr [eax],al
  1000CA39: add         byte ptr [eax],al
  1000CA3B: add         byte ptr [ebx],al
  1000CA3D: xor         byte ptr [ecx],al
  1000CA3F: add         byte ptr [edi],al
  1000CA41: add         byte ptr [eax],al
  1000CA43: add         byte ptr [eax],al
  1000CA45: add         byte ptr [eax],al
  1000CA47: add         byte ptr [edx],al
  1000CA49: sub         byte ptr [edi+2A060000h],bh
  1000CA4F: add         byte ptr [eax],al
  1000CA51: add         byte ptr [eax],al
  1000CA53: add         byte ptr [ebx],cl
  1000CA55: xor         byte ptr [edx],al
  1000CA57: add         byte ptr [edi],ah
  1000CA59: add         byte ptr [eax],al
  1000CA5B: add         byte ptr [edx+12110001h],ah
  1000CA61: add         byte ptr [eax],ch
  1000CA63: inc         dword ptr [eax]
  1000CA65: add         byte ptr [esi],al
  1000CA67: adc         al,byte ptr es:[eax]
  1000CA6A: sub         ch,bh
  1000CA6C: add         byte ptr [eax],al
  1000CA6E: push        es
  1000CA6F: fimul       word ptr [esi]
  1000CA71: inc         byte ptr [esi]
  1000CA73: add         byte ptr [ecx],al
  1000CA75: add         byte ptr [esi],al
  1000CA77: adc         al,byte ptr [eax]
  1000CA79: sub         byte ptr [ebx],al
  1000CA7B: add         dword ptr [eax],eax
  1000CA7D: push        es
  1000CA7E: fcom        qword ptr [edx]
  1000CA80: add         byte ptr [eax],ch
  1000CA82: mov         edi,2A060000h
  1000CA87: add         byte ptr [ecx+1Ch],al
  1000CA8A: add         byte ptr [eax],al
  1000CA8C: add         al,0
  1000CA8E: add         byte ptr [eax],al
  1000CA90: or          byte ptr [eax],al
  1000CA92: add         byte ptr [eax],al
  1000CA94: or          dword ptr [eax],eax
  1000CA96: add         byte ptr [eax],al
  1000CA98: adc         dword ptr [eax],eax
  1000CA9A: add         byte ptr [eax],al
  1000CA9C: push        cs
  1000CA9D: add         byte ptr [eax],al
  1000CA9F: add         byte ptr [ecx],dh
  1000CAA1: add         byte ptr [eax],al
  1000CAA3: add         dword ptr [ebx],ecx
  1000CAA5: xor         byte ptr [edx],al
  1000CAA7: add         byte ptr [edx],bl
  1000CAA9: add         byte ptr [eax],al
  1000CAAB: add         byte ptr [eax],al
  1000CAAD: add         byte ptr [eax],al
  1000CAAF: add         byte ptr [ebx],al
  1000CAB1: add         ch,byte ptr [ecx]
  1000CAB3: movs        byte ptr es:[edi],byte ptr [esi]
  1000CAB4: add         dword ptr [eax],eax
  1000CAB6: adc         esi,ebx
  1000CAB8: adc         byte ptr [esi],ah
  1000CABA: sub         byte ptr [ebx],bl
  1000CABD: add         byte ptr [edx],cl
  1000CABF: sub         byte ptr [edx],bh
  1000CAC1: add         dword ptr [eax],eax
  1000CAC3: push        es
  1000CAC4: FE
  1000CAC5: adc         dword ptr [esi],esp
  1000CAC7: fiadd       word ptr [eax]
  1000CAC9: sub         al,byte ptr [eax]
  1000CACB: add         byte ptr [ecx+1Ch],al
  1000CACE: add         byte ptr [eax],al
  1000CAD0: add         dword ptr [eax],eax
  1000CAD2: add         byte ptr [eax],al
  1000CAD4: add         byte ptr [eax],al
  1000CAD6: add         byte ptr [eax],al
  1000CAD8: or          dword ptr [eax],eax
  1000CADA: add         byte ptr [eax],al
  1000CADC: push        ss
  1000CADD: add         byte ptr [eax],al
  1000CADF: add         byte ptr [ebx],al
  1000CAE1: add         byte ptr [eax],al
  1000CAE3: add         byte ptr [ecx],cl
  1000CAE5: add         byte ptr [eax],al
  1000CAE7: add         byte ptr [ebx],al
  1000CAE9: xor         byte ptr [edx],al
  1000CAEB: add         byte ptr [ebx],dl
  1000CAED: add         byte ptr [eax],al
  1000CAEF: add         byte ptr [eax],al
  1000CAF1: add         byte ptr [eax],al
  1000CAF3: add         byte ptr [edx],al
  1000CAF5: dec         edx
  1000CAF6: dec         edx
  1000CAF7: and         byte ptr [ebx+73h],ah
  1000CAFA: ins         dword ptr es:[edi],dx
  1000CAFB: loopne      1000CB2B
  1000CAFD: add         dl,byte ptr [esi]
  1000CAFF: sub         ch,byte ptr [eax]
  1000CB01: cmp         eax,dword ptr [ecx]
  1000CB03: add         byte ptr [esi],al
  1000CB05: push        ss
  1000CB06: sub         cl,ah
  1000CB08: or          esi,dword ptr [eax]
  1000CB0A: add         al,byte ptr [eax]
  1000CB0C: sub         al,byte ptr [eax]
  1000CB0E: add         byte ptr [eax],al
  1000CB10: add         byte ptr [eax],al
  1000CB12: add         byte ptr [eax],al
  1000CB14: add         al,17h
  1000CB16: pop         ecx
  1000CB17: adc         byte ptr [edx],al
  1000CB19: add         al,16h
  1000CB1B: xor         cl,byte ptr [esi]
  1000CB1D: add         al,byte ptr [ebx]
  1000CB1F: pop         ecx
  1000CB20: adc         byte ptr [eax],al
  1000CB22: add         al,byte ptr ds:[0001A429h]
  1000CB28: adc         dword ptr [ebx],ebp
  1000CB2A: jmp         3826DC0D
  1000CB2F: pop         ebx
  1000CB30: add         byte ptr [eax],al
  1000CB32: or          ch,byte ptr [eax]
  1000CB34: add         eax,0FE060001h
  1000CB39: adc         dword ptr [esi],esp
  1000CB3B: fiadd       word ptr [eax]
  1000CB3D: sub         al,byte ptr [eax]
  1000CB3F: add         byte ptr [ecx+1Ch],al
  1000CB42: add         byte ptr [eax],al
  1000CB44: add         dword ptr [eax],eax
  1000CB46: add         byte ptr [eax],al
  1000CB48: add         byte ptr [eax],al
  1000CB4A: add         byte ptr [eax],al
  1000CB4C: sbb         dword ptr [eax],eax
  1000CB4E: add         byte ptr [eax],al
  1000CB50: add         byte ptr es:[eax],al
  1000CB53: add         byte ptr [ebx],al
  1000CB55: add         byte ptr [eax],al
  1000CB57: add         byte ptr [ecx],bl
  1000CB59: add         byte ptr [eax],al
  1000CB5B: add         byte ptr [ebx],cl
  1000CB5D: xor         byte ptr [eax+eax],al
  1000CB60: xor         al,byte ptr [eax]
  1000CB62: add         byte ptr [eax],al
  1000CB64: adc         byte ptr [eax],al
  1000CB66: add         byte ptr [ecx],dl
  1000CB68: push        ss
  1000CB69: or          al,byte ptr [ebx]
  1000CB6B: add         al,5Ah
  1000CB6D: add         bl,byte ptr [eax+10h]
  1000CB70: add         byte ptr [edi+edx],al
  1000CB73: pop         ecx
  1000CB74: adc         byte ptr [edx],al
  1000CB76: add         al,16h
  1000CB78: xor         cl,byte ptr [esi]
  1000CB7A: add         al,byte ptr [ebx]
  1000CB7C: pop         ecx
  1000CB7D: adc         byte ptr [eax],al
  1000CB7F: add         al,byte ptr ds:[0001A429h]
  1000CB85: adc         dword ptr [ebx],ebp
  1000CB87: jmp         1DDED5A3
  1000CB8C: push        es
  1000CB8D: sub         eax,4030209h
  1000CB92: add         eax,10628h
  1000CB97: push        es
  1000CB98: fsubr       qword ptr [edx]
  1000CB9A: add         byte ptr [eax],al
  1000CB9C: inc         ecx
  1000CB9D: sbb         al,0
  1000CB9F: add         byte ptr [edx],al
  1000CBA1: add         byte ptr [eax],al
  1000CBA3: add         byte ptr [ecx],cl
  1000CBA5: add         byte ptr [eax],al
  1000CBA7: add         byte ptr [ebx],bl
  1000CBA9: add         byte ptr [eax],al
  1000CBAB: add         byte ptr [eax+eax],ah
  1000CBAE: add         byte ptr [eax],al
  1000CBB0: or          eax,19000000h
  1000CBB5: add         byte ptr [eax],al
  1000CBB7: add         dword ptr [ebx],eax
  1000CBB9: xor         byte ptr [edx],al
  1000CBBB: add         byte ptr [ebp],dl
  1000CBBE: add         byte ptr [eax],al
  1000CBC0: test        eax,7E110001h
  1000CBC5: push        edx
  1000CBC6: add         dword ptr [eax],eax
  1000CBC8: add         al,28h
  1000CBCA: cmp         eax,0B060001h
  1000CBCF: jle         1000CC24
  1000CBD1: add         dword ptr [eax],eax
  1000CBD3: add         al,28h
  1000CBD5: cmp         eax,0A060001h
  1000CBDA: pop         es
  1000CBDB: adc         eax,2C073A2Eh
  1000CBE0: aaa
  1000CBE1: push        es
  1000CBE2: sub         al,34h
  1000CBE4: push        es
  1000CBE5: sbb         bl,byte ptr [ecx+0Ah]
  1000CBE8: push        es
  1000CBE9: pop         es
  1000CBEA: aaa
  1000CBEB: push        ds
  1000CBEC: push        es
  1000CBED: dec         edx
  1000CBEE: or          al,8
  1000CBF0: sub         byte ptr [esi],bh
  1000CBF2: add         dword ptr [eax],eax
  1000CBF4: push        es
  1000CBF5: or          ecx,dword ptr cs:[eax]
  1000CBF8: sub         byte ptr ds:[29060001h],bh
  1000CBFE: cmps        dword ptr [esi],dword ptr es:[edi]
  1000CBFF: add         dword ptr [eax],eax
  1000CC01: adc         dword ptr [esi],eax
  1000CC03: sbb         bl,byte ptr [ecx+0Ah]
  1000CC06: push        es
  1000CC07: pop         es
  1000CC08: xor         al,0E2h
  1000CC0A: adc         al,byte ptr [ebx]
  1000CC0C: pop         es
  1000CC0D: sub         byte ptr [edx],ch
  1000CC0F: add         byte ptr [eax],al
  1000CC11: or          cl,byte ptr [ecx]
  1000CC13: sub         byte ptr [ebx],bh
  1000CC15: add         byte ptr [eax],al
  1000CC17: or          ch,byte ptr [edx]
  1000CC19: int         3
  1000CC1A: int         3
  1000CC1B: int         3
  1000CC1C: or          esi,dword ptr [eax]
  1000CC1E: add         al,byte ptr [eax]
  1000CC20: push        ecx
  1000CC21: add         byte ptr [eax],al
  1000CC23: add         byte ptr [edx+7E110001h],ch
  1000CC29: dec         edi
  1000CC2A: add         dword ptr [eax],eax
  1000CC2C: add         al,28h
  1000CC2E: cmp         eax,0B060001h
  1000CC33: jle         1000CC86
  1000CC35: add         dword ptr [eax],eax
  1000CC37: add         al,28h
  1000CC39: cmp         eax,0A060001h
  1000CC3E: pop         es
  1000CC3F: adc         eax,2C07362Eh
  1000CC44: xor         eax,dword ptr [esi]
  1000CC46: sub         al,30h
  1000CC48: push        es
  1000CC49: sbb         bl,byte ptr [ecx+0Ah]
  1000CC4C: push        es
  1000CC4D: pop         es
  1000CC4E: aaa
  1000CC4F: pop         ss
  1000CC50: push        es
  1000CC51: dec         edx
  1000CC52: sub         byte ptr [esi],bh
  1000CC54: add         dword ptr [eax],eax
  1000CC56: push        es
  1000CC57: or          al,6
  1000CC5A: dec         edx
  1000CC5B: sub         byte ptr ds:[29060001h],bh
  1000CC61: cmps        dword ptr [esi],dword ptr es:[edi]
  1000CC62: add         dword ptr [eax],eax
  1000CC64: adc         dword ptr [ebx],ebp
  1000CC66: loope       1000CC46
  1000CC68: movlps      xmm0,qword ptr [edx]
  1000CC6B: pop         es
  1000CC6C: sub         byte ptr [edx],ch
  1000CC6E: add         byte ptr [eax],al
  1000CC70: or          cl,byte ptr [eax]
  1000CC72: sub         byte ptr [ebx],bh
  1000CC74: add         byte ptr [eax],al
  1000CC76: or          bl,ah
  1000CC78: sub         al,byte ptr [eax]
  1000CC7A: add         byte ptr [eax],al
  1000CC7C: inc         ecx
  1000CC7D: sbb         al,0
  1000CC7F: add         byte ptr [edx],al
  1000CC81: add         byte ptr [eax],al
  1000CC83: add         byte ptr [eax],ah
  1000CC85: add         byte ptr [eax],al
  1000CC87: add         byte ptr [ecx],ah
  1000CC89: add         byte ptr [eax],al
  1000CC8B: add         byte ptr [ecx],al
  1000CC8E: add         byte ptr [eax],al
  1000CC90: sldt        word ptr [eax]
  1000CC93: add         byte ptr [edx],ah
  1000CC95: add         byte ptr [eax],al
  1000CC97: add         dword ptr [ebx],eax
  1000CC99: xor         byte ptr [edx],al
  1000CC9B: add         byte ptr [eax+eax],bl
  1000CC9E: add         byte ptr [eax],al
  1000CCA0: lods        byte ptr [esi]
  1000CCA1: add         dword ptr [eax],eax
  1000CCA3: adc         dword ptr [edx],eax
  1000CCA5: dec         edx
  1000CCA6: or          al,byte ptr [esi]
  1000CCA8: sub         al,14h
  1000CCAA: adc         al,byte ptr [ecx]
  1000CCAC: push        es
  1000CCAD: sub         byte ptr [edx],ch
  1000CCAF: add         byte ptr [eax],al
  1000CCB1: or          al,byte ptr [edi]
  1000CCB3: sub         byte ptr [ebp],bl
  1000CCB6: add         byte ptr [edx],cl
  1000CCB8: mov         word ptr [ebx],gs
  1000CCBA: add         byte ptr [eax],al
  1000CCBC: add         dword ptr [edx],ebp
  1000CCBE: adc         al,2Ah
  1000CCC0: add         esi,dword ptr [eax]
  1000CCC2: add         al,byte ptr [eax]
  1000CCC4: aas
  1000CCC5: add         byte ptr [eax],al
  1000CCC7: add         byte ptr [esi+02110001h],ch
  1000CCCD: sub         byte ptr [esi],dl
  1000CCCF: add         dword ptr [eax],eax
  1000CCD1: push        es
  1000CCD2: or          al,byte ptr [esi]
  1000CCD4: sub         eax,30280328h
  1000CCD9: add         byte ptr [eax],al
  1000CCDB: or          cl,byte ptr [ebx+ebp+0A010000h]
  1000CCE2: push        es
  1000CCE3: jns         1000CD10
  1000CCE5: add         byte ptr [eax],al
  1000CCE7: add         dword ptr [ecx+2Bh],esi
  1000CCEA: add         byte ptr [eax],al
  1000CCEC: add         dword ptr [eax],ebp
  1000CCEE: pop         esi
  1000CCEF: add         byte ptr [eax],al
  1000CCF1: or          cl,byte ptr [ebx]
  1000CCF3: add         dl,byte ptr [edx]
  1000CCF5: add         dword ptr [eax],ebp
  1000CCF7: sub         eax,dword ptr [eax]
  1000CCF9: add         byte ptr [edx],cl
  1000CCFB: push        esp
  1000CCFC: sub         ecx,dword ptr [esi+eax]
  1000CCFF: jns         1000CD2C
  1000CD01: add         byte ptr [eax],al
  1000CD03: add         dword ptr [ebx],eax
  1000CD05: sub         byte ptr [edx],bh
  1000CD07: add         byte ptr [eax],al
  1000CD09: or          ch,byte ptr [edx]
  1000CD0B: int         3
  1000CD0C: add         esi,dword ptr [eax]
  1000CD0E: add         dword ptr [eax],eax
  1000CD10: sbb         byte ptr [eax],al
  1000CD12: add         byte ptr [eax],al
  1000CD14: scas        dword ptr es:[edi]
  1000CD15: add         dword ptr [eax],eax
  1000CD17: adc         dword ptr [edx],eax
  1000CD19: sub         byte ptr [esi],dl
  1000CD1B: add         dword ptr [eax],eax
  1000CD1D: push        es
  1000CD1E: or          al,byte ptr [esi]
  1000CD20: sub         al,0Ch
  1000CD22: push        es
  1000CD23: jns         1000CD50
  1000CD25: add         byte ptr [eax],al
  1000CD27: add         dword ptr [eax],ebp
  1000CD29: xor         al,0
  1000CD2B: add         byte ptr [edx],cl
  1000CD2D: sub         dl,byte ptr [edx+ebp]
  1000CD30: add         esi,dword ptr [eax]
  1000CD32: add         al,byte ptr [eax]
  1000CD34: sbb         dword ptr [eax],eax
  1000CD36: add         byte ptr [eax],al
  1000CD38: scas        dword ptr es:[edi]
  1000CD39: add         dword ptr [eax],eax
  1000CD3B: adc         dword ptr [edx],eax
  1000CD3D: sub         byte ptr [esi],dl
  1000CD3F: add         dword ptr [eax],eax
  1000CD41: push        es
  1000CD42: or          al,byte ptr [esi]
  1000CD44: sub         al,0Eh
  1000CD46: push        es
  1000CD47: jns         1000CD74
  1000CD49: add         byte ptr [eax],al
  1000CD4B: add         dword ptr [eax],ebp
  1000CD4D: xor         dword ptr [eax],eax
  1000CD4F: add         byte ptr [edx],cl
  1000CD51: add         dl,byte ptr [esi]
  1000CD53: push        esp
  1000CD54: sub         cl,ah
  1000CD56: int         3
  1000CD57: int         3
  1000CD58: add         esi,dword ptr [eax]
  1000CD5A: add         al,byte ptr [eax]
  1000CD5C: sbb         dword ptr [eax],eax
  1000CD5E: add         byte ptr [eax],al
  1000CD60: mov         al,1
  1000CD62: add         byte ptr [ecx],dl
  1000CD64: jae         1000CD93
  1000CD66: add         byte ptr [eax],al
  1000CD68: or          cl,byte ptr [edx]
  1000CD6A: jg          1000CDB9
  1000CD6C: add         dword ptr [eax],eax
  1000CD6E: add         al,16h
  1000CD70: push        esp
  1000CD71: jg          1000CDC0
  1000CD73: add         dword ptr [eax],eax
  1000CD75: add         al,6
  1000CD77: sub         byte ptr [edi],dl
  1000CD79: add         dword ptr [eax],eax
  1000CD7B: push        es
  1000CD7C: sub         cl,ah
  1000CD7E: int         3
  1000CD7F: int         3
  1000CD80: add         esi,dword ptr [eax]
  1000CD82: add         al,byte ptr [eax]
  1000CD84: adc         eax,dword ptr [eax]
  1000CD86: add         byte ptr [eax],al
  1000CD88: add         byte ptr [eax],al
  1000CD8A: add         byte ptr [eax],al
  1000CD8C: jg          1000CDDB
  1000CD8E: add         dword ptr [eax],eax
  1000CD90: add         al,28h
  1000CD92: adc         al,1
  1000CD94: add         byte ptr [esi],al
  1000CD96: adc         al,33h
  1000CD98: add         edx,dword ptr [esi]
  1000CD9A: sub         eax,dword ptr [ecx]
  1000CD9C: pop         ss
  1000CD9D: shr         byte ptr [edx],cl
  1000CD9F: int         3
  1000CDA0: add         esi,dword ptr [eax]
  1000CDA2: add         dword ptr [eax],eax
  1000CDA4: sbb         al,0
  1000CDA6: add         byte ptr [eax],al
  1000CDA8: mov         cl,1
  1000CDAA: add         byte ptr [ecx],dl
  1000CDAC: push        ss
  1000CDAD: or          ch,byte ptr [eax]
  1000CDAF: or          byte ptr [ecx],al
  1000CDB1: add         byte ptr [esi],al
  1000CDB3: sub         al,11h
  1000CDB5: jg          1000CE04
  1000CDB7: add         dword ptr [eax],eax
  1000CDB9: add         al,28h
  1000CDBB: adc         al,1
  1000CDBD: add         byte ptr [esi],al
  1000CDBF: sub         byte ptr [ecx],ah
  1000CDC2: add         byte ptr [edx],cl
  1000CDC4: pop         ss
  1000CDC5: or          al,byte ptr [esi]
  1000CDC7: sub         al,byte ptr [ebx]
  1000CDC9: xor         byte ptr [ecx],al
  1000CDCB: add         byte ptr [eax+eax],bl
  1000CDCE: add         byte ptr [eax],al
  1000CDD0: mov         cl,1
  1000CDD2: add         byte ptr [ecx],dl
  1000CDD4: push        ss
  1000CDD5: or          ch,byte ptr [eax]
  1000CDD7: or          byte ptr [ecx],al
  1000CDD9: add         byte ptr [esi],al
  1000CDDB: sub         al,11h
  1000CDDD: jg          1000CE2C
  1000CDDF: add         dword ptr [eax],eax
  1000CDE1: add         al,28h
  1000CDE3: adc         al,1
  1000CDE5: add         byte ptr [esi],al
  1000CDE7: sub         byte ptr [edx],ah
  1000CDEA: add         byte ptr [edx],cl
  1000CDEC: pop         ss
  1000CDED: or          al,byte ptr [esi]
  1000CDEF: sub         al,byte ptr [ebx]
  1000CDF1: xor         byte ptr [ecx],al
  1000CDF3: add         byte ptr [edx],dl
  1000CDF5: add         byte ptr [eax],al
  1000CDF7: add         byte ptr [eax],al
  1000CDF9: add         byte ptr [eax],al
  1000CDFB: add         byte ptr [eax],ch
  1000CDFD: or          byte ptr [ecx],al
  1000CDFF: add         byte ptr [esi],al
  1000CE01: sub         eax,1072805h
  1000CE06: add         byte ptr [esi],al
  1000CE08: sub         byte ptr [eax],cl
  1000CE0A: add         dword ptr [eax],eax
  1000CE0C: push        es
  1000CE0D: sub         cl,ah
  1000CE0F: int         3
  1000CE10: or          esi,dword ptr [eax]
  1000CE12: add         al,0
  1000CE14: cli
  1000CE15: add         byte ptr [eax],al
  1000CE17: add         byte ptr [ebp+16110001h],dh
  1000CE1D: adc         eax,dword ptr ds:[15022D02h]
  1000CE23: sub         ch,byte ptr [eax]
  1000CE25: or          eax,dword ptr [ecx]
  1000CE27: add         byte ptr [esi],al
  1000CE29: pop         ss
  1000CE2A: inc         eax
  1000CE2B: fild        word ptr [eax]
  1000CE2D: add         byte ptr [eax],al
  1000CE2F: add         ecx,dword ptr [edx+17h]
  1000CE32: pop         ecx
  1000CE33: add         al,4Ah
  1000CE35: add         eax,6418594Ah
  1000CE3A: inc         ecx
  1000CE3B: scas        byte ptr es:[edi]
  1000CE3C: add         byte ptr [eax],al
  1000CE3E: add         byte ptr [ebx],al
  1000CE40: dec         edx
  1000CE41: sbb         bl,byte ptr [edx+0Bh]
  1000CE44: pop         es
  1000CE45: and         byte ptr [eax],al
  1000CE47: or          byte ptr [eax],al
  1000CE49: add         byte ptr [eax+2B041307h],dh
  1000CE50: pop         es
  1000CE51: and         byte ptr [eax],al
  1000CE53: or          byte ptr [eax],al
  1000CE55: add         byte ptr [ebx],dl
  1000CE57: add         al,12h
  1000CE59: or          dword ptr [edi],eax
  1000CE5B: adc         dword ptr [eax+ebx*2],eax
  1000CE5E: sub         byte ptr [eax+eax],bl
  1000CE62: or          dl,byte ptr [edx]
  1000CE64: or          byte ptr ds:[002A284Ah],al
  1000CE6A: add         byte ptr [edx],cl
  1000CE6C: adc         dword ptr [eax],ecx
  1000CE6E: adc         dword ptr [ecx],ecx
  1000CE70: sub         byte ptr [eax],ah
  1000CE73: add         byte ptr [edx],cl
  1000CE75: adc         ecx,dword ptr [ebx]
  1000CE77: add         al,25h
  1000CE79: dec         edx
  1000CE7A: adc         cl,byte ptr [ebx]
  1000CE7C: sub         byte ptr [ebx],ch
  1000CE7E: add         byte ptr [eax],al
  1000CE80: or          al,byte ptr ds:[5458594Ah]
  1000CE86: add         eax,2B280B12h
  1000CE8B: add         byte ptr [eax],al
  1000CE8D: or          dl,byte ptr [ebx+eax+4Ah]
  1000CE91: or          ah,byte ptr [eax]
  1000CE93: add         byte ptr [edx],al
  1000CE95: add         byte ptr [eax],al
  1000CE97: push        es
  1000CE98: xor         al,8
  1000CE9A: and         byte ptr [eax],al
  1000CE9C: add         al,byte ptr [eax]
  1000CE9E: add         byte ptr ds:[0D06022Bh],cl
  1000CEA4: add         eax,dword ptr [esi]
  1000CEA6: or          dword ptr [eax+54h],ebx
  1000CEA9: fiadd       word ptr [edx+26h]
  1000CEAC: adc         al,byte ptr [edi]
  1000CEAE: add         ecx,dword ptr [edx+1Ah]
  1000CEB1: pop         edx
  1000CEB2: push        ds
  1000CEB3: pop         eax
  1000CEB4: sub         byte ptr [eax+eax],bl
  1000CEB8: or          dl,byte ptr [edx]
  1000CEBA: push        es
  1000CEBB: add         eax,2A284Ah
  1000CEC0: add         byte ptr [edx],cl
  1000CEC2: adc         dword ptr [esi],eax
  1000CEC4: adc         dword ptr [edi],eax
  1000CEC6: sub         byte ptr [eax],ah
  1000CEC9: add         byte ptr [edx],cl
  1000CECB: adc         ecx,dword ptr [edx]
  1000CECD: add         al,25h
  1000CECF: dec         edx
  1000CED0: adc         cl,byte ptr [edx]
  1000CED2: sub         byte ptr [ebx],ch
  1000CED4: add         byte ptr [eax],al
  1000CED6: or          al,byte ptr ds:[5458594Ah]
  1000CEDC: add         eax,2B280A12h
  1000CEE1: add         byte ptr [eax],al
  1000CEE3: or          dl,byte ptr [ebx+eax+25h]
  1000CEE7: dec         edx
  1000CEE8: sbb         bl,byte ptr [eax+54h]
  1000CEEB: fiadd       word ptr [eax]
  1000CEED: add         al,4Ah
  1000CEEF: add         dl,byte ptr [esp+eax+25h]
  1000CEF3: dec         edx
  1000CEF4: sbb         bl,byte ptr [eax+54h]
  1000CEF7: add         dl,byte ptr [ebx]
  1000CEF9: add         eax,0DE2605DEh
  1000CEFE: add         dh,bl
  1000CF00: or          esi,ebx
  1000CF02: pop         es
  1000CF03: sub         byte ptr [ecx+eax],cl
  1000CF06: add         byte ptr [esi],al
  1000CF08: fcom        qword ptr es:[ecx]
  1000CF0B: add         eax,0C15042Dh
  1000CF10: sub         eax,dword ptr [edx]
  1000CF12: push        ss
  1000CF13: or          al,8
  1000CF15: sub         al,byte ptr [eax]
  1000CF17: add         byte ptr [ecx+4Ch],al
  1000CF1A: add         byte ptr [eax],al
  1000CF1C: add         byte ptr [eax],al
  1000CF1E: add         byte ptr [eax],al
  1000CF20: and         eax,dword ptr [eax]
  1000CF22: add         byte ptr [eax],al
  1000CF24: ins         byte ptr es:[edi],dx
  1000CF25: add         byte ptr [eax],al
  1000CF27: add         byte ptr [edi+42000000h],cl
  1000CF2D: add         byte ptr [eax],al
  1000CF2F: add         byte ptr [eax+eax],cl
  1000CF33: add         dword ptr [eax],eax
  1000CF35: add         byte ptr [eax],al
  1000CF37: add         byte ptr [ebx],dl
  1000CF39: add         byte ptr [eax],al
  1000CF3B: add         ch,cl
  1000CF3D: add         byte ptr [eax],al
  1000CF3F: add         al,ah
  1000CF41: add         byte ptr [eax],al
  1000CF43: add         byte ptr [ebx],al
  1000CF45: add         byte ptr [eax],al
  1000CF47: add         byte ptr [eax+eax],cl
  1000CF4B: add         dword ptr [edx],eax
  1000CF4D: add         byte ptr [eax],al
  1000CF4F: add         byte ptr [ebx],dl
  1000CF51: add         byte ptr [eax],al
  1000CF53: add         ah,dl
  1000CF55: add         byte ptr [eax],al
  1000CF57: add         bh,ah
  1000CF59: add         byte ptr [eax],al
  1000CF5B: add         byte ptr [edi],al
  1000CF5D: add         byte ptr [eax],al
  1000CF5F: add         byte ptr [edx],ah
  1000CF61: add         byte ptr [eax],al
  1000CF63: add         dword ptr [ebx],eax
  1000CF65: xor         byte ptr [ebx],al
  1000CF67: add         byte ptr [ecx],bh
  1000CF69: add         byte ptr [eax],al
  1000CF6B: add         byte ptr [edi+16110000h],bl
  1000CF71: sub         byte ptr ds:[17060001h],cl
  1000CF77: xor         ebp,dword ptr [edi]
  1000CF79: and         byte ptr es:[eax+28000000h],al
  1000CF80: pop         edi
  1000CF81: add         byte ptr [eax],al
  1000CF83: or          cl,byte ptr [edx]
  1000CF85: adc         al,byte ptr [eax]
  1000CF87: sub         byte ptr [ebx],ch
  1000CF89: add         byte ptr [eax],al
  1000CF8B: or          ch,byte ptr [eax]
  1000CF8D: cmp         al,1
  1000CF8F: add         byte ptr [esi],al
  1000CF91: adc         byte ptr [edx+1],0
  1000CF95: add         al,7Eh
  1000CF97: push        edx
  1000CF98: add         dword ptr [eax],eax
  1000CF9A: add         al,80h
  1000CF9C: push        ebx
  1000CF9D: add         dword ptr [eax],eax
  1000CF9F: add         al,1Fh
  1000CFA1: and         byte ptr [eax+04000150h],al
  1000CFA7: pop         ss
  1000CFA8: sub         cl,ah
  1000CFAA: int         3
  1000CFAB: int         3
  1000CFAC: add         esi,dword ptr [eax]
  1000CFAE: add         al,byte ptr [eax]
  1000CFB0: aaa
  1000CFB1: add         byte ptr [eax],al
  1000CFB3: add         byte ptr [edi+28110000h],bl
  1000CFB9: or          eax,17060001h
  1000CFBE: xor         ebp,dword ptr ds:[00008020h]
  1000CFC4: add         byte ptr [eax],ch
  1000CFC6: pop         edi
  1000CFC7: add         byte ptr [eax],al
  1000CFC9: or          cl,byte ptr [edx]
  1000CFCB: adc         al,byte ptr [eax]
  1000CFCD: sub         byte ptr [ebx],ch
  1000CFCF: add         byte ptr [eax],al
  1000CFD1: or          ch,byte ptr [eax]
  1000CFD3: cmp         al,1
  1000CFD5: add         byte ptr [esi],al
  1000CFD7: or          byte ptr [edi+1],0
  1000CFDB: add         al,7Eh
  1000CFDD: dec         edi
  1000CFDE: add         dword ptr [eax],eax
  1000CFE0: add         al,80h
  1000CFE2: push        ecx
  1000CFE3: add         dword ptr [eax],eax
  1000CFE5: add         al,1Fh
  1000CFE7: and         byte ptr [eax+0400014Ch],al
  1000CFED: pop         ss
  1000CFEE: sub         cl,ah
  1000CFF0: add         esi,dword ptr [eax]
  1000CFF2: add         al,0
  1000CFF4: inc         ecx
  1000CFF5: add         byte ptr [eax],al
  1000CFF7: add         byte ptr [esi+7E110001h],dh
  1000CFFD: dec         edi
  1000CFFE: add         dword ptr [eax],eax
  1000D000: add         al,28h
  1000D002: cmp         eax,0B060001h
  1000D007: jle         1000D05A
  1000D009: add         dword ptr [eax],eax
  1000D00B: add         al,28h
  1000D00D: cmp         eax,0A060001h
  1000D012: add         ch,byte ptr [eax]
  1000D014: cmp         al,1
  1000D016: add         byte ptr [esi],al
  1000D018: jg          1000D066
  1000D01A: add         dword ptr [eax],eax
  1000D01C: add         al,12h
  1000D01E: add         byte ptr [edx],dl
  1000D020: add         dword ptr [eax],ebp
  1000D022: push        cs
  1000D023: add         dword ptr [eax],eax
  1000D025: push        es
  1000D026: pop         es
  1000D027: sub         byte ptr [ecx+eax],bh
  1000D02A: add         byte ptr [esi],al
  1000D02C: or          byte ptr [edi+1],0
  1000D030: add         al,6
  1000D032: sub         byte ptr [ecx+eax],bh
  1000D035: add         byte ptr [esi],al
  1000D037: adc         byte ptr [ecx+1],0
  1000D03B: add         al,2Ah
  1000D03D: int         3
  1000D03E: int         3
  1000D03F: int         3
  1000D040: add         esi,dword ptr [eax]
  1000D042: add         al,byte ptr [eax]
  1000D044: and         dword ptr [eax],eax
  1000D046: add         byte ptr [eax],al
  1000D048: mov         dword ptr [eax],eax
  1000D04A: add         byte ptr [ecx],dl
  1000D04C: push        ss
  1000D04D: or          al,byte ptr [edx]
  1000D04F: add         esi,dword ptr [ecx+ebx]
  1000D052: push        es
  1000D053: sub         eax,0B4A0216h
  1000D058: pop         es
  1000D059: sub         al,7
  1000D05B: pop         es
  1000D05C: sub         dword ptr [ecx+0A110001h],edi
  1000D062: add         bl,byte ptr [edx]
  1000D064: pop         eax
  1000D065: adc         byte ptr [eax],al
  1000D067: add         al,byte ptr [ebx]
  1000D069: aaa
  1000D06A: out         6,eax
  1000D06C: sub         cl,ah
  1000D06E: int         3
  1000D06F: int         3
  1000D070: add         esi,dword ptr [eax]
  1000D072: add         al,byte ptr [eax]
  1000D074: sbb         al,byte ptr [eax]
  1000D076: add         byte ptr [eax],al
  1000D078: or          dword ptr [eax],eax
  1000D07A: add         byte ptr [ecx],dl
  1000D07C: add         al,byte ptr [ebx]
  1000D07E: xor         al,15h
  1000D080: add         cl,byte ptr [edx+0Ah]
  1000D083: push        es
  1000D084: sub         al,6
  1000D086: push        es
  1000D087: sub         dword ptr [edi+02110001h],esi
  1000D08D: sbb         bl,byte ptr [eax+10h]
  1000D090: add         byte ptr [edx],al
  1000D092: add         esi,dword ptr [edi]
  1000D094: jmp         1000D0C0
  1000D096: int         3
  1000D097: int         3
  1000D098: add         esi,dword ptr [eax]
  1000D09A: add         dword ptr [eax],eax
  1000D09C: adc         eax,0
  1000D0A1: add         byte ptr [eax],al
  1000D0A3: add         al,dl
  1000D0A5: retf        0
  1000D0A8: add         ch,byte ptr [eax]
  1000D0AA: arpl        word ptr [eax],ax
  1000D0AC: add         byte ptr [edx],cl
  1000D0AE: outs        dx,dword ptr [esi]
  1000D0AF: add         byte ptr fs:[eax],al
  1000D0B2: or          ch,byte ptr [eax]
  1000D0B4: add         byte ptr [bx+si],al
  1000D0B7: or          ch,byte ptr [edx]
  1000D0B9: int         3
  1000D0BA: int         3
  1000D0BB: int         3
  1000D0BC: add         esi,dword ptr [eax]
  1000D0BE: add         al,byte ptr [eax]
  1000D0C0: pop         ds
  1000D0C1: add         byte ptr [eax],al
  1000D0C3: add         byte ptr [ebp+28110001h],bh
  1000D0C9: sbb         al,byte ptr [ecx]
  1000D0CB: add         byte ptr [esi],al
  1000D0CD: or          al,12h
  1000D0CF: add         al,byte ptr [edx]
  1000D0D1: sub         byte ptr [esi],ah
  1000D0D4: add         byte ptr [edx],cl
  1000D0D6: or          edx,dword ptr [edx]
  1000D0D8: add         dword ptr [eax],ebp
  1000D0DA: add         byte ptr gs:[eax],al
  1000D0DD: or          cl,byte ptr [edx]
  1000D0DF: adc         al,byte ptr [eax]
  1000D0E1: sub         byte ptr [ebx],ch
  1000D0E3: add         byte ptr [eax],al
  1000D0E5: or          ch,byte ptr [edx]
  1000D0E7: int         3
  1000D0E8: add         esi,dword ptr [eax]
  1000D0EA: add         al,byte ptr [eax]
  1000D0EC: and         byte ptr [eax],al
  1000D0EE: add         byte ptr [eax],al
  1000D0F0: or          dword ptr [eax],eax
  1000D0F2: add         byte ptr [ecx],dl
  1000D0F4: add         al,byte ptr [ebx]
  1000D0F6: xor         al,1Bh
  1000D0F8: add         cl,byte ptr [edx+0Ah]
  1000D0FB: push        es
  1000D0FC: sub         al,0Ch
  1000D0FE: push        es
  1000D0FF: sub         byte ptr [ecx+eax],bl
  1000D102: add         byte ptr [esi],al
  1000D104: sub         dword ptr [eax+26110001h],edi
  1000D10A: add         bl,byte ptr [edx]
  1000D10C: pop         eax
  1000D10D: adc         byte ptr [eax],al
  1000D10F: add         al,byte ptr [ebx]
  1000D111: aaa
  1000D112: in          eax,2Ah
  1000D114: jmp         dword ptr ds:[1000E030h]
  1000D11A: int         3
  1000D11B: int         3
  1000D11C: int         3
  1000D11D: int         3
  1000D11E: int         3
  1000D11F: int         3
  1000D120: mov         ecx,dword ptr [esp+4]
  1000D124: mov         eax,dword ptr [ecx]
  1000D126: test        eax,eax
  1000D128: je          1000D13B
  1000D12A: mov         ecx,dword ptr [eax+4]
  1000D12D: test        ecx,ecx
  1000D12F: je          1000D151
  1000D131: mov         eax,ecx
  1000D133: mov         ecx,dword ptr [eax+4]
  1000D136: test        ecx,ecx
  1000D138: jne         1000D131
  1000D13A: ret
  1000D13B: mov         eax,dword ptr [ecx+8]
  1000D13E: cmp         ecx,dword ptr [eax]
  1000D140: jne         1000D14B
  1000D142: mov         ecx,eax
  1000D144: mov         eax,dword ptr [eax+8]
  1000D147: cmp         ecx,dword ptr [eax]
  1000D149: je          1000D142
  1000D14B: cmp         dword ptr [ecx],eax
  1000D14D: jne         1000D151
  1000D14F: mov         eax,ecx
  1000D151: ret
  1000D152: int         3
  1000D153: int         3
  1000D154: int         3
  1000D155: int         3
  1000D156: int         3
  1000D157: int         3
  1000D158: int         3
  1000D159: int         3
  1000D15A: int         3
  1000D15B: int         3
  1000D15C: int         3
  1000D15D: int         3
  1000D15E: int         3
  1000D15F: int         3
  1000D160: mov         ecx,dword ptr [esp+4]
  1000D164: mov         edx,dword ptr [ecx+8]
  1000D167: cmp         dword ptr [edx+8],ecx
  1000D16A: jne         1000D175
  1000D16C: cmp         byte ptr [ecx+0Ch],0
  1000D170: jne         1000D175
  1000D172: mov         eax,dword ptr [ecx]
  1000D174: ret
  1000D175: mov         eax,dword ptr [ecx+4]
  1000D178: test        eax,eax
  1000D17A: je          1000D18B
  1000D17C: mov         ecx,dword ptr [eax]
  1000D17E: test        ecx,ecx
  1000D180: je          1000D19C
  1000D182: mov         eax,ecx
  1000D184: mov         ecx,dword ptr [eax]
  1000D186: test        ecx,ecx
  1000D188: jne         1000D182
  1000D18A: ret
  1000D18B: mov         eax,edx
  1000D18D: cmp         ecx,dword ptr [eax+4]
  1000D190: jne         1000D19C
  1000D192: mov         ecx,eax
  1000D194: mov         eax,dword ptr [eax+8]
  1000D197: cmp         ecx,dword ptr [eax+4]
  1000D19A: je          1000D192
  1000D19C: ret
  1000D19D: int         3
  1000D19E: int         3
  1000D19F: int         3
  1000D1A0: mov         eax,dword ptr [esp+4]
  1000D1A4: mov         ecx,dword ptr [esp+8]
  1000D1A8: push        ebx
  1000D1A9: xor         ebx,ebx
  1000D1AB: cmp         dword ptr [esp+14h],ebx
  1000D1AF: push        esi
  1000D1B0: mov         esi,dword ptr [esp+14h]
  1000D1B4: mov         dword ptr [eax+8],ecx
  1000D1B7: mov         dword ptr [eax],ebx
  1000D1B9: mov         dword ptr [eax+4],ebx
  1000D1BC: mov         byte ptr [eax+0Ch],bl
  1000D1BF: jne         1000D1D7
  1000D1C1: cmp         ecx,esi
  1000D1C3: mov         dword ptr [ecx+4],eax
  1000D1C6: jne         1000D1CD
  1000D1C8: mov         dword ptr [esi+8],eax
  1000D1CB: jmp         1000D1DD
  1000D1CD: cmp         ecx,dword ptr [esi+4]
  1000D1D0: jne         1000D1DF
  1000D1D2: mov         dword ptr [esi+4],eax
  1000D1D5: jmp         1000D1DF
  1000D1D7: mov         dword ptr [ecx],eax
  1000D1D9: cmp         ecx,dword ptr [esi]
  1000D1DB: jne         1000D1DF
  1000D1DD: mov         dword ptr [esi],eax
  1000D1DF: cmp         eax,dword ptr [esi+8]
  1000D1E2: je          1000D365
  1000D1E8: push        ebp
  1000D1E9: push        edi
  1000D1EA: lea         ebx,[ebx+00000000h]
  1000D1F0: mov         edx,dword ptr [eax+8]
  1000D1F3: cmp         byte ptr [edx+0Ch],bl
  1000D1F6: jne         1000D36F
  1000D1FC: mov         ecx,dword ptr [edx+8]
  1000D1FF: mov         edi,dword ptr [ecx+4]
  1000D202: cmp         edx,edi
  1000D204: jne         1000D2B2
  1000D20A: mov         edi,dword ptr [ecx]
  1000D20C: cmp         edi,ebx
  1000D20E: je          1000D227
  1000D210: cmp         byte ptr [edi+0Ch],bl
  1000D213: jne         1000D227
  1000D215: mov         byte ptr [edx+0Ch],1
  1000D219: mov         byte ptr [edi+0Ch],1
  1000D21D: mov         byte ptr [ecx+0Ch],bl
  1000D220: mov         eax,ecx
  1000D222: jmp         1000D350
  1000D227: cmp         eax,dword ptr [edx]
  1000D229: jne         1000D267
  1000D22B: mov         ebp,dword ptr [esi+8]
  1000D22E: mov         eax,edx
  1000D230: mov         edx,dword ptr [eax]
  1000D232: mov         edi,dword ptr [edx+4]
  1000D235: mov         dword ptr [eax],edi
  1000D237: mov         edi,dword ptr [edx+4]
  1000D23A: cmp         edi,ebx
  1000D23C: je          1000D241
  1000D23E: mov         dword ptr [edi+8],eax
  1000D241: cmp         eax,ebp
  1000D243: mov         edi,dword ptr [eax+8]
  1000D246: mov         dword ptr [edx+8],edi
  1000D249: jne         1000D24F
  1000D24B: mov         ebp,edx
  1000D24D: jmp         1000D25E
  1000D24F: mov         edi,dword ptr [eax+8]
  1000D252: cmp         eax,dword ptr [edi+4]
  1000D255: jne         1000D25C
  1000D257: mov         dword ptr [edi+4],edx
  1000D25A: jmp         1000D25E
  1000D25C: mov         dword ptr [edi],edx
  1000D25E: mov         dword ptr [edx+4],eax
  1000D261: mov         dword ptr [eax+8],edx
  1000D264: mov         dword ptr [esi+8],ebp
  1000D267: mov         edx,dword ptr [eax+8]
  1000D26A: mov         byte ptr [edx+0Ch],1
  1000D26E: mov         edx,dword ptr [ecx+4]
  1000D271: mov         byte ptr [ecx+0Ch],bl
  1000D274: mov         edi,dword ptr [edx]
  1000D276: mov         ebp,dword ptr [esi+8]
  1000D279: mov         dword ptr [ecx+4],edi
  1000D27C: mov         edi,dword ptr [edx]
  1000D27E: cmp         edi,ebx
  1000D280: je          1000D285
  1000D282: mov         dword ptr [edi+8],ecx
  1000D285: cmp         ecx,ebp
  1000D287: mov         edi,dword ptr [ecx+8]
  1000D28A: mov         dword ptr [edx+8],edi
  1000D28D: jne         1000D298
  1000D28F: mov         ebp,edx
  1000D291: mov         dword ptr [edx],ecx
  1000D293: jmp         1000D34A
  1000D298: mov         edi,dword ptr [ecx+8]
  1000D29B: cmp         ecx,dword ptr [edi]
  1000D29D: jne         1000D2A8
  1000D29F: mov         dword ptr [edi],edx
  1000D2A1: mov         dword ptr [edx],ecx
  1000D2A3: jmp         1000D34A
  1000D2A8: mov         dword ptr [edi+4],edx
  1000D2AB: mov         dword ptr [edx],ecx
  1000D2AD: jmp         1000D34A
  1000D2B2: cmp         edi,ebx
  1000D2B4: je          1000D2CD
  1000D2B6: cmp         byte ptr [edi+0Ch],bl
  1000D2B9: jne         1000D2CD
  1000D2BB: mov         byte ptr [edx+0Ch],1
  1000D2BF: mov         byte ptr [edi+0Ch],1
  1000D2C3: mov         byte ptr [ecx+0Ch],bl
  1000D2C6: mov         eax,ecx
  1000D2C8: jmp         1000D350
  1000D2CD: cmp         eax,dword ptr [edx+4]
  1000D2D0: jne         1000D30C
  1000D2D2: mov         ebp,dword ptr [esi+8]
  1000D2D5: mov         eax,edx
  1000D2D7: mov         edx,dword ptr [eax+4]
  1000D2DA: mov         edi,dword ptr [edx]
  1000D2DC: mov         dword ptr [eax+4],edi
  1000D2DF: mov         edi,dword ptr [edx]
  1000D2E1: cmp         edi,ebx
  1000D2E3: je          1000D2E8
  1000D2E5: mov         dword ptr [edi+8],eax
  1000D2E8: cmp         eax,ebp
  1000D2EA: mov         edi,dword ptr [eax+8]
  1000D2ED: mov         dword ptr [edx+8],edi
  1000D2F0: jne         1000D2F6
  1000D2F2: mov         ebp,edx
  1000D2F4: jmp         1000D304
  1000D2F6: mov         edi,dword ptr [eax+8]
  1000D2F9: cmp         eax,dword ptr [edi]
  1000D2FB: jne         1000D301
  1000D2FD: mov         dword ptr [edi],edx
  1000D2FF: jmp         1000D304
  1000D301: mov         dword ptr [edi+4],edx
  1000D304: mov         dword ptr [edx],eax
  1000D306: mov         dword ptr [eax+8],edx
  1000D309: mov         dword ptr [esi+8],ebp
  1000D30C: mov         edx,dword ptr [eax+8]
  1000D30F: mov         byte ptr [edx+0Ch],1
  1000D313: mov         edx,dword ptr [ecx]
  1000D315: mov         byte ptr [ecx+0Ch],bl
  1000D318: mov         edi,dword ptr [edx+4]
  1000D31B: mov         ebp,dword ptr [esi+8]
  1000D31E: mov         dword ptr [ecx],edi
  1000D320: mov         edi,dword ptr [edx+4]
  1000D323: cmp         edi,ebx
  1000D325: je          1000D32A
  1000D327: mov         dword ptr [edi+8],ecx
  1000D32A: cmp         ecx,ebp
  1000D32C: mov         edi,dword ptr [ecx+8]
  1000D32F: mov         dword ptr [edx+8],edi
  1000D332: jne         1000D338
  1000D334: mov         ebp,edx
  1000D336: jmp         1000D347
  1000D338: mov         edi,dword ptr [ecx+8]
  1000D33B: cmp         ecx,dword ptr [edi+4]
  1000D33E: jne         1000D345
  1000D340: mov         dword ptr [edi+4],edx
  1000D343: jmp         1000D347
  1000D345: mov         dword ptr [edi],edx
  1000D347: mov         dword ptr [edx+4],ecx
  1000D34A: mov         dword ptr [ecx+8],edx
  1000D34D: mov         dword ptr [esi+8],ebp
  1000D350: cmp         eax,dword ptr [esi+8]
  1000D353: jne         1000D1F0
  1000D359: mov         eax,dword ptr [esi+8]
  1000D35C: pop         edi
  1000D35D: pop         ebp
  1000D35E: pop         esi
  1000D35F: mov         byte ptr [eax+0Ch],1
  1000D363: pop         ebx
  1000D364: ret
  1000D365: mov         ecx,dword ptr [esi+8]
  1000D368: pop         esi
  1000D369: mov         byte ptr [ecx+0Ch],1
  1000D36D: pop         ebx
  1000D36E: ret
  1000D36F: mov         edx,dword ptr [esi+8]
  1000D372: pop         edi
  1000D373: pop         ebp
  1000D374: pop         esi
  1000D375: mov         byte ptr [edx+0Ch],1
  1000D379: pop         ebx
  1000D37A: ret
  1000D37B: jmp         1000D392
  1000D380: jmp         dword ptr ds:[1000E090h]
  1000D386: jmp         dword ptr ds:[1000E094h]
  1000D38C: jmp         dword ptr ds:[1000E098h]
  1000D392: jmp         dword ptr ds:[1000E09Ch]
  1000D398: jmp         dword ptr ds:[1000E0A0h]
  1000D39E: jmp         dword ptr ds:[1000E0A4h]
  1000D3A4: jmp         dword ptr ds:[1000E0A8h]
  1000D3AA: jmp         dword ptr ds:[1000E0ACh]
  1000D3B0: jmp         dword ptr ds:[1000E0B0h]
  1000D3B6: jmp         dword ptr ds:[1000E0B4h]
  1000D3BC: jmp         dword ptr ds:[1000E0B8h]
  1000D3C2: jmp         dword ptr ds:[1000E0BCh]
  1000D3C8: jmp         dword ptr ds:[1000E0C0h]
  1000D3CE: jmp         dword ptr ds:[1000E0C4h]
  1000D3D4: jmp         dword ptr ds:[1000E0E8h]
  1000D3DA: jmp         dword ptr ds:[1000E0E4h]
  1000D3E0: jmp         dword ptr ds:[1000E0E0h]
  1000D3E6: jmp         dword ptr ds:[1000E0D4h]
  1000D3EC: jmp         dword ptr ds:[1000E0D8h]
  1000D3F2: jmp         dword ptr ds:[1000E0DCh]
  1000D3F8: jmp         dword ptr ds:[1000E0CCh]
  1000D3FE: int         3
  1000D3FF: int         3
  1000D400: add         esi,dword ptr [eax]
  1000D402: add         dword ptr [eax],eax
  1000D404: or          eax,dword ptr [eax]
  1000D406: add         byte ptr [eax],al
  1000D408: add         byte ptr [eax],al
  1000D40A: add         byte ptr [eax],al
  1000D40C: sub         byte ptr [edx],cl
  1000D40E: add         byte ptr [eax],al
  1000D410: push        es
  1000D411: add         byte ptr [eax+eax],0
  1000D415: add         al,2Ah
  1000D417: int         3
  1000D418: add         esi,dword ptr [eax]
  1000D41A: add         al,byte ptr [eax]
  1000D41C: pop         ss
  1000D41D: add         byte ptr [eax],al
  1000D41F: add         byte ptr [eax],al
  1000D421: add         byte ptr [eax],al
  1000D423: add         byte ptr [ebx],ah
  1000D425: add         byte ptr [eax],al
  1000D427: add         byte ptr [eax],al
  1000D429: add         byte ptr [eax],al
  1000D42B: lock aas
  1000D42D: jle         1000D3B8
  1000D42F: add         byte ptr [eax],al
  1000D431: add         al,6Ch
  1000D433: pop         ebx
  1000D434: imul        eax,dword ptr [eax+04000085h],2Ah
  1000D43B: int         3
  1000D43C: add         esi,dword ptr [eax]
  1000D43E: add         dword ptr [eax],eax
  1000D440: pop         es
  1000D441: add         byte ptr [eax],al
  1000D443: add         byte ptr [eax],al
  1000D445: add         byte ptr [eax],al
  1000D447: add         byte ptr [esi],dl
  1000D449: cmp         byte ptr [edx],1
  1000D44C: add         byte ptr [edx+ebp],al
  1000D44F: int         3
  1000D450: add         esi,dword ptr [eax]
  1000D452: add         dword ptr [eax],eax
  1000D454: pop         es
  1000D455: add         byte ptr [eax],al
  1000D457: add         byte ptr [eax],al
  1000D459: add         byte ptr [eax],al
  1000D45B: add         byte ptr [esi],dl
  1000D45D: xor         byte ptr [eax],1
  1000D460: add         byte ptr [edx+ebp],al
  1000D463: int         3
  1000D464: add         esi,dword ptr [eax]
  1000D466: add         dword ptr [eax],eax
  1000D468: pop         es
  1000D469: add         byte ptr [eax],al
  1000D46B: add         byte ptr [eax],al
  1000D46D: add         byte ptr [eax],al
  1000D46F: add         byte ptr [esi],dl
  1000D471: xor         byte ptr ds:[2A040001h],0CCh
  1000D478: add         esi,dword ptr [eax]
  1000D47A: add         dword ptr [eax],eax
  1000D47C: pop         es
  1000D47D: add         byte ptr [eax],al
  1000D47F: add         byte ptr [eax],al
  1000D481: add         byte ptr [eax],al
  1000D483: add         byte ptr [esi],dl
  1000D485: cmp         byte ptr ds:[2A040001h],0CCh
  1000D48C: add         esi,dword ptr [eax]
  1000D48E: add         dword ptr [eax],eax
  1000D490: pop         es
  1000D491: add         byte ptr [eax],al
  1000D493: add         byte ptr [eax],al
  1000D495: add         byte ptr [eax],al
  1000D497: add         byte ptr [esi],dl
  1000D499: cmp         byte ptr [eax],1
  1000D49C: add         byte ptr [edx+ebp],al
  1000D49F: int         3
  1000D4A0: add         esi,dword ptr [eax]
  1000D4A2: add         dword ptr [eax],eax
  1000D4A4: pop         es
  1000D4A5: add         byte ptr [eax],al
  1000D4A7: add         byte ptr [eax],al
  1000D4A9: add         byte ptr [eax],al
  1000D4AB: add         byte ptr [esi],dl
  1000D4AD: add         byte ptr [eax+1],0
  1000D4B1: add         al,2Ah
  1000D4B3: int         3
  1000D4B4: add         esi,dword ptr [eax]
  1000D4B6: add         dword ptr [eax],eax
  1000D4B8: pop         es
  1000D4B9: add         byte ptr [eax],al
  1000D4BB: add         byte ptr [eax],al
  1000D4BD: add         byte ptr [eax],al
  1000D4BF: add         byte ptr [esi],dl
  1000D4C1: xor         byte ptr [ebx],1
  1000D4C4: add         byte ptr [edx+ebp],al
  1000D4C7: int         3
  1000D4C8: add         esi,dword ptr [eax]
  1000D4CA: add         dword ptr [eax],eax
  1000D4CC: or          eax,0
  1000D4D1: add         byte ptr [eax],al
  1000D4D3: add         dh,bh
  1000D4D5: push        es
  1000D4D6: or          al,byte ptr [ecx]
  1000D4D8: add         byte ptr [esi],al
  1000D4DA: sub         byte ptr [ebx],dl
  1000D4DC: add         dword ptr [eax],eax
  1000D4DE: push        es
  1000D4DF: sub         cl,ah
  1000D4E2: int         3
  1000D4E3: int         3
  1000D4E4: add         esi,dword ptr [eax]
  1000D4E6: add         dword ptr [eax],eax
  1000D4E8: or          eax,dword ptr [eax]
  1000D4EA: add         byte ptr [eax],al
  1000D4EC: add         byte ptr [eax],al
  1000D4EE: add         byte ptr [eax],al
  1000D4F0: jg          1000D53F
  1000D4F2: add         dword ptr [eax],eax
  1000D4F4: add         al,28h
  1000D4F6: adc         eax,2A060001h

  Summary

        2000 .data
       16000 .rdata
        1000 .reloc
        1000 .rsrc
        D000 .text
