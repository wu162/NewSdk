PC TextureCompiler source build

Install this package into a matching SDK copy using:
./InstallTextureCompiler.ps1 -PackageDirectory . -SdkDirectory <SDK>
The installer verifies every runtime fingerprint, saves prior file states and
prints a backup directory. To restore:
./RestoreTextureCompiler.ps1 -ReceiptPath <backup>/installation.json
Restore refuses to overwrite files edited after installation.

The five Recovered.*.dll files go beside the existing SDK/tools host. The SDK's
Core/Utility and other compiler plugins remain. The three Texture roots use:
Recovered.Compiler.Texture.Plugin, Recovered.BinaryAssetBuilder.TextureCompiler

The CLR4 host startup must set useLegacyV2RuntimeActivationPolicy="true".
Use Win32 only. Default DXT1 and opaque DXT1A blocks remain explicitly rejected;
see recovery/RESUME.md at the manifest's sourceCommit for the accepted scope.
The colour/alpha DLLs serve the separately exposed low-level recovered APIs.
The complete production DXT route uses PublicS3; JPEG uses the pinned IJG6b DLL.

This bundle includes original upstream notices, provenance and adapted PublicS3
source. It does not include the original TextureCompiler, Core or Utility DLLs.
manifest.json records the exact source and runtime fingerprints; a successful
build alone is not component/SDK acceptance or production installation.
